"""COLORMAP: generation from the palette, hand overrides, diagnostics and
"create fade colours".

Rows 0..31 are light levels (0 = full bright), row 32 is invulnerability,
row 33 is all dark. Classic generation matches Freedoom's generator (and
id's dcolors.c): blend each colour toward the fade target by (32-row)/32
and take the nearest palette colour by plain RGB distance.

Everything here is keyed by palette slot index; CmapState.remap() keeps
hand edits attached to their colours when the palette is reordered or
culled.
"""

import bisect
import math
import os
import struct

from .cleanpal_lib_colour import hex_of, oklab, oklab_to_rgbf, parse_colour
from .cleanpal_lib_constants import ENTRIES

ROWS = 34
LIGHT_ROWS = 32
INVUL_ROW = 32
DARK_ROW = 33

CMAP_METHODS = ["Perceptual (OKLab)", "Classic (RGB, like id / Freedoom)"]
INVUL_MODES = ["Inverse grey (Doom)", "From loaded COLORMAP", "None (same as row 0)"]
CMAP_EXPORTS = [("COLORMAP lump (.lmp)", ".lmp"), ("COLORMAP image (256x34 .png)", ".png")]

DIAG_TYPES = {
    "crush": ("Early crush", "#ff3030"),
    "drift": ("Hue drift", "#ff9a00"),
    "jump": ("Big jump", "#ffe100"),
    "miss": ("Far from ideal", "#d050ff"),
}


def default_cmap_settings():
    return {"cmap_method": CMAP_METHODS[0], "cmap_curve": 1.0, "cmap_target": [0, 0, 0],
            "cmap_smooth": True, "cmap_invul": INVUL_MODES[0]}


def clean_cmap_settings(src, strict=False):
    out = {}

    def bad(k):
        if strict:
            raise ValueError("Bad value for '%s'." % k)

    if "cmap_method" in src:
        if src["cmap_method"] in CMAP_METHODS:
            out["cmap_method"] = src["cmap_method"]
        else:
            bad("cmap_method")
    if "cmap_invul" in src:
        if src["cmap_invul"] in INVUL_MODES:
            out["cmap_invul"] = src["cmap_invul"]
        else:
            bad("cmap_invul")
    if "cmap_curve" in src:
        v = src["cmap_curve"]
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out["cmap_curve"] = float(min(max(v, 0.25), 4.0))
        else:
            bad("cmap_curve")
    if "cmap_smooth" in src:
        if isinstance(src["cmap_smooth"], bool):
            out["cmap_smooth"] = src["cmap_smooth"]
        else:
            bad("cmap_smooth")
    if "cmap_target" in src:
        v = src["cmap_target"]
        if isinstance(v, (list, tuple)) and len(v) == 3 and \
                all(isinstance(x, int) and 0 <= x <= 255 for x in v):
            out["cmap_target"] = list(v)
        else:
            bad("cmap_target")
    return out


# ============================================================ state
class CmapState:
    """Hand edits to the COLORMAP, keyed by palette slot."""

    def __init__(self):
        self.overrides = {}      # (row, src) -> target slot
        self.fullbright = set()  # slots that never darken
        self.limits = {}         # src -> frozenset of allowed target slots
        self.curves = {}         # src -> fade curve for that colour

    def copy(self):
        c = CmapState()
        c.overrides = dict(self.overrides)
        c.fullbright = set(self.fullbright)
        c.limits = dict(self.limits)
        c.curves = dict(self.curves)
        return c

    def __eq__(self, other):
        return isinstance(other, CmapState) and self.to_json() == other.to_json()

    def empty(self):
        return not (self.overrides or self.fullbright or self.limits or self.curves)

    def permute(self, newpos):
        """Palette reordered: newpos[old] = new slot."""
        self.overrides = {(r, newpos[s]): newpos[t] for (r, s), t in self.overrides.items()}
        self.fullbright = {newpos[i] for i in self.fullbright}
        self.limits = {newpos[s]: frozenset(newpos[t] for t in v)
                       for s, v in self.limits.items()}
        self.curves = {newpos[s]: v for s, v in self.curves.items()}

    def remap(self, mapping, owner=None):
        """Palette culled / packed: mapping[old] = new slot or None.
        Edits pointing at a removed colour follow its kept owner (exact /
        similar merge) when there is one, else they are dropped.
        Returns the number of hand-set cells that were dropped."""
        owner = owner or {}

        def tgt(t):
            n = mapping.get(t)
            if n is None and t in owner:
                n = mapping.get(owner[t])
            return n

        dropped = 0
        ov = {}
        for (r, s), t in self.overrides.items():
            ns, nt = mapping.get(s), tgt(t)
            if ns is None:
                continue              # the colour itself is gone: its column goes
            if nt is None:
                dropped += 1
                continue
            ov[(r, ns)] = nt
        self.overrides = ov
        self.fullbright = {mapping[i] for i in self.fullbright if mapping.get(i) is not None}
        lim = {}
        for s, v in self.limits.items():
            ns = mapping.get(s)
            if ns is None:
                continue
            nv = frozenset(x for x in (tgt(t) for t in v) if x is not None)
            if nv:
                lim[ns] = nv
        self.limits = lim
        self.curves = {mapping[s]: v for s, v in self.curves.items()
                       if mapping.get(s) is not None}
        return dropped

    def invalidate(self, slots):
        """These slots got new colours: their own fades go back to auto and
        hand edits pointing at them are dropped. Returns how many hand-set
        cells of OTHER colours were dropped."""
        slots = set(slots)
        dropped = sum(1 for (r, s), t in self.overrides.items()
                      if s not in slots and t in slots)
        self.overrides = {(r, s): t for (r, s), t in self.overrides.items()
                          if s not in slots and t not in slots}
        self.fullbright -= slots
        for s in slots:
            self.limits.pop(s, None)
            self.curves.pop(s, None)
        lim = {}
        for s, v in self.limits.items():
            nv = frozenset(t for t in v if t not in slots)
            if nv:
                lim[s] = nv
        self.limits = lim
        return dropped

    def clear_rows(self, slots):
        slots = set(slots)
        self.overrides = {k: t for k, t in self.overrides.items() if k[1] not in slots}

    def to_json(self):
        return {"overrides": sorted([r, s, t] for (r, s), t in self.overrides.items()),
                "fullbright": sorted(self.fullbright),
                "limits": {str(s): sorted(v) for s, v in sorted(self.limits.items())},
                "curves": {str(s): v for s, v in sorted(self.curves.items())}}

    @classmethod
    def from_json(cls, d):
        c = cls()
        if not isinstance(d, dict):
            return c

        def ok(i, hi=ENTRIES):
            return isinstance(i, int) and not isinstance(i, bool) and 0 <= i < hi

        for item in d.get("overrides") or []:
            if isinstance(item, list) and len(item) == 3 and ok(item[0], ROWS - 1) \
                    and ok(item[1]) and ok(item[2]):
                c.overrides[(item[0], item[1])] = item[2]
        c.fullbright = {i for i in (d.get("fullbright") or []) if ok(i)}
        for k, v in (d.get("limits") or {}).items():
            try:
                s = int(k)
            except (TypeError, ValueError):
                continue
            if ok(s) and isinstance(v, list):
                vv = frozenset(i for i in v if ok(i))
                if vv:
                    c.limits[s] = vv
        for k, v in (d.get("curves") or {}).items():
            try:
                s = int(k)
            except (TypeError, ValueError):
                continue
            if ok(s) and isinstance(v, (int, float)) and not isinstance(v, bool):
                c.curves[s] = float(min(max(v, 0.25), 4.0))
        return c


# ============================================================ nearest search
class Matcher:
    """Nearest palette slot for a colour, in RGB or OKLab, restricted to a
    pool of slots. Sorted-axis search with pruning plus a result cache."""

    def __init__(self, rgbs, pool, perceptual):
        self.perceptual = perceptual
        self.rgbs = rgbs
        self.pool = sorted(pool)
        self._labs = {}
        self.items = []                  # (key, coords, slot), sorted by key
        for i in self.pool:
            co = self.coords(rgbs[i])
            self.items.append((self._key(co), co, i))
        self.items.sort()
        self.keys = [it[0] for it in self.items]
        self.cache = {}

    def coords(self, rgb):
        if self.perceptual:
            k = tuple(int(round(v)) for v in rgb)
            v = self._labs.get(k)
            if v is None:
                v = self._labs[k] = oklab(k)
            return v
        return tuple(float(x) for x in rgb)

    def _key(self, co):
        if self.perceptual:
            return co[0]
        return (co[0] + co[1] + co[2]) / math.sqrt(3.0)

    def dist(self, rgb_a, rgb_b):
        a, b = self.coords(rgb_a), self.coords(rgb_b)
        return math.sqrt(sum((a[k] - b[k]) ** 2 for k in range(3)))

    def nearest(self, rgb, allowed=None):
        if allowed is not None:
            co = self.coords(rgb)
            best, bi = None, None
            for i in sorted(allowed):
                if self.rgbs[i] is None:
                    continue
                c2 = self.coords(self.rgbs[i])
                d = sum((co[k] - c2[k]) ** 2 for k in range(3))
                if best is None or d < best:
                    best, bi = d, i
            return bi
        key = tuple(round(v, 3) for v in rgb)
        hit = self.cache.get(key)
        if hit is not None:
            return hit
        if not self.items:
            return None
        co = self.coords(rgb)
        q = self._key(co)
        pos = bisect.bisect_left(self.keys, q)
        best, bi = None, None
        lo, hi = pos - 1, pos
        n = len(self.items)
        while lo >= 0 or hi < n:
            dl = q - self.keys[lo] if lo >= 0 else None
            dh = self.keys[hi] - q if hi < n else None
            if dh is None or (dl is not None and dl <= dh):
                k, d1 = lo, dl
                lo -= 1
            else:
                k, d1 = hi, dh
                hi += 1
            lim = None if best is None else best + 1e-7      # float slack: keep ties
            if lim is not None and d1 * d1 > lim:
                if (lo < 0 or (q - self.keys[lo]) ** 2 > lim) and \
                        (hi >= n or (self.keys[hi] - q) ** 2 > lim):
                    break
                continue
            c2 = self.items[k][1]
            d = (co[0] - c2[0]) ** 2 + (co[1] - c2[1]) ** 2 + (co[2] - c2[2]) ** 2
            slot = self.items[k][2]
            if best is None or d < best - 1e-9 or (abs(d - best) <= 1e-9 and slot < bi):
                best, bi = d, slot
        self.cache[key] = bi
        return bi


# ============================================================ generation
def _blend(a, b, f):
    """f = 1 -> a, f = 0 -> b."""
    return tuple(b[k] + (a[k] - b[k]) * f for k in range(3))


def ideal_path(src, row, curve, target, anchors=None):
    """Ideal (float RGB) colour of `src` at a light row.
    anchors: sorted [(row, rgb)] of hand-set steps for smooth auto-fill."""
    if not anchors:
        f = ((LIGHT_ROWS - row) / float(LIGHT_ROWS)) ** curve
        return _blend(src, target, f)
    pts = [(0, tuple(src))] + [a for a in anchors if a[0] > 0] + [(LIGHT_ROWS, tuple(target))]
    if anchors and anchors[0][0] == 0:
        pts[0] = (0, tuple(anchors[0][1]))
    for (ra, ca), (rb, cb) in zip(pts, pts[1:]):
        if ra <= row <= rb:
            u = 0.0 if rb == ra else (row - ra) / float(rb - ra)
            f = (1.0 - u) ** curve
            return _blend(ca, cb, f)
    return tuple(target)


class CmapResult:
    def __init__(self):
        self.rows = [[0] * ENTRIES for _ in range(ROWS)]
        self.ideal = {}           # (row, src) -> float rgb (rows 1..32)
        self.source = {}          # (row, src) -> "auto" / "override" / "bright" / "bad"
        self.matcher = None
        self.pool = []


def generate(rgbs, deleted, settings, state, loaded=None, locks=None):
    """Build the 34 x 256 COLORMAP for the working palette.
    loaded: {"rows", "pal"} of a loaded COLORMAP (for the invul option).
    locks: {src: (31 target slots for rows 1-31)} - frozen fades, applied
    last so nothing else can change them. Row 0 is always the colour itself."""
    perceptual = settings.get("cmap_method", CMAP_METHODS[0]) == CMAP_METHODS[0]
    curve = float(settings.get("cmap_curve", 1.0))
    target = tuple(settings.get("cmap_target", (0, 0, 0)))
    smooth = bool(settings.get("cmap_smooth", True))
    invul = settings.get("cmap_invul", INVUL_MODES[0])
    deleted = deleted or set()
    pool = [i for i, c in enumerate(rgbs) if c is not None and i not in deleted]
    res = CmapResult()
    res.pool = pool
    m = Matcher(rgbs, pool, perceptual)
    res.matcher = m
    if not pool:
        return res
    dark = m.nearest(target)
    ov = state.overrides
    loaded_lookup = None
    if invul == INVUL_MODES[1] and loaded and len(loaded.get("rows", [])) > INVUL_ROW:
        loaded_lookup = {}
        for j, c in enumerate(loaded["pal"]):
            if c is not None:
                loaded_lookup.setdefault(tuple(c), j)

    for s in range(ENTRIES):
        src = rgbs[s]
        if src is None:
            for r in range(ROWS):
                res.rows[r][s] = ov.get((r, s), dark) if r < DARK_ROW else dark
            continue
        allowed = state.limits.get(s)
        if allowed is not None:
            allowed = [t for t in allowed if t in pool or t == s] or None
        c_curve = state.curves.get(s, curve)
        anchors = None
        if smooth:
            hs = sorted((r, t) for (r, ss), t in ov.items() if ss == s and r < LIGHT_ROWS
                        and t < ENTRIES and rgbs[t] is not None and t not in deleted)
            if hs:
                anchors = [(r, rgbs[t]) for r, t in hs]
        bright = s in state.fullbright
        for r in range(LIGHT_ROWS):
            t = ov.get((r, s)) if r else None          # row 0 is fixed: the colour
            if t is not None and t < ENTRIES and rgbs[t] is not None and t not in deleted:
                res.rows[r][s] = t
                res.source[(r, s)] = "override"
                if r:
                    res.ideal[(r, s)] = ideal_path(src, r, c_curve, target, anchors)
                continue
            if t is not None:
                res.source[(r, s)] = "bad"       # hand-set target no longer usable
            if bright or r == 0:
                res.rows[r][s] = m.nearest(src)      # lowest slot holding this colour
                res.source.setdefault((r, s), "bright" if bright and r else "auto")
                continue
            ideal = ideal_path(src, r, c_curve, target, anchors)
            res.ideal[(r, s)] = ideal
            res.rows[r][s] = m.nearest(ideal, allowed)
            res.source.setdefault((r, s), "auto")
        # invulnerability
        t = ov.get((INVUL_ROW, s))
        if t is not None and t < ENTRIES and rgbs[t] is not None and t not in deleted:
            res.rows[INVUL_ROW][s] = t
            res.source[(INVUL_ROW, s)] = "override"
        else:
            if invul == INVUL_MODES[2]:
                res.rows[INVUL_ROW][s] = res.rows[0][s]
            else:
                want = None
                if loaded_lookup is not None:
                    j = loaded_lookup.get(tuple(src))
                    if j is not None:
                        tj = loaded["rows"][INVUL_ROW][j]
                        if 0 <= tj < len(loaded["pal"]) and loaded["pal"][tj] is not None:
                            want = loaded["pal"][tj]
                if want is None:
                    g = round(src[0] * 0.2126 + src[1] * 0.7152 + src[2] * 0.0722)
                    want = (255 - g,) * 3
                res.ideal[(INVUL_ROW, s)] = tuple(float(v) for v in want)
                res.rows[INVUL_ROW][s] = m.nearest(want)
            res.source[(INVUL_ROW, s)] = "auto"
        res.rows[DARK_ROW][s] = dark
    for s, vals in (locks or {}).items():
        if not 0 <= s < ENTRIES or rgbs[s] is None:
            continue
        for r, t in enumerate(vals, 1):
            if r < LIGHT_ROWS and 0 <= t < ENTRIES and rgbs[t] is not None \
                    and t not in deleted:
                res.rows[r][s] = t
                res.source[(r, s)] = "locked"
    return res


# ============================================================ fade locks
# {src slot: tuple of 31 target slots (rows 1-31)} - not part of history.
def lock_values(res, s):
    return tuple(res.rows[r][s] for r in range(1, LIGHT_ROWS))


def locks_permute(locks, newpos):
    """Palette reordered: newpos[old] = new slot. A locked colour that
    leaves the palette (below the red line) loses its lock."""
    out = {}
    for s, vals in locks.items():
        ns = newpos[s] if s < len(newpos) else s
        if ns >= ENTRIES:
            continue
        out[ns] = tuple(newpos[t] if t < len(newpos) and newpos[t] < ENTRIES else t
                        for t in vals)
    return out


def locks_remap(locks, mapping, owner=None):
    """Palette culled / packed (mapping[old] = new slot or None). A step
    pointing at a removed colour follows its kept owner; a culled locked
    colour loses its lock. Steps with no target left keep their old slot
    (they show the generated colour until it holds a colour again)."""
    owner = owner or {}
    out = {}
    for s, vals in locks.items():
        ns = mapping.get(s)
        if ns is None:
            continue
        nv = []
        for t in vals:
            n = mapping.get(t)
            if n is None and t in owner:
                n = mapping.get(owner[t])
            nv.append(t if n is None else n)
        out[ns] = tuple(nv)
    return out


def locks_to_json(locks):
    return {str(s): list(v) for s, v in sorted(locks.items())}


def locks_from_json(d):
    out = {}
    if not isinstance(d, dict):
        return out
    for k, v in d.items():
        try:
            s = int(k)
        except (TypeError, ValueError):
            continue
        if 0 <= s < ENTRIES and isinstance(v, list) and len(v) == LIGHT_ROWS - 1 and \
                all(isinstance(t, int) and not isinstance(t, bool) and 0 <= t < ENTRIES
                    for t in v):
            out[s] = tuple(v)
    return out


# ============================================================ diagnostics
def _lch(rgb):
    L, a, b = oklab(tuple(int(round(v)) for v in rgb))
    return L, math.hypot(a, b), math.degrees(math.atan2(b, a)) % 360.0


def diagnose(rgbs, res, state):
    """Flag poor fade steps: {(row, src): type}. Types: crush, drift, jump, miss."""
    flags = {}
    for s, src in enumerate(rgbs):
        if src is None or s in state.fullbright:
            continue
        sL, sC, sh = _lch(src)
        prevL = sL
        prev_ideal_L = sL
        for r in range(1, LIGHT_ROWS):
            t = res.rows[r][s]
            act = rgbs[t]
            ideal = res.ideal.get((r, s))
            if act is None or ideal is None:
                continue
            aL, aC, ah = _lch(act)
            iL, iC, ih = _lch(ideal)
            f = None
            if aL < 0.07 and iL > 0.22:
                f = "crush"
            elif sC > 0.05 and aC > 0.03 and iC > 0.02 and \
                    abs((ah - ih + 180.0) % 360.0 - 180.0) > 40.0:
                f = "drift"
            elif abs(aL - prevL) > max(0.09, 3.0 * abs(iL - prev_ideal_L)):
                f = "jump"
            else:
                d = math.sqrt(sum((x - y) ** 2 for x, y in
                                  zip(oklab(act), oklab(tuple(int(round(v)) for v in ideal)))))
                if d > 0.09:
                    f = "miss"
            if f:
                flags[(r, s)] = f
            prevL, prev_ideal_L = aL, iL
    return flags


# ============================================================ create fade colours
def fade_misses(rgbs, res, scope, state, weights=None):
    """Light-row steps whose fade lands far from its ideal colour.
    Returns [(ideal_lab, ideal_rgb, current_dist, weight, src, row)]."""
    out = []
    for s in scope:
        src = rgbs[s]
        if src is None or s in state.fullbright:
            continue
        w0 = 1.0 if not weights else max(weights.get(s, 0), 0) ** 0.5 + 0.05
        for r in range(1, LIGHT_ROWS):
            if res.source.get((r, s)) == "override":
                continue
            ideal = res.ideal.get((r, s))
            t = res.rows[r][s]
            if ideal is None or rgbs[t] is None:
                continue
            il = oklab(tuple(int(round(v)) for v in ideal))
            al = oklab(rgbs[t])
            d = math.sqrt(sum((x - y) ** 2 for x, y in zip(il, al)))
            if d > 0.015:
                # darker steps are seen less: weight by the ideal's lightness
                out.append((il, tuple(int(round(v)) for v in ideal), d,
                            w0 * (0.35 + il[0]), s, r))
    return out


def propose_fade_colours(rgbs, res, scope, state, budget, weights=None):
    """Greedy: the new colours that most reduce weighted fade error.
    Returns (proposals, before, after); each proposal is a dict with rgb,
    gain, serves (colour count), rows (min, max)."""
    misses = fade_misses(rgbs, res, scope, state, weights)
    return greedy_new_colours(misses, budget)


def greedy_new_colours(misses, budget):
    """misses: [(ideal_lab, ideal_rgb, current_dist, weight, src, row)].
    Picks up to `budget` new colours (from the ideal colours) that most
    reduce the weighted distance. Returns (proposals, before, after)."""
    if not misses or budget <= 0:
        tot = sum(m[2] * m[3] for m in misses)
        return [], tot, tot
    cur = [m[2] for m in misses]
    before = sum(cur[k] * misses[k][3] for k in range(len(misses)))
    cell = 0.06

    def bucket(lab):
        return (int(lab[0] // cell), int(lab[1] // cell), int(lab[2] // cell))

    grid = {}
    for k, m in enumerate(misses):
        grid.setdefault(bucket(m[0]), []).append(k)
    cands = {}
    for m in misses:                              # candidate = a miss's ideal colour
        cands.setdefault(tuple(int(v) for v in m[1]), m[0])
    cands = list(cands.items())
    if len(cands) > 500:                          # thin very large sets
        step = len(cands) / 500.0
        cands = [cands[int(i * step)] for i in range(500)]
    hood = []
    for rgb, lab in cands:
        b = bucket(lab)
        lst = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    for k in grid.get((b[0] + dx, b[1] + dy, b[2] + dz), ()):
                        m = misses[k][0]
                        d = math.sqrt((lab[0] - m[0]) ** 2 + (lab[1] - m[1]) ** 2
                                      + (lab[2] - m[2]) ** 2)
                        if d < misses[k][2]:
                            lst.append((k, d))
        hood.append(lst)
    props = []
    used = set()
    for _ in range(int(budget)):
        best = None
        for ci, lst in enumerate(hood):
            if ci in used:
                continue
            gain = 0.0
            for k, d in lst:
                if d < cur[k]:
                    gain += (cur[k] - d) * misses[k][3]
            if best is None or gain > best[0]:
                best = (gain, ci)
        if best is None or best[0] <= 1e-6:
            break
        gain, ci = best
        used.add(ci)
        rgb, lab = cands[ci]
        srcs, rows = set(), []
        for k, d in hood[ci]:
            if d < cur[k]:
                cur[k] = d
                srcs.add(misses[k][4])
                rows.append(misses[k][5])
        props.append({"rgb": tuple(rgb), "gain": gain, "serves": len(srcs),
                      "srcs": sorted(srcs), "rows": (min(rows), max(rows)) if rows else (0, 0)})
    after = sum(cur[k] * misses[k][3] for k in range(len(misses)))
    return props, before, after


# ============================================================ fade ramps (Ramp tool on fades)
def _lch_of(rgb):
    L, a, b = oklab(tuple(int(round(min(max(v, 0), 255))) for v in rgb))
    return L, math.hypot(a, b), math.atan2(b, a)


def relative_colour(ref_anchor, node_rgb, anchor):
    """The node colour, re-expressed for another strip's anchor (Relative):
    same lightness ratio, chroma ratio and hue turn as node vs ref_anchor."""
    rL, rC, rh = _lch_of(ref_anchor)
    nL, nC, nh = _lch_of(node_rgb)
    aL, aC, ah = _lch_of(anchor)
    L = min(1.0, aL * (nL / rL)) if rL > 1e-3 else nL
    grey = 0.02
    if rC >= grey:
        C = aC * (nC / rC)
    else:
        C = aC + nC                       # grey reference: add the node's colourfulness
    if rC >= grey and aC >= grey:
        h = ah + (nh - rh)
    elif aC < grey:
        h = nh                            # grey anchor: take the node's hue
    else:
        h = ah
    return oklab_to_rgbf(L, C * math.cos(h), C * math.sin(h))


def fade_ramp_rows(state, ref_anchor, strips, anchors, matcher, limits=None):
    """Snapped fades for every strip.
    strips: {src: start_row}; anchors: {src: rgb before the range (or the
    colour itself for start 0)}. Returns {src: [(row, ideal_rgb, slot, dist)]}."""
    from .cleanpal_lib_ramps import ramp_colour_at

    out = {}
    for s, r0 in strips.items():
        anc = tuple(anchors[s])
        st = {"space": state["space"], "ease": state["ease"],
              "strength": state["strength"], "ease_scope": state["ease_scope"],
              "nodes": []}
        for k, n in enumerate(state["nodes"]):
            rgb = anc if k == 0 else relative_colour(ref_anchor, n["rgb"], anc)
            st["nodes"].append({"pos": n["pos"], "rgb": [min(max(v, 0.0), 255.0)
                                                         for v in rgb]})
        a = r0 - 1 if r0 > 0 else 0
        span = float(LIGHT_ROWS - 1 - a) or 1.0
        allowed = (limits or {}).get(s)
        rows = []
        for row in range(r0, LIGHT_ROWS):
            t = (row - a) / span
            ideal = ramp_colour_at(st, t)
            if row == 0:
                slot = s                  # full bright is always the colour itself
            else:
                slot = matcher.nearest(ideal, allowed)
            dist = 0.0
            if slot is not None and matcher.rgbs[slot] is not None:
                il = oklab(tuple(int(round(v)) for v in ideal))
                sl = oklab(matcher.rgbs[slot])
                dist = math.sqrt(sum((x - y) ** 2 for x, y in zip(il, sl)))
            rows.append((row, ideal, slot, dist))
        out[s] = rows
    return out


# ============================================================ bulk edit helpers
def fade_within(rgbs, slots, steps_per_level, order, past_end, dark_slot):
    """Overrides that make each selected colour fade down through the
    selection itself. Returns {(row, src): target}."""
    cols = [s for s in slots if rgbs[s] is not None]
    if order == "Lightness":
        cols.sort(key=lambda s: -oklab(rgbs[s])[0])
    n = len(cols)
    out = {}
    for k, s in enumerate(cols):
        for r in range(LIGHT_ROWS):
            pos = k + r * steps_per_level
            j = int(math.floor(pos + 1e-9))
            if j < n:
                out[(r, s)] = cols[j]
            elif past_end == "Black" and dark_slot is not None:
                out[(r, s)] = dark_slot
    return out


def fade_shape(rgbs, res, s):
    """A colour's fade as OKLab offsets from the colour itself (row -> delta)."""
    base = oklab(rgbs[s])
    shape = {}
    for r in range(LIGHT_ROWS):
        t = res.rows[r][s]
        if rgbs[t] is None:
            continue
        lt = oklab(rgbs[t])
        shape[r] = tuple(lt[k] - base[k] for k in range(3))
    return shape


def apply_shape(rgbs, matcher, shape, s):
    """Overrides for colour s following a copied fade shape."""
    base = oklab(rgbs[s])
    out = {}
    for r, d in shape.items():
        lab = (max(0.0, base[0] + d[0]), base[1] + d[1], base[2] + d[2])
        out[(r, s)] = matcher.nearest(oklab_to_rgbf(*lab))
    return out


# ============================================================ files
def read_wad_lump(path, name):
    with open(path, "rb") as fh:
        data = fh.read()
    if len(data) < 12 or data[0:4] not in (b"IWAD", b"PWAD"):
        raise ValueError("Not a valid WAD file (bad header).")
    numlumps, infotableofs = struct.unpack_from("<ii", data, 4)
    found = None
    for i in range(numlumps):
        off = infotableofs + i * 16
        if off + 16 > len(data):
            break
        filepos, size = struct.unpack_from("<ii", data, off)
        nm = data[off + 8: off + 16].split(b"\x00")[0].decode("ascii", "replace")
        if nm.upper() == name:
            found = data[filepos: filepos + size]     # last one wins, like the engine
    return found


def rows_from_bytes(raw):
    n = min(len(raw) // ENTRIES, ROWS)
    if n < LIGHT_ROWS:
        raise ValueError("COLORMAP data is too small (%d bytes)." % len(raw))
    return [list(raw[r * ENTRIES:(r + 1) * ENTRIES]) for r in range(n)]


def load_colormap(path, palette):
    """Rows from a WAD (COLORMAP lump), a raw .lmp, or a 256 x 32..34 image
    whose pixels are palette colours."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".wad":
        raw = read_wad_lump(path, "COLORMAP")
        if raw is None:
            raise ValueError("No COLORMAP lump in this WAD.")
        return rows_from_bytes(raw)
    if ext == ".png":
        from PIL import Image

        with Image.open(path) as im:
            im.load()
            img = im.convert("RGB")
        w, h = img.size
        if w != ENTRIES or not LIGHT_ROWS <= h <= ROWS:
            raise ValueError("A COLORMAP image must be 256 wide and 32-34 rows tall "
                             "(this one is %dx%d)." % (w, h))
        lookup = {}
        for i, c in enumerate(palette):
            if c is not None:
                lookup.setdefault(tuple(c), i)
        m = Matcher(palette, [i for i, c in enumerate(palette) if c is not None], False)
        px = img.load()
        rows = []
        for y in range(h):
            row = []
            for x in range(w):
                c = px[x, y]
                row.append(lookup[c] if c in lookup else m.nearest(c))
            rows.append(row)
        return rows
    with open(path, "rb") as fh:
        return rows_from_bytes(fh.read())


def write_colormap(path, rows, palette):
    if path.lower().endswith(".png"):
        from PIL import Image

        img = Image.new("RGB", (ENTRIES, len(rows)))
        px = img.load()
        for y, row in enumerate(rows):
            for x, t in enumerate(row):
                c = palette[t] if 0 <= t < len(palette) else None
                px[x, y] = tuple(c) if c is not None else (0, 255, 0)
        img.save(path)
    else:
        with open(path, "wb") as fh:
            fh.write(bytes(v & 0xFF for row in rows for v in row))


def import_overrides(rgbs, res, loaded):
    """Cells where a loaded COLORMAP differs from the current auto result,
    matched by colour. Returns {(row, src): target}."""
    lpal = loaded["pal"]
    first = {}
    for j, c in enumerate(lpal):
        if c is not None:
            first.setdefault(tuple(c), j)
    here = {}
    for i, c in enumerate(rgbs):
        if c is not None:
            here.setdefault(tuple(c), i)
    out = {}
    for s, c in enumerate(rgbs):
        if c is None:
            continue
        j = first.get(tuple(c))
        if j is None:
            continue
        for r in range(min(len(loaded["rows"]), LIGHT_ROWS)):   # light rows only
            tj = loaded["rows"][r][j]
            if not 0 <= tj < len(lpal) or lpal[tj] is None:
                continue
            tc = tuple(lpal[tj])
            t = here.get(tc)
            if t is None:
                t = res.matcher.nearest(tc)
            if t is not None and t != res.rows[r][s]:
                out[(r, s)] = t
    return out


def hexes(cols):
    return [hex_of(c) if c is not None else None for c in cols]


def from_hexes(lst):
    return [parse_colour(x) if isinstance(x, str) else None for x in lst]


# ============================================================ Generate tool
GEN_DEFAULTS = {"gen_to": "black", "gen_colour": [0, 0, 0], "gen_reach": 32,
                "gen_curve": 1.0, "gen_hue": 20, "gen_keep": 50, "gen_mono": True,
                "gen_new": False, "gen_new_max": 6, "gen_new_place": "insert",
                "gen_new_together": True, "gen_blend": "classic", "gen_hold": 30,
                "gen_dark": 0, "gen_match": "nearest", "gen_metric": "rgb",
                "gen_from": "all", "gen_fb": False, "gen_grad": [[31, [0, 0, 0]]],
                "gen_order": "light", "gen_pace": "curve", "gen_black": True}
GEN_PLACES = ("insert", "empty")
GEN_BLENDS = ("classic", "wheel", "straight")
# SLADE's generateColormaps(): row r = each channel * (32 - r) / 32 (+0.5),
# matched to the nearest palette colour by plain RGB distance.
SLADE_GEN = {"gen_to": "black", "gen_blend": "classic", "gen_match": "nearest",
             "gen_metric": "rgb", "gen_reach": 32, "gen_curve": 1.0, "gen_dark": 0}


def clean_gen_settings(src):
    out = dict(GEN_DEFAULTS)
    if not isinstance(src, dict):
        return out
    if src.get("gen_to") in ("black", "colour"):
        out["gen_to"] = src["gen_to"]
    c = src.get("gen_colour")
    if isinstance(c, (list, tuple)) and len(c) == 3 and \
            all(isinstance(v, int) and 0 <= v <= 255 for v in c):
        out["gen_colour"] = list(c)
    for k, lo, hi, typ in (("gen_reach", 1, 32, int), ("gen_curve", 0.25, 4.0, float),
                           ("gen_hue", 0, 60, int), ("gen_keep", 0, 100, int)):
        v = src.get(k)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out[k] = typ(min(max(v, lo), hi))
    for k in ("gen_mono", "gen_new", "gen_new_together"):
        if isinstance(src.get(k), bool):
            out[k] = src[k]
    v = src.get("gen_new_max")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        out["gen_new_max"] = int(min(max(v, 1), 32))
    if src.get("gen_new_place") in GEN_PLACES:
        out["gen_new_place"] = src["gen_new_place"]
    if src.get("gen_blend") in GEN_BLENDS:
        out["gen_blend"] = src["gen_blend"]
    for k, ok in (("gen_match", ("smart", "nearest", "ladder")),
                  ("gen_metric", ("oklab", "rgb")), ("gen_from", ("all", "selection")),
                  ("gen_order", ("light", "index")), ("gen_pace", ("curve", "even"))):
        if src.get(k) in ok:
            out[k] = src[k]
    for k in ("gen_fb", "gen_black"):
        if isinstance(src.get(k), bool):
            out[k] = src[k]
    g = clean_gradient(src.get("gen_grad"))
    if g:
        out["gen_grad"] = g
    if src.get("gen_to") == "gradient":
        out["gen_to"] = "gradient"
    elif src.get("gen_to") == "colour":           # 5.0.x "Colour" -> a one-node gradient
        out["gen_to"] = "gradient"
        if not g:
            out["gen_grad"] = [[out["gen_reach"], list(out["gen_colour"])]]
    for k in ("gen_hold", "gen_dark"):
        v = src.get(k)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out[k] = int(min(max(v, 0), 100))
    return out


def clean_gradient(v):
    """Fade gradient nodes [[row 1-31, [r, g, b]], ...], sorted, one per row."""
    out = {}
    if not isinstance(v, (list, tuple)):
        return []
    for n in v:
        if not isinstance(n, (list, tuple)) or len(n) != 2:
            continue
        r, c = n
        if isinstance(r, (int, float)) and not isinstance(r, bool) and \
                isinstance(c, (list, tuple)) and len(c) == 3 and \
                all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in c):
            row = int(min(max(round(r), 1), LIGHT_ROWS - 1))
            out[row] = [int(min(max(round(x), 0), 255)) for x in c]
    return [[r, out[r]] for r in sorted(out)]


def _classic_factor(L0, r, o):
    """Brightness left at row r (1 = full): (1 - r / reach) ^ curve-shaped,
    reach squeezed for dark colours. Defaults = SLADE / Doom: (32 - r) / 32."""
    dark = o["gen_dark"] / 100.0
    reach = max(1.0, o["gen_reach"] * (1.0 - dark + dark * min(max(L0, 0.0), 1.0)))
    f = min(r / reach, 1.0) ** o["gen_curve"]
    return 1.0 - f


def classic_rgb(src, r, o, L0=None):
    """Classic (SLADE) target: every channel scaled toward black, rounded."""
    if L0 is None:
        L0 = oklab(tuple(src))[0]
    k = _classic_factor(L0, r, o)
    return tuple(int(c * k + 0.5) for c in src)


def gen_stops(o):
    """[(row, rgb)] the fades head for: black at Reach, or the gradient."""
    if o["gen_to"] == "gradient" and o.get("gen_grad"):
        return [(r, tuple(c)) for r, c in o["gen_grad"]]
    return [(o["gen_reach"], (0, 0, 0))]


def _in_gamut(L, a, b):
    return all(-0.5 <= v <= 255.5 for v in oklab_to_rgbf(L, a, b))


def _gamut(L, a, b):
    """Pull colourfulness in (same lightness and hue) until the colour can be
    shown - clipping RGB instead would swing dark blues to purple."""
    if L <= 0.0:
        return (0.0, 0.0, 0.0)
    if L >= 1.0:
        return (1.0, 0.0, 0.0)
    if _in_gamut(L, a, b):
        return (L, a, b)
    lo, hi = 0.0, 1.0
    for _i in range(14):
        k = (lo + hi) / 2.0
        if _in_gamut(L, a * k, b * k):
            lo = k
        else:
            hi = k
    return (L, a * lo, b * lo)


def _soft_end(f):
    """Ease into the end colour (no hard corner where a fade arrives)."""
    if f <= 0.7:
        return f
    u = (f - 0.7) / 0.3
    return 0.7 + 0.3 * (-u ** 3 + u ** 2 + u)


def _gen_blend(A, B, f, fc, wheel):
    """OKLab colour f of the way from A to B (fc = colourfulness progress)."""
    if not wheel:
        return tuple(A[i] + (B[i] - A[i]) * f for i in range(3))
    CA, CB = math.hypot(A[1], A[2]), math.hypot(B[1], B[2])
    hA, hB = math.atan2(A[2], A[1]), math.atan2(B[2], B[1])
    if CA < 0.02:                     # grey start: take the end's hue
        hA = hB
    if CB < 0.02:                     # black / grey end: keep our own hue
        hB = hA
    dh = (hB - hA + math.pi) % (2.0 * math.pi) - math.pi
    L = A[0] + (B[0] - A[0]) * f
    C = CA + (CB - CA) * fc
    C = min(C, max(0.0, L) * 0.5 + CB * f)          # darks can't stay vivid
    h = hA + dh * f
    return (L, C * math.cos(h), C * math.sin(h))


def _fade_ideal(lab0, o):
    """Ideal OKLab colour per row 0-31 for a fade starting at lab0, plus the
    progress f (0 at row 0, 1 at the last stop) per row.

    Stops: black at Reach, or the Fade gradient's nodes (row, colour); the
    fade runs from the colour itself through each node in turn and holds
    the last. Dark colours finish sooner (gen_dark) squeezes the stop rows
    for dark colours. Darken curve shapes each stretch; the last stretch
    eases into its colour. Blend "wheel": lightness, colourfulness and hue
    separately (hue the short way round, black / grey keeps the hue);
    "straight": a straight OKLab line. gen_hold delays the loss of
    colourfulness. Every target is pulled into the displayable range."""
    L0 = lab0[0]
    if o["gen_blend"] == "classic":
        src = tuple(int(round(min(max(v, 0.0), 255.0))) for v in oklab_to_rgbf(*lab0))
        out, fs = [tuple(lab0)], [0.0]
        for r in range(1, LIGHT_ROWS):
            fs.append(1.0 - _classic_factor(L0, r, o))
            out.append(oklab(classic_rgb(src, r, o, L0)))
        return out, fs
    dark = o["gen_dark"] / 100.0
    sc = 1.0 - dark + dark * min(max(L0, 0.0), 1.0)
    stops = [(0.0, tuple(lab0))]
    for r, c in gen_stops(o):
        stops.append((max(stops[-1][0] + 0.5, max(1.0, r * sc)), oklab(c)))
    last = stops[-1][0]
    hold = 1.0 + 3.0 * o["gen_hold"] / 100.0
    wheel = o["gen_blend"] == "wheel"
    curve = o["gen_curve"]
    out = [tuple(lab0)]
    fs = [0.0]
    for r in range(1, LIGHT_ROWS):
        fs.append(min(r / last, 1.0))
        if r >= last:
            col = stops[-1][1]
        else:
            k = next(i for i in range(1, len(stops)) if r <= stops[i][0])
            (r0, A), (r1, B) = stops[k - 1], stops[k]
            f = ((r - r0) / (r1 - r0)) ** curve
            if k == len(stops) - 1:
                f = _soft_end(f)
            col = _gen_blend(A, B, f, f ** hold, wheel)
        out.append(_gamut(*col))
    return out, fs


def _miss(lab, ideal):
    return math.sqrt(4.0 * (lab[0] - ideal[0]) ** 2 + (lab[1] - ideal[1]) ** 2 +
                     (lab[2] - ideal[2]) ** 2)


def propose_new_colours(rgbs, deleted, scope, opts, fades=None):
    """Generate fade colours: up to gen_new_max NEW colours that best fill
    the steps the current palette misses (greys where the ideal fade has
    colour, far-off steps). Chosen together across every fade in `scope`
    (a colour that fixes several fades wins), never near-copies of palette
    colours. Returns a list of rgb tuples, best first."""
    o = clean_gen_settings(opts)
    deleted = deleted or set()
    if o["gen_fb"]:
        return []
    if fades is None:
        fades = build_fades(rgbs, deleted, scope, o)
    have = [oklab(c) for i, c in enumerate(rgbs[:ENTRIES])
            if c is not None and i not in deleted]
    labcache = {}
    bins = {}
    Q = 0.03
    for s in scope:
        src = rgbs[s] if 0 <= s < len(rgbs) else None
        if src is None:
            continue
        ideal, _fs = _fade_ideal(oklab(src), o)
        for r in range(1, LIGHT_ROWS):
            t = fades.get((r, s))
            if t is None or rgbs[t] is None:
                continue
            lab = labcache.get(t)
            if lab is None:
                lab = labcache[t] = oklab(rgbs[t])
            I = ideal[r]
            Ci = math.hypot(I[1], I[2])
            if (I[0] < 0.12 and Ci < 0.04) or (I[0] < 0.22 and Ci < 0.03):
                continue                       # dark and dull: repeats are fine
            e = _miss(lab, I)
            if e < 0.035 + max(0.0, 0.2 - I[0]) * 0.15:
                continue
            key = (round(I[0] / Q), round(I[1] / Q), round(I[2] / Q))
            b = bins.get(key)
            if b is None:
                bins[key] = [1.0, I[0], I[1], I[2], e]
            else:
                b[0] += 1.0
                b[1] += I[0]
                b[2] += I[1]
                b[3] += I[2]
                b[4] += e
    if not bins:
        return []
    items = []
    for w, sl, sa, sb, se in bins.values():
        items.append([w, (sl / w, sa / w, sb / w), se / w])
    items.sort(key=lambda it: -it[0] * it[2])
    items = items[:400]
    picks = []
    for _k in range(o["gen_new_max"]):
        best, bg = None, 0.0
        for _w, c, _e in items:
            if any(_miss(c, h) < 0.025 for h in have) or                     any(_miss(c, p) < 0.03 for p in picks):
                continue
            g = 0.0
            for w, rep, e in items:
                d = _miss(c, rep)
                if d < e:
                    g += w * (e - d)
            if g > bg:
                best, bg = c, g
        if best is None or bg < 0.05:
            break
        picks.append(best)
        for it in items:
            it[2] = min(it[2], _miss(best, it[1]))
    out = []
    pal_set = {tuple(c) for c in rgbs[:ENTRIES] if c is not None}
    for L, a, b in picks:
        rgb = tuple(int(round(min(max(v, 0.0), 255.0))) for v in oklab_to_rgbf(L, a, b))
        if rgb not in out and rgb not in pal_set:
            out.append(rgb)
    return out


def _angdiff(a, b):
    d = abs(a - b) % 360.0
    return 360.0 - d if d > 180.0 else d


class _Pool:
    """Palette colours in OKLab / LCh, sorted by lightness for range lookups."""

    def __init__(self, rgbs, deleted, only=None, limit=ENTRIES):
        items = []
        only = set(only) if only else None
        for i, c in enumerate(rgbs[:limit]):
            if c is None or i in deleted or (only is not None and i not in only):
                continue
            L, a, b = oklab(c)
            C = math.hypot(a, b)
            h = math.degrees(math.atan2(b, a)) % 360.0
            items.append((L, i, a, b, C, h))
        items.sort()
        self.items = items
        self.Ls = [it[0] for it in items]

    def near_L(self, L, span):
        lo = bisect.bisect_left(self.Ls, L - span)
        hi = bisect.bisect_right(self.Ls, L + span)
        return self.items[lo:hi]


def gradient_strip(start_rgb, opts):
    """31 rgb colours (rows 1-31) of a fade from start_rgb with these
    settings - the Fade gradient window's preview strip."""
    o = clean_gen_settings(opts)
    ideal, _fs = _fade_ideal(oklab(tuple(start_rgb)), o)
    return [tuple(int(round(min(max(v, 0.0), 255.0))) for v in oklab_to_rgbf(*ideal[r]))
            for r in range(1, LIGHT_ROWS)]


def gen_targets(rgbs, scope, opts):
    """Generate's true-colour targets {(row, src): rgb} for rows 1-31 (what
    Hold for true colour shows). Full bright: the colour itself."""
    o = clean_gen_settings(opts)
    out = {}
    for s in scope:
        src = rgbs[s] if 0 <= s < len(rgbs) else None
        if src is None:
            continue
        if o["gen_fb"]:
            for r in range(1, LIGHT_ROWS):
                out[(r, s)] = tuple(src)
            continue
        if o["gen_blend"] == "classic":
            L0 = oklab(tuple(src))[0]
            for r in range(1, LIGHT_ROWS):
                out[(r, s)] = classic_rgb(src, r, o, L0)
            continue
        ideal, _fs = _fade_ideal(oklab(src), o)
        for r in range(1, LIGHT_ROWS):
            out[(r, s)] = tuple(int(round(min(max(v, 0.0), 255.0)))
                                for v in oklab_to_rgbf(*ideal[r]))
    return out


def _nearest_fades(rgbs, scope, o, pool):
    """Match "nearest": each row's true-colour target snapped on its own to
    the nearest pool colour (OKLab or RGB distance) - like id / Freedoom."""
    rgb_metric = o["gen_metric"] == "rgb"
    cands = sorted((it[1], it[0], it[2], it[3], tuple(rgbs[it[1]])) for it in pool.items)
    out = {}
    for s in scope:
        src = rgbs[s] if 0 <= s < len(rgbs) else None
        if src is None:
            continue
        ideal, _fs = _fade_ideal(oklab(src), o)
        L0 = ideal[0][0]
        for r in range(1, LIGHT_ROWS):
            L, a, b = ideal[r]
            if rgb_metric:
                if o["gen_blend"] == "classic":
                    t = classic_rgb(src, r, o, L0)
                else:
                    t = tuple(min(max(v, 0.0), 255.0) for v in oklab_to_rgbf(L, a, b))
                best = min(cands, key=lambda c: (c[4][0] - t[0]) ** 2 + (c[4][1] - t[1]) ** 2
                           + (c[4][2] - t[2]) ** 2)
            else:
                best = min(cands, key=lambda c: (c[1] - L) ** 2 + (c[2] - a) ** 2
                           + (c[3] - b) ** 2)
            out[(r, s)] = best[0]
    return out


def _ladder_fades(rgbs, scope, o, pool):
    """Match "ladder" (Generate selected): the pool is a staircase - sorted
    light to dark (or in palette index order) - and every fade walks DOWN it,
    never back up. Each fade first skips the steps lighter than itself.
    Pacing "curve": each row takes the next step whose lightness is closest
    to the row's target (Reach / Darken curve / Dark colours finish sooner
    shape it); "even": the steps are spread evenly from row 1 to Reach."""
    steps = [(it[1], it[0]) for it in pool.items]          # (slot, L)
    by_index = o["gen_order"] == "index"
    if by_index:
        steps.sort()
    else:
        steps.sort(key=lambda t: (-t[1], t[0]))
    if o.get("gen_black"):                   # Allow black: always the last step
        b = black_slot(rgbs)
        steps = [t for t in steps if t[0] != b] + [t for t in steps if t[0] == b]
    out = {}
    if not steps:
        return out
    dark = o["gen_dark"] / 100.0
    for s in scope:
        src = rgbs[s] if 0 <= s < len(rgbs) else None
        if src is None:
            continue
        lab0 = oklab(src)
        L0 = lab0[0]
        q = [t for t in steps if t[1] <= L0 + 0.02 and t[0] != s] or [steps[-1]]
        if o["gen_pace"] == "even":
            reach = max(1.0, o["gen_reach"] * (1.0 - dark + dark * min(max(L0, 0.0), 1.0)))
            n = len(q)
            for r in range(1, LIGHT_ROWS):
                f = min(r / reach, 1.0) ** o["gen_curve"]
                k = min(n - 1, int(f * n - 1e-9)) if f > 0 else 0
                out[(r, s)] = q[max(k, 0)][0]
            continue
        ideal, _fs = _fade_ideal(lab0, o)
        k = 0
        for r in range(1, LIGHT_ROWS):
            Lt = ideal[r][0]
            best = k
            for j in range(k, len(q)):
                if abs(q[j][1] - Lt) < abs(q[best][1] - Lt):
                    best = j
                if not by_index and q[j][1] < Lt - 0.15:
                    break
            k = best
            out[(r, s)] = q[k][0]
    return out


def black_slot(rgbs, deleted=()):
    """The palette's black: an exact #000000, else the darkest colour."""
    best = None
    for i, c in enumerate(rgbs[:ENTRIES]):
        if c is None or i in deleted:
            continue
        if tuple(c) == (0, 0, 0):
            return i
        L = oklab(c)[0]
        if best is None or L < best[0]:
            best = (L, i)
    return None if best is None else best[1]


def build_fades(rgbs, deleted, scope, opts, pool_slots=None, limit=ENTRIES):
    """Generate tool: rows 1-31 for each colour in `scope`, as
    {(row, src): slot}. Row 0 is the colour itself (the fade starts there).

    The ideal path is an OKLab blend from the colour to the destination
    (black or a chosen colour), reached at row gen_reach and held after;
    gen_curve shapes it (>1 stays bright longer). Each step picks a real
    palette colour: lightness matters most, then colourfulness; hue may
    wander up to gen_hue degrees (the window grows with depth) for free,
    beyond that it costs a lot. gen_keep penalises going greyer than the
    ideal. The 31 steps are chosen together (best path through the
    cheapest candidates per row), never lighter than the step before when
    gen_mono is on."""
    o = clean_gen_settings(opts)
    deleted = deleted or set()
    if o["gen_fb"]:                              # full bright: never darkens
        return {(r, s): s for s in scope if 0 <= s < len(rgbs) and rgbs[s] is not None
                for r in range(1, LIGHT_ROWS)}
    pool = _Pool(rgbs, deleted, pool_slots, limit)     # limit > 256: extra colours
    if not pool.items:
        pool = _Pool(rgbs, deleted, None, limit)
    if not pool.items:
        return {}
    if o["gen_match"] == "nearest":
        return _nearest_fades(rgbs, scope, o, pool)
    if o["gen_match"] == "ladder":
        return _ladder_fades(rgbs, scope, o, pool)
    freedom = float(o["gen_hue"])
    keep = o["gen_keep"] / 100.0
    mono = o["gen_mono"]
    TOP = 14
    out = {}
    for s in scope:
        src = rgbs[s] if 0 <= s < len(rgbs) else None
        if src is None:
            continue
        L0, a0, b0 = oklab(src)
        rows = []                                   # per row: [(cost, slot, L, a, b)]
        ideal, fs = _fade_ideal((L0, a0, b0), o)
        for r in range(1, LIGHT_ROWS):
            f = fs[r]
            Li, ai, bi = ideal[r]
            Ci = math.hypot(ai, bi)
            hi = math.degrees(math.atan2(bi, ai)) % 360.0
            window = freedom * f
            span = 0.06
            cands = pool.near_L(Li, span)
            while len(cands) < 6 and span < 1.0:
                span *= 2
                cands = pool.near_L(Li, span)
            scored = []
            for L, i, a, b, C, h in cands:
                cost = 4.0 * (L - Li) ** 2 + (C - Ci) ** 2
                if C > 0.02 and Ci > 0.02:
                    dh = _angdiff(h, hi)
                    g = 2.0 * math.sqrt(C * Ci)
                    ex = max(0.0, dh - window)
                    cost += 4.0 * (g * math.sin(math.radians(ex) / 2.0)) ** 2
                    cost += 0.1 * (g * math.sin(math.radians(dh) / 2.0)) ** 2
                if C < Ci:
                    cost += 3.0 * keep * (Ci - C) ** 2
                scored.append((cost, i, L, a, b))
            scored.sort()
            rows.append(scored[:TOP])
        # best path: row 0 = the colour itself
        # best path: row 0 = the colour itself. Steps cost their own miss plus
        # a smoothness term: a lightness step unlike the ideal one, or a
        # sideways (hue / colourfulness) jump bigger than the ideal's, costs.
        prev = [(0.0, None, L0, a0, b0, None)]   # (total, slot, L, a, b, back-pointer)
        table = []
        for r, cands in enumerate(rows, 1):
            pi_, ci_ = ideal[r - 1], ideal[r]
            step_L = pi_[0] - ci_[0]
            step_ab = math.hypot(pi_[1] - ci_[1], pi_[2] - ci_[2])
            smooth = min(1.0, ci_[0] / 0.3)     # dark steps may repeat freely
            cur = []
            for cost, i, L, a, b in cands:
                best = None
                for k, (tot, _pi, pL, pa, pb, _bp) in enumerate(prev):
                    if mono and L > pL + 0.004:
                        continue
                    side = max(0.0, math.hypot(pa - a, pb - b) - step_ab)
                    t = tot + cost + smooth * (0.5 * ((pL - L) - step_L) ** 2 +
                                               4.0 * side ** 2)
                    if best is None or t < best[0]:
                        best = (t, k)
                if best is not None:
                    cur.append((best[0], i, L, a, b, best[1]))
            if not cur:                          # nothing allowed: relax for this row
                k = min(range(len(prev)), key=lambda q: prev[q][0])
                for cost, i, L, a, b in cands:
                    cur.append((prev[k][0] + cost, i, L, a, b, k))
            table.append(cur)
            prev = cur
        k = min(range(len(prev)), key=lambda q: prev[q][0])
        for r in range(len(table), 0, -1):
            entry = table[r - 1][k]
            out[(r, s)] = entry[1]
            k = entry[5]
    return out
