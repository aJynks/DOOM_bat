"""Repalettise WAD bitmap data onto a new palette (Run).

index_map(src, dst): each source index -> the same index when the colour is
still there, else the nearest dst colour (plain RGB, first minimum wins).
Pictures (patches / sprites / graphics) get their post bytes remapped,
flats their raw bytes, PNG lumps their colours (grAb offsets kept).
Non-bitmap lumps are never touched."""

import io
import struct

from .cleanpal_lib_wadgfx import WadArchive, is_doom_picture

PNG_SIG = b"\x89PNG\r\n\x1a\n"
SKIP = {"PLAYPAL", "COLORMAP", "TEXTURE1", "TEXTURE2", "PNAMES", "ENDOOM", "GENMIDI",
        "DMXGUS", "DMXGUSC", "SWITCHES", "ANIMATED", "DSDACR", "OPTIONS", "DEHACKED",
        "MAPINFO", "UMAPINFO", "SNDINFO", "TRANMAP", "WATERMAP", "LANGUAGE"}
MAPLUMPS = {"THINGS", "LINEDEFS", "SIDEDEFS", "VERTEXES", "SEGS", "SSECTORS", "NODES",
            "SECTORS", "REJECT", "BLOCKMAP", "BEHAVIOR", "SCRIPTS", "TEXTMAP", "ZNODES",
            "ENDMAP", "DIALOGUE"}
FLAT_START, FLAT_END = ("F_START", "FF_START"), ("F_END", "FF_END")
SPR_START, SPR_END = ("S_START", "SS_START"), ("S_END", "SS_END")


def pal_from(raw):
    if raw is None or len(raw) < 768:
        return None
    return [tuple(raw[i * 3:i * 3 + 3]) for i in range(256)]


def index_map(src, dst):
    cand = [(j, c) for j, c in enumerate(dst) if c is not None]
    out = []
    for i in range(256):
        c = src[i] if i < len(src) else None
        if c is None or not cand:
            out.append(i)
            continue
        if i < len(dst) and dst[i] is not None and tuple(dst[i]) == tuple(c):
            out.append(i)
            continue
        r, g, b = c
        best, bd = i, None
        for j, d in cand:
            dd = (d[0] - r) ** 2 + (d[1] - g) ** 2 + (d[2] - b) ** 2
            if bd is None or dd < bd:
                best, bd = j, dd
        out.append(best)
    return out


def remap_picture(d, mp):
    b = bytearray(d)
    w = struct.unpack_from("<H", b, 0)[0]
    for x in range(w):
        p = struct.unpack_from("<I", b, 8 + 4 * x)[0]
        while p < len(b) and b[p] != 0xFF:
            ln = b[p + 1]
            for k in range(p + 3, min(p + 3 + ln, len(b))):
                b[k] = mp[b[k]]
            p += 4 + ln
    return bytes(b)


def remap_flat(d, mp):
    return bytes(d).translate(bytes(mp))


def _chunks(d):
    p = 8
    while p + 8 <= len(d):
        n = struct.unpack(">I", d[p:p + 4])[0]
        yield d[p + 4:p + 8], d[p:p + 12 + n]
        p += 12 + n


def remap_png(d, src, dst, mp):
    """Paletted PNG: index remap; true colour: nearest dst colour per pixel.
    grAb (offsets) chunk kept. Returns new bytes (or the old ones on failure)."""
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(d))
        im.load()
    except Exception:  # noqa: BLE001
        return d
    grab = [c for t, c in _chunks(d) if t == b"grAb"]
    cand = [(j, c) for j, c in enumerate(dst) if c is not None]
    memo = {}

    def near(c):
        v = memo.get(c)
        if v is None:
            r, g, b = c
            v = memo[c] = min(cand, key=lambda jc: (jc[1][0] - r) ** 2 + (jc[1][1] - g) ** 2
                              + (jc[1][2] - b) ** 2)[1]
        return v
    if im.mode == "P":
        pal = im.getpalette()[:768]
        pal += [0] * (768 - len(pal))
        newp = []
        for i in range(256):
            c = tuple(pal[i * 3:i * 3 + 3])
            newp += list(near(c)) if cand else list(c)
        out = im.copy()
        out.putpalette(newp)
    else:
        rgba = im.convert("RGBA")
        px = list(rgba.getdata())
        out = Image.new("RGBA", rgba.size)
        out.putdata([(near(p[:3]) + (p[3],)) if p[3] else p for p in px])
    buf = io.BytesIO()
    out.save(buf, "PNG", **({"transparency": im.info["transparency"]}
                            if im.mode == "P" and "transparency" in im.info else {}))
    nd = buf.getvalue()
    if grab:                                          # put grAb back after IHDR
        ih = next(c for t, c in _chunks(nd) if t == b"IHDR")
        cut = 8 + len(ih)
        nd = nd[:cut] + b"".join(grab) + nd[cut:]
    return nd


def bitmap_kind(name, data, ns):
    """'flat' / 'pic' / 'png' / None for one lump."""
    if not data or name in SKIP or name in MAPLUMPS:
        return None
    if ns == "f":
        return "png" if data[:8] == PNG_SIG else ("flat" if len(data) >= 64 else None)
    if data[:8] == PNG_SIG:
        return "png"
    if is_doom_picture(data):
        return "pic"
    return None


def repal_lumps(arch, src, dst, only_bitmaps):
    """[(name, bytes)] - the WAD's lumps with bitmaps converted. only_bitmaps:
    just the converted lumps (flats / sprites wrapped in their markers);
    else every lump in order (PLAYPAL / COLORMAP dropped). -> (lumps, n)."""
    mp = index_map(src, dst)
    out, flats, sprites, n = [], [], [], 0
    ns = None
    for i, (name, _pos, size) in enumerate(arch.lumps):
        if name in FLAT_START:
            ns = "f"
        elif name in SPR_START:
            ns = "s"
        elif name in FLAT_END + SPR_END:
            ns = None
        d = arch.lump_at(i) if size else b""
        k = None if name in FLAT_START + SPR_START + FLAT_END + SPR_END else \
            bitmap_kind(name, d, ns)
        nd = d
        if k == "flat":
            nd = remap_flat(d, mp)
        elif k == "pic":
            nd = remap_picture(d, mp)
        elif k == "png":
            nd = remap_png(d, src, dst, mp)
        if k:
            n += 1
        if only_bitmaps:
            if k:
                (flats if ns == "f" else sprites if ns == "s" else out).append((name, nd))
        elif name not in ("PLAYPAL", "COLORMAP"):
            out.append((name, nd))
    if only_bitmaps:
        if flats:
            out += [("FF_START", b"")] + flats + [("FF_END", b"")]
        if sprites:
            out += [("SS_START", b"")] + sprites + [("SS_END", b"")]
    return out, n


def repal_wad(path, dst, fallback_src, only_bitmaps):
    arch = WadArchive(path)
    src = pal_from(arch.lump("PLAYPAL")) or fallback_src
    return repal_lumps(arch, src, dst, only_bitmaps)
