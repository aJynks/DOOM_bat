"""cleanpal - Doom palette tool (library)."""

from .cleanpal_lib_constants import VERSION  # noqa: F401
