"""Colour-bar sliders for the Adjust tools: the bar shows what the value does
(hue spectrum, grey -> vivid, dark -> light, warm / cool ...), the handle is
filled with the colour at the current value."""

import math


def _ok(L, C, hdeg):
    from ..cleanpal_lib_colour import oklab_to_rgbf
    h = math.radians(hdeg)
    return tuple(int(round(min(max(v, 0), 255)))
                 for v in oklab_to_rgbf(min(max(L, 0.0), 1.0), C * math.cos(h), C * math.sin(h)))


def _hsl(h, s_, l):
    from ..cleanpal_lib_colour import hsl_to_rgb
    return tuple(int(round(min(max(v, 0), 255)))
                 for v in hsl_to_rgb(h % 360.0, min(max(s_, 0), 100), min(max(l, 0), 100)))


def avg_of(cols):
    """(L, C, OK hue, HSL hue) of some colours."""
    from ..cleanpal_lib_colour import oklab, rgb_to_hsl
    cols = cols or [(128, 128, 128)]
    labs = [oklab(c) for c in cols]
    n = float(len(labs))
    L = sum(v[0] for v in labs) / n
    a = sum(v[1] for v in labs) / n
    b = sum(v[2] for v in labs) / n
    r = [sum(c[k] for c in cols) / n for k in range(3)]
    return (L, math.hypot(a, b), math.degrees(math.atan2(b, a)) % 360, rgb_to_hsl(*r)[0])


def grad_fn(name, key, params, avg):
    """value -> colour for a slider's bar, or None for a plain slider."""
    L, C, hok, hhsl = avg
    C = max(C, 0.06)
    if name == "Colorise":
        if key == "hue":
            return lambda v: _hsl(v, 90, 50)
        if key == "sat":
            return lambda v: _hsl(params.get("hue", 0), v, 50)
        if key == "light":
            return lambda v: _hsl(params.get("hue", 0), params.get("sat", 50), 50 + v / 2.0)
    if name == "Hue / Saturation / Lightness":
        if key == "hue":
            return lambda v: _hsl(hhsl + v, 90, 50)
        if key == "sat":
            return lambda v: _ok(L, C * (1 + v / 100.0), hok)
        if key == "light":
            return lambda v: _ok(L + (1 - L if v > 0 else L) * v / 100.0, C, hok)
    if key in ("dark_hue", "light_hue", "shadow_hue", "highlight_hue") or \
            (name == "Selective hue" and key == "hue"):
        return lambda v: _ok(0.72, 0.15, v)
    if name == "Selective hue" and key == "shift":
        return lambda v: _ok(0.72, 0.15, params.get("hue", 0) + v)
    if (name, key) in (("Vibrance", "amount"), ("Selective hue", "saturation")):
        return lambda v: _ok(L, C * (1 + v / 100.0), hok)
    if name == "Saturation along ramp":
        return lambda v: _ok(L, C * v / 100.0, hok)
    if (name, key) in (("Shadows / Highlights", "shadows"), ("Shadows / Highlights", "highlights"),
                       ("Brightness / Contrast", "brightness"), ("Selective hue", "lightness")):
        return lambda v: _ok(L + 0.4 * v / 100.0, C, hok)
    if name == "Exposure":
        return lambda v: _ok(L * (2 ** v) ** 0.33, C, hok)
    if name == "Contrast S-curve" and key == "pivot":
        return lambda v: _ok(v / 100.0, 0, 0)
    if name == "Temperature / Tint":
        if key == "temp":
            return lambda v: _ok(0.7, 0.12 * abs(v) / 100.0, 60 if v > 0 else 250)
        if key == "tint":
            return lambda v: _ok(0.7, 0.12 * abs(v) / 100.0, 340 if v > 0 else 140)
    pairs = {"cyan_red": ((0, 200, 200), (220, 40, 40)),
             "magenta_green": ((200, 40, 200), (40, 190, 60)),
             "yellow_blue": ((220, 210, 40), (40, 80, 220))}
    if name == "Colour balance" and key in pairs:
        a, b = pairs[key]

        def f(v, a=a, b=b):
            t = abs(v) / 100.0
            e = b if v > 0 else a
            return tuple(int(128 + (e[k] - 128) * t) for k in range(3))
        return f
    if name == "Split toning" and key == "strength":
        return lambda v: _ok(0.65, 0.15 * v / 100.0, params.get("shadow_hue", 230))
    return None


SEL_CYAN = "#00e5ff"     # the palette selection's cyan = "selected"


def draw_node(c, pts, fill, selected, ui=1.0):
    """A gradient node triangle: the node's colour, a white outline (shows on
    the dark strip whatever the colour), a thick cyan outline when selected."""
    if selected:
        c.create_polygon(*pts, fill=fill, outline=SEL_CYAN, width=max(3, round(3 * ui)))
    else:
        c.create_polygon(*pts, fill=fill, outline="#ffffff", width=max(1, round(1.5 * ui)))


class GradSlider:
    def __init__(self, parent, app, lo, hi, step, value, cb, fn, ui):
        from tkinter import ttk
        tk = app.tk
        self.lo, self.hi, self.step = float(lo), float(hi), float(step)
        self.cb, self.fn, self.ui = cb, fn, ui
        self.v = float(value)
        self.enabled = True
        self.log = False            # True: the track is logarithmic (lo > 0)
        self.frame = ttk.Frame(parent)
        self.c = tk.Canvas(self.frame, height=int(24 * ui), width=int(260 * ui),
                           highlightthickness=0, cursor="hand2")
        self.c.pack(side="left", fill="x", expand=True)
        self.lab = ttk.Label(self.frame, width=7, anchor="e")
        self.lab.pack(side="left", padx=(6, 0))
        self.c.bind("<Configure>", lambda e: self.draw())
        self.c.bind("<ButtonPress-1>", self._drag)
        self.c.bind("<B1-Motion>", self._drag)
        self.c.bind("<MouseWheel>", lambda e: self._nudge(1 if e.delta > 0 else -1, e))
        self._img = None
        self.draw()

    def _geom(self):
        W, H = max(self.c.winfo_width(), 40), max(self.c.winfo_height(), 10)
        pad = H // 2
        return pad, W - pad, H

    def _snap(self, v):
        v = min(max(v, self.lo), self.hi)
        return round(self.lo + round((v - self.lo) / self.step) * self.step, 6)

    def set_enabled(self, on):
        self.enabled = bool(on)
        try:
            self.c.configure(cursor="hand2" if on else "")
            self.lab.state(["!disabled"] if on else ["disabled"])
        except Exception:  # noqa: BLE001 - widget gone
            return
        self.draw()

    def _drag(self, ev):
        if not self.enabled:
            return
        x0, x1, _H = self._geom()
        t = min(max((ev.x - x0) / max(x1 - x0, 1), 0.0), 1.0)
        self.set(self._snap(self._from_t(t)), fire=True)

    def _from_t(self, t):
        if self.log:
            return self.lo * (self.hi / self.lo) ** t
        return self.lo + t * (self.hi - self.lo)

    def _to_t(self, v):
        if self.log:
            return math.log(max(v, self.lo) / self.lo) / math.log(self.hi / self.lo)
        return (v - self.lo) / max(self.hi - self.lo, 1e-9)

    def _nudge(self, n, ev):
        if not self.enabled:
            return "break"
        mul = 10 if ev.state & 0x0001 else 1
        if self.log:
            self.set(self._snap(self._from_t(self._to_t(self.v) + n * mul * 0.01)), fire=True)
        else:
            self.set(self._snap(self.v + n * mul * self.step), fire=True)
        return "break"

    def set(self, v, fire=False):
        changed = v != self.v
        self.v = v
        self.draw()
        if fire and changed:
            self.cb(v)

    def set_fn(self, fn):
        self.fn = fn
        self.draw()

    def draw(self):
        from PIL import Image, ImageTk
        c = self.c
        x0, x1, H = self._geom()
        c.delete("all")
        w = int(x1 - x0)
        if w >= 4:
            th = max(6, H // 3)
            if self.fn is not None:
                n = 96
                strip = Image.new("RGB", (n, 1))
                strip.putdata([self.fn(self._from_t(k / (n - 1.0))) for k in range(n)])
                self._img = ImageTk.PhotoImage(strip.resize((w, th), Image.BILINEAR))
                c.create_image(x0, (H - th) // 2, anchor="nw", image=self._img)
            else:
                c.create_rectangle(x0, (H - th) // 2, x1, (H + th) // 2, fill="#9a9a9a",
                                   outline="#777777")
            t = min(max(self._to_t(self.v), 0.0), 1.0)
            x = x0 + t * (x1 - x0)
            r = H / 2.0 - 2
            fill = "#%02x%02x%02x" % self.fn(self.v) if self.fn else "#dddddd"
            if not self.enabled:
                fill = "#bdbdbd"
                c.create_rectangle(x0, (H - th) // 2, x1, (H + th) // 2, fill="#cfcfcf",
                                   outline="#bbbbbb")
            c.create_oval(x - r, H / 2 - r, x + r, H / 2 + r, outline="#000000", width=3)
            c.create_oval(x - r, H / 2 - r, x + r, H / 2 + r, outline="#ffffff", width=2,
                          fill=fill)
        self.lab.configure(text=("%d" % self.v) if self.step >= 1 else ("%g" % self.v))
