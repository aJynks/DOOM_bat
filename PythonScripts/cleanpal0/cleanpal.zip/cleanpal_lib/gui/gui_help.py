"""In-app help text."""

from ..cleanpal_lib_constants import VERSION


# ============================================================ GUI
HELP_TEXT = """\
cleanpal v%s - Doom PLAYPAL / COLORMAP editor

MODES  (Mode dropdown, top bar)
  PLAYPAL    the palette tools (Cull / Move / Reorder / Paint), view, export.
  COLORMAP   the light tables: the palette grid shrinks to a selector, a
             fade view appears under it and the side panel shows the
             COLORMAP tools. Selection and history are shared by both.

IWAD  (IWAD button, top bar - always needed)
  The IWAD (doom2.wad, doom.wad, ...) supplies textures and patches for the
  Palettised preview, and the fallback PLAYPAL / COLORMAP. On first start
  cleanpal asks for it, offering one found beside the loaded file or in
  DOOMWADDIR / DOOMWADPATH (the folders dsda-doom searches).

LOADING
  Open a WAD (PLAYPAL lump - and its COLORMAP lump, kept for compare /
  import; the IWAD's COLORMAP is used when the file has none), SLADE
  playpal.pal / pal0.pal, SLADE pal0.png, DoomTools playpal.png, a
  .cleanpal project, or a COLORMAP image. pal0 (the first 256 colours,
  or row / line 0 of an image) is shown as a SLADE style 16x16 grid,
  index 0 top-left.

TOOLS  (PLAYPAL - side panel: Cull / Move / Reorder / Paint)
  Each tool is a window; only one is open at a time and its button lights
  up (the grid border takes its colour). With no tool open the grid shows
  the current snapshot with no markers - select, step through history,
  export, save.
    Cull     matching (exact / similar), Align, manual delete, Snapshot.
             Culling ONLY runs while this window is open.
    Move     drag colours to new slots.
    Reorder  sort colours into ramps.
    Paint    palette ramps and solid fills.
  Move, Reorder and Paint need a clean snapshot. Culling keeps the FIRST
  colour of each group, so changing the palette with culls pending would
  change which colours get kept. Switching from Cull with marks on the grid
  says so and offers "Take snapshot and continue" or Cancel.
  While Move / Reorder / Paint is open: culling is paused, Align is
  ignored (slots = indices), Back / Ctrl+Z only steps through that
  session's entries, and Export / Collapse are paused.
  Closing Cull with marks pending asks: Take snapshot / Close without
  applying (the marks come back when you reopen Cull) / Cancel.
  Switching to COLORMAP mode closes the open tool; COLORMAP always works
  on the current snapshot (no culling there).

CULL TOOLS - MATCHING, runs in order
  1. Remove exact colours
     Entries with exactly the same RGB value. The first occurrence (lowest
     index) is kept, later copies are removed.            Marker: X

  2. Remove similar colours  (needs stage 1)
     Only looks at what stage 1 left. Pairs within the tolerance are
     joined into clusters, and clustering is TRANSITIVE: if A~B and B~C,
     then A, B and C are one cluster even if A and C are further apart.
     The lowest index of each cluster is kept.           Marker: O

     CIEDE2000      (default) modern perceptual distance, built for judging
                    small differences. Corrects dE76's over-reaction to
                    saturated colours and its blue-purple distortion.
                    ~1 is just noticeable. Default 1.5.
     CIE Lab dE76   older perceptual distance. Cautious with vivid
                    colours. Default 2.0.
     Weighted RGB   channel-weighted RGB distance (0.299/0.587/0.114).
                    Blue barely counts. Default 1.1.

  Tolerance
     Drag the slider, click anywhere on its bar to jump there, use the
     mouse wheel over it (+/-0.05), or type in the box (applies as you
     type).
     In the box: Up/Down = +/-0.05, Shift+Up/Down = +/-0.5,
     mouse wheel = +/-0.05. Values above the slider range can be typed.

  Align
     Removes the removed entries and packs the kept colours toward index 0
     in their original order. The empty tail shows as a checkerboard.

TEXT FIELDS
  Every text / number box has a right-click menu: Cut, Copy, Paste,
  Delete, Select all. Ctrl+A selects the whole box while typing.

VIEW
  Mouse wheel      zoom toward the cursor
  Middle drag      pan
  Fit / F / double middle-click   reset to auto-fit
  The grid auto-fits as the window resizes until you zoom or pan.

SELECTION
  Click             select one colour
  Click-drag        box-select every colour inside
  Shift + click/drag   add to the selection
  Ctrl + click/drag    toggle colours in / out
  Ctrl+A            select all
  Esc / Clear       clear the selection
  Cull scope (under Remove similar):
    Whole palette          similar matching works on every colour
    Selected colours only  only the selection is culled; colours can only
                           merge with each other, unselected colours are
                           never touched. Nothing selected = nothing culled.
  In the Cull tools, selecting on the grid switches the scope to Selected
  colours only. Selecting is easiest with Align off - the grid reflows as
  culling changes.

REORDER TOOLS  (Reorder button -> Reorder tools window)
  Reorders the working palette into ramps (needs a clean snapshot - see
  TOOLS). You can select colours in the grid (with Preview off) to reorder
  just those.

  In the window pick a method, set its options, then:
    Preview   shows the result live on the grid (button turns blue). Changing
              any option re-sorts at once. While it is on, the selection is
              locked.
    Apply     keeps it and adds a "Reorder ..." history entry. Works with or
              without Preview. The window stays open, so you can select the
              next colour family and reorder that too.
    Cancel    (or Esc, or the Preview button again) restores the palette.

  Apply to:
    Whole palette        every colour is sorted; empty slots go to the end.
    Selected (gathered)  the selected colours are sorted and pulled together
                         into ONE block that starts at the first selected
                         slot. The other colours keep their order and shift
                         along to close the gaps. Select all the reds anywhere
                         in the palette and they end up as one red section.
                         The selection stays on the moved block afterwards.
    Opens on Selected if 2+ colours are selected, else Whole palette.
    Selecting in the grid while the window is open switches it to Selected;
    clearing the selection switches it back to Whole palette.

  Methods that find ramps:
    Curved ramps    (default, best on Doom's PLAYPAL) every colour links to
                    its nearest darker neighbour, cheapest links first, each
                    colour taking at most one lighter and one darker link.
                    Max step   longest allowed link (OKLab distance x100)
                    Max bend   how sharply a ramp may change direction - keep
                               it high for white -> colour -> black ramps
                    Hue/chroma weight  how much more a hue / colourfulness
                               change costs than a lightness change
    Line ramps      repeatedly takes the longest gap-free run of colours lying
                    on one straight line in RGB (ramps made by linear RGB
                    blending), removes it and repeats.
                    Line tolerance  distance from the line (RGB units)
                    Max gap         largest gap between neighbours on a line
    Shade families  colours with the same R:G:B ratio, i.e. one colour scaled
                    toward black. Ratio tolerance x100.
    Hue bands       greys first, then groups split at gaps in hue. Simple
                    baseline. Max band width in degrees.
  Shared options for those four:
    Order colours by   order inside each ramp (default OKLab lightness)
    Lightest / Darkest first
    Ramp order         Greys first then hue / Original position /
                       Largest first / By key (each ramp's highest value)
    Outliers           colours in ramps smaller than Min ramp size:
                       Join nearest ramp (if one is close, else left single),
                       Collect at end, or Leave single
    Min ramp size      smaller groups count as outliers

  Plain orderings (no ramps):
    Stepped hue     Alan Zucconi's hue x lightness buckets, alternating
                    direction. Smooth looking grid, not strict ramps.
    Gradient path   one nearest-colour chain through everything (OKLab),
                    tidied with 2-opt. Good on a selection.
    Single key      plain sort by the Order colours by key.
    Reverse         reverses the palette or the selection.

  No sort is perfect - try a few and compare. Sorting a selection (one
  colour family at a time) gives the most control.
  Method, options and direction are saved with the settings and presets.

  Ramp test (command line, no GUI):
    cleanpal --ramptest <palette> [folder]
  Shuffles the palette three times, runs every method with its defaults and
  reports how many of the palette's own ramps (runs of close colours in its
  current order) come back as neighbours. Writes <name>_ramptest.png with
  every result side by side.

PAINT TOOLS  (Paint button -> Paint tools window)
  Needs a clean snapshot (see TOOLS). Palette colours can only be changed
  here: the ramp, Fill, single cells, and scratch colours dragged onto the
  grid.

  Paint session - edits stay pending until you Snapshot
    Ramp Apply, Fill selected, single-cell picker edits and scratch drops
    change the working palette at once but add NO history entry. Change
    the selection between edits as much as you like.
    Snapshot   records everything since the last snapshot as ONE entry
               ("Painted: 3 ramps, 2 fills, 5 cells - ...")
    Revert     throws away everything since the last snapshot (or since
               Paint opened); the selection is kept
    Hide selection outline  hides the cyan selection, the ramp-target
               dashes and the picked-cell box. The selection stays active
               but is LOCKED - clicks, drags, Ctrl+A and Esc don't change
               it until you untick the box.
    Closing with pending edits asks Snapshot / Discard / Cancel. History
    (Back / the list) is locked while edits are pending.

  Live ramp preview  (Preview: ON by default, remembered)
    The ramp is shown on whatever cells are selected and follows the
    selection as you click and drag - no need to switch it off to select.
    Apply makes it a pending edit; the next selection starts a fresh preview.
    Any other edit (Fill, a filter, cut / paste, the picker, Snapshot,
    Revert, Back) pauses it; it comes back on your next selection or ramp
    change. Cancel clears it until the next selection. Preview: OFF stops
    it altogether. The preview never counts as a pending edit.

  Filters...  (Paint session row) - classic filters on the selection.
    The window opens with Preview on (remembered); its preview pauses the
    ramp preview while it runs.
    Pick a filter on the left, set its options (slider or number box).
    The strip shows the selected colours before (top) / after (bottom);
    blank cells are skipped. Preview shows it live on the grid - you can
    change the selection while previewing and it re-runs. Apply writes it
    (a pending paint edit - Snapshot records it). Reset = filter defaults.
    Cancel / Esc restores. Each filter remembers its settings.
      Levels                 input black / gamma / white, output range;
                             RGB or one channel
      Brightness / Contrast  Perceptual (OKLab) or Classic (RGB); pivot =
                             mid grey or selection average
      Hue / Saturation / Lightness   OKLCH (perceptual) or HSL (classic)
      Colorise               one hue, keeps lightness; hue / saturation or
                             the Paint fill colour; strength
      Black & white          Doom / Rec.601, Rec.709, OKLab L or a custom
                             channel mix
      Invert                 RGB, or lightness only (keeps the hue)
      Gradient map           lightness -> the Paint window's current ramp
                             (recolour a family, keep its shading)
      Even out ramp          even lightness steps, hue + chroma kept
      Temperature / Tint     warm / cool, green / magenta
      Posterise              N levels per channel, or lightness only

  Double-click a cell   colour picker on that one cell - changes apply
    live. The selection is left as it was. A white dashed box marks the
    cell. Double-click another cell to move the picker; picking a ramp
    node or the fill swatch moves it back. Blank cells work too.

  Fill
    Swatch / hex box / Picker... set the fill colour; From selection takes
    the first selected colour. Fill selected writes it into every selected
    cell.

  Ramp
  Select the cells to fill in the main grid - blank (empty) cells and
  normal colours can all be selected. The ramp fills them in INDEX ORDER,
  one step per cell; scattered cells work too.

  Gradient bar
    Start and end nodes are fixed at the ends.
    Click the bar        add a node there (it takes the colour shown, so the
                         ramp doesn't jump)
    Drag a node          move it            Right-click / Del   remove it
    Double-click a node  open the colour picker on it
    Node row: swatch (click = picker), hex box, position %%, Delete node.
    Right-click the swatch or hex box to copy / paste the node colour.
  Blend
    OKLab            (default) even-looking steps, no muddy middle
    RGB              plain RGB mixing, like most paint programs / Doom's ramps
    OKLCH (hue path) goes round the hue wheel - the most vivid in-betweens
  Ease     Linear / Ease in / Ease out / Ease in-out, Strength 1 - 6
  Ease applies to: Whole ramp, or Each segment (every node-to-node stretch
           eases on its own). With whole-ramp easing the nodes are drawn
           where their colour actually lands on the bar.
  Reverse              flips the ramp
  Use selection ends   start / end take the first / last selected cells'
                       colours (extend or smooth an existing ramp)
  Steps strip          the actual colours that will be written, with hover
                       info. Dot = same RGB as an earlier step; corner
                       triangle = already in the palette elsewhere (Remove
                       exact would flag it).
  Preview (live on / off) / Apply / Cancel: Apply writes the ramp into the
  selected cells (a pending paint edit - Snapshot records it).
  Load ramp... / Save ramp... store nodes, blend and easing as .json.
  The ramp is remembered between sessions and saved in projects.

COLOUR PICKER  (popup - Picker... / double-click a node / swatch)
  Non-modal: edits apply live to the node, the steps and the grid preview.
  Clicking another ramp node switches the picker to that node.
  Modes (dropdown) - all edit the same colour, switching never changes it:
    RGB Sliders        R / G / B sliders + full spectrum box (hue across,
                       white - colour - black down)
    HSL Sliders        H / S / L sliders + hue x lightness box drawn at the
                       current saturation
    HSL Colour Wheel   hue ring + saturation / lightness triangle
  Hue and saturation are remembered through greys, black and white, so
  dropping saturation to 0 and back keeps your hue.
  Fields: R G B (0-255), H (0-360) S L (0-100), R# G# B#, and # hex.
  The # box takes EBEBEB, #EBEBEB, #ebe or 235,235,235; Ctrl+C / Ctrl+V.
  Right-click any field or the swatch: Cut / Copy / Paste / Select all, plus
  Copy colour as hex, Copy colour as R,G,B and Paste colour (applies a
  copied colour in any of those forms to the whole colour).
  Precision:  Shift + drag = fine (quarter speed)   Ctrl + drag = lock to
              one axis   arrow keys nudge the last-used control by 1
              (Shift = 10)   mouse wheel on sliders / fields = 1 (Shift 10)
  Swatch: left = new, right = colour when the node was picked - click the
  right half to revert.
  Eyedropper: click anywhere on screen (any program); a magnifier shows the
  exact pixel. Esc / right-click cancels.
  Recent: last 16 colours used. On top keeps the window above others.

SCRATCH PALETTE  (Scratch palette... button)
  Temporary swatches in named sets (New / Rename / Delete).
  Add:   + Picker (current picker colour), + Selected (selected grid
         cells), Eyedropper, Ctrl+V (hex lines), or drag cells from the
         main grid onto it (a selected group drags as a group).
  Use:   click a swatch          -> picker / active ramp node
         drag onto a grid cell   -> writes it into the palette (Paint)
         drag onto the ramp bar  -> recolours that node (or adds one)
         drag onto the picker    -> sets the picker
         Fill selected           -> writes it into every selected cell
                                    (Paint tools must be open)
         Palette writes become "Set colour ..." history entries.
  Manage: drag to reorder, Shift / Ctrl click to multi-select, Del
         removes, Ctrl+C copies as hex. Right-click a swatch: Copy hex,
         Copy R,G,B, Paste colour(s) here, Send to picker, Remove. A dot marks swatches whose
         colour is already in the palette; hover shows where.
  Import: hex text, GIMP .gpl, JASC .pal or raw .pal (as a new set).
  Export: .gpl or hex .txt. Sets are kept between sessions and in projects.

THE RED LINE - HELD CELLS
  The grid is a strip: the first 16 rows (256 cells) are the palette, then a
  red line, then held cells - as many rows as you're using, plus one spare
  empty row. Only the 256 above the line are the palette: held cells are
  never culled, reordered, used for COLORMAP, previewed or exported. Use
  them to park colours (a ramp you're working on, colours you might want
  back) while you work on the rest.
  Held cells select, move (drag across the line either way, cut / insert)
  and paint (ramps, fills, filters, picker, paste) like any other cell.
  They're kept in history and projects. The status line shows "Held: n".
  Nothing ever runs out of room: inserts and pastes that don't fit just
  carry on past the red line. Inserts fill holes on the same side of the
  line first (after the target, then the nearest before it), so cut +
  insert is still a move. Snapshot keeps the held cells.
  In COLORMAP mode only the 256 palette cells are shown.

PICKING COLOURS FROM THE PREVIEW  (Palettised preview, single view)
  Left-drag a box on the image - the Picked colours window opens with every
  colour inside it, exactly as shown: the sprite's own colours in Original
  view, palette colours in Palettised view, lit colours with COLORMAP
  lighting on (Corridor too). Shift-drag adds another box; a plain click
  clears the boxes. Transparent pixels are ignored.
  Picked colours (opens alongside any tool):
    Sort         Most used / Lightness / Hue
    Merge similar   (originals only) groups near-identical shades
    Copy         to cleanpal's clipboard (Ctrl+V / Ctrl+Shift+V in the grid)
    Copy hex     the hex codes as text - paste into a ramp node's hex box,
                 the Scratch palette, anything
    Copy Cells / Insert Cells   into the main palette, as in Playpals
    To scratch   add them to the current Scratch palette set
    Drag a swatch onto the Paint ramp bar (a node), a palette cell (Paint)
    or the colour picker. White corner = already in your palette.

PLAYPALS  (Tools panel -> Playpals... - a reference window, opens alongside any tool)
  Browse other palettes and copy colours out of them.
  Add...       load pal0s: WAD PLAYPAL, SLADE .pal / pal0.png, DoomTools
               playpal.png, a .cleanpal project (its current entry). Pick
               several at once. The IWAD's PLAYPAL is always listed first.
               The list is remembered.
  Remove / Clear   take palettes off the list (the IWAD stays).
  Single / Tile    one big palette, or C x R at once. Up / Down (or the
               wheel) = next palette; in Tile the active one is outlined.
  Mark colours already in my palette   white corner = exists in yours;
               hover also says "also in working palette at #n".
  Select like the main grid (click / drag / Shift / Ctrl / Ctrl+A), then:
    Copy (Ctrl+C)   to the shared clipboard (index order, no gaps) - nothing
                    else changes
    Copy Cells      into the cells selected in the main grid, one for one in
                    index order. Extra colours are dropped; extra cells are
                    left alone.
    Insert Cells    in front of the main grid's first selected cell, pushing
                    the rest along.
    Drag one colour onto a main-grid cell to set it (Paint tools).
  Copy Cells / Insert Cells act on the main palette straight away:
    no tool open  -> one history entry ("Copied 6 cells from x.pal"), Back
                     undoes it
    Paint open    -> a pending paint edit (Snapshot records it)
    Cull / Move / Reorder open -> refused (close them first)
  They complain if nothing is selected in either window.

CLIPBOARD  (side panel buttons + Paint / Move windows; Ctrl+C works anywhere)
  Ctrl+C  copy     the selected colours, index order, blank cells skipped -
                   one gap-free block. Also put on the system clipboard as
                   hex (Scratch palette's Ctrl+V can take it).
  Ctrl+X  cut      Paint: copy, then the cells become empty.
                   Move: take them out; the rest of the strip closes up.
  Ctrl+Shift+V  paste over   Paint only: write the block over the cells
                   starting at the first selected cell (or the cell under
                   the mouse); it carries on past the red line if needed.
  Ctrl+V  insert paste   Paint and Move: the block goes in front of the
                   target colour, pushing the rest along (see THE RED LINE
                   for where the push goes). Never refused.
  Pasted colours become the selection. If the system clipboard holds a hex
  list copied elsewhere since your last Ctrl+C, that list is pasted instead.
  Paint: cuts / pastes are pending edits (Snapshot records them). Move: each
  is one undo step (Ctrl+Z), recorded by Apply.

MANUAL DELETE  (Cull tools)
  Delete / Backspace / the "Delete / restore selected" button
                    marks the selected colours as deleted   Marker: bar -
                    Do it again on deleted colours to restore them.
  Deleted colours are left out of exact / similar matching completely, are
  baked by Snapshot and are left out of exports. In the Align view they
  vanish, so switch Align off to reach them again.

MOVE TOOLS  (Move button or M key - needs a clean snapshot)
  Select first, then drag: dragging a SELECTED colour moves the
  selection; dragging from an unselected colour (or outside the grid)
  draws a selection box as usual (Shift adds, Ctrl toggles). To move one
  colour: click it, then drag it.
  A dropped colour lands on the slot and the colours in between shift
  along. Alt + drag (or "Swap instead of insert") swaps two single colours
  instead. A multi-colour selection moves as a block, in order, with its
  gaps closed up.
  Undo move / Ctrl+Z   undoes moves one at a time
  Apply                records the moves as one "Moved colours" entry
                       (the window stays open)
  Revert               back to how it was at the last Apply / opening
  Closing with unapplied moves asks Apply / Discard / Cancel. History
  can't be stepped while moves are unapplied.

PALETTISED PREVIEW
  Opens a separate window.
  Open folder...  every PNG in the folder and its subfolders - Type: Loose.
  Open WAD...     Type: All / Patches / Sprites / Flats / Graphics, plus
                  TEXTURE1 and TEXTURE2 when present:
    TEXTURE1 / TEXTURE2  every texture the lump defines, composited from
        its patches. Each lump comes from the WAD if it has one, else from
        the IWAD. The WAD's lists use the WAD's PNAMES (else the IWAD's);
        IWAD lists use the IWAD's. Patches are looked up by name in the WAD
        first, then the IWAD. Missing patches leave a transparent gap and
        are named in the info line (red name in Grid view).
    All  this WAD's own graphics plus the textures it defines itself.
  Doom-format graphics are decoded with the WAD's PLAYPAL, else the IWAD's,
  else the loaded palette. Type / name filters narrow the list.
  Up / Down (or PgUp / PgDn, or the arrow buttons) cycles through them.
  The image is shown converted to the CURRENT result palette (the colours
  an export would write right now) and updates live as you edit.
  Space flips Palettised / Original. Wheel zoom, middle-drag pan, F fit.
  Single / Grid: Grid shows columns x rows images per page (default 4x4,
  1-16 each). All images share one pixel scale so relative sizes are true;
  each cell is the size of the page's largest image. Up / Down moves a
  page and refits; zoom and pan freely in between. Names show on the
  cells when large enough (Names tick box or N key hides them); hover
  shows details; double-click an image to open it in Single view.
  Dither: Floyd-Steinberg on / off. Matching is nearest RGB.
  Source images and WADs are only read, never modified.

  Apply COLORMAP lighting (tick box under the image):
    Shows the images the way Doom's software renderer lights them, through
    the CURRENT COLORMAP (generated + your hand edits; it updates live).
    Sector light 0-255 and Distance (16-2048 map units) pick the COLORMAP
    row with vanilla's own light-table maths (320x200 reference, full
    screen); the info line shows the row used.
    Wall / sprite or Floor / ceiling (they use different distance tables).
    Diagonal / East-West (one band darker) / North-South (one band
    brighter) - Doom's fake contrast on axis-aligned walls.
    Corridor (single view): the image as a wall receding in perspective
    from 48 to 2048 units - every row the engine would use, in one picture.
    Invulnerability shows row 32 (only offered when COLORMAP mode's "Show
    invulnerability + dark rows" is ticked).
    Space compares with loaded COLORMAP: Space then flips between the
    current palette + COLORMAP and the loaded PLAYPAL + COLORMAP at the
    same light and distance (instead of Palettised / Original).
    Ports with lighting options, other resolutions or GL renderers can
    differ from the vanilla maths.

SNAPSHOTS - work like export + reload
  Snapshot   (Cull tools) takes the current result exactly as an export
             would (culling applied, packed toward 0 if Align is ticked) and makes
             it the working palette. Everything after that works on the new
             palette as if you had exported it and loaded it again.
  History    every entry is a complete palette. Click one to load it.
             Back / Ctrl+Z loads the previous entry.
  Remove     deletes the current entry and loads the one before it.
             #0 Original can't be removed.
  Collapse   keeps only the current entry and makes it the new #0 (asks
             first - the other entries are gone for good).
  A snapshot taken after stepping back discards the later entries.
  History lives in the session unless you save a project. Closing with
  changes that are neither exported nor saved as a project asks first.
  Loading a palette starts a fresh history.

COLORMAP MODE
  The COLORMAP is 34 rows x 256: rows 0-31 light levels (0 = full bright),
  row 32 invulnerability, row 33 dark. Every cell names a palette index -
  lighting can only ever pick colours already in the palette.
  The working COLORMAP is GENERATED from the current palette and updates
  with every palette change; your hand edits sit on top of it.

  COLORMAP tools  (side panel - one window at a time, like the PLAYPAL tools)
    Generate        Matching, Fade curve, Fade toward, Invulnerability,
                    Auto-fill - how the whole COLORMAP is built
    Fade edit       Full bright / Normal, Fade through the selection, per-colour
                    fade curve, Copy / Paste fade shape, Clear hand edits
    Limit           store target colours, limit fades to them
    Create colours  find new palette colours for better fades
    Ramps           build one colour's fade from palette colours (below)
    AutoRamps       smooth fades for the whole palette / a selection (below)
    Light curve     lighten or darken a finished COLORMAP (below)
    Diagnostics     the problem list (a viewer - changes nothing)
    Changes show live in the fade view. Apply records them as ONE history
    entry (Back undoes it - including Generate settings); Revert puts them
    back; closing with unapplied changes asks Apply / Discard / Cancel.
    While a tool is open, brush strokes in the fade view join its session.
    COLORMAP files (Open / Import / Export) stay in the side panel.

  RAMPS tool - hand-build one colour's fade from palette colours
    1. Select colours in the palette grid, then click a colour's NUMBER at
       the left of the fade view (it turns gold). Open Ramps.
    2. The tool reads that colour's current 32 levels and finds the fewest
       nodes that rebuild them exactly - Apply straight away changes nothing.
    3. Edit: click a level to add a node (a palette pop-up appears - nodes
       can only be palette colours) or to recolour one; drag a node to move
       it; right-click to remove it. Level 0 is the colour itself (locked).
       Clear nodes = start over (level 0 + your fade-toward colour at 31);
       Reset to current = re-read the colour's levels.
    Rows: current (now) / ideal (smooth OKLab blend between nodes; RGB with
    Classic matching) / result (what Apply writes). Orange underline = that
    level changes. The levels between nodes are chosen together as the run
    of palette colours closest to the ideal, not snapped one at a time:
      Never get lighter  each level as dark or darker than the one before
                         (relaxed where your own nodes get lighter)
      Smooth             favours even steps over occasional exact hits
    Apply writes all 32 levels as that colour's hand edits. Click another
    colour's number to ramp it next. The older "Ramp tool..." on the fade
    toolbar (several strips at once, true colour) is still there.
    AUTO - shape the fade instead of placing nodes (sliders update live)
      Darken curve      how fast lightness falls (>1 holds bright longer)
      Hue drift         degrees the hue turns on the way down (pink -> red ->
                        brown is a positive drift for most pinks)
      Colour fade start / Grey by level   colour holds until the first, then
                        fades to grey by the second (a grey stage before black)
      End               Black, or your Fade toward colour
      Untick Auto to turn the result into nodes you can edit by hand.
    MATCHING (manual and Auto)
      Lightness / Hue / Colourfulness   what matters most when a palette
                        colour is picked for a level (hue high = stays in the
                        family; lightness high = gets the darkness right)
      Only use          all colours / the colours selected in the grid / the
                        Limit tool's stored targets
    ADD NEW COLOURS (Auto) - tick it and set how many (1-16): it picks the new
      colours (from the ideal) that improve the whole ramp most and puts them
      in the palette - empty slots first, then inserted right after the
      colour. A red warning lists any colour that would be pushed below the
      red line. "+" marks result levels using a new colour. Revert / Discard
      take them out again; Apply records colours + ramp as one entry (and
      switches Add new colours off so it doesn't keep adding).

  AUTORAMPS tool - smooth fades for the whole palette (or a selection)
    Like Ramps' Auto mode, for every colour at once. Goal: fades as smooth
    to black as possible, keeping colour instead of going grey.
    Shape: Darken curve, Hold colour until, Grey by (31 = never), End.
    Hue: Hue freedom = how far a fade's hue may wander as it darkens (more
      with depth); inside that window hue costs nothing, so each fade finds
      whichever neighbouring hue has dark colours in your palette. Keep
      colour = how much greying out is penalised. Lean = Warm / Cool tie-break.
    Matching: Lightness / Hue / Colourfulness weights, Only use, Never get
      lighter, Smooth.
    Add new colours: Find colours picks the colours that help the most fades
      at once (shared dark tints) - empty slots only, capped at how many are
      free. Click a swatch to leave it out, double-click to edit it.
      Make room by culling (Quick / Careful): if you ask for more than are
      free, near-identical colours are merged into their twin to free slots.
      Careful keeps the twin more fades use. Your graphics are indexed, so
      Apply offers a cull report (old index -> kept index) for remapping.
    Summary: average / worst miss and how many fades go grey early. Worst
      fades list: click one to view it. Whole palette takes ~0.5-2 s per
      change (sliders update when released); small selections are live.

  LIGHT CURVE tool - lighten or darken the COLORMAP you have now
    Works on any COLORMAP (generated, hand-edited, AutoRamps, imported as hand
    edits). Each light level takes its colour from another level of the same
    fade, so fades keep their shape - just stretched or squeezed. Level 0 and
    full-bright colours never change. Opens neutral (no change).
      Brightness (+ lighter)   + = fades stay bright longer, - = darken sooner
      Black at level           where the darkest step is reached: 31 = as now,
                               higher = later (lighter), lower = sooner
      Smooth in-betweens       a level between two steps uses the palette
                               colour nearest their blend (less banding)
      Colours                  whole palette or the selected colours
    Check it in the Palettised preview (COLORMAP lighting / Corridor) while
    you drag. Apply writes the levels as hand edits (one history entry).

  REORDER AND THE COLORMAP - reordering, moving, cutting and inserting
    palette colours carries every colour's fade (hand edits, AutoRamps, Light
    curve, full bright) to its new position, so the exported COLORMAP always
    matches. A loaded reference COLORMAP is matched by colour, so it stays
    correct too.

  FADE EDIT - Fade through is live: the selected colours fade into each
    other; change order / steps / end or the selection and it updates.
    Add colours into the chain's biggest gaps (empty slots only). The More
    section (Full bright, Normal, Clear hand edits, Fade curve, Copy / Paste
    shape) bakes the live preview in before acting.

    SHOW MISSES (Ramps) - a bar per level: how far the result is from the ideal
      (yellow = visible, red = clearly off). Hover a level for the numbers.
      Runs of red = where your palette is thin.

  Generation (Generate tool)
    Matching   Perceptual (OKLab) keeps hue better in the darks; Classic
               (RGB) is exactly Freedoom's / id's generator.
    Fade curve 1 = linear like Doom; above 1 stays bright longer, below 1
               darkens sooner.
    Fade toward  black by default; a tint gives coloured darkness.
    Invulnerability  Inverse grey (Doom's formula), From loaded COLORMAP
               (matched by colour), or None (copy row 0). Hidden unless
               "Show invulnerability + dark rows" is ticked.
    Show invulnerability + dark rows  off by default: the fade strips show
               rows 0-31 only and the matrix 32 rows. Exports always write
               all 34 rows (row 32 inverse grey, row 33 dark).
    Auto-fill smoothly between hand-set steps: a colour with some hand-set
               steps fades along a smooth path through them instead of the
               plain fade - pin rows 12 and 24 and the rest follows.
  Open COLORMAP...   a WAD's COLORMAP lump, a raw .lmp, or a 256 x 32-34
               image (pixels = palette colours). It is kept for the
               preview compare and Import as hand edits (cells that differ
               from the generated ones become hand edits, matched by colour).
  Export...    COLORMAP lump (.lmp) or 256x34 image (.png), for exactly the
               palette an export writes now (removals packed or emptied the
               same way, hand edits remapped).

  Fade view (under the grid)
    Drag the bar between the palette grid and the fade view to resize them
    (remembered). On that bar:  ▲ Palette  minimises the palette grid so
    the fade view gets the full height;  ▼ Fades  shrinks the fade view
    to just the bar so the grid gets the room. Click the same button again,
    or double-click the bar, to restore the previous split.
    Fades: one strip per selected colour, light rows 0-31 left to right
    (numbered along the top), bright to dark. With "Show invulnerability
    + dark rows" ticked an extra column marked I shows the invulnerability
    row - view-only here (set it with the Invulnerability dropdown).
    Matrix: the whole COLORMAP, 256 columns x 32 light rows (+ the I row
    when shown). Row 33, the unused all-black row, is never displayed
    (exports still write it).
    Markers (H): untick to see raw colours only - no hand-set triangles /
    squares, no "target gone" marks, no diagnostic outlines. Hover still
    tells you everything. Highlight problem steps (Diagnostics panel)
    switches the diagnostic outlines alone while Markers is on.
    Right-click a palette cell = brush colour (yellow dashed outline).
    Paint   click / drag cells to set them to the brush
    Erase   back to auto        Pick   take a cell's colour as the brush
    Ctrl + paint / erase = that step for every selected colour.
    All COLORMAP tools (Paint / Erase / Pick, Clear hand edits, Import as
    hand edits, the bulk tools, diagnostics, Create fade colours) work on
    light rows 0-31 only; the invulnerability row and row 33 are left alone.
    Corner triangle = hand-set; red slash = hand-set target was removed /
    deleted (auto used meanwhile). Wheel scrolls long selections.
    Each stroke is one history entry (Back undoes; the selection stays).

  Ramp tool on fades (Ramp tool in the fade view toolbar)
    Build fades with the Ramp tool. Choose strips first (Fades view):
      click an index number   = the whole strip (rows 0-31)
      click a cell            = that strip from that row to 31
      Ctrl + click            = add another strip with ITS OWN start row
                                (e.g. 112 whole, 113 from 20, 114 from 30);
                                Ctrl + click a chosen index removes it
      Shift + click an index  = whole strips from the last one to this one
    Gold outline = reference strip (the last one clicked), cyan = others;
    rows before each start are dimmed and left alone.
    "Ramp tool..." opens the Ramp tool in fade mode:
      start node = LOCKED: the colour the fade continues from (the colour
        itself for a whole strip, or what the row before the start shows);
      end node = row 31; add nodes, blends and easing as usual.
      RELATIVE: nodes are stored as changes from the start (lightness and
        colourfulness ratios, hue turn), so every strip gets the same shape
        of fade from its own colour, spread over its own rows.
      Steps: top = smooth ramp, bottom = palette colour it snaps to (the
        COLORMAP can only use palette colours); red underline = poor snap.
      Add missing colours (budget): new palette colours (empty slots) that
        fix the worst snaps across all strips.
      Preview / Apply / Cancel: Apply writes each strip's range as hand-set
        steps (one history entry).

    Full bright / Normal      never darken (or undo that)
    Clear hand edits          the selection back to auto
    Fade down through the selection itself: treats the selection as a
      ramp (by Lightness or Index); each colour steps down through the
      others N steps per light level, then Black or Auto past the end.
    Store selection as targets + Limit to targets: the selected colours'
      fades may only use the stored colours (plus the fade colour) - stops
      reds drifting into muddy browns. Remove limit undoes it.
    Fade curve Set / Clear    a curve for just these colours
    Copy fade shape / Paste shape to selected: copies one colour's fade as
      a relative shape (offsets from its own colour) onto others.

  Create fade colours
    Works out which NEW dark colours would most improve the fades (whole
    palette or selected), up to the budget. Steps are weighted by how much
    the colour is used in the Palettised preview's images when it is open.
    The proposals window shows each colour, what it serves and the error
    before / after; untick any, then Add to palette - they go into empty
    slots (cull + snapshot first to make room) and the COLORMAP starts
    using them at once.

  Diagnostics
    Early crush (red)  falls to near black too soon
    Hue drift (orange) lands on a different hue than it should
    Big jump (yellow)  a much bigger brightness step than the ideal fade
    Far from ideal (purple)
    Click a colour in the list to select it and see its fade.

  Hand edits follow their colours through moves, sorts, Align packing and
  snapshots. Edits pointing at a culled colour follow the colour it merged
  into; otherwise they go back to auto (the snapshot status line says how
  many). Changing a colour (ramp, set colour) resets its own fade.

PROJECTS
  Save project / Save project as...  write a .cleanpal file (JSON):
    every history entry and which one is loaded, deleted marks, the
    selection, matching / sort / export / COLORMAP settings, every entry's
    COLORMAP hand edits, the loaded COLORMAP, the mode, the ramp, scratch
    sets, recent colours and picker mode. Palettes are stored inside, so the
    project still opens if the source WAD / PNG moves.
  Load project... (or Open..., or cleanpal mywork.cleanpal) restores it exactly. Its scratch
    sets are merged into yours (same name = project's version wins).
  A project save counts as saved for the close warning.
  Hover info and analysis PNGs refer to the working palette's indices.

HOVER
  Shows index, RGB and Lab. Hovering a removed entry outlines the colour
  it collapses into; hovering a kept entry outlines what it absorbed.

EXPORT - writes what the grid currently shows. Export... (top bar) exports
  the palette in PLAYPAL mode and the COLORMAP in COLORMAP mode, using the
  format chosen in the side panel.
  With the Cull tools open: the culled result (packed if Align is on).
  With no tool open: the palette as it is. Paused in Move / Reorder / Paint.
  DoomTools playpal.png        256x14, Doom pain / item / radsuit tints
  DoomTools blank playpal.png  256x14, pal0 copied to every row
  SLADE pal0.png               128x128 grid, 8x8 cells
  SLADE pal0.pal               768 byte raw palette
  SLADE playpal.pal            14 x 768 bytes, tinted
  Analysis PNGs                original cleanpal0 outputs, into a folder:
     -identical-  stage 1 removals at their original slots
     -similar-    stage 2 removals at their original slots
     -aligned-    kept colours packed from slot 0
     Split        also one -keepNNN file per set / cluster

  Removed / empty slots are TRANSPARENT in PNGs and GREEN (0,255,0) in
  .pal files. Green stays untinted in every palette so it reads as a
  placeholder. You are warned if a kept colour is exactly (0,255,0).

  Filename token: (DE2000-1.5) / (CIE-2.0) / (RGB-1.1) with similar on,
  (EXACT) for
  exact only, (NONE) with no matching.

SETTINGS
  Everything is remembered when you close: matching tick boxes, metric,
  each metric's tolerance, Align, sort method and options, export format,
  split, window size /
  position and the last folder. Stored in
  %%APPDATA%%\\cleanpal\\cleanpal_settings.json. You are told if saving fails.

PRESETS
  Save preset...  writes the matching, sort + export setup to a .json file:
                  tick boxes, metric, every metric's tolerance, Align,
                  sort method and options, export format and split (no
                  window size or folders).
  Load preset...  applies one immediately. The preset's name shows in
                  the title bar.
  Default folder: %%APPDATA%%\\cleanpal\\presets
""" % VERSION
