"""In-app help text."""

from ..cleanpal_lib_constants import VERSION


# ============================================================ GUI
HELP_TEXT = """\
cleanpal v%s - Doom PLAYPAL / COLORMAP editor

MODES  (Mode dropdown, top bar)
  PLAYPAL    the palette tools (Cull / Move / Reorder / Paint), view, export.
  COLORMAP   the light tables: the palette grid shrinks to a selector, a
             fade view appears under it and the side panel shows the
             COLORMAP tools. Selection and history are shared by both.

IWAD  (IWAD button, top bar - always needed)
  The IWAD (doom2.wad, doom.wad, ...) supplies textures and patches for the
  Palettised preview, and the fallback PLAYPAL / COLORMAP. On first start
  cleanpal asks for it, offering one found beside the loaded file or in
  DOOMWADDIR / DOOMWADPATH (the folders dsda-doom searches).

NEW  (New... button, top bar)
  Starts a palette from scratch - no file needed. Start from:
    Empty            256 empty cells: paint, paste or insert into them
    Black            256 black cells, ready to overwrite
    Greyscale        256 greys, black to white
    Ramp grid        16 rows of 16 black-to-white greys - tint row by row
    IWAD PLAYPAL     a copy of the IWAD's PLAYPAL
    Copy of current  the open palette, without its history
  The new palette is "untitled": history starts at "New - <template>",
  every tool works on it, and Export / Save project ask for a name.
  Empty cells export the same way culled cells always have.
  "Start cleanpal with a new Empty palette" (in the New dialog, on by
  default) opens straight into an Empty palette when no file is given.
  Every template is exactly what it says - Empty is 256 empty cells. For
  black at 0 / 247 and the player ramps use Locks... > Lock reserved...
  Paint tools: Clear cells empties the selected cells, or with nothing
  selected every palette cell (held cells below the red line and locked
  cells stay) - a pending paint edit like any other.

COLOUR LOCK  (PLAYPAL - Locks... button in the Move and Paint tools)
  Locked cells are left alone by EVERY tool, even when they are selected:
    Paint      ramps, filters, the cell picker, cut, paste, Clear cells
    Cull       never culled or deleted, and never a keeper others merge into;
               Align packs the other colours around them
    Move / Reorder   they stay in place - the other colours flow around them
    Clipboard  paste-over steps over them, inserts never land on them
    COLORMAP   COLORMAP tools never put new colours there
  You can still select and copy them. Lock an EMPTY cell to reserve the slot.
  Lock selected / Unlock selected / Unlock all, double-click a cell (while
  the Locks popup is open) to toggle it, Select locked. Locks stay on when the tool closes, show as a
  small lock on the grid ("LOCKED" in the hover line), are saved in
  projects and don't add history entries. New / Open clear them.
  Lock reserved...  tick boxes that lock the slots of Doom's important
  ranges - whatever colours are in them, or none (build your own player
  colours there). Nothing is written or moved. Unticking unlocks them.
    Black - index 0      vanilla clears / automap, COLORMAP fades
    Black - index 247    Doom's second black (DeuTex transparent, Boom /
                         dsda automap background)
    Green ramp 112-127   player 1 sprite range - recoloured for the others
    Grey ramp 96-111     player 2      Brown ramp 64-79   player 3
    Red ramp 32-47       player 4
  Restore Colours  puts the original colours (the IWAD's PLAYPAL, or Doom's
  built in) back into the TICKED groups - with cells selected, only the
  selected cells of ticked groups. Per cell:
    already right          left alone
    empty                  filled
    another colour there   pushed along to the nearest free cell (past 255
                           it goes below the red line) - never overwritten
    the colour is elsewhere in the strip   that cell is moved in (even from
                           a locked cell) - no duplicate is added
  Other locked cells stay put during the push. One history entry.

PALETTE BROWSER: RESTORE
  "Original" is first in the list: the IWAD's PLAYPAL, or Doom's palette
  built in when no IWAD is set. Select cells, press Restore:
    normal       each colour into the SAME index in your palette, with the
                 Restore Colours rules above - no tick-box or lock limits
                 (other locked cells still stay put)
    Place in first free space   the colours, in order, into the first run
                 of empty unlocked cells that fits them all (colours already
                 elsewhere are moved in, not copied). No such run: they go
                 below the red line after the last filled cell there
                 (colours already in the strip aren't added again).
  Works from any palette in the list. No tool open = one history entry;
  in Paint it's a pending paint edit.

LOADING
  Open a WAD (PLAYPAL lump - and its COLORMAP lump, kept for compare /
  import; the IWAD's COLORMAP is used when the file has none), SLADE
  playpal.pal / pal0.pal, SLADE pal0.png, DoomTools playpal.png, a
  .cleanpal project, or a COLORMAP image. pal0 (the first 256 colours,
  or row / line 0 of an image) is shown as a SLADE style 16x16 grid,
  index 0 top-left.

TOOLS  (PLAYPAL - side panel: Cull / Move / Reorder / Paint / Lock)
  Each tool is a window; only one is open at a time and its button lights
  up (the grid border takes its colour). With no tool open the grid shows
  the current snapshot with no markers - select, step through history,
  export, save.
    Cull     matching (exact / similar), Align, manual delete, Snapshot.
             Culling ONLY runs while this window is open.
    Move     drag colours to new slots.
    Reorder  sort colours into ramps.
    Paint    palette ramps and solid fills.
  Move, Reorder and Paint need a clean snapshot. Culling keeps the FIRST
  colour of each group, so changing the palette with culls pending would
  change which colours get kept. Switching from Cull with marks on the grid
  says so and offers "Take snapshot and continue" or Cancel.
  While Move / Reorder / Paint is open: culling is paused, Align is
  ignored (slots = indices), Back / Ctrl+Z only steps through that
  session's entries, and Export / Collapse are paused.
  Closing Cull with marks pending asks: Take snapshot / Close without
  applying (the marks come back when you reopen Cull) / Cancel.
  Switching to COLORMAP mode closes the open tool; COLORMAP always works
  on the current snapshot (no culling there).

CULL TOOLS - MATCHING, runs in order (both optional: with neither ticked,
  just select cells and press Delete)
  1. Remove exact colours
     Entries with exactly the same RGB value. The first occurrence (lowest
     index) is kept, later copies are removed.            Marker: X

  2. Remove similar colours  (works with or without stage 1)
     Looks at what stage 1 left (without stage 1, exact copies are
     distance 0 and simply join a cluster). Pairs within the tolerance are
     joined into clusters, and clustering is TRANSITIVE: if A~B and B~C,
     then A, B and C are one cluster even if A and C are further apart.
     "Keep in each group" picks the survivor: First index, Most
     saturated, Lightest, Darkest or Nearest average.   Marker: O
     Under the tolerance: the next pair the slider would merge.

     CIEDE2000      (default) modern perceptual distance, built for judging
                    small differences. Corrects dE76's over-reaction to
                    saturated colours and its blue-purple distortion.
                    ~1 is just noticeable. Default 1.5.
     CIE Lab dE76   older perceptual distance. Cautious with vivid
                    colours. Default 2.0.
     Weighted RGB   channel-weighted RGB distance (0.299/0.587/0.114).
                    Blue barely counts. Default 1.1.

  Tolerance
     Drag the slider, click anywhere on its bar to jump there, use the
     mouse wheel over it (+/-0.05), or type in the box (applies as you
     type).
     In the box: Up/Down = +/-0.05, Shift+Up/Down = +/-0.5,
     mouse wheel = +/-0.05. Values above the slider range can be typed.

  Align
     Removes the removed entries and packs the kept colours toward index 0
     in their original order. The empty tail shows as a checkerboard.

TEXT FIELDS
  Every text / number box has a right-click menu: Cut, Copy, Paste,
  Delete, Select all. Ctrl+A selects the whole box while typing.

VIEW
  Mouse wheel      zoom toward the cursor
  Middle drag      pan
  Fit / F / double middle-click   reset to auto-fit
  The grid auto-fits as the window resizes until you zoom or pan.

SELECTION
  Click             select one colour
  Click-drag        box-select every colour inside
  Shift + click/drag   add to the selection
  Ctrl + click/drag    toggle colours in / out
  Ctrl+A            select all
  Esc / Clear       clear the selection
  Cull scope (under Remove similar):
    Whole palette          similar matching works on every colour
    Selected colours only  only the selection is culled; colours can only
                           merge with each other, unselected colours are
                           never touched. Nothing selected = nothing culled.
  In the Cull tools, selecting on the grid switches the scope to Selected
  colours only. Selecting is easiest with Align off - the grid reflows as
  culling changes.

REORDER TOOLS  (Reorder button -> Reorder tools window)
  Reorders the working palette into ramps (needs a clean snapshot - see
  TOOLS). You can select colours in the grid (with Preview off) to reorder
  just those.

  In the window pick a method, set its options, then:
    Preview   shows the result live on the grid (button turns blue). Changing
              any option re-sorts at once. While it is on, the selection is
              locked.
    Apply     keeps it and adds a "Reorder ..." history entry. Works with or
              without Preview. The window stays open, so you can select the
              next colour family and reorder that too.
    Cancel    (or Esc, or the Preview button again) restores the palette.

  Apply to:
    Whole palette        every colour is sorted; empty slots go to the end.
    Selected (gathered)  the selected colours are sorted and pulled together
                         into ONE block that starts at the first selected
                         slot. The other colours keep their order and shift
                         along to close the gaps. Select all the reds anywhere
                         in the palette and they end up as one red section.
                         The selection stays on the moved block afterwards.
    Opens on Selected if 2+ colours are selected, else Whole palette.
    Selecting in the grid while the window is open switches it to Selected;
    clearing the selection switches it back to Whole palette.

  Methods that find ramps:
    Curved ramps    (default, best on Doom's PLAYPAL) every colour links to
                    its nearest darker neighbour, cheapest links first, each
                    colour taking at most one lighter and one darker link.
                    Max step   longest allowed link (OKLab distance x100)
                    Max bend   how sharply a ramp may change direction - keep
                               it high for white -> colour -> black ramps
                    Hue/chroma weight  how much more a hue / colourfulness
                               change costs than a lightness change
    Line ramps      repeatedly takes the longest gap-free run of colours lying
                    on one straight line in RGB (ramps made by linear RGB
                    blending), removes it and repeats.
                    Line tolerance  distance from the line (RGB units)
                    Max gap         largest gap between neighbours on a line
    Shade families  colours with the same R:G:B ratio, i.e. one colour scaled
                    toward black. Ratio tolerance x100.
    Hue bands       greys first, then groups split at gaps in hue. Simple
                    baseline. Max band width in degrees.
  Shared options for those four:
    Order colours by   order inside each ramp (default OKLab lightness)
    Lightest / Darkest first
    Ramp order         Greys first then hue / Original position /
                       Largest first / By key (each ramp's highest value)
    Outliers           colours in ramps smaller than Min ramp size:
                       Join nearest ramp (if one is close, else left single),
                       Collect at end, or Leave single
    Min ramp size      smaller groups count as outliers

  Plain orderings (no ramps):
    Stepped hue     Alan Zucconi's hue x lightness buckets, alternating
                    direction. Smooth looking grid, not strict ramps.
    Gradient path   one nearest-colour chain through everything (OKLab),
                    tidied with 2-opt. Good on a selection.
    Single key      plain sort by the Order colours by key.
    Reverse         reverses the palette or the selection.

  No sort is perfect - try a few and compare. Sorting a selection (one
  colour family at a time) gives the most control.
  Method, options and direction are saved with the settings and presets.

  Ramp test (command line, no GUI):
    cleanpal --ramptest <palette> [folder]
  Shuffles the palette three times, runs every method with its defaults and
  reports how many of the palette's own ramps (runs of close colours in its
  current order) come back as neighbours. Writes <name>_ramptest.png with
  every result side by side.

PAINT TOOLS  (Paint button -> Paint tools window)
  Needs a clean snapshot (see TOOLS). Palette colours can only be changed
  here: the ramp, single cells, Clear cells, and scratch colours dragged
  onto the grid.

  Paint session - edits stay pending until you Snapshot
    Ramp Apply, Clear cells, single-cell picker edits and scratch drops
    change the working palette at once but add NO history entry. Change
    the selection between edits as much as you like.
    Snapshot   records everything since the last snapshot as ONE entry
               ("Painted: 3 ramps, 2 fills, 5 cells - ...")
    Revert     throws away everything since the last snapshot (or since
               Paint opened); the selection is kept
    Hide selection outline  hides the cyan selection, the ramp-target
               dashes and the picked-cell box. The selection stays active
               but is LOCKED - clicks, drags, Ctrl+A and Esc don't change
               it until you untick the box.
    Closing with pending edits asks Snapshot / Discard / Cancel. History
    (Back / the list) is locked while edits are pending.

  Live ramp preview  (Preview: ON by default, remembered)
    The ramp is shown on whatever cells are selected and follows the
    selection as you click and drag - no need to switch it off to select.
    Apply makes it a pending edit; the next selection starts a fresh preview.
    Any other edit (Fill, a filter, cut / paste, the picker, Snapshot,
    Revert, Back) pauses it; it comes back on your next selection or ramp
    change. Cancel clears it until the next selection. Preview: OFF stops
    it altogether. The preview never counts as a pending edit.

  Filters...  (Paint session row) - classic filters on the selection.
    The window opens with Preview on (remembered); its preview pauses the
    ramp preview while it runs.
    Pick a filter on the left, set its options (slider or number box).
    The strip shows the selected colours before (top) / after (bottom);
    blank cells are skipped. Preview shows it live on the grid - you can
    change the selection while previewing and it re-runs. Apply writes it
    (a pending paint edit - Snapshot records it). Reset = filter defaults.
    Cancel / Esc restores. Each filter remembers its settings.
      Levels                 input black / gamma / white, output range;
                             RGB or one channel
      Brightness / Contrast  Perceptual (OKLab) or Classic (RGB); pivot =
                             mid grey or selection average
      Hue / Saturation / Lightness   OKLCH (perceptual) or HSL (classic)
      Colorise               one hue, keeps lightness; hue / saturation or
                             the Paint fill colour; strength
      Black & white          Doom / Rec.601, Rec.709, OKLab L or a custom
                             channel mix
      Invert                 RGB, or lightness only (keeps the hue)
      Gradient map           lightness -> the Paint window's current ramp
                             (recolour a family, keep its shading)
      Even out ramp          even lightness steps, hue + chroma kept
      Temperature / Tint     warm / cool, green / magenta
      Posterise              N levels per channel, or lightness only

  Double-click a cell   colour picker on that one cell - changes apply
    live. The selection is left as it was. A white dashed box marks the
    cell. Double-click another cell to move the picker; picking a ramp
    node moves it back. Blank cells work too.

  Clear cells  (Clipboard row) empties the selected cells - held cells below
    the red line too; with nothing selected, every palette cell (held cells
    stay). Locked cells are skipped. Pending until Snapshot. The selection
    is kept, so with the ramp Preview on the gradient shows on the emptied
    cells straight away (Apply writes it); with Preview off they stay empty.

  Ramp
  Select the cells to fill in the main grid - blank (empty) cells and
  normal colours can all be selected. The ramp fills them in INDEX ORDER,
  one step per cell; scattered cells work too.

  Gradient bar
    Start and end nodes are fixed at the ends.
    Click the bar        add a node there (it takes the colour shown, so the
                         ramp doesn't jump)
    Drag a node          move it            Right-click / Del   remove it
    Double-click a node  open the colour picker on it
    Node row: swatch (click = picker), hex box, position %%, Delete node.
    Right-click the swatch or hex box to copy / paste the node colour.
  Blend
    OKLab            (default) even-looking steps, no muddy middle
    RGB              plain RGB mixing, like most paint programs / Doom's ramps
    OKLCH (hue path) goes round the hue wheel - the most vivid in-betweens
  Ease     Linear / Ease in / Ease out / Ease in-out, Strength 1 - 6
  Ease applies to: Whole ramp, or Each segment (every node-to-node stretch
           eases on its own). With whole-ramp easing the nodes are drawn
           where their colour actually lands on the bar.
  Reverse              flips the ramp
  Use selection ends   start / end take the first / last selected cells'
                       colours (extend or smooth an existing ramp)
  Steps strip          the actual colours that will be written, with hover
                       info. Dot = same RGB as an earlier step; corner
                       triangle = already in the palette elsewhere (Remove
                       exact would flag it).
                       Click a step = don't add it (red cross; click again
                       to undo) - that cell keeps what it had.
  Only add unique colours   (tick box, remembered) steps that exactly match
                       a colour already in the palette / below the red line,
                       or an earlier step, aren't written (white cross) -
                       their cells keep what they had.
  Preview (live on / off) / Apply / Cancel: Apply writes the ramp into the
  selected cells (a pending paint edit - Snapshot records it).
  Load ramp... / Save ramp... store nodes, blend and easing as .json.
  The ramp is remembered between sessions and saved in projects.

COLOUR PICKER  (popup - Picker... / double-click a node / swatch)
  Non-modal: edits apply live to the node, the steps and the grid preview.
  Clicking another ramp node switches the picker to that node.
  Modes (dropdown) - all edit the same colour, switching never changes it:
    RGB Sliders        R / G / B sliders + full spectrum box (hue across,
                       white - colour - black down)
    HSL Sliders        H / S / L sliders + hue x lightness box drawn at the
                       current saturation
    HSL Colour Wheel   hue ring + saturation / lightness triangle; the
                       triangle turns so its pure-hue tip always points at
                       the ring marker
    HSL Box            Affinity style: a strip across the top + a square.
                       The dropdown picks what the strip drives:
                         Hue        strip = hue, square = S across, L up
                         Saturation strip = S, square = hue across, L up
                         Lightness  strip = L, square = hue across, S up
    Photoshop          square + upright strip + 9 radio fields. The radio
                       picks the strip channel, the square shows the other
                       two of its group: H S B (HSB / HSV), R G B, L a b.
                       Lab squares hold colours RGB can't show - those
                       parts are hatched and picking there clips to RGB.
    OKLCH Sliders      perceptual L (0-100), C (chroma, 0-37) and H, with
                       number fields. Out-of-RGB parts of a track are
                       hatched; the colour clips by lowering chroma.
    LAB Sliders        CIE L* a* b* sliders + number fields (hatched where
                       out of RGB; the colour clips to RGB)
    Greyscale Slider   one black-to-white slider: sets R = G = B; shows
                       the current colour's luma
  HSL Box remembers its dropdown and Photoshop its radio choice.
  Values set in a model stay where you put them while the colour is
  unchanged (the hue of a grey, the saturation of black, a clipped Lab).
  Hue and saturation are remembered through greys, black and white, so
  dropping saturation to 0 and back keeps your hue.
  Fields: R G B (0-255), H (0-360) S L (0-100), R# G# B#, and # hex.
  The # box takes EBEBEB, #EBEBEB, #ebe or 235,235,235; Ctrl+C / Ctrl+V.
  Right-click any field or the swatch: Cut / Copy / Paste / Select all, plus
  Copy colour as hex, Copy colour as R,G,B and Paste colour (applies a
  copied colour in any of those forms to the whole colour).
  Precision:  Shift + drag = fine (quarter speed)   Ctrl + drag = lock to
              one axis   arrow keys nudge the last-used control by 1
              (Shift = 10)   mouse wheel on sliders / fields = 1 (Shift 10)
  Swatch: left = new, right = colour when the node was picked - click the
  right half to revert.
  Eyedropper: click anywhere on screen (any program); a magnifier shows the
  exact pixel. Esc / right-click cancels.
  Recent: last 16 colours used. On top keeps the window above others.

SCRATCH PALETTE  (Scratch palette... button)
  Temporary swatches in named sets (New / Rename / Delete).
  Add:   + Picker (current picker colour), + Selected (selected grid
         cells), Eyedropper, Ctrl+V (hex lines), or drag cells from the
         main grid onto it (a selected group drags as a group).
  Use:   click a swatch          -> picker / active ramp node
         drag onto a grid cell   -> writes it into the palette (Paint)
         drag onto the ramp bar  -> recolours that node (or adds one)
         drag onto the picker    -> sets the picker
         Fill selected           -> writes it into every selected cell
                                    (Paint tools must be open)
         Palette writes become "Set colour ..." history entries.
  Manage: drag to reorder, Shift / Ctrl click to multi-select, Del
         removes, Ctrl+C copies as hex. Right-click a swatch: Copy hex,
         Copy R,G,B, Paste colour(s) here, Send to picker, Remove. A dot marks swatches whose
         colour is already in the palette; hover shows where.
  Import: hex text, GIMP .gpl, JASC .pal or raw .pal (as a new set).
  Export: .gpl or hex .txt. Sets are kept between sessions and in projects.

THE RED LINE - HELD CELLS
  The grid is a strip: the first 16 rows (256 cells) are the palette, then a
  red line, then held cells - as many rows as you're using, plus one spare
  empty row. Only the 256 above the line are the palette: held cells are
  never culled, reordered, used for COLORMAP, previewed or exported. Use
  them to park colours (a ramp you're working on, colours you might want
  back) while you work on the rest.
  Held cells select, move (drag across the line either way, cut / insert)
  and paint (ramps, fills, filters, picker, paste) like any other cell.
  They're kept in history and projects. The status line shows "Held: n".
  Nothing ever runs out of room: inserts and pastes that don't fit just
  carry on past the red line. Inserts fill holes on the same side of the
  line first (after the target, then the nearest before it), so cut +
  insert is still a move. Snapshot keeps the held cells.
  In COLORMAP mode only the 256 palette cells are shown.

PICKING COLOURS FROM THE PREVIEW  (Palettised preview - one image at a time)
  Paint tools: "Sample region..." brings the preview forward for this.
  Single view: drag anywhere on the image. Grid view: start the drag on one
  image - the box stays inside it and reads that image's own pixels.
  Left-drag a box on the image: it stays as a selection (Shift-drag adds
  another box; a plain click clears them). The Picked colours... button
  (preview top line) opens the window with every colour inside the boxes,
  exactly as shown: the sprite's own colours in Original view, palette
  colours in Palettised view, lit colours with COLORMAP lighting on
  (Corridor too). Once open it follows the boxes. Transparent pixels are
  ignored.
  Show on palette (toggle, preview top line) - like SLADE's colour remap
  preview: the pixel under the mouse marks the palette cell it uses with a
  black box inside a white one, in the main grid and in the Palette Browser
  (dashed = nearest, not exact); the info line gives the index. With a box
  selection, the colours inside it get a gold outline (in both); the hover
  box still shows on top.
  Picked colours (opens alongside any tool):
    Sort         Most used / Lightness / Hue
    Merge similar   (originals only) groups near-identical shades
    Copy         to cleanpal's clipboard (Ctrl+V / Ctrl+Shift+V in the grid)
    Copy hex     the hex codes as text - paste into a ramp node's hex box,
                 the Scratch palette, anything
    Copy Cells / Insert Cells   into the main palette, as in Palette Browser
    To scratch   add them to the current Scratch palette set
    Select in palette   select the main-grid cells holding those colours
    Remove colours already in palette   (tick box, remembered) hides every
                 swatch that exactly matches a colour in your palette or
                 below the red line - what's left is new, so every button
                 only adds new colours
    Right-click a swatch   cross it out: it is never added by any button
                 (right-click again to undo)
    Drag a swatch onto the Paint ramp bar (a node), a palette cell (Paint)
    or the colour picker. White corner = already in your palette; the bar
    along each swatch's foot = how many pixels use it.
    Paint ramp (needs the Paint tool open):
      Add to ramp nodes   the chosen swatches (or all shown, max 32) onto
                   the ramp bar, dark -> light; Replace nodes = they become
                   the bar's nodes, evenly spaced (else added between)
      Build ramp   the main grid's selected cells get a dark -> light ramp
                   that best represents the picked pixels (only the chosen
                   swatches, if any). It starts the ramp preview: Reverse,
                   tweak nodes, Apply or Cancel as usual. Locked cells are
                   skipped.
        Method  Match pixel distribution (default) - each step stands for
                an equal share of the pixels, so more steps go where the
                art has more pixels
                Even lightness - equal lightness steps from the darkest to
                the lightest picked pixel

PALETTE BROWSER  (Tools panel -> Palette Browser... - a reference window, opens alongside any tool)
  Browse other palettes and copy colours out of them.
  Add...       load pal0s: WAD PLAYPAL, SLADE .pal / pal0.png, DoomTools
               playpal.png, a .cleanpal project (its current entry). Pick
               several at once. The IWAD's PLAYPAL is always listed first.
               The list is remembered.
  Remove / Clear   take palettes off the list (the IWAD stays).
  Single / Tile    one big palette, or C x R at once. Up / Down (or the
               wheel) = next palette; in Tile the active one is outlined.
  Mark colours already in my palette   white corner = exists in yours;
               hover also says "also in working palette at #n".
  Select like the main grid (click / drag / Shift / Ctrl / Ctrl+A), then:
    Copy (Ctrl+C)   to the shared clipboard (index order, no gaps) - nothing
                    else changes
    Copy Cells      into the cells selected in the main grid, one for one in
                    index order. Extra colours are dropped; extra cells are
                    left alone.
    Insert Cells    in front of the main grid's first selected cell, pushing
                    the rest along. Colours already in your palette (or
                    below the red line) are skipped - inserts never add
                    exact duplicates (Ctrl+V insert paste too).
    Drag one colour onto a main-grid cell to set it (Paint tools).
  Copy Cells / Insert Cells act on the main palette straight away:
    no tool open  -> one history entry ("Copied 6 cells from x.pal"), Back
                     undoes it
    Paint open    -> a pending paint edit (Snapshot records it)
    Cull / Move / Reorder open -> refused (close them first)
  They complain if nothing is selected in either window.

CLIPBOARD  (side panel buttons + Paint / Move windows; Ctrl+C works anywhere)
  Ctrl+C  copy     the selected colours, index order, blank cells skipped -
                   one gap-free block. Also put on the system clipboard as
                   hex (Scratch palette's Ctrl+V can take it).
  Ctrl+X  cut      Paint: copy, then the cells become empty.
                   Move: take them out; the rest of the strip closes up.
  Ctrl+Shift+V  paste over   Paint only: write the block over the cells
                   starting at the first selected cell (or the cell under
                   the mouse); it carries on past the red line if needed.
  Ctrl+V  insert paste   Paint and Move: the block goes in front of the
                   target colour, pushing the rest along (see THE RED LINE
                   for where the push goes). Never refused.
  Pasted colours become the selection. If the system clipboard holds a hex
  list copied elsewhere since your last Ctrl+C, that list is pasted instead.
  Paint: cuts / pastes are pending edits (Snapshot records them). Move: each
  is one undo step (Ctrl+Z), recorded by Apply.

MANUAL DELETE  (Cull tools)
  Delete / Backspace / the "Delete / restore selected" button
                    marks the selected colours as deleted   Marker: bar -
                    Do it again on deleted colours to restore them.
  Deleted colours are left out of exact / similar matching completely, are
  baked by Snapshot and are left out of exports. In the Align view they
  vanish, so switch Align off to reach them again.

MOVE TOOLS  (Move button or M key - needs a clean snapshot)
  Select first, then drag: dragging a SELECTED colour moves the
  selection; dragging from an unselected colour (or outside the grid)
  draws a selection box as usual (Shift adds, Ctrl toggles). To move one
  colour: click it, then drag it.
  The dragged colour lands on the cell you drop it on; a multi-selection
  keeps its EXACT shape around it (gaps included). The cells it left become
  empty and nothing else in the palette changes. The landing cells are
  outlined while you drag (red = refused).
  A colour already in a landing cell is never overwritten: it is pushed up
  the index order into the next empty cell (the colours between shift up
  one); past 255 the last one goes below the red line.
  Align       the moving cells land in one unbroken run from the drop cell,
              in index order (stepping over locked cells)
  Close gaps  closes the holes this move left behind: the colours after
              each hole slide down one, up to the next empty cell. Other
              gaps are left alone (Collapse gaps does the whole palette).
  Locked cells never move; a move whose shape would land on one is refused
  (tick Align to step over it). Alt + drag (or "Swap instead of move")
  swaps two single colours instead.
  Collapse gaps        palette colours slide toward index 0 in order and
                       the empty cells gather at the end (just before 255).
                       With cells selected: only between the first and last
                       selected cell. Locked cells stay put (the others
                       flow around them); cells below the red line are
                       never touched. A move like any other (Undo / Revert).
  Undo move / Ctrl+Z   undoes moves one at a time
  Apply                records the moves as one "Moved colours" entry
                       (the window stays open)
  Revert               back to how it was at the last Apply / opening
  Closing with unapplied moves asks Apply / Discard / Cancel. History
  can't be stepped while moves are unapplied.

PALETTISED PREVIEW
  Opens a separate floating window - its own taskbar button, it stays open
  when the main window is minimised, and it can sit on another monitor.
  F9 (anywhere in cleanpal) hides / shows it. Its position is remembered;
  if that monitor is gone it opens on the main screen.
  On top      keeps it above every window, other programs included
              (remembered).
  Live        (default) shows the working state: every edit as you make it -
              Cull sliders, Paint ramps / fills / filters, and the COLORMAP
              tools in the lit view -
              no Snapshot or Apply needed. Redraws are throttled while you
              drag (slower for big Grid pages) so the app stays smooth.
  Applied     shows the current history entry instead - flip Live / Applied
              to compare before and after a pending edit.
  Sources: the preview keeps a LIST of sources. The IWAD is always first
  (and follows the IWAD you set); Open folder... / Open WAD... add to the
  list (opening one already there just switches to it). The left / right
  arrow buttons and the dropdown switch sources; each source remembers its
  own Type, Name filter and image. Close removes the current source (the
  IWAD can't be closed), Close all leaves just the IWAD. The list is saved
  in projects (missing paths are dropped on load); a fresh start shows just
  the IWAD. Lost colours always works on the current source.
  Open folder...  every PNG in the folder and its subfolders - Type: Loose.
  Open WAD...     Type: All / Patches / Sprites / Flats / Graphics, plus
                  TEXTURE1 and TEXTURE2 when present:
    TEXTURE1 / TEXTURE2  every texture the lump defines, composited from
        its patches. Each lump comes from the WAD if it has one, else from
        the IWAD. The WAD's lists use the WAD's PNAMES (else the IWAD's);
        IWAD lists use the IWAD's. Patches are looked up by name in the WAD
        first, then the IWAD. Missing patches leave a transparent gap and
        are named in the info line (red name in Grid view).
    All  this WAD's own graphics plus the textures it defines itself.
  Doom-format graphics are decoded with the WAD's PLAYPAL, else the IWAD's,
  else the loaded palette. Type / name filters narrow the list.
  Up / Down (or PgUp / PgDn, or the up / down buttons after Fit to window)
  cycles through them.
  The image is shown converted to the CURRENT result palette (the colours
  an export would write right now) and updates live as you edit.
  Space flips Palettised / Original. Wheel zoom, middle-drag pan, F fit.
  Single / Grid: Grid shows columns x rows images per page (default 4x4,
  1-16 each). All images share one pixel scale so relative sizes are true;
  each cell is the size of the page's largest image. Up / Down moves a
  page and refits; zoom and pan freely in between. Names show on the
  cells when large enough (Names tick box or N key hides them); hover
  shows details; double-click an image to open it in Single view.
  Dither: Floyd-Steinberg on / off. Matching is nearest RGB.
  Source images and WADs are only read, never modified.

  Apply COLORMAP lighting (tick box under the image):
    Shows the images the way Doom's software renderer lights them, through
    the CURRENT COLORMAP (generated + your hand edits; it updates live).
    Sector light 0-255 and Distance (16-2048 map units) pick the COLORMAP
    row with vanilla's own light-table maths (320x200 reference, full
    screen); the info line shows the row used.
    Wall / sprite or Floor / ceiling (they use different distance tables).
    Diagonal / East-West (one band darker) / North-South (one band
    brighter) - Doom's fake contrast on axis-aligned walls.
    Corridor (single view): the image as a wall receding in perspective
    from 48 to 2048 units - every row the engine would use, in one picture.
    Invulnerability shows row 32 (only offered when COLORMAP mode's "Show
    invulnerability + dark rows" is ticked).
    Space compares with loaded COLORMAP: Space then flips between the
    current palette + COLORMAP and the loaded PLAYPAL + COLORMAP at the
    same light and distance (instead of Palettised / Original).
    Ports with lighting options, other resolutions or GL renderers can
    differ from the vanilla maths.

SNAPSHOTS - work like export + reload
  Snapshot   (Cull tools) takes the current result exactly as an export
             would (culling applied, packed toward 0 if Align is ticked) and makes
             it the working palette. Everything after that works on the new
             palette as if you had exported it and loaded it again.
  History    every entry is a complete palette. Click one to load it.
             Back / Ctrl+Z loads the previous entry.
  Remove     deletes the current entry and loads the one before it.
             #0 Original can't be removed.
  Collapse   keeps only the current entry and makes it the new #0 (asks
             first - the other entries are gone for good).
  A snapshot taken after stepping back discards the later entries.
  History lives in the session unless you save a project. Closing with
  changes that are neither exported nor saved as a project asks first.
  Loading a palette starts a fresh history.

COLORMAP MODE
  The COLORMAP is 34 rows x 256: rows 0-31 light levels (0 = full bright),
  row 32 invulnerability, row 33 dark. Every cell names a palette index -
  lighting can only ever pick colours already in the palette.
  The working COLORMAP is GENERATED from the current palette and updates
  with every palette change; hand edits already in your history (or
  brought in with Import as hand edits) sit on top of it.

  COLORMAP tools  (side panel)
    The COLORMAP tools are being rebuilt one at a time: Generate, Generate
    selected, Edit Ramps; the blank buttons are slots for the next tools.
    Tools open one window at a time: changes show
    live, Apply records them as ONE history entry (Back undoes it), Revert
    puts them back, closing with unapplied changes asks Apply / Discard /
    Cancel.

  GENERATE tool - a standard starting COLORMAP for the WHOLE palette
    Every fade goes to black. Locked fades and empty slots are skipped (the
    top line counts them); the fade / palette selections don't matter here.
    Writes rows 1-31 as hand edits - a starting point for other tools; row 0
    is the colour itself. Live - watch the Matrix / Fades view; Apply = one
    history entry, Revert puts it back. Settings are remembered.
    SLADE Generation  every setting back to SLADE's generateColormaps()
                   maths: each RGB channel x (32 - row) / 32 (rounded), then
                   the nearest palette colour by plain RGB distance - the
                   exact COLORMAP SLADE makes (also what the defaults give).
    Match          Nearest (default): every row on its own to the nearest
                   palette colour - RGB (SLADE / id) or Perceptual (OKLab).
                   Smart path: the 31 steps are chosen together - lightness
                   first, then colourfulness and hue, no odd jumps.
    Blend          Classic (SLADE): each channel scaled toward black.
                   Around the wheel: lightness / colourfulness / hue in OKLab,
                   keeping the hue. Straight: a straight OKLab line.
    Reach black at row  1-32 (32 = SLADE / Doom: black just past row 31).
    Darken curve   1 = even steps; higher stays bright longer.
    Dark colours finish sooner  0 = SLADE; higher = dark colours reach black
                   in fewer rows, then repeat it.
    Colour hold    (Around the wheel) how long colourfulness lasts.
    Hue freedom / Keep colour / Never get lighter  (Smart path only).
    Hold to compare: see the COLORMAP from before; Hold for true colour (fade
    bar): see the true-colour targets.

  GENERATE SELECTED tool - build chosen fades from a COLOUR POOL
    Edits only the selected fades: the fade selection (click fade numbers),
    else the palette selection. With nothing selected it changes nothing.
    Locked fades are skipped. Writes rows 1-31 as hand edits; live; Apply =
    one history entry.
    Select Colour Pool (toggle)  while it's on (lavender, "Picking pool..."),
                   clicks / drags in the palette grid pick the POOL instead of
                   the selection (Shift adds, Ctrl toggles) - the colours these
                   fades may use. Click it again or press Esc to stop.
                   The colours being edited are always in the pool (no need to
                   add them, and they get no dot). Other pool cells show a
                   green dot with a white ring (bottom left). Clear pool
                   empties it; an empty pool = the whole palette. The pool is
                   saved in projects and follows its colours when they move.
    Allow black    black is always usable as the last step (on by default).
    Match          Ladder (default): the pool is a staircase, light to dark
                   (By lightness) or in palette order (By index), and every
                   fade walks DOWN it, never back up, skipping steps lighter
                   than itself. Follow the curve = each row takes the step
                   closest to the row's target brightness (Reach / Darken
                   curve / Dark colours finish sooner); Even steps = the
                   steps spread evenly up to Reach. Smart path / Nearest work
                   as in Generate, limited to the pool.
    Blend / sliders as in Generate (greyed where they don't apply).

  EDIT RAMPS tool - the selected fades from ONE ramp you draw yourself
    Edits the fade selection (click fade numbers), else the palette
    selection; never the whole palette. Locked fades are skipped. Writes
    rows 1-31 as hand edits; live; Apply = one history entry.
    Ramp type      Gradient: one strip of colour nodes. Lightness + colour:
                   a grey Lightness strip (how dark each row is - set with
                   the Lightness slider) and a Colour strip (only hue and
                   colourfulness - changing it never changes the darkness);
                   Result shows the two together. Changing type resets nodes.
    Strips         32 cells = ramp positions 0-31. Node 0 (gold) is always
                   the brightest selected colour - it can't move or go.
                   Double-click a cell to add a node, drag a node along,
                   Delete (or Delete node) removes it. Pick index = click a
                   palette cell or a Matrix / Fades cell for that exact
                   palette colour; Picker... (or click the swatch) = any
                   true colour.
    Where fades start  every fade enters the ramp where the ramp is as dark
                   as its own colour - the marks above the strip. Row 0 is
                   always the fade's own colour.
    Pace           Same speed (default): one ramp position per row, so dark
                   colours reach the end sooner and stay there. Stretch to
                   fit: every fade spreads the rest of the ramp over all
                   31 rows.
    Blend          (Gradient) Around the wheel / Straight (OKLab) / RGB.
    Blend in       rows over which each fade eases from its own colour into
                   the ramp (0 = straight onto the ramp).
    Match          RGB or Perceptual - how the ramp is snapped to the palette.
    Show           True colour (default): the edited fades show the ramp as
                   drawn in the Matrix / Fades. Palettised: the real result.
                   Palettised + new colours (with Add missing colours on):
                   snapped to the palette PLUS the suggested colours. Mark
                   new colours (off by default, remembered) puts a white dot
                   on every cell that would use a new colour.
                   Nothing changes in the palette until Add to palette.
    Add missing colours  suggests up to Max new colours the palette lacks for
                   this ramp (worst misses first, near-black skipped; Max is
                   a limit - it stops when another colour wouldn't help).
                   Ticking it switches Show to Palettised + new colours.
                   The suggestions box can be made taller with the grip bar
                   under it (remembered); swatches grow to fit. Hover a
                   swatch for its hex and how many cells use it.
                   Ctrl+click swatches to pick them: then only the picked
                   ones are previewed and added (others shrink); Clear picks
                   = all again. Add to palette puts them in (After selection
                   / Empty slots, Keep together) and Show goes to
                   Palettised; Revert takes them out again.
                   Apply with Add missing colours ticked adds the colours
                   first (picked ones, else all; this section's placement),
                   rebuilds the fades on them and records it all as one
                   history entry; the tick box then turns off. If they can't
                   be placed, nothing is applied (the status line says why).

  COLORMAP files
    Open COLORMAP...   a WAD's COLORMAP lump, a raw .lmp, or a 256 x 32-34
               image (pixels = palette colours). It is kept for the
               preview compare and Import as hand edits (cells that differ
               from the generated ones become hand edits, matched by colour).
    Export...  COLORMAP lump (.lmp) or 256x34 image (.png), for exactly the
               palette an export writes now (removals packed or emptied the
               same way, hand edits remapped).
    Hide invulnerability + dark rows  ticked by default: the fade strips
               show rows 0-31 only and the matrix 32 rows. Exports always
               write all 34 rows. Fade edits never touch row 32 / 33 (a
               separate invulnerability tool will handle row 32).

  Fade view (under the grid)
    Drag the bar between the palette grid and the fade view to resize them
    (remembered). The fade view holds TWO panes, Matrix on top and Fades
    under it, with their own split bar. Fades keeps its height (remembered):
    the palette divider and window resizing only change the palette and the
    Matrix. On the fade bar:
    ▲ Palette  minimises the palette grid so the panes get the full height;
    ▼ Matrix / ▼ Fades  hide that pane (▲ shows it again); hiding both folds
    the fade view down to its bar. Double-click the bar to restore.
    Matrix: the COLORMAP as columns (one per colour) x 32 light
      rows (+ the I row when shown).
      Selected only (Matrix header, ticked by default): just the selected
        colours' columns, side by side - all 256 when nothing is selected.
      Unticked: all 256 columns, each selected colour marked cyan in the band
        above row 0.
    Fades: one strip per selected colour, light rows 0-31 left to right
      (row 0, the white heading, is the colour itself), bright to dark.
      With nothing selected in the palette it asks for a selection.
    Hold for true colour (button on the bar): while held, Matrix / Fades show
      the TRUE-COLOUR targets instead of the palette result - the open
      tool's own targets for the fades it edits, else the
      generator's ideal; hand-set / locked cells show their palette colour.
      Hover shows the target's hex. Release = back to the palette.
    Zoom: − / + / Fit in each pane's header, or Ctrl + mouse wheel. Wheel scrolls up /
      down, Shift + wheel sideways. Matrix and Fades keep their own zoom
      (remembered); Fit fits everything in the area.
    Hover any cell for its row, target colour and whether it is hand-set
    or locked. Row 0 is always the colour itself - it is never edited.

  Palette selection vs fade selection
    The palette selection is a FILTER: it decides which colours the Matrix /
    Fades views show. The FADE SELECTION decides what the COLORMAP tools work
    on: click a fade's index number (Fades) or the band above its column
    (Matrix) - white box = selected. Ctrl + click adds / removes, Shift +
    click adds a range. With no fade selection, tools work on every visible
    fade (the palette selection, or the whole palette). Fades that stop
    being visible drop out of the fade selection. Esc clears the fade
    selection first, then (pressed again) the palette selection.
    Right-click an index number / column band = lock or unlock that fade.

  Fade locks  (Lock / Unlock on the fade bar)
    Lock    freezes rows 1-31 of the selected fades (fade selection, else the
            palette selection) exactly as they
            are now. Nothing changes them - no tool, import, palette edit or
            settings change - until you unlock. You can still select them
            and see them in Fades and Matrix.
    Unlock  makes them editable again; nothing changes until a tool does
            (if the palette changed while locked, the frozen steps are kept
            as hand edits so the fade doesn't jump - one history entry).
    Nothing selected = a message asking you to select colours first.
    Right-click a fade's number / Matrix band toggles its lock directly.
    Gold padlocks mark locked fades: on the palette cell (top left - palette
    locks are top right), next to the fade's number in Fades and in the band
    above its Matrix column (a gold bar when columns are too narrow) - so you
    can see them with the palette minimised.
    Like palette locks: not history entries, saved in projects, follow
    their colours through moves / reorders / culls; New / Open clear them.

  REORDER AND THE COLORMAP - reordering, moving, cutting and inserting
    palette colours carries every colour's hand edits to its new position,
    so the exported COLORMAP always matches. A loaded reference COLORMAP is
    matched by colour, so it stays correct too. Edits pointing at a culled
    colour follow the colour it merged into; otherwise they go back to auto.

PROJECTS
  Save project / Save project as...  write a .cleanpal file (JSON):
    every history entry and which one is loaded, deleted marks, the
    selection, matching / sort / export / COLORMAP settings, every entry's
    COLORMAP hand edits, the loaded COLORMAP, the mode, the ramp, scratch
    sets, recent colours and picker mode. Palettes are stored inside, so the
    project still opens if the source WAD / PNG moves.
  Load project... (or Open..., or cleanpal mywork.cleanpal) restores it exactly. Its scratch
    sets are merged into yours (same name = project's version wins).
  A project save counts as saved for the close warning.
  Hover info and analysis PNGs refer to the working palette's indices.

HOVER
  Shows index, RGB and Lab. Hovering a removed entry outlines the colour
  it collapses into; hovering a kept entry outlines what it absorbed.

EXPORT - writes what the grid currently shows. Export... (top bar) exports
  the palette in PLAYPAL mode and the COLORMAP in COLORMAP mode, using the
  format chosen in the side panel.
  With the Cull tools open: the culled result (packed if Align is on).
  With no tool open: the palette as it is. Paused in Move / Reorder / Paint.
  DoomTools playpal.png        256x14, Doom pain / item / radsuit tints
  DoomTools blank playpal.png  256x14, pal0 copied to every row
  SLADE pal0.png               128x128 grid, 8x8 cells
  SLADE pal0.pal               768 byte raw palette
  SLADE playpal.pal            14 x 768 bytes, tinted
  Analysis PNGs                original cleanpal0 outputs, into a folder:
     -identical-  stage 1 removals at their original slots
     -similar-    stage 2 removals at their original slots
     -aligned-    kept colours packed from slot 0
     Split        also one -keepNNN file per set / cluster

  Removed / empty slots are TRANSPARENT in PNGs and GREEN (0,255,0) in
  .pal files. Green stays untinted in every palette so it reads as a
  placeholder. You are warned if a kept colour is exactly (0,255,0).

  Filename token: (DE2000-1.5) / (CIE-2.0) / (RGB-1.1) with similar on,
  (EXACT) for
  exact only, (NONE) with no matching.

SETTINGS
  Everything is remembered when you close: matching tick boxes, metric,
  each metric's tolerance, Align, sort method and options, export format,
  split, window size /
  position and the last folder. Stored in
  %%APPDATA%%\\cleanpal\\cleanpal_settings.json. You are told if saving fails.

PRESETS
  Save preset...  writes the matching, sort + export setup to a .json file:
                  tick boxes, metric, every metric's tolerance, Align,
                  sort method and options, export format and split (no
                  window size or folders).
  Load preset...  applies one immediately. The preset's name shows in
                  the title bar.
  Default folder: %%APPDATA%%\\cleanpal\\presets

PALETTE ANALYSER  (side panel: Analyser)
  One window, a mode dropdown. Scope (whole palette / selection), Live /
  Applied and On top apply to every mode. Distances use the Cull metric
  and its units. Click a colour = select that cell (Shift adds).
  Missing colours  (default) what a Palette Browser palette (or all of them) has
                   that yours does not. Dot = identical, triangle = within
                   Closeness, unmarked = missing. Hide marked blanks the
                   rest in place. Copy missing / To scratch.
  censor           runs the external censor analyser (cargo install
                   censor-analyser) and shows its plot. Locate censor...
  Hue / lightness  every colour by hue (across) and lightness (up).
  Ramps            index runs with a steady hue; red = lightness jumps or
                   goes the wrong way.
  Close colours    pairs within Closeness (what Cull's similar pass merges).
  Greyscale        lightness only, plus a dark -> light strip.
  Usage            how much each cell is used by a WAD / PNG folder, as
                   stored (indices) or after palettisation. X = unused.

LOST COLOURS  (preview: Lost colours... and Show lost)
  Which colours of the art your palette fails once palettised:
    lost    the cell a colour lands on is further than Closeness (Cull units)
    greyed  a colourful pixel landing on a grey (Greyed tick)
  Scope: This image / This page / Filtered (Type, Name, Filters) / Whole.
  Lost colours are grouped (within twice Closeness), biggest first, as
  Swatches or a List with the images that use them most. Click / Shift-click
  picks swatches, double-click shows the image using it most. Each swatch's
  corner triangle: magenta = lost, cyan = greyed.
  Insert   puts the picked swatches (none picked = all) into the palette as
           one history entry (a Paint edit while Paint is open), in PLAYPAL
           or COLORMAP mode. After selection = right after the highest
           selected palette index (nothing selected: after the last colour),
           everything after it moves along, past the red line if needed;
           Empty slots = only empty palette slots. Keep together = one
           unbroken run of indices. Exact duplicates are skipped,
           palette-locked cells never move, the list re-scans afterwards.
           Not while Cull / Move / Reorder or a COLORMAP tool is open.
  Copy (Ctrl+V in Paint inserts), To scratch, To ramp nodes (Paint's ramp
  bar).
  Show lost (preview, Palettised view): lost pixels magenta, greyed cyan.
  Scans are cached for good (per lump / per PNG file) in
  %%APPDATA%%\\cleanpal\\scans - the stock Doom / Doom II IWADs are built in.
  Save scan... / Load scan... (.cpscan) keep a custom WAD's scan to reuse.

ADJUST TOOLS  (PLAYPAL - side panel: Adjust)
  A stack of adjustments over the selected cells (nothing selected = the
  whole palette; locked and held cells are skipped), previewed live. Each
  has Mix %% and Fade (Even / Dark end / Light end / Middle, by lightness).
  On / off, Up / Down, Remove; Ctrl+Z removes the last one. Hold to compare
  shows the before. Apply = one history entry (Back undoes); Cancel drops
  the stack. Cells box: top half before, bottom half after; Match palette
  rows; drag the grip to resize.
  The Paint filters plus Curves, Vibrance, Hue shift ramp, Saturation
  along ramp, Shadows / Highlights, Colour balance, Split toning, Channel
  mixer, Selective hue, Exposure, Contrast S-curve, Match lightness (from
  the clipboard), Jitter, Replace colour.
""" % VERSION
