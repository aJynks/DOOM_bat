"""Invulnerability (COLORMAP tool): row 32 only - which palette colour every
colour becomes while invulnerable. (7.0.1 redesign - the 6.0.13 grid +
settings design was rejected.)

Window, top to bottom:
* True colour (press-in, setting invul_true) - True = the colours the
  method aims for, off = what row 32 really holds (nearest pal0). Hold
  (bottom row) shows the other view while held.
* Wrap (press-in) + number: the 256 strip breaks onto a new line every N
  colours (that sets the layout, not the window width); off = one line of
  256 with a scrollbar. Both remembered (invul_wrap / invul_wrap_n).
* The strip: all 256 indices, each cell = that index's row-32 colour.
* Method: Colour picker (addInvun's Recolour) / Gradient.

Colour picker = addInvun.py's method, the same maths: each palette colour's
grey (0.299 / 0.587 / 0.114) is inverted, Recoloured Affinity-style (the grey
is the HSL lightness, moved by Lightness shift; hue + saturation from the
picked colour - black stays black, white stays white, mid greys take the full
colour), then the nearest pal0 colour by plain RGB (lowest index wins a tie)
goes into row 32. Swatch click = the colour picker (pal0-WIP mode picks
from the palette). Until a colour is picked / the slider moved row 32 is left
as it is. Apply = one history entry.

Gradient (7.0.2): a gradient bar you draw (node rules as every gradient bar:
right-click = select, drag = move, < > = one cell, Alt+right-click = add,
Alt+click = delete, double-click = picker; Blend RGB / Straight / Around the
wheel) laid across the cells selected in pal0 (nothing selected = all 256)
in INDEX order: first selected = left end, last = right end. Each of those
cells' row 32 = that gradient colour (true colour), palettised (nearest pal0
RGB) like Colour picker. Unselected cells keep their row 32. Apply invert =
exactly the Colour picker method with the gradient colour of each cell (its
inverted grey -> Recolour with that colour's hue / saturation, Lightness
shift too). Follows the pal0 selection live."""

import colorsys
import copy
import time

from ..cleanpal_lib_colormap import INVUL_ROW
from ..cleanpal_lib_colour import hex_of, oklab
from ..cleanpal_lib_constants import ENTRIES
from ..cleanpal_lib_rampedit import _mix_lab, lab_to_rgb
from .gui_cmap_tools import CTOOL_COLOUR, _CWin
from .gui_gradslider import draw_node

METHODS = (("picker", "Colour picker"), ("gradient", "Gradient"))
LUMA = (0.299, 0.587, 0.114)          # addInvun.py's weights
UNDO_GAP = 0.6
BG = "#2a2a2a"
BLENDS = (("rgb", "RGB"), ("straight", "Straight"), ("wheel", "Around the wheel"))
INVUL_DEFAULTS = {"method": "picker", "colour": [128, 128, 128], "light": 0,
                  "grad": [[0.0, [0, 0, 0]], [1.0, [255, 255, 255]]], "blend": "rgb",
                  "invert": False}


def _clean_grad(v):
    """[[pos 0..1, [r, g, b]], ...] sorted, ends at 0 and 1, >= 2 nodes."""
    out = []
    if isinstance(v, list):
        for n in v:
            try:
                p = float(n[0])
                c = [max(0, min(255, int(x))) for x in n[1]][:3]
            except (TypeError, ValueError, IndexError):
                continue
            if len(c) == 3 and 0.0 <= p <= 1.0:
                out.append([p, c])
    out.sort(key=lambda n: n[0])
    if len(out) < 2 or out[0][0] != 0.0 or out[-1][0] != 1.0:
        return copy.deepcopy(INVUL_DEFAULTS["grad"])
    return out


def clean_invul(d):
    o = dict(INVUL_DEFAULTS)
    if isinstance(d, dict):
        if d.get("method") in [m for m, _t in METHODS]:
            o["method"] = d["method"]
        v = d.get("colour")
        if isinstance(v, (list, tuple)) and len(v) == 3 and \
                all(isinstance(x, int) and not isinstance(x, bool) for x in v):
            o["colour"] = [max(0, min(255, x)) for x in v]
        if isinstance(d.get("light"), (int, float)) and not isinstance(d.get("light"), bool):
            o["light"] = max(-100, min(100, int(d["light"])))
        o["grad"] = _clean_grad(d.get("grad"))
        if d.get("blend") in [b for b, _t in BLENDS]:
            o["blend"] = d["blend"]
        if isinstance(d.get("invert"), bool):
            o["invert"] = d["invert"]
    o["grad"] = copy.deepcopy(o["grad"])
    return o


# ------------------------------------------------------------ the maths
def inverse_grey(rgb):
    """0-255 grey of a palette colour, inverted (white -> 0, black -> 255)."""
    r, g, b = rgb
    v = int(round(LUMA[0] * r + LUMA[1] * g + LUMA[2] * b))
    return 255 - max(0, min(255, v))


def recolour(grey, hue, sat, light):
    """addInvun.recolour: Affinity-style Recolour of one grey (0-255) ->
    (r, g, b). hue 0-360, sat 0-100, light -100..100 (0 = no shift)."""
    l = grey / 255.0
    if light > 0:
        l += (1.0 - l) * (light / 100.0)
    elif light < 0:
        l *= 1.0 + light / 100.0
    r, g, b = colorsys.hls_to_rgb((hue % 360.0) / 360.0, l, sat / 100.0)
    return (round(r * 255), round(g * 255), round(b * 255))


def colour_hs(rgb):
    """Hue (0-360) and saturation (0-100) of the picked colour, HSL."""
    h, _l, s = colorsys.rgb_to_hls(*(v / 255.0 for v in rgb))
    return h * 360.0, s * 100.0


def nearest_rgb(pal, rgb, cache):
    """Nearest palette index by plain RGB distance, lowest index wins ties
    (empty cells never). pal: list of rgb or None."""
    hit = cache.get(rgb)
    if hit is not None:
        return hit
    r, g, b = rgb
    best, best_d = None, None
    for i, c in enumerate(pal):
        if c is None:
            continue
        d = (c[0] - r) ** 2 + (c[1] - g) ** 2 + (c[2] - b) ** 2
        if best_d is None or d < best_d:
            best, best_d = i, d
            if d == 0:
                break
    cache[rgb] = best
    return best


def picker_row(pal, colour, light, skip=()):
    """{s: (true rgb, index)} for every non-empty palette colour."""
    hue, sat = colour_hs(colour)
    cache = {}
    out = {}
    for s, c in enumerate(pal):
        if c is None or s in skip:
            continue
        t = recolour(inverse_grey(c), hue, sat, light)
        out[s] = (t, nearest_rgb(pal, t, cache))
    return out


def grad_rgb(nodes, t, blend="rgb"):
    """Gradient colour at t (0..1). nodes = sorted [[pos, rgb]], ends 0 / 1."""
    t = min(max(float(t), 0.0), 1.0)
    for (p0, c0), (p1, c1) in zip(nodes, nodes[1:]):
        if t <= p1:
            if p1 - p0 <= 1e-12:
                return tuple(c1)
            f = (t - p0) / (p1 - p0)
            if blend == "rgb":                   # plain sRGB mix (manual gradient)
                return tuple(int(round(c0[i] + (c1[i] - c0[i]) * f)) for i in range(3))
            A, B = (oklab(tuple(c0)), tuple(c0)), (oklab(tuple(c1)), tuple(c1))
            return lab_to_rgb(_mix_lab(A, B, f, blend))
    return tuple(nodes[-1][1])


def gradient_row(pal, cells, nodes, blend, invert, light):
    """{s: (true rgb, index)} for `cells` (index order): cell k of n takes the
    gradient at k / (n - 1). invert = the Colour picker method per cell with
    that gradient colour."""
    cells = sorted(cells)
    n = len(cells)
    cache = {}
    out = {}
    for k, s in enumerate(cells):
        c = pal[s]
        if c is None:
            continue
        g = grad_rgb(nodes, k / float(n - 1) if n > 1 else 0.0, blend)
        if invert:
            hue, sat = colour_hs(g)
            t = recolour(inverse_grey(c), hue, sat, light)
        else:
            t = tuple(g)
        out[s] = (t, nearest_rgb(pal, t, cache))
    return out


# ------------------------------------------------------------ gradient bar
class GradBar:
    """The Gradient method's bar: positions 0..1 across the target cells.
    Node rules as every gradient bar; the end nodes stay at the ends."""

    def __init__(self, parent, owner):
        tk = owner.app.tk
        ui = owner.ui
        self.o, self.ui = owner, ui
        self.H = int(round(26 * ui))
        self.nh = int(round(13 * ui))
        self.pad = int(round(8 * ui))
        self.c = tk.Canvas(parent, height=self.H + self.nh + 4, width=int(512 * ui),
                           bg=BG, highlightthickness=0, cursor="hand2")
        self.c.bind("<Configure>", lambda e: self.draw())
        self.c.bind("<ButtonPress-1>", self._press)
        self.c.bind("<B1-Motion>", self._drag)
        self.c.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag_k", None))
        self.c.bind("<ButtonPress-3>", self._right)
        self.c.bind("<Double-Button-1>", self._double)
        self._drag_k = None
        self._img = None

    def _x0x1(self):
        W = max(self.c.winfo_width(), 40)
        return self.pad, W - self.pad

    def _pos(self, x):
        x0, x1 = self._x0x1()
        return min(max((x - x0) / float(max(x1 - x0, 1)), 0.0), 1.0)

    def _node_near(self, x):
        x0, x1 = self._x0x1()
        nodes = self.o.o["grad"]
        best, bd = None, 7 * self.ui
        for k, (p, _c) in enumerate(nodes):
            d = abs(x0 + p * (x1 - x0) - x)
            if d <= bd:
                best, bd = k, d
        return best

    def _press(self, ev):
        self._drag_k = None
        k = self._node_near(ev.x)
        if self.o.app._alt_down(ev):
            if k is not None:
                self.o.grad_delete(k)
            return
        if k is not None and k == self.o.gsel and 0 < k < len(self.o.o["grad"]) - 1:
            self._drag_k = k
        elif k is not None and k != self.o.gsel:
            self.o.app.status_var.set("Right-click a node to select it, then drag it.")

    def _drag(self, ev):
        if self._drag_k is not None:
            self.o.grad_move(self._drag_k, self._pos(ev.x))

    def _right(self, ev):
        k = self._node_near(ev.x)
        if self.o.app._alt_down(ev):
            if k is None:
                self.o.grad_add(self._pos(ev.x))
            else:
                self.o.app.status_var.set("There's a node there already - right-click "
                                          "selects it.")
            return
        if k is not None:
            self.o.grad_select(k)

    def _double(self, ev):
        k = self._node_near(ev.x)
        if k is not None and k == self.o.gsel:
            self.o.open_picker()

    def draw(self):
        from PIL import Image, ImageTk
        c = self.c
        c.delete("all")
        x0, x1 = self._x0x1()
        w = int(x1 - x0)
        if w < 4:
            return
        o = self.o.o
        n = 256
        strip = Image.new("RGB", (n, 1))
        strip.putdata([grad_rgb(o["grad"], k / (n - 1.0), o["blend"]) for k in range(n)])
        self._img = ImageTk.PhotoImage(strip.resize((w, self.H), Image.BILINEAR))
        c.create_image(x0, 2, anchor="nw", image=self._img)
        yt = self.H + 3
        h = self.nh - 2
        for k, (p, col) in enumerate(o["grad"]):
            x = x0 + p * (x1 - x0)
            draw_node(c, (x, yt, x - h * 0.7, yt + h, x + h * 0.7, yt + h),
                      hex_of(tuple(col)), k == self.o.gsel, self.ui)


# ------------------------------------------------------------ window
class InvulWin(_CWin):
    TITLE = "Invulnerability - COLORMAP row 32"

    def build(self, f):
        from tkinter import ttk
        from .gui_gradslider import GradSlider
        a = self.app
        tk = a.tk
        ui = self.ui
        self.o = clean_invul(a.s.get("invul"))
        self.base = a.cm.copy()
        self.dirty = False               # a colour was picked / slider moved
        self.built = {}                  # s -> (true rgb, index) of the last build
        self._true = bool(a.s.get("invul_true", True))
        self._flip = False
        self._undo, self._redo = [], []
        self._last_t, self._last_key = 0.0, None
        self._hits = []
        self.cs = max(8, int(round(16 * ui)))
        # ---- top line
        top = ttk.Frame(f)
        top.grid(row=0, column=0, sticky="we", pady=(0, 6))
        self.head_var = tk.StringVar()
        ttk.Label(top, textvariable=self.head_var, foreground="#666").pack(side="left")
        self.true_btn = tk.Button(top, text="True colour", width=16, relief="raised",
                                  command=self._true_click)
        self.true_btn.pack(side="right")
        self._true_bg = self.true_btn.cget("background")
        # ---- wrap
        wf = ttk.Frame(f)
        wf.grid(row=1, column=0, sticky="w", pady=(0, 4))
        self.wrap_on = bool(a.s.get("invul_wrap", True))
        n = a.s.get("invul_wrap_n", 16)
        self.wrap_n = max(1, min(256, int(n))) if isinstance(n, int) and \
            not isinstance(n, bool) else 16
        self.wrap_btn = tk.Button(wf, text="Wrap", width=10, relief="raised",
                                  command=self._wrap_click)
        self.wrap_btn.pack(side="left")
        self._wrap_bg = self.wrap_btn.cget("background")
        ttk.Label(wf, text="colours per line").pack(side="left", padx=(8, 4))
        self.wrap_var = tk.StringVar(value=str(self.wrap_n))
        sp = ttk.Spinbox(wf, from_=1, to=256, increment=1, width=5,
                         textvariable=self.wrap_var, command=self._wrap_n_changed)
        sp.pack(side="left")
        sp.bind("<Return>", lambda e: self._wrap_n_changed())
        sp.bind("<FocusOut>", lambda e: self._wrap_n_changed())
        self.wrap_sp = sp
        # ---- strip (scrolls sideways when one line is wider than the screen)
        sf = ttk.Frame(f)
        sf.grid(row=2, column=0, sticky="we")
        self.cv = tk.Canvas(sf, bg=BG, highlightthickness=0, cursor="crosshair")
        self.cv.grid(row=0, column=0, sticky="w")
        self.hsb = ttk.Scrollbar(sf, orient="horizontal", command=self.cv.xview)
        self.cv.configure(xscrollcommand=self.hsb.set)
        self.cv.bind("<Motion>", self._hover)
        self.cv.bind("<Leave>", lambda e: self.info_var.set(""))
        self.cv.bind("<Shift-MouseWheel>",
                     lambda e: self.cv.xview_scroll(-1 if e.delta > 0 else 1, "units"))
        self.info_var = tk.StringVar()
        ttk.Label(f, textvariable=self.info_var, font=("Consolas", 9)).grid(
            row=3, column=0, sticky="w", pady=(4, 0))
        # ---- method
        ttk.Separator(f).grid(row=4, column=0, sticky="we", pady=(8, 6))
        mf = ttk.Frame(f)
        mf.grid(row=5, column=0, sticky="w")
        ttk.Label(mf, text="Method").pack(side="left", padx=(0, 6))
        names = dict(METHODS)
        self.method_var = tk.StringVar(value=names[self.o["method"]])
        mc = ttk.Combobox(mf, textvariable=self.method_var, state="readonly", width=16,
                          values=[t for _m, t in METHODS])
        mc.pack(side="left")
        mc.bind("<<ComboboxSelected>>", lambda e: self._method_changed())
        self.method_note = tk.StringVar()
        ttk.Label(mf, textvariable=self.method_note, foreground="#b03000").pack(
            side="left", padx=(8, 0))
        # ---- colour picker method
        pf = ttk.LabelFrame(f, text="Colour picker (black stays black, white stays white, "
                                    "mid greys take the colour)", padding=6)
        pf.grid(row=6, column=0, sticky="we", pady=(6, 0))
        self.pick_frame = pf
        row = ttk.Frame(pf)
        row.grid(row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(row, text="Colour").pack(side="left", padx=(0, 6))
        self.swatch = tk.Canvas(row, width=int(44 * ui), height=int(22 * ui),
                                highlightthickness=1, highlightbackground="#555",
                                cursor="hand2")
        self.swatch.pack(side="left")
        self.swatch.bind("<Button-1>", lambda e: self.open_picker())
        ttk.Button(row, text="Picker...", command=self.open_picker).pack(side="left",
                                                                         padx=(8, 0))
        self.col_var = tk.StringVar()
        ttk.Label(row, textvariable=self.col_var, font=("Consolas", 9)).pack(
            side="left", padx=(8, 0))
        pf.columnconfigure(1, weight=1)
        # ---- gradient method
        self.gsel = 1                          # selected gradient node
        gf = ttk.LabelFrame(f, padding=6,
                            text="Gradient (right-click node = select · drag = move · "
                                 "◀ ▶ = one cell · Alt+right-click = add · Alt+click = "
                                 "delete)")
        gf.grid(row=6, column=0, sticky="we", pady=(6, 0))
        self.grad_frame = gf
        self.bar = GradBar(gf, self)
        self.bar.c.grid(row=0, column=0, columnspan=2, sticky="we")
        nr = ttk.Frame(gf)
        nr.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.gnode_var = tk.StringVar()
        ttk.Label(nr, textvariable=self.gnode_var, width=18).pack(side="left")
        self.gswatch = tk.Canvas(nr, width=int(44 * ui), height=int(22 * ui),
                                 highlightthickness=1, highlightbackground="#555",
                                 cursor="hand2")
        self.gswatch.pack(side="left")
        self.gswatch.bind("<Button-1>", lambda e: self.open_picker())
        ttk.Button(nr, text="Picker...", command=self.open_picker).pack(side="left",
                                                                        padx=(6, 0))
        ttk.Button(nr, text="◀", width=3, command=lambda: self.grad_nudge(-1)).pack(
            side="left", padx=(10, 0))
        ttk.Button(nr, text="▶", width=3, command=lambda: self.grad_nudge(1)).pack(
            side="left", padx=(2, 0))
        ttk.Button(nr, text="Delete node", command=lambda: self.grad_delete(self.gsel)
                   ).pack(side="left", padx=(6, 0))
        br = ttk.Frame(gf)
        br.grid(row=2, column=0, columnspan=2, sticky="w", pady=(4, 0))
        ttk.Label(br, text="Blend").pack(side="left", padx=(0, 6))
        self.blend_var = tk.StringVar(value=self.o["blend"])
        for v, t in BLENDS:
            ttk.Radiobutton(br, text=t, value=v, variable=self.blend_var,
                            command=lambda: self._set_opt("blend", self.blend_var.get())
                            ).pack(side="left", padx=(0, 8))
        self.inv_var = tk.BooleanVar(value=self.o["invert"])
        ttk.Checkbutton(gf, text="Apply invert (the Colour picker method, a gradient "
                                 "colour per cell)", variable=self.inv_var,
                        command=lambda: self._set_opt("invert", bool(self.inv_var.get()))
                        ).grid(row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))
        self.gsc_var = tk.StringVar()
        ttk.Label(gf, textvariable=self.gsc_var, foreground="#666").grid(
            row=4, column=0, columnspan=2, sticky="w", pady=(4, 0))
        gf.columnconfigure(0, weight=1)
        # ---- lightness shift (Colour picker, and Gradient with Apply invert)
        lf = ttk.Frame(f)
        lf.grid(row=7, column=0, sticky="we", pady=(6, 0))
        ttk.Label(lf, text="Lightness shift").pack(side="left")
        self.light_sl = GradSlider(lf, a, -100, 100, 1, self.o["light"],
                                   lambda v: self._set_light(int(v)), None, ui)
        self.light_sl.frame.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.state_var = tk.StringVar()
        ttk.Label(f, textvariable=self.state_var, foreground="#666").grid(
            row=8, column=0, sticky="w", pady=(6, 0))
        self.win.bind("<Delete>", lambda e: self.grad_delete(self.gsel))
        f.columnconfigure(0, weight=1)
        self.win.bind("<Escape>", lambda e: (a.close_ctool(), "break")[1])
        self._true_ui()
        self._wrap_ui()
        self._method_ui()
        self._ui()
        self.draw()
        sw = getattr(a, "scene_win", None)        # an open Scene shows invulnerability
        self._scene_was = None
        if sw is not None and sw.win is not None:
            self._scene_was = sw.o.get("invul")
            sw.set_invul(True)

    # ---------------------------------------------------------- view
    def truecol(self):
        return self._true != self._flip

    def _true_click(self):
        self._flip = False
        self._true = not self._true
        self.app.s["invul_true"] = self._true
        self._true_ui()
        self.draw()
        self.app.draw_fades()

    def _true_ui(self):
        on = self._true
        bg = CTOOL_COLOUR if on else self._true_bg
        self.true_btn.configure(relief="sunken" if on else "raised", background=bg,
                                activebackground=bg,
                                text="True colour (on)" if on else "True colour")
        if hasattr(self, "cmp_btn"):
            self.cmp_btn.configure(text="Hold: palettised" if on else "Hold: true colour")

    def buttons_made(self):
        self._true_ui()

    def compare_hold(self, on):
        """Hold = the OTHER view while held (true colour <-> palettised)."""
        if self._flip == bool(on):
            return
        self._flip = bool(on)
        self.draw()
        self.app.draw_fades()

    def show_true(self):
        return self.truecol()

    def invul_rgb(self, s):
        """Main window, row 32 in True colour: the colour aimed for."""
        if not self.truecol() or not self.dirty:
            return None
        b = self.built.get(s)
        return b[0] if b else None

    # ---------------------------------------------------------- wrap
    def _wrap_click(self):
        self.wrap_on = not self.wrap_on
        self.app.s["invul_wrap"] = self.wrap_on
        self._wrap_ui()
        self.draw()

    def _wrap_n_changed(self):
        try:
            n = max(1, min(256, int(float(self.wrap_var.get()))))
        except ValueError:
            n = self.wrap_n
        self.wrap_var.set(str(n))
        if n != self.wrap_n:
            self.wrap_n = n
            self.app.s["invul_wrap_n"] = n
            self.draw()

    def _wrap_ui(self):
        on = self.wrap_on
        bg = CTOOL_COLOUR if on else self._wrap_bg
        self.wrap_btn.configure(relief="sunken" if on else "raised", background=bg,
                                activebackground=bg, text="Wrap (on)" if on else "Wrap")
        self.wrap_sp.state(["!disabled"] if on else ["disabled"])

    # ---------------------------------------------------------- method
    def _method(self):
        return {t: m for m, t in METHODS}.get(self.method_var.get(), "picker")

    def _method_changed(self):
        m = self._method()
        if m != self.o["method"]:
            self.o["method"] = m
            self._save()
        self._method_ui()
        self._retarget_picker()
        self._write()

    def _method_ui(self):
        m = self._method()
        self.method_note.set("")
        if m == "picker":
            self.grad_frame.grid_remove()
            self.pick_frame.grid()
        else:
            self.pick_frame.grid_remove()
            self.grad_frame.grid()
        self.light_sl.set_enabled(m == "picker" or self.o["invert"])
        self._grad_ui()

    # ---------------------------------------------------------- colour picker
    def _save(self):
        self.app.s["invul"] = copy.deepcopy(self.o)

    def open_picker(self):
        p = self.app.open_picker()
        p.owner = self.win
        self._retarget_picker(force=True)

    def _retarget_picker(self, force=False):
        """Point the picker (if it's ours) at the colour / the selected node."""
        p = self.app.picker
        if p is None or (getattr(p, "owner", None) is not self.win and not force):
            return
        if self._method() == "picker":
            p.set_target(lambda rgb, _h=None: self._set_colour(rgb),
                         tuple(self.o["colour"]), None, "Invulnerability colour")
        else:
            k = self.gsel
            p.set_target(lambda rgb, _h=None, k=k: self._set_node_colour(k, rgb),
                         tuple(self.o["grad"][k][1]), None,
                         "Invulnerability gradient node %d" % (k + 1))

    # ---------------------------------------------------------- gradient
    def _targets(self):
        """Gradient cells: the pal0 selection, else every colour (index order)."""
        a = self.app

        def ok(i):
            return i < ENTRIES and a.rgbs[i] is not None and i not in a.deleted
        sel = sorted(i for i in a.selection if ok(i))
        return sel if sel else [i for i in range(ENTRIES) if ok(i)]

    def _grad_changed(self, key):
        self._save()
        self.dirty = True
        self._write()
        self._grad_ui()                          # bar + node swatch

    def _set_opt(self, key, v):
        if self.o[key] == v:
            return
        self._push(key)
        self.o[key] = v
        self._method_ui()
        self._grad_changed(key)

    def grad_select(self, k):
        self.gsel = k
        self._grad_ui()
        self._retarget_picker()

    def grad_move(self, k, p):
        g = self.o["grad"]
        if not 0 < k < len(g) - 1:
            return
        eps = 1e-4
        p = min(max(p, g[k - 1][0] + eps), g[k + 1][0] - eps)
        if abs(p - g[k][0]) < 1e-9:
            return
        self._push(("move", k))
        g[k][0] = p
        self._grad_changed("move")

    def grad_nudge(self, d):
        """< >: one cell of the current targets."""
        n = len(self._targets())
        step = 1.0 / (n - 1) if n > 1 else 0.05
        g = self.o["grad"]
        k = self.gsel
        if not 0 < k < len(g) - 1:
            self.app.status_var.set("The end nodes stay at the ends.")
            return
        cur = g[k][0] / step
        if abs(cur - round(cur)) < 1e-6:
            tgt = round(cur) + d
        else:
            tgt = int(cur) + (1 if d > 0 else 0)
        self.grad_move(k, tgt * step)

    def grad_add(self, p):
        g = self.o["grad"]
        if p <= 0.0 or p >= 1.0:
            return
        self._push()
        col = list(grad_rgb(g, p, self.o["blend"]))
        g.append([p, col])
        g.sort(key=lambda n: n[0])
        self._grad_changed("add")

    def grad_delete(self, k):
        g = self.o["grad"]
        if self._method() != "gradient":
            return
        if not 0 < k < len(g) - 1:
            self.app.status_var.set("The end nodes can't be deleted.")
            return
        self._push()
        del g[k]
        self.gsel = min(k, len(g) - 1)
        self._grad_changed("delete")
        self._retarget_picker()

    def _set_node_colour(self, k, rgb):
        g = self.o["grad"]
        if not 0 <= k < len(g):
            return
        rgb = [max(0, min(255, int(round(v)))) for v in rgb]
        if g[k][1] == rgb and self.dirty:
            return
        self._push(("node", k))
        g[k][1] = rgb
        self._grad_changed("colour")

    def _grad_ui(self):
        if not hasattr(self, "bar"):
            return
        g = self.o["grad"]
        self.gsel = min(self.gsel, len(g) - 1)
        k = self.gsel
        self.gnode_var.set("Node %d/%d%s" % (k + 1, len(g), " (start)" if k == 0 else
                                             " (end)" if k == len(g) - 1 else ""))
        self.gswatch.configure(background=hex_of(tuple(g[k][1])))
        t = self._targets()
        sel = any(i < ENTRIES for i in self.app.selection)
        self.gsc_var.set("%s: %d cells, left end = index %s, right end = index %s" % (
            "Selected cells" if sel else "Nothing selected - whole palette", len(t),
            t[0] if t else "-", t[-1] if t else "-"))
        self.bar.draw()

    def sel_changed(self):
        if self._method() == "gradient":
            self._grad_ui()
            if self.dirty:
                self._write()

    def _set_colour(self, rgb):
        rgb = [max(0, min(255, int(round(v)))) for v in rgb]
        if rgb == self.o["colour"] and self.dirty:
            return
        self._push("colour")
        self.o["colour"] = rgb
        self._save()
        self.dirty = True
        self._write()

    def _set_light(self, v):
        if v == self.o["light"] and self.dirty:
            return
        self._push("light")
        self.o["light"] = v
        self._save()
        self.dirty = True
        self._write()

    def _ui(self):
        c = tuple(self.o["colour"])
        self.swatch.configure(background=hex_of(c))
        h, s = colour_hs(c)
        self.col_var.set("%s  hue %d  sat %d  light %+d" % (hex_of(c), round(h), round(s),
                                                             self.o["light"]))
        self.head_var.set("Row 32: every palette colour while invulnerable")
        if self._method() == "gradient" and not self.dirty:
            st = "Row 32 unchanged - edit the gradient to build it."
        elif self.dirty:
            st = "Row 32 built from the %s (%d colours) - not applied yet." % (
                "gradient" if self._method() == "gradient" else "colour", len(self.built))
        else:
            st = "Row 32 unchanged - click the swatch to pick a colour."
        self.state_var.set(st)

    # ---------------------------------------------------------- the row
    def _write(self):
        a = self.app
        cm = self.base.copy()
        self.built = {}
        if self.dirty and a.rgbs is not None:
            pal = [a.rgbs[i] if i < len(a.rgbs) and i not in a.deleted else None
                   for i in range(ENTRIES)]
            if self._method() == "picker":
                self.built = picker_row(pal, tuple(self.o["colour"]), self.o["light"])
            else:
                self.built = gradient_row(pal, self._targets(), self.o["grad"],
                                          self.o["blend"], self.o["invert"],
                                          self.o["light"])
            for s, (_t, i) in self.built.items():
                if i is not None:
                    cm.overrides[(INVUL_ROW, s)] = i
        if cm != a.cm:
            a.cm = cm
            a.cm_changed()
        a.recompute()
        self._ui()
        self.draw()
        self.refresh()

    def result(self):
        """[index or None] x 256: what row 32 is now (incl. this tool)."""
        a = self.app
        res, _f = a.cmap_result()
        return [res.rows[INVUL_ROW][s] if a.rgbs[s] is not None else None
                for s in range(ENTRIES)]

    def _cell_colour(self, s, res):
        a = self.app
        if a.rgbs[s] is None:
            return None
        if self.truecol() and self.dirty and s in self.built:
            return self.built[s][0]
        t = res[s]
        return a.rgbs[t] if t is not None and t < len(a.rgbs) and a.rgbs[t] else (0, 0, 0)

    # ---------------------------------------------------------- strip
    def draw(self):
        c = self.cv
        c.delete("all")
        self._hits = []
        a = self.app
        if a.rgbs is None:
            return
        cs = self.cs
        per = self.wrap_n if self.wrap_on else ENTRIES
        lines = (ENTRIES + per - 1) // per
        W, H = per * cs + 1, lines * cs + 1
        res = self.result()
        g = max(1, int(round(self.ui)))
        for s in range(ENTRIES):
            x = (s % per) * cs
            y = (s // per) * cs
            col = self._cell_colour(s, res)
            if col is None:
                c.create_rectangle(x + 1, y + 1, x + cs - g + 1, y + cs - g + 1,
                                   fill="#1c1c1c", outline="")
                continue
            c.create_rectangle(x + 1, y + 1, x + cs - g + 1, y + cs - g + 1,
                               fill=hex_of(col), outline="")
            self._hits.append((x, y, x + cs, y + cs, s))
        try:
            maxw = int(self.win.winfo_screenwidth() * 0.8)
        except self.app.tk.TclError:
            maxw = W
        vis = min(W, maxw)
        c.configure(width=vis, height=H, scrollregion=(0, 0, W, H))
        if W > vis:
            self.hsb.grid(row=1, column=0, sticky="we")
        else:
            self.hsb.grid_remove()
            c.xview_moveto(0)

    def _hover(self, ev):
        x, y = self.cv.canvasx(ev.x), self.cv.canvasy(ev.y)
        a = self.app
        for x0, y0, x1, y1, s in self._hits:
            if x0 <= x < x1 and y0 <= y < y1:
                t = self.result()[s]
                tc = a.rgbs[t] if t is not None and a.rgbs[t] else None
                txt = "index %d %s -> row 32: index %s %s" % (
                    s, hex_of(a.rgbs[s]), t, hex_of(tc) or "?")
                if self.dirty and s in self.built:
                    txt += "   (aimed for %s)" % hex_of(self.built[s][0])
                self.info_var.set(txt)
                return
        self.info_var.set("")

    # ---------------------------------------------------------- undo
    def _state(self):
        return (copy.deepcopy(self.o), self.dirty)

    def _push(self, key=None):
        now = time.time()
        if key is not None and key == self._last_key and now - self._last_t < UNDO_GAP:
            self._last_t = now
            return
        self._undo.append(self._state())
        del self._undo[:-200]
        self._redo = []
        self._last_t, self._last_key = now, key

    def undo(self, redo=False):
        a, b = (self._redo, self._undo) if redo else (self._undo, self._redo)
        if not a:
            return False
        b.append(self._state())
        o, dirty = a.pop()
        self.o, self.dirty = copy.deepcopy(o), dirty
        self._save()
        self.light_sl.set(self.o["light"])
        self.method_var.set(dict(METHODS)[self.o["method"]])
        self.blend_var.set(self.o["blend"])
        self.inv_var.set(self.o["invert"])
        self._method_ui()
        self._retarget_picker()
        self._last_key = None
        self._write()
        return True

    # ---------------------------------------------------------- session
    def log_text(self):
        if not self.dirty:
            return "row 32 unchanged"
        if self._method() == "gradient":
            g = self.o["grad"]
            return "row 32 - gradient %s over %d cells (%d nodes, %s%s)" % (
                " -> ".join(hex_of(tuple(c)) for _p, c in g[:4]) +
                (" ..." if len(g) > 4 else ""), len(self.built), len(g),
                dict(BLENDS)[self.o["blend"]], ", invert, lightness %+d" %
                self.o["light"] if self.o["invert"] else "")
        h, s = colour_hs(tuple(self.o["colour"]))
        return "row 32 - colour picker %s (hue %d, sat %d, lightness %+d)" % (
            hex_of(tuple(self.o["colour"])), round(h), round(s), self.o["light"])

    def note_applied(self):
        self.base = self.app.cm.copy()
        self.dirty = False
        self.built = {}
        self._undo, self._redo = [], []
        self._ui()
        self.draw()

    def note_reverted(self):
        self.note_applied()

    def external_edit(self):
        self.base = self.app.cm.copy()
        if self.dirty:
            self._write()

    def refresh(self):
        """Called after every recompute: redraw the strip when the palette or
        the COLORMAP changed; a palette change while built rebuilds row 32."""
        _CWin.refresh(self)
        a = self.app
        if not hasattr(self, "cv") or a.rgbs is None:
            return
        pk = (tuple(a.pal), frozenset(a.deleted))
        if getattr(self, "_pal_key", None) is None:
            self._pal_key = pk
        elif pk != self._pal_key:
            self._pal_key = pk
            if self.dirty:
                a.root.after_idle(self._write)
                return
        sig = (pk, a.cmap_signature(), self.truecol())
        if sig != getattr(self, "_draw_sig", None):
            self._draw_sig = sig
            self.draw()

    def teardown(self):
        a = self.app
        p = a.picker
        if p is not None and getattr(p, "owner", None) is self.win:
            p.owner = None
            try:
                p.set_target(None, (128, 128, 128), None, "")
            except a.tk.TclError:
                pass
        sw = getattr(a, "scene_win", None)
        if sw is not None and sw.win is not None and self._scene_was is not None:
            sw.set_invul(bool(self._scene_was))
        _CWin.teardown(self)
