"""Picked colours: the colours inside a box drawn on the Palettised preview.

A reference window (like Palette Browser) that can stay open with any tool. Shows
the unique colours under the box exactly as displayed - original, palettised
or lit - with pixel counts. Select swatches and Copy (clipboard), Copy hex
(text), Copy Cells / Insert Cells (into the main palette), or add them to the
Scratch palette. Drag a swatch onto the Paint ramp bar to set a node.
"""

from ..cleanpal_lib_colour import hex_of, oklab, oklab_to_rgbf
from ..cleanpal_lib_constants import ENTRIES, fmt_tol

BUILD_METHODS = ("Match pixel distribution", "Even lightness")


def build_ramp_colours(counts, n, method):
    """n colours, dark -> light, that best represent pixels counts [(n, rgb)].
    Match pixel distribution: each colour stands for an equal share of the
    pixels (more steps where the art has more pixels). Even lightness: equal
    OKLab lightness steps between the darkest and lightest pixels."""
    px = sorted(((oklab(c), k) for k, c in counts if k > 0), key=lambda t: t[0][0])
    if not px or n < 1:
        return []
    total = float(sum(k for _l, k in px))
    acc = [[0.0, 0.0, 0.0, 0.0] for _ in range(n)]          # L, a, b, weight
    if method == "Even lightness":
        lo, hi = px[0][0][0], px[-1][0][0]
        span = max(hi - lo, 1e-9)
        for (L, a, b), k in px:
            j = min(int((L - lo) / span * n), n - 1)
            q = acc[j]
            q[0] += L * k
            q[1] += a * k
            q[2] += b * k
            q[3] += k
    else:
        share = total / n
        pos = 0.0
        for (L, a, b), k in px:                # spread each colour's pixels
            left = float(k)                    # over the buckets it covers
            while left > 1e-9:
                j = min(int(pos / share), n - 1)
                room = (j + 1) * share - pos if j < n - 1 else left
                take = min(left, max(room, 1e-9))
                q = acc[j]
                q[0] += L * take
                q[1] += a * take
                q[2] += b * take
                q[3] += take
                pos += take
                left -= take
    out = [None] * n
    for j, (L, a, b, w) in enumerate(acc):
        if w > 0:
            out[j] = (L / w, a / w, b / w)
    known = [j for j in range(n) if out[j] is not None]
    for j in range(n):                         # empty lightness bands: blend
        if out[j] is None:
            lo_j = max((k for k in known if k < j), default=None)
            hi_j = min((k for k in known if k > j), default=None)
            if lo_j is None:
                out[j] = out[hi_j]
            elif hi_j is None:
                out[j] = out[lo_j]
            else:
                t = (j - lo_j) / float(hi_j - lo_j)
                out[j] = tuple(out[lo_j][m] + (out[hi_j][m] - out[lo_j][m]) * t
                               for m in range(3))
    res = []
    for L, a, b in out:
        r, g, bb = oklab_to_rgbf(L, a, b)
        res.append(tuple(int(round(min(max(v, 0.0), 255.0))) for v in (r, g, bb)))
    return res


def _lab(c):
    L, a, b = oklab(c)
    return (L * 100.0, a * 100.0, b * 100.0)


def merge_similar(counts, tol):
    """counts: [(n, rgb)] -> [(n, rgb)] with colours closer than tol (OKLab x100)
    grouped under their most frequent member."""
    if tol <= 0:
        return list(counts)
    reps = []                                  # [n, rgb, lab]
    t2 = tol * tol
    for n, c in sorted(counts, key=lambda nc: -nc[0]):
        lab = _lab(c)
        for r in reps:
            q = r[2]
            if (q[0] - lab[0]) ** 2 + (q[1] - lab[1]) ** 2 + (q[2] - lab[2]) ** 2 <= t2:
                r[0] += n
                break
        else:
            reps.append([n, c, lab])
    return [(n, c) for n, c, _l in reps]


class PickedColoursWin:
    MAX_SHOWN = 256
    SORTS = ("Most used", "Lightness", "Hue")

    def __init__(self, app):
        tk = app.tk
        from tkinter import ttk

        self.app = app
        s = app.s
        self.ui = ui = getattr(app, "ui", 1.0)
        self.win = tk.Toplevel(app.root)
        self.win.title("Picked colours")
        self.win.transient(app.root)
        self.win.minsize(int(420 * ui), int(300 * ui))
        try:
            self.win.geometry(s.get("picked_geometry") or "%dx%d" % (560 * ui, 460 * ui))
        except tk.TclError:
            pass
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.raw = []                    # [(count, rgb)] exactly as picked
        self.items = []                  # shown: [(count, rgb)]
        self.sel = set()
        self.source = ""
        self.original = False
        self._drag = None
        self.cell = int(28 * ui)

        top = ttk.Frame(self.win, padding=(8, 8, 8, 0))
        top.pack(fill="x")
        self.src_var = tk.StringVar(value="Draw a box on an image in the Palettised preview "
                                          "(single view, or one image in grid view).")
        ttk.Label(top, textvariable=self.src_var, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        r = ttk.Frame(top)
        r.pack(fill="x", pady=(6, 0))
        ttk.Label(r, text="Sort").pack(side="left")
        self.sort_var = tk.StringVar(value=s.get("picked_sort", self.SORTS[0])
                                     if s.get("picked_sort") in self.SORTS else self.SORTS[0])
        cb = ttk.Combobox(r, textvariable=self.sort_var, values=self.SORTS, state="readonly",
                          width=11)
        cb.pack(side="left", padx=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._resort())
        ttk.Label(r, text="Merge similar").pack(side="left", padx=(12, 0))
        self.merge_var = tk.StringVar(value=fmt_tol(float(s.get("picked_merge", 3.0))))
        self.merge_sc = tk.Scale(r, from_=0, to=15, resolution=0.5, orient="horizontal",
                                 showvalue=0, length=int(120 * ui), sliderlength=int(26 * ui),
                                 width=int(16 * ui), command=self._merge_changed)
        self.merge_sc.set(float(s.get("picked_merge", 3.0)))
        self.merge_sc.pack(side="left", padx=(4, 0))
        ttk.Label(r, textvariable=self.merge_var, width=4).pack(side="left")
        self.merge_note = tk.StringVar()
        ttk.Label(r, textvariable=self.merge_note, foreground="#888").pack(side="left")
        r2 = ttk.Frame(top)
        r2.pack(fill="x", pady=(4, 0))
        self.hide_var = tk.BooleanVar(value=bool(s.get("picked_hide", False)))
        ttk.Checkbutton(r2, text="Remove colours already in palette", variable=self.hide_var,
                        command=self._hide_changed).pack(side="left")
        ttk.Label(r2, text="  right-click a swatch = don't add it",
                  foreground="#888").pack(side="left")
        self.off = set()                 # colours crossed out by hand
        self._hidden = 0

        self.cv = tk.Canvas(self.win, bg="#262626", highlightthickness=0)
        self.cv.pack(fill="both", expand=True, padx=8, pady=6)
        self.cv.bind("<Configure>", lambda e: self.draw())
        self.cv.bind("<ButtonPress-1>", self._press)
        self.cv.bind("<B1-Motion>", self._motion)
        self.cv.bind("<ButtonRelease-1>", self._release)
        self.cv.bind("<Motion>", self._hover)
        self.cv.bind("<ButtonPress-3>", self._toggle_off)

        bot = ttk.Frame(self.win, padding=(8, 0, 8, 8))
        bot.pack(fill="x")
        self.hover_var = tk.StringVar()
        ttk.Label(bot, textvariable=self.hover_var, font=("Consolas", 9)).pack(anchor="w")
        self.sel_var = tk.StringVar()
        ttk.Label(bot, textvariable=self.sel_var, foreground="#666").pack(anchor="w",
                                                                        pady=(4, 0))
        bf = ttk.Frame(bot)                      # buttons on their own rows: never cut off
        bf.pack(fill="x", pady=(4, 0))
        for text, cmd in (("Copy", self.copy), ("Copy hex", self.copy_hex),
                          ("Copy Cells", self.copy_cells), ("Insert Cells", self.insert_cells)):
            ttk.Button(bf, text=text, command=cmd).pack(side="left", padx=(0, 4))
        bf2 = ttk.Frame(bot)
        bf2.pack(fill="x", pady=(4, 0))
        for text, cmd in (("To scratch", self.to_scratch),
                          ("Select in palette", self.select_in_palette)):
            ttk.Button(bf2, text=text, command=cmd).pack(side="left", padx=(0, 4))
        rf = ttk.LabelFrame(bot, text="Paint ramp", padding=6)
        rf.pack(fill="x", pady=(6, 0))
        r1 = ttk.Frame(rf)
        r1.pack(fill="x")
        ttk.Button(r1, text="Add to ramp nodes", command=self.add_nodes).pack(side="left")
        self.replace_var = tk.BooleanVar(value=bool(s.get("picked_replace", True)))
        ttk.Checkbutton(r1, text="Replace nodes", variable=self.replace_var,
                        command=lambda: s.__setitem__("picked_replace",
                                                      bool(self.replace_var.get()))).pack(
            side="left", padx=(6, 0))
        r2 = ttk.Frame(rf)
        r2.pack(fill="x", pady=(4, 0))
        ttk.Button(r2, text="Build ramp", command=self.build_ramp).pack(side="left")
        ttk.Label(r2, text="Method").pack(side="left", padx=(8, 0))
        want = s.get("picked_build", BUILD_METHODS[0])
        self.method_var = tk.StringVar(value=want if want in BUILD_METHODS
                                       else BUILD_METHODS[0])
        mc = ttk.Combobox(r2, textvariable=self.method_var, values=BUILD_METHODS,
                          state="readonly", width=24)
        mc.pack(side="left", padx=(4, 0))
        mc.bind("<<ComboboxSelected>>",
                lambda e: s.__setitem__("picked_build", self.method_var.get()))
        ttk.Label(rf, text="Build ramp: the main grid's selected cells get a dark -> light ramp "
                           "of these pixels\n(selected swatches only, if any) - a Paint ramp "
                           "preview: Reverse / Apply / Cancel as usual.",
                  foreground="#888", justify="left").pack(anchor="w", pady=(4, 0))
        ttk.Label(bot, text="click / drag = select  Shift add  Ctrl toggle  Ctrl+A all\n"
                            "drag a swatch onto the Paint ramp bar = a node",
                  foreground="#888").pack(anchor="w", pady=(4, 0))
        w = self.win
        for seq in ("<Control-a>", "<Control-A>"):
            w.bind(seq, lambda e: self._all())
        w.bind("<Control-c>", lambda e: self.copy())
        w.bind("<Escape>", lambda e: self._set_sel(set()))
        from .gui_tool_windows import focus_on_click
        focus_on_click(w)
        self._sel_text()
        try:                                     # room for every control
            w.update_idletasks()
            rw, rh = w.winfo_reqwidth(), w.winfo_reqheight() + int(80 * ui)
            cw, ch = w.winfo_width(), w.winfo_height()
            if cw > 1 and (cw < rw or ch < rh):
                w.geometry("%dx%d" % (max(cw, rw), max(ch, rh)))
            w.minsize(int(420 * ui), min(rh, int(w.winfo_screenheight() * 0.9)))
        except tk.TclError:
            pass

    # ---------------------------------------------------------- content
    def set_colours(self, counts, source, original):
        """counts: [(n, rgb)] from the preview box."""
        self.raw = [(n, tuple(c)) for n, c in counts]
        self.off = set()
        self.source = source
        self.original = original
        self.sel = set()
        self.src_var.set(source)
        self.merge_sc.configure(state="normal" if original else "disabled")
        self._rebuild()
        self.win.deiconify()
        self.win.lift()

    def _merge_changed(self, x):
        v = float(x)
        self.merge_var.set(fmt_tol(v))
        self.app.s["picked_merge"] = v
        if self.original:
            self.sel = set()
            self._rebuild()

    def _rebuild(self):
        tol = float(self.merge_sc.get()) if self.original else 0.0
        items = merge_similar(self.raw, tol)
        self._hidden = 0
        if self.hide_var.get():
            have = {tuple(c) for c in (self.app.rgbs or []) if c is not None}
            keep = [nc for nc in items if nc[1] not in have]
            self._hidden = len(items) - len(keep)
            items = keep
        n_all = len(items)
        items.sort(key=lambda nc: -nc[0])
        items = items[:self.MAX_SHOWN]
        self.items = items
        self._apply_sort()
        extra = ""
        if self.original and tol > 0:
            extra = "  %d exact -> %d" % (len(self.raw), n_all)
        if n_all > self.MAX_SHOWN:
            extra += "  (top %d of %d shown)" % (self.MAX_SHOWN, n_all)
        if self._hidden:
            extra += "  (%d already in palette, hidden)" % self._hidden
        self.merge_note.set(extra if self.original else
                            "  (exact)" + ("  (%d already in palette, hidden)" % self._hidden
                                           if self._hidden else ""))
        self.draw()

    def _apply_sort(self):
        k = self.sort_var.get()
        if k == "Lightness":
            self.items.sort(key=lambda nc: -oklab(nc[1])[0])
        elif k == "Hue":
            import math

            def hue(nc):
                L, a, b = oklab(nc[1])
                c = math.hypot(a, b)
                return (0 if c < 0.02 else 1, math.atan2(b, a) if c >= 0.02 else -L)
            self.items.sort(key=hue)
        else:
            self.items.sort(key=lambda nc: -nc[0])

    def _resort(self):
        chosen = {self.items[i][1] for i in self.sel if i < len(self.items)}
        self.app.s["picked_sort"] = self.sort_var.get()
        self._apply_sort()
        self.sel = {i for i, (_n, c) in enumerate(self.items) if c in chosen}
        self.draw()

    # ---------------------------------------------------------- drawing
    def _per_row(self):
        return max(4, (max(self.cv.winfo_width(), 100) - 4) // self.cell)

    def _xy(self, k):
        pr = self._per_row()
        return 2 + (k % pr) * self.cell, 2 + (k // pr) * self.cell

    def _at(self, x, y):
        pr = self._per_row()
        col, row = int((x - 2) // self.cell), int((y - 2) // self.cell)
        if x < 2 or col >= pr or row < 0:
            return None
        k = row * pr + col
        return k if 0 <= k < len(self.items) else None

    def draw(self):
        cv = self.cv
        try:
            cv.delete("all")
        except self.app.tk.TclError:
            return
        c = self.cell
        pal = {tuple(x) for x in (self.app.pal or []) if x is not None}
        t = max(4, c // 5)
        top = max((n for n, _c in self.items), default=1) or 1
        bh = max(3, c // 7)
        for k, (n, col) in enumerate(self.items):
            x, y = self._xy(k)
            cv.create_rectangle(x, y, x + c - 3, y + c - 3, fill=hex_of(col), outline="#202020")
            bw = max(2, (c - 5) * n / float(top))            # pixel-count bar
            cv.create_rectangle(x + 1, y + c - 4 - bh, x + c - 4, y + c - 4,
                                fill="#000000", outline="")
            cv.create_rectangle(x + 1, y + c - 4 - bh, x + 1 + bw, y + c - 4,
                                fill="#ffffff", outline="")
            if col in pal:                                  # already in your palette
                cv.create_polygon(x + 1, y + 1, x + t, y + 1, x + 1, y + t,
                                  fill="#ffffff", outline="#000000")
        lw = max(2, round(c / 12))
        for k, (_n, col) in enumerate(self.items):          # crossed out: not added
            if col in self.off:
                x, y = self._xy(k)
                for xa, ya, xb, yb in ((x + 3, y + 3, x + c - 6, y + c - 6),
                                       (x + c - 6, y + 3, x + 3, y + c - 6)):
                    cv.create_line(xa, ya, xb, yb, fill="#000000", width=lw + 2)
                    cv.create_line(xa, ya, xb, yb, fill="#ff4040", width=lw)
        ow = max(1, min(4, round(c / 10)))
        for k in self.sel:
            if k < len(self.items):
                x, y = self._xy(k)
                cv.create_rectangle(x + ow, y + ow, x + c - 3 - ow, y + c - 3 - ow,
                                    outline="#000000", width=ow + 3)
                cv.create_rectangle(x + ow, y + ow, x + c - 3 - ow, y + c - 3 - ow,
                                    outline="#00ffff", width=ow)
        self._sel_text()

    def _sel_text(self):
        n = len(self.sel)
        self.sel_var.set("%d of %d selected   |   %s" % (n, len(self.items), self.app.clip_text()))

    # ---------------------------------------------------------- selection
    def _set_sel(self, sel):
        self.sel = set(sel)
        self.draw()

    def _all(self):
        self._set_sel(range(len(self.items)))
        return "break"

    def _press(self, ev):
        self.cv.focus_set()
        mode = "toggle" if ev.state & 0x0004 else "add" if ev.state & 0x0001 else "replace"
        self._drag = {"x0": ev.x, "y0": ev.y, "k": self._at(ev.x, ev.y), "mode": mode,
                      "moved": False, "out": False}

    def _motion(self, ev):
        d = self._drag
        if d is None:
            return
        if abs(ev.x - d["x0"]) + abs(ev.y - d["y0"]) > 4:
            d["moved"] = True
        inside = self.win.winfo_containing(ev.x_root, ev.y_root) is self.cv
        self.cv.delete("box")
        if inside or d["k"] is None:
            d["out"] = False
            self.cv.configure(cursor="")
            w = max(2, round(3 * self.ui))
            self.cv.create_rectangle(d["x0"], d["y0"], ev.x, ev.y, outline="#000000",
                                     width=w + 3, tags="box")
            self.cv.create_rectangle(d["x0"], d["y0"], ev.x, ev.y, outline="#00ffff", width=w,
                                     tags="box")
        else:
            d["out"] = True
            self.cv.configure(cursor="hand2")              # dragging a colour out

    def _release(self, ev):
        d, self._drag = self._drag, None
        self.cv.delete("box")
        self.cv.configure(cursor="")
        if d is None:
            return
        if d["out"] and d["k"] is not None:
            self._drop(ev, self.items[d["k"]][1])
            return
        if d["moved"]:
            x0, x1 = sorted((d["x0"], ev.x))
            y0, y1 = sorted((d["y0"], ev.y))
            hits = []
            for k in range(len(self.items)):
                x, y = self._xy(k)
                if x + self.cell > x0 and x < x1 and y + self.cell > y0 and y < y1:
                    hits.append(k)
        else:
            hits = [d["k"]] if d["k"] is not None else []
        if d["mode"] == "replace":
            sel = set(hits)
        elif d["mode"] == "add":
            sel = self.sel | set(hits)
        else:
            sel = self.sel ^ set(hits)
        self._set_sel(sel)

    def _drop(self, ev, rgb):
        """A swatch dragged out: onto the Paint ramp bar (node), the main grid
        (Paint: set that cell) or the colour picker."""
        a = self.app
        w = self.win.winfo_containing(ev.x_root, ev.y_root)
        if a.ramp is not None and not getattr(a.ramp, "FADE", False) and w is a.ramp.bar:
            a.ramp.drop_colour(ev.x_root, rgb)
        elif w is a.canvas:
            a.drop_colour_on_grid(ev.x_root, ev.y_root, rgb)
        elif a.picker is not None and w is not None and str(w).startswith(str(a.picker.win)):
            a.picker.set_rgb(rgb)
            a.picker._commit()
        else:
            a.status_var.set("Drop a swatch on the Paint ramp bar, a palette cell (Paint) or "
                             "the colour picker.")

    def _hover(self, ev):
        k = self._at(ev.x, ev.y)
        if k is None:
            self.hover_var.set("")
            return
        n, c = self.items[k]
        work = list(self.app.pal or [])
        where = ("   in your palette at #%d" % work.index(c)) if c in work else ""
        if c in self.off:
            where += "   NOT ADDED (crossed out - right-click to undo)"
        self.hover_var.set("%s  RGB(%3d,%3d,%3d)  %d pixel%s%s" % (
            hex_of(c), c[0], c[1], c[2], n, "" if n == 1 else "s", where))

    # ---------------------------------------------------------- actions
    def _chosen(self):
        cols = [self.items[k][1] for k in sorted(self.sel) if k < len(self.items)
                and self.items[k][1] not in self.off]
        if not cols:
            self.app.status_var.set("Select colours in the Picked colours window first "
                                    "(crossed-out ones are never added).")
        return cols

    def _usable(self):
        """Shown, not crossed out: [(count, rgb)]."""
        return [nc for nc in self.items if nc[1] not in self.off]

    def _toggle_off(self, ev):
        k = self._at(ev.x, ev.y)
        if k is None:
            return
        self.off ^= {self.items[k][1]}
        self.draw()
        self._hover(ev)

    def _hide_changed(self):
        self.app.s["picked_hide"] = bool(self.hide_var.get())
        self.sel = set()
        self._rebuild()

    def palette_changed(self):
        """The working palette changed: re-filter if hiding, else re-mark."""
        if self.hide_var.get():
            chosen = {self.items[k][1] for k in self.sel if k < len(self.items)}
            self._rebuild()
            self.sel = {k for k, (_n, c) in enumerate(self.items) if c in chosen}
        self.draw()

    def copy(self):
        cols = self._chosen()
        if cols:
            self.app.clip_set(cols, "the preview")
            self._sel_text()
        return "break"

    def copy_hex(self):
        cols = self._chosen()
        if not cols:
            return
        text = "\n".join(hex_of(c) for c in cols)
        try:
            self.app.root.clipboard_clear()
            self.app.root.clipboard_append(text)
        except self.app.tk.TclError:
            return
        self.app.status_var.set("Copied %d hex code%s as text." % (len(cols), "" if len(cols) == 1
                                                                    else "s"))

    def copy_cells(self):
        cols = self._chosen()
        if cols:
            self.app.cells_copy_from(cols, "the preview")
            self._sel_text()

    def insert_cells(self):
        cols = self._chosen()
        if cols:
            self.app.cells_insert_from(cols, "the preview")
            self._sel_text()

    def to_scratch(self):
        cols = self._chosen()
        if not cols:
            return
        sc = self.app.open_scratch()
        sc.add_colours(cols)
        self.app.status_var.set("Added %d colour%s to the Scratch palette." % (
            len(cols), "" if len(cols) == 1 else "s"))

    def select_in_palette(self):
        """Select, in the main grid, the cells holding the chosen colours
        (all shown colours when none are chosen)."""
        a = self.app
        cols = ({self.items[k][1] for k in self.sel if k < len(self.items)}
                or {c for _n, c in self._usable()})
        hits = {i for i, c in enumerate(a.rgbs or []) if c is not None and tuple(c) in cols}
        if not hits:
            a.status_var.set("None of those colours are in your palette.")
            return
        a.selection = hits
        a.recompute()
        a.status_var.set("Selected %d palette cell(s) holding %s colour(s)." % (
            len(hits), "the chosen" if self.sel else "the picked"))

    def _ramp_win(self):
        a = self.app
        r = a.ramp
        if a.tool != "paint" or r is None or getattr(r, "FADE", False):
            a.status_var.set("Open the Paint tool first (its ramp bar takes the colours).")
            return None
        return r

    def _set_nodes(self, r, cols, replace):
        nodes = r.nodes()
        m = len(cols)
        if replace and m >= 2:
            nodes[:] = [{"pos": r._to_pos(k / float(m - 1)), "rgb": list(c), "hsl": None}
                        for k, c in enumerate(cols)]
            nodes[0]["pos"], nodes[-1]["pos"] = 0.0, 1.0
        elif replace and m == 1:
            for n in nodes:
                n["rgb"], n["hsl"] = list(cols[0]), None
        else:
            for k, c in enumerate(cols):
                t = min(max(r._to_pos((k + 1) / float(m + 1)), 0.001), 0.999)
                nodes.append({"pos": t, "rgb": list(c), "hsl": None})
            nodes.sort(key=lambda q: q["pos"])
        r.set_active(nodes[0])
        r.changed()

    def add_nodes(self):
        """The chosen swatches (or all shown) onto the Paint ramp bar, dark -> light."""
        r = self._ramp_win()
        if r is None:
            return
        cols = ([self.items[k][1] for k in sorted(self.sel) if k < len(self.items)
                 and self.items[k][1] not in self.off]
                or [c for _n, c in self._usable()])
        if not cols:
            self.app.status_var.set("Draw a box on an image in the preview first.")
            return
        if len(cols) > 32:
            cols = [c for _n, c in sorted(((n, c) for n, c in self.items
                                           if c in set(cols)), key=lambda t: -t[0])[:32]]
        cols.sort(key=lambda c: oklab(c)[0])
        self._set_nodes(r, cols, bool(self.replace_var.get()))
        self.app.status_var.set("%s %d ramp node(s) from the picked colours." % (
            "Set" if self.replace_var.get() else "Added", len(cols)))

    def build_ramp(self):
        """The main grid's selected cells: a ramp that best represents the
        picked pixels (chosen swatches only, if any) - as a ramp preview."""
        a = self.app
        r = self._ramp_win()
        if r is None:
            return
        tg = sorted(i for i in a.editable(a.selection) if i < ENTRIES)
        if len(tg) < 2:
            a.status_var.set("Select at least two (unlocked) palette cells in the main grid "
                             "to build the ramp into.")
            return
        if self.sel:
            counts = [self.items[k] for k in sorted(self.sel) if k < len(self.items)
                      and self.items[k][1] not in self.off]
        elif self.off or self._hidden:
            counts = self._usable()
        else:
            counts = list(self.raw)
        if not counts:
            a.status_var.set("Draw a box on an image in the preview first.")
            return
        cols = build_ramp_colours(counts, len(tg), self.method_var.get())
        if a._ramp_backup is None:
            if not a.ramp_preview_start():
                return
        elif list(a._ramp_targets) != tg:      # a preview on other cells: retarget
            a._ramp_restore_base()
        a._ramp_targets = tg
        a._ramp_paused = False
        self._set_nodes(r, cols, True)
        a.ramp_preview_set(r.out_colours())
        r.update_buttons()
        r.draw_strip()
        a.status_var.set("Built a %d-step ramp (%s) from %d picked pixel(s) - Reverse / "
                         "Apply / Cancel on the Paint ramp." % (
                             len(tg), self.method_var.get().lower(),
                             sum(n for n, _c in counts)))

    def refresh(self):
        self.draw()

    def close(self):
        try:
            self.app.s["picked_geometry"] = self.win.geometry()
        except self.app.tk.TclError:
            pass
        self.app.picked = None
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass
