"""Picked colours: the colours inside a box drawn on the Palettised preview.

A reference window (like Playpals) that can stay open with any tool. Shows
the unique colours under the box exactly as displayed - original, palettised
or lit - with pixel counts. Select swatches and Copy (clipboard), Copy hex
(text), Copy Cells / Insert Cells (into the main palette), or add them to the
Scratch palette. Drag a swatch onto the Paint ramp bar to set a node.
"""

from ..cleanpal_lib_colour import hex_of, oklab
from ..cleanpal_lib_constants import ENTRIES, fmt_tol


def _lab(c):
    L, a, b = oklab(c)
    return (L * 100.0, a * 100.0, b * 100.0)


def merge_similar(counts, tol):
    """counts: [(n, rgb)] -> [(n, rgb)] with colours closer than tol (OKLab x100)
    grouped under their most frequent member."""
    if tol <= 0:
        return list(counts)
    reps = []                                  # [n, rgb, lab]
    t2 = tol * tol
    for n, c in sorted(counts, key=lambda nc: -nc[0]):
        lab = _lab(c)
        for r in reps:
            q = r[2]
            if (q[0] - lab[0]) ** 2 + (q[1] - lab[1]) ** 2 + (q[2] - lab[2]) ** 2 <= t2:
                r[0] += n
                break
        else:
            reps.append([n, c, lab])
    return [(n, c) for n, c, _l in reps]


class PickedColoursWin:
    MAX_SHOWN = 256
    SORTS = ("Most used", "Lightness", "Hue")

    def __init__(self, app):
        tk = app.tk
        from tkinter import ttk

        self.app = app
        s = app.s
        self.ui = ui = getattr(app, "ui", 1.0)
        self.win = tk.Toplevel(app.root)
        self.win.title("Picked colours")
        self.win.transient(app.root)
        self.win.minsize(int(420 * ui), int(300 * ui))
        try:
            self.win.geometry(s.get("picked_geometry") or "%dx%d" % (560 * ui, 460 * ui))
        except tk.TclError:
            pass
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.raw = []                    # [(count, rgb)] exactly as picked
        self.items = []                  # shown: [(count, rgb)]
        self.sel = set()
        self.source = ""
        self.original = False
        self._drag = None
        self.cell = int(28 * ui)

        top = ttk.Frame(self.win, padding=(8, 8, 8, 0))
        top.pack(fill="x")
        self.src_var = tk.StringVar(value="Draw a box on an image in the Palettised preview "
                                          "(single view).")
        ttk.Label(top, textvariable=self.src_var, font=("Segoe UI", 9, "bold")).pack(anchor="w")
        r = ttk.Frame(top)
        r.pack(fill="x", pady=(6, 0))
        ttk.Label(r, text="Sort").pack(side="left")
        self.sort_var = tk.StringVar(value=s.get("picked_sort", self.SORTS[0])
                                     if s.get("picked_sort") in self.SORTS else self.SORTS[0])
        cb = ttk.Combobox(r, textvariable=self.sort_var, values=self.SORTS, state="readonly",
                          width=11)
        cb.pack(side="left", padx=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._resort())
        ttk.Label(r, text="Merge similar").pack(side="left", padx=(12, 0))
        self.merge_var = tk.StringVar(value=fmt_tol(float(s.get("picked_merge", 3.0))))
        self.merge_sc = tk.Scale(r, from_=0, to=15, resolution=0.5, orient="horizontal",
                                 showvalue=0, length=int(120 * ui), sliderlength=int(26 * ui),
                                 width=int(16 * ui), command=self._merge_changed)
        self.merge_sc.set(float(s.get("picked_merge", 3.0)))
        self.merge_sc.pack(side="left", padx=(4, 0))
        ttk.Label(r, textvariable=self.merge_var, width=4).pack(side="left")
        self.merge_note = tk.StringVar()
        ttk.Label(r, textvariable=self.merge_note, foreground="#888").pack(side="left")

        self.cv = tk.Canvas(self.win, bg="#262626", highlightthickness=0)
        self.cv.pack(fill="both", expand=True, padx=8, pady=6)
        self.cv.bind("<Configure>", lambda e: self.draw())
        self.cv.bind("<ButtonPress-1>", self._press)
        self.cv.bind("<B1-Motion>", self._motion)
        self.cv.bind("<ButtonRelease-1>", self._release)
        self.cv.bind("<Motion>", self._hover)

        bot = ttk.Frame(self.win, padding=(8, 0, 8, 8))
        bot.pack(fill="x")
        self.hover_var = tk.StringVar()
        ttk.Label(bot, textvariable=self.hover_var, font=("Consolas", 9)).pack(anchor="w")
        self.sel_var = tk.StringVar()
        ttk.Label(bot, textvariable=self.sel_var, foreground="#666").pack(anchor="w",
                                                                        pady=(4, 0))
        bf = ttk.Frame(bot)                      # buttons on their own row: never cut off
        bf.pack(fill="x", pady=(4, 0))
        for text, cmd in (("Copy", self.copy), ("Copy hex", self.copy_hex),
                          ("Copy Cells", self.copy_cells), ("Insert Cells", self.insert_cells),
                          ("To scratch", self.to_scratch)):
            ttk.Button(bf, text=text, command=cmd).pack(side="left", padx=(0, 4))
        ttk.Label(bot, text="click / drag = select  Shift add  Ctrl toggle  Ctrl+A all\n"
                            "drag a swatch onto the Paint ramp bar = a node",
                  foreground="#888").pack(anchor="w", pady=(4, 0))
        w = self.win
        for seq in ("<Control-a>", "<Control-A>"):
            w.bind(seq, lambda e: self._all())
        w.bind("<Control-c>", lambda e: self.copy())
        w.bind("<Escape>", lambda e: self._set_sel(set()))
        from .gui_tool_windows import focus_on_click
        focus_on_click(w)
        self._sel_text()

    # ---------------------------------------------------------- content
    def set_colours(self, counts, source, original):
        """counts: [(n, rgb)] from the preview box."""
        self.raw = [(n, tuple(c)) for n, c in counts]
        self.source = source
        self.original = original
        self.sel = set()
        self.src_var.set(source)
        self.merge_sc.configure(state="normal" if original else "disabled")
        self._rebuild()
        self.win.deiconify()
        self.win.lift()

    def _merge_changed(self, x):
        v = float(x)
        self.merge_var.set(fmt_tol(v))
        self.app.s["picked_merge"] = v
        if self.original:
            self.sel = set()
            self._rebuild()

    def _rebuild(self):
        tol = float(self.merge_sc.get()) if self.original else 0.0
        items = merge_similar(self.raw, tol)
        n_all = len(items)
        items.sort(key=lambda nc: -nc[0])
        items = items[:self.MAX_SHOWN]
        self.items = items
        self._apply_sort()
        extra = ""
        if self.original and tol > 0:
            extra = "  %d exact -> %d" % (len(self.raw), n_all)
        if n_all > self.MAX_SHOWN:
            extra += "  (top %d of %d shown)" % (self.MAX_SHOWN, n_all)
        self.merge_note.set(extra if self.original else "  (exact)")
        self.draw()

    def _apply_sort(self):
        k = self.sort_var.get()
        if k == "Lightness":
            self.items.sort(key=lambda nc: -oklab(nc[1])[0])
        elif k == "Hue":
            import math

            def hue(nc):
                L, a, b = oklab(nc[1])
                c = math.hypot(a, b)
                return (0 if c < 0.02 else 1, math.atan2(b, a) if c >= 0.02 else -L)
            self.items.sort(key=hue)
        else:
            self.items.sort(key=lambda nc: -nc[0])

    def _resort(self):
        chosen = {self.items[i][1] for i in self.sel if i < len(self.items)}
        self.app.s["picked_sort"] = self.sort_var.get()
        self._apply_sort()
        self.sel = {i for i, (_n, c) in enumerate(self.items) if c in chosen}
        self.draw()

    # ---------------------------------------------------------- drawing
    def _per_row(self):
        return max(4, (max(self.cv.winfo_width(), 100) - 4) // self.cell)

    def _xy(self, k):
        pr = self._per_row()
        return 2 + (k % pr) * self.cell, 2 + (k // pr) * self.cell

    def _at(self, x, y):
        pr = self._per_row()
        col, row = int((x - 2) // self.cell), int((y - 2) // self.cell)
        if x < 2 or col >= pr or row < 0:
            return None
        k = row * pr + col
        return k if 0 <= k < len(self.items) else None

    def draw(self):
        cv = self.cv
        try:
            cv.delete("all")
        except self.app.tk.TclError:
            return
        c = self.cell
        pal = {tuple(x) for x in (self.app.pal or []) if x is not None}
        t = max(4, c // 5)
        for k, (_n, col) in enumerate(self.items):
            x, y = self._xy(k)
            cv.create_rectangle(x, y, x + c - 3, y + c - 3, fill=hex_of(col), outline="#202020")
            if col in pal:                                  # already in your palette
                cv.create_polygon(x + 1, y + 1, x + t, y + 1, x + 1, y + t,
                                  fill="#ffffff", outline="#000000")
        ow = max(1, min(4, round(c / 10)))
        for k in self.sel:
            if k < len(self.items):
                x, y = self._xy(k)
                cv.create_rectangle(x + ow, y + ow, x + c - 3 - ow, y + c - 3 - ow,
                                    outline="#000000", width=ow + 3)
                cv.create_rectangle(x + ow, y + ow, x + c - 3 - ow, y + c - 3 - ow,
                                    outline="#00ffff", width=ow)
        self._sel_text()

    def _sel_text(self):
        n = len(self.sel)
        self.sel_var.set("%d of %d selected   |   %s" % (n, len(self.items), self.app.clip_text()))

    # ---------------------------------------------------------- selection
    def _set_sel(self, sel):
        self.sel = set(sel)
        self.draw()

    def _all(self):
        self._set_sel(range(len(self.items)))
        return "break"

    def _press(self, ev):
        self.cv.focus_set()
        mode = "toggle" if ev.state & 0x0004 else "add" if ev.state & 0x0001 else "replace"
        self._drag = {"x0": ev.x, "y0": ev.y, "k": self._at(ev.x, ev.y), "mode": mode,
                      "moved": False, "out": False}

    def _motion(self, ev):
        d = self._drag
        if d is None:
            return
        if abs(ev.x - d["x0"]) + abs(ev.y - d["y0"]) > 4:
            d["moved"] = True
        inside = self.win.winfo_containing(ev.x_root, ev.y_root) is self.cv
        self.cv.delete("box")
        if inside or d["k"] is None:
            d["out"] = False
            self.cv.configure(cursor="")
            w = max(2, round(3 * self.ui))
            self.cv.create_rectangle(d["x0"], d["y0"], ev.x, ev.y, outline="#000000",
                                     width=w + 3, tags="box")
            self.cv.create_rectangle(d["x0"], d["y0"], ev.x, ev.y, outline="#00ffff", width=w,
                                     tags="box")
        else:
            d["out"] = True
            self.cv.configure(cursor="hand2")              # dragging a colour out

    def _release(self, ev):
        d, self._drag = self._drag, None
        self.cv.delete("box")
        self.cv.configure(cursor="")
        if d is None:
            return
        if d["out"] and d["k"] is not None:
            self._drop(ev, self.items[d["k"]][1])
            return
        if d["moved"]:
            x0, x1 = sorted((d["x0"], ev.x))
            y0, y1 = sorted((d["y0"], ev.y))
            hits = []
            for k in range(len(self.items)):
                x, y = self._xy(k)
                if x + self.cell > x0 and x < x1 and y + self.cell > y0 and y < y1:
                    hits.append(k)
        else:
            hits = [d["k"]] if d["k"] is not None else []
        if d["mode"] == "replace":
            sel = set(hits)
        elif d["mode"] == "add":
            sel = self.sel | set(hits)
        else:
            sel = self.sel ^ set(hits)
        self._set_sel(sel)

    def _drop(self, ev, rgb):
        """A swatch dragged out: onto the Paint ramp bar (node), the main grid
        (Paint: set that cell) or the colour picker."""
        a = self.app
        w = self.win.winfo_containing(ev.x_root, ev.y_root)
        if a.ramp is not None and not getattr(a.ramp, "FADE", False) and w is a.ramp.bar:
            a.ramp.drop_colour(ev.x_root, rgb)
        elif w is a.canvas:
            a.drop_colour_on_grid(ev.x_root, ev.y_root, rgb)
        elif a.picker is not None and w is not None and str(w).startswith(str(a.picker.win)):
            a.picker.set_rgb(rgb)
            a.picker._commit()
        else:
            a.status_var.set("Drop a swatch on the Paint ramp bar, a palette cell (Paint) or "
                             "the colour picker.")

    def _hover(self, ev):
        k = self._at(ev.x, ev.y)
        if k is None:
            self.hover_var.set("")
            return
        n, c = self.items[k]
        work = list(self.app.pal or [])
        where = ("   in your palette at #%d" % work.index(c)) if c in work else ""
        self.hover_var.set("%s  RGB(%3d,%3d,%3d)  %d pixel%s%s" % (
            hex_of(c), c[0], c[1], c[2], n, "" if n == 1 else "s", where))

    # ---------------------------------------------------------- actions
    def _chosen(self):
        cols = [self.items[k][1] for k in sorted(self.sel) if k < len(self.items)]
        if not cols:
            self.app.status_var.set("Select colours in the Picked colours window first.")
        return cols

    def copy(self):
        cols = self._chosen()
        if cols:
            self.app.clip_set(cols, "the preview")
            self._sel_text()
        return "break"

    def copy_hex(self):
        cols = self._chosen()
        if not cols:
            return
        text = "\n".join(hex_of(c) for c in cols)
        try:
            self.app.root.clipboard_clear()
            self.app.root.clipboard_append(text)
        except self.app.tk.TclError:
            return
        self.app.status_var.set("Copied %d hex code%s as text." % (len(cols), "" if len(cols) == 1
                                                                    else "s"))

    def copy_cells(self):
        cols = self._chosen()
        if cols:
            self.app.cells_copy_from(cols, "the preview")
            self._sel_text()

    def insert_cells(self):
        cols = self._chosen()
        if cols:
            self.app.cells_insert_from(cols, "the preview")
            self._sel_text()

    def to_scratch(self):
        cols = self._chosen()
        if not cols:
            return
        sc = self.app.open_scratch()
        sc.add_colours(cols)
        self.app.status_var.set("Added %d colour%s to the Scratch palette." % (
            len(cols), "" if len(cols) == 1 else "s"))

    def refresh(self):
        self.draw()

    def close(self):
        try:
            self.app.s["picked_geometry"] = self.win.geometry()
        except self.app.tk.TclError:
            pass
        self.app.picked = None
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass
