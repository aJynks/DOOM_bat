"""Scene: a still, Doom-like screen made from the IWAD's graphics, drawn the
way the engine draws it - palette INDICES first, then every pixel through a
COLORMAP row and the live palette:

* walls / floor / ceiling: Doom light diminishing (sector light + distance,
  cleanpal_lib_lighting); side walls N-S (+1 band), back wall E-W (-1)
* monster + item sprites: wall rows at their distance; weapon: brightest
  sprite row for the light level
* sky: row 0 (full bright); with invulnerability it follows row 32 when
  "Sky follows invulnerability" is ticked (dsda-doom / Nyan at MBF / MBF21
  complevels: comp_skymap = 0 -> fixedcolormap; vanilla / Boom keep it)
* invulnerability: row 32 for the whole 3D view; the status bar is never
  colormapped (drawn with the palette straight)

Live: re-renders when the palette or the COLORMAP result changes."""

import struct

from ..cleanpal_lib_constants import ENTRIES
from ..cleanpal_lib_lighting import flat_row, wall_row
from ..cleanpal_lib_wadgfx import (_ID_PAL, compose_texture, decode_doom_picture,
                                   is_doom_picture, parse_pnames, parse_texturex)

SW, VH, SBH = 320, 168, 32          # screen width, 3D view height, status bar
CX, CY, FOC = 160.0, 84.0, 160.0    # 90 degree view
EYE, CEIL, HALF, BACK = 41.0, 128.0, 128.0, 640.0
INVUL = 32

MONSTERS = ["TROOA1", "POSSA1", "SPOSA1", "SARGA1", "HEADA1", "BOSSA1", "SKULA1",
            "CPOSA1", "SKELA1", "FATTA1", "BSPIA1", "PAINA1", "CYBRA1", "SPIDA1"]
ITEMS = ["MEDIA0", "STIMA0", "SOULA0", "PINVA0", "MEGAA0", "BON1A0", "BON2A0", "ARM1A0",
         "ARM2A0", "SHELA0", "CLIPA0", "ROCKA0", "CELLA0", "PSTRA0", "BKEYA0"]
WEAPONS = ["PISGA0", "SHTGA0", "SHT2A0", "CHGGA0", "MISGA0", "PLSGA0", "BFGGA0", "SAWGA0",
           "PUNGA0"]
SCENE_DEFAULTS = {"wall": "STARTAN3", "floor": "FLOOR4_8", "ceiling": "(sky)",
                  "sky": "SKY1", "monster": "TROOA1", "item": "MEDIA0", "weapon": "PISGA0",
                  "light": 160, "invul": False, "both": False, "skyinv": True, "zoom": 2}


class _Pic:
    """An index image: w, h, idx (bytes), alpha (bytes), left / top offsets."""

    def __init__(self, img, left=0, top=0):
        self.w, self.h = img.size
        r, _g, _b, a = img.split()
        self.idx = r.tobytes()
        self.alpha = a.tobytes()
        self.left, self.top = left, top


class SceneGfx:
    """The graphics the scene uses, as palette indices (from the IWAD, a PWAD
    on top if given)."""

    def __init__(self, archives):
        self.archs = [a for a in archives if a is not None]
        self.pnames, self.tex = [], {}
        for a in self.archs:                      # later archives win
            pn = parse_pnames(a.lump("PNAMES"))
            if pn:
                self.pnames = pn
            for nm in ("TEXTURE1", "TEXTURE2"):
                for t in parse_texturex(a.lump(nm)):
                    self.tex[t["name"]] = (t, self.pnames)
        self.flats, self.sprites = {}, {}
        for a in self.archs:
            ns = None
            for i, (name, _pos, size) in enumerate(a.lumps):
                if name in ("F_START", "FF_START"):
                    ns = "f"
                    continue
                if name in ("S_START", "SS_START"):
                    ns = "s"
                    continue
                if name in ("F_END", "FF_END", "S_END", "SS_END"):
                    ns = None
                    continue
                if ns == "f" and size >= 4096:
                    self.flats[name] = (a, i)
                elif ns == "s" and size:
                    self.sprites[name] = (a, i)
        self._cache = {}

    def textures(self):
        return sorted(self.tex)

    def flat_names(self):
        return sorted(self.flats)

    def has_sprite(self, n):
        return n in self.sprites

    def _patch(self, name):
        for a in reversed(self.archs):
            d = a.global_lump(name)
            if d is not None and is_doom_picture(d):
                return decode_doom_picture(d, _ID_PAL)
        return None

    def texture(self, name):
        key = ("t", name)
        if key not in self._cache:
            t = self.tex.get(name)
            if t is None:
                self._cache[key] = None
            else:
                img, _m = compose_texture(t[0], t[1], self._patch)
                self._cache[key] = _Pic(img)
        return self._cache[key]

    def flat(self, name):
        key = ("f", name)
        if key not in self._cache:
            f = self.flats.get(name)
            if f is None:
                self._cache[key] = None
            else:
                d = f[0].lump_at(f[1])[:4096]
                self._cache[key] = (bytes(d), 64)
        return self._cache[key]

    def sprite(self, name):
        key = ("s", name)
        if key not in self._cache:
            s = self.sprites.get(name)
            pic = None
            if s is not None:
                d = s[0].lump_at(s[1])
                if is_doom_picture(d):
                    left, top = struct.unpack_from("<hh", d, 4)
                    pic = _Pic(decode_doom_picture(d, _ID_PAL), left, top)
            self._cache[key] = pic
        return self._cache[key]

    def stbar(self):
        key = ("p", "STBAR")
        if key not in self._cache:
            img = self._patch("STBAR")
            self._cache[key] = _Pic(img) if img is not None else None
        return self._cache[key]


def render(gfx, o, rows, pal, invul):
    """-> PIL RGB image 320x200 of the scene. rows = COLORMAP result rows
    (>= 33 rows of 256 indices), pal = 256 colours (None = black)."""
    from PIL import Image

    light = int(o.get("light", 160))
    sky_on = o.get("ceiling") == "(sky)"
    idx = bytearray(SW * VH)
    row = bytearray(SW * VH)
    wall = gfx.texture(o.get("wall"))
    floor = gfx.flat(o.get("floor"))
    ceil = None if sky_on else gfx.flat(o.get("ceiling"))
    sky = gfx.texture(o.get("sky")) if sky_on else None
    sky_row = (INVUL if o.get("skyinv", True) else 0) if invul else 0
    fr_cache = {}

    def frow(d):
        k = int(d)
        v = fr_cache.get(k)
        if v is None:
            v = fr_cache[k] = INVUL if invul else flat_row(light, d)
        return v

    for x in range(SW):
        dx = (x + 0.5 - CX) / FOC
        side = HALF / abs(dx) if dx else 1e9
        if side < BACK:
            dist, u, orient = side, side, 2
        else:
            dist, u, orient = BACK, dx * BACK + 1024.0, 1
        top = CY - (CEIL - EYE) * FOC / dist
        bot = CY + EYE * FOC / dist
        wrow = INVUL if invul else wall_row(light, dist, orient)
        y0, y1 = max(0, int(top + 0.5)), min(VH, int(bot + 0.5))
        if wall is not None:
            tu = int(u) % wall.w
            for y in range(y0, y1):
                z = EYE + (CY - y - 0.5) * dist / FOC
                tv = int(CEIL - z) % wall.h
                k = tv * wall.w + tu
                p = y * SW + x
                idx[p] = wall.idx[k] if wall.alpha[k] else 0
                row[p] = wrow
        for y in range(y1, VH):                   # floor
            d = EYE * FOC / (y + 0.5 - CY)
            p = y * SW + x
            if floor is not None:
                fx, fy = int(dx * d) & 63, int(d) & 63
                idx[p] = floor[0][fy * 64 + fx]
            row[p] = frow(d)
        for y in range(0, y0):                    # ceiling / sky
            p = y * SW + x
            if sky_on:
                if sky is not None:
                    su = int(x * 256 / SW) % sky.w
                    sv = min(sky.h - 1, int(y * sky.h / 100.0))
                    k = sv * sky.w + su
                    idx[p] = sky.idx[k]
                row[p] = sky_row
            else:
                d = (CEIL - EYE) * FOC / (CY - y - 0.5)
                if ceil is not None:
                    fx, fy = int(dx * d) & 63, int(d) & 63
                    idx[p] = ceil[0][fy * 64 + fx]
                row[p] = frow(d)

    def sprite_at(pic, wx, wd, prow):
        if pic is None:
            return
        sc = FOC / wd
        x0 = CX + (wx - pic.left) * sc
        ytop = CY - (pic.top - EYE) * sc
        w2, h2 = int(pic.w * sc), int(pic.h * sc)
        for sx in range(max(0, int(x0)), min(SW, int(x0) + w2)):
            tx = int((sx - x0) / sc)
            if not 0 <= tx < pic.w:
                continue
            for sy in range(max(0, int(ytop)), min(VH, int(ytop) + h2)):
                ty = int((sy - ytop) / sc)
                if not 0 <= ty < pic.h:
                    continue
                k = ty * pic.w + tx
                if pic.alpha[k]:
                    p = sy * SW + sx
                    idx[p] = pic.idx[k]
                    row[p] = prow

    sprite_at(gfx.sprite(o.get("monster")), 20.0, 360.0,
              INVUL if invul else wall_row(light, 360.0))
    sprite_at(gfx.sprite(o.get("item")), -70.0, 200.0,
              INVUL if invul else wall_row(light, 200.0))
    wp = gfx.sprite(o.get("weapon"))
    if wp is not None:                            # psprite: x = 1 - left, y = 16 - top
        prow = INVUL if invul else wall_row(light, 1)
        x0, y0 = 1 - wp.left, 16 - wp.top
        for ty in range(wp.h):
            sy = y0 + ty
            if not 0 <= sy < VH:
                continue
            for tx in range(wp.w):
                sx = x0 + tx
                k = ty * wp.w + tx
                if 0 <= sx < SW and wp.alpha[k]:
                    p = sy * SW + sx
                    idx[p] = wp.idx[k]
                    row[p] = prow
    # through the COLORMAP + palette
    pal = [tuple(c) if c is not None else (0, 0, 0) for c in pal[:ENTRIES]]
    pal += [(0, 0, 0)] * (ENTRIES - len(pal))
    luts = {}
    out = bytearray(SW * 200 * 3)
    for p in range(SW * VH):
        r = row[p]
        lut = luts.get(r)
        if lut is None:
            rr = rows[r]
            lut = luts[r] = [pal[rr[i]] if 0 <= rr[i] < ENTRIES else (0, 0, 0)
                             for i in range(ENTRIES)]
        out[p * 3:p * 3 + 3] = bytes(lut[idx[p]])
    sb = gfx.stbar()                              # status bar: never colormapped
    for y in range(SBH):
        for x in range(SW):
            p = ((VH + y) * SW + x) * 3
            if sb is not None and x < sb.w and y < sb.h:
                k = y * sb.w + x
                out[p:p + 3] = bytes(pal[sb.idx[k]]) if sb.alpha[k] else b"\0\0\0"
    return Image.frombytes("RGB", (SW, 200), bytes(out))


class SceneWin:
    """The Scene window (one per app: app.scene_win)."""

    def __init__(self, app):
        from tkinter import ttk
        tk = app.tk
        self.app = app
        self.ui = getattr(app, "ui", 1.0)
        o = dict(SCENE_DEFAULTS)
        if isinstance(app.s.get("scene"), dict):
            o.update({k: v for k, v in app.s["scene"].items() if k in SCENE_DEFAULTS})
        self.o = o
        self.gfx = self._load_gfx()
        self._key = None
        self._img = None
        self._after = None
        w = self.win = tk.Toplevel(app.root)
        w.title("cleanpal - Scene (how it looks in game)")
        w.protocol("WM_DELETE_WINDOW", self.close)
        w.bind("<Escape>", lambda e: self.close())
        top = ttk.Frame(w, padding=(8, 6, 8, 0))
        top.pack(fill="x")
        self.inv_var = tk.StringVar(value="invul" if o["invul"] else "normal")
        for t, v in (("Normal", "normal"), ("Invulnerability", "invul")):
            ttk.Radiobutton(top, text=t, value=v, variable=self.inv_var,
                            command=self._changed).pack(side="left", padx=(0, 8))
        self.both_var = tk.BooleanVar(value=o["both"])
        ttk.Checkbutton(top, text="Side by side", variable=self.both_var,
                        command=self._changed).pack(side="left", padx=(6, 0))
        self.skyinv_var = tk.BooleanVar(value=o["skyinv"])
        ttk.Checkbutton(top, text="Sky follows invulnerability (MBF / MBF21)",
                        variable=self.skyinv_var, command=self._changed).pack(
            side="left", padx=(12, 0))
        ttk.Label(top, text="Light").pack(side="left", padx=(12, 2))
        self.light_var = tk.IntVar(value=int(o["light"]))
        sp = ttk.Spinbox(top, from_=0, to=255, increment=16, width=5,
                         textvariable=self.light_var, command=self._changed)
        sp.pack(side="left")
        sp.bind("<Return>", lambda e: self._changed())
        ttk.Label(top, text="Zoom").pack(side="left", padx=(12, 2))
        self.zoom_var = tk.IntVar(value=int(o["zoom"]))
        zp = ttk.Spinbox(top, from_=1, to=6, width=3, textvariable=self.zoom_var,
                         command=self._changed)
        zp.pack(side="left")
        row2 = ttk.Frame(w, padding=(8, 4, 8, 0))
        row2.pack(fill="x")
        self.cbs = {}
        texs = self.gfx.textures() if self.gfx else []
        flats = self.gfx.flat_names() if self.gfx else []
        lists = (("wall", "Wall", texs), ("floor", "Floor", flats),
                 ("ceiling", "Ceiling", ["(sky)"] + flats),
                 ("sky", "Sky", [t for t in texs if t.startswith("SKY")] or texs),
                 ("monster", "Monster", self._have(MONSTERS)),
                 ("item", "Item", self._have(ITEMS)),
                 ("weapon", "Weapon", self._have(WEAPONS)))
        for key, lab, vals in lists:
            ttk.Label(row2, text=lab).pack(side="left", padx=(0, 2))
            v = tk.StringVar(value=o[key] if o[key] in vals or not vals else vals[0])
            cb = ttk.Combobox(row2, textvariable=v, values=vals, state="readonly",
                              width=max(6, min(10, max([len(x) for x in vals] or [6]))))
            cb.pack(side="left", padx=(0, 8))
            cb.bind("<<ComboboxSelected>>", lambda e: self._changed())
            self.cbs[key] = v
        self.note = tk.StringVar()
        ttk.Label(w, textvariable=self.note, foreground="#666", padding=(8, 2)).pack(
            anchor="w")
        self.cv = tk.Canvas(w, highlightthickness=0, bg="#000000")
        self.cv.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        if not self.gfx:
            self.note.set("No IWAD loaded - choose one (Choose the IWAD) to see the scene.")
        self.render_now()
        self._poll()

    def _load_gfx(self):
        a = self.app
        try:
            iw = a.iwad_archive()
        except Exception:  # noqa: BLE001
            iw = None
        if iw is None:
            return None
        return SceneGfx([iw])

    def _have(self, names):
        return [n for n in names if self.gfx and self.gfx.has_sprite(n)] or names[:1]

    def set_invul(self, on):
        self.inv_var.set("invul" if on else "normal")
        self._changed()

    def _opts(self):
        o = dict(self.o)
        for k, v in self.cbs.items():
            o[k] = v.get()
        try:
            o["light"] = max(0, min(255, int(self.light_var.get())))
        except (ValueError, self.app.tk.TclError):
            pass
        try:
            o["zoom"] = max(1, min(6, int(self.zoom_var.get())))
        except (ValueError, self.app.tk.TclError):
            pass
        o["invul"] = self.inv_var.get() == "invul"
        o["both"] = bool(self.both_var.get())
        o["skyinv"] = bool(self.skyinv_var.get())
        return o

    def _changed(self):
        self.o = self._opts()
        self.app.s["scene"] = dict(self.o)
        self._key = None
        self.render_now()

    def _state_key(self):
        a = self.app
        try:
            res, _f = a.cmap_result()
            rows = tuple(tuple(r) for r in res.rows[:INVUL + 1])
        except Exception:  # noqa: BLE001
            rows = None
        return (tuple(a.rgbs[:ENTRIES]) if a.rgbs else None, rows)

    def _poll(self):
        self._after = None
        if self.win is None:
            return
        try:
            if self._state_key() != self._key:
                self.render_now()
        except Exception:  # noqa: BLE001
            pass
        self._after = self.app.root.after(400, self._poll)

    def render_now(self):
        from PIL import Image, ImageTk
        a = self.app
        if self.gfx is None or a.rgbs is None:
            return
        key = self._state_key()
        self._key = key
        try:
            res, _f = a.cmap_result()
            rows = res.rows
        except Exception:  # noqa: BLE001
            rows = [list(range(ENTRIES))] * (INVUL + 1)
        o = self.o
        pal = a.rgbs[:ENTRIES]
        if o["both"]:
            im1 = render(self.gfx, o, rows, pal, False)
            im2 = render(self.gfx, o, rows, pal, True)
            img = Image.new("RGB", (SW * 2 + 4, 200), (40, 40, 40))
            img.paste(im1, (0, 0))
            img.paste(im2, (SW + 4, 0))
        else:
            img = render(self.gfx, o, rows, pal, o["invul"])
        z = o["zoom"]
        img = img.resize((img.size[0] * z, int(img.size[1] * 1.2 * z)), Image.NEAREST)
        self.image = img
        self._img = ImageTk.PhotoImage(img)
        c = self.cv
        c.delete("all")
        c.configure(width=img.size[0], height=img.size[1])
        c.create_image(0, 0, anchor="nw", image=self._img)
        self.note.set(("Normal | Invulnerability" if o["both"] else
                       "Invulnerability (row 32)" if o["invul"] else "Normal lighting") +
                      " - live palette + COLORMAP, unapplied edits included. Status bar "
                      "isn't colormapped, as in game.")

    def close(self):
        if self._after is not None:
            try:
                self.app.root.after_cancel(self._after)
            except Exception:  # noqa: BLE001
                pass
        self.app.s["scene"] = dict(self._opts())
        try:
            self.win.destroy()
        except Exception:  # noqa: BLE001
            pass
        self.win = None
        self.app.scene_win = None


def open_scene(app, invul=None):
    w = getattr(app, "scene_win", None)
    if w is None or w.win is None:
        w = app.scene_win = SceneWin(app)
    else:
        w.win.deiconify()
        w.win.lift()
    if invul is not None:
        w.set_invul(invul)
    return w
