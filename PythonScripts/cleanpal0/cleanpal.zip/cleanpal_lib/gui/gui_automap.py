"""Automap: the OPTIONS lump's mapcolor_* keys for dsda-doom / Nyan Doom.

A free window (never changes the palette). Left: a map preview (the IWAD
plus any WADs you open; Left / Right = WAD, Up / Down = map; wheel / + / -
zoom, drag pan, Fit / F) drawn with the ports' automap rules
(cleanpal_lib_automap) in WIP pal0 colours. Right: every mapcolor key -
swatch, index, Pick... (pal0 popup), Off for keys where 0 turns a feature
off. Default = Classic Doom. Export OPTIONS... writes every key (and keeps
the other lines of a loaded OPTIONS). Values live on the app
(`app.automap`, `app.automap_other`) and are saved in projects.
"""

import os
import time

from ..cleanpal_lib_automap import (
    DSDA_DEFAULTS, FEATURE, KEYS, NYAN_ONLY, REVEAL_LABEL, REVEALS, DoomMap, classic,
    find_maps, line_colour_key, options_text, parse_options,
)
from ..cleanpal_lib_colour import hex_of
from .gui_tool_windows import focus_on_click

PREVIEW_KEYS = {k[0] for k in KEYS if k[1] == "Lines" and k[0] != "mapcolor_tagfinder"}


class AutomapWin:
    POS_KEY = "automap_pos"

    def __init__(self, app):
        tk = app.tk
        from tkinter import ttk

        self.app = app
        self.ui = ui = getattr(app, "ui", 1.0)
        s = app.s
        self._undo, self._redo = [], []
        self._last_push = 0.0
        self._arch = {}
        self._maps = {}
        self._map = None
        self._map_key = None
        self._pal_key = None
        self._drag = None
        self.cx = self.cy = 0.0
        self.scale = 1.0
        self._chooser = None
        wads = s.get("automap_wads")
        self.wads = [p for p in wads if isinstance(p, str) and os.path.isfile(p)] \
            if isinstance(wads, list) else []

        win = self.win = tk.Toplevel(app.root)
        win.title("Automap colours - OPTIONS")
        win.transient(app.root)
        win.protocol("WM_DELETE_WINDOW", self.close)
        win.bind("<Escape>", lambda e: self.close())
        for k in ("<Control-z>", "<Control-Z>"):
            win.bind(k, lambda e: self.undo())
        for k in ("<Control-y>", "<Control-Y>"):
            win.bind(k, lambda e: self.undo(redo=True))
        win.columnconfigure(0, weight=3)
        win.columnconfigure(1, weight=1)
        win.rowconfigure(0, weight=1)

        # ---------------- map (left)
        mf = ttk.LabelFrame(win, text="Map preview", padding=6)
        mf.grid(row=0, column=0, sticky="nsew", padx=(8, 4), pady=8)
        mf.columnconfigure(0, weight=1)
        mf.rowconfigure(3, weight=1)
        r1 = ttk.Frame(mf)
        r1.grid(row=0, column=0, sticky="ew")
        ttk.Button(r1, text="Open WAD...", command=self.open_wad).pack(side="left")
        ttk.Button(r1, text="◀", width=3, command=lambda: self.step_wad(-1)).pack(
            side="left", padx=(8, 0))
        self.wad_var = tk.StringVar()
        self.wad_cb = ttk.Combobox(r1, textvariable=self.wad_var, state="readonly",
                                   width=26)
        self.wad_cb.pack(side="left", padx=(2, 0))
        self.wad_cb.bind("<<ComboboxSelected>>", lambda e: self.choose_wad())
        ttk.Button(r1, text="▶", width=3, command=lambda: self.step_wad(1)).pack(
            side="left", padx=(2, 0))
        ttk.Button(r1, text="Close", command=self.close_wad).pack(side="left", padx=(8, 0))
        ttk.Button(r1, text="Close all", command=self.close_all).pack(side="left",
                                                                     padx=(4, 0))
        r2 = ttk.Frame(mf)
        r2.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Button(r2, text="▲", width=3, command=lambda: self.step_map(-1)).pack(
            side="left")
        self.map_var = tk.StringVar()
        self.map_cb = ttk.Combobox(r2, textvariable=self.map_var, state="readonly",
                                   width=10)
        self.map_cb.pack(side="left", padx=(2, 0))
        self.map_cb.bind("<<ComboboxSelected>>", lambda e: self.choose_map())
        ttk.Button(r2, text="▼", width=3, command=lambda: self.step_map(1)).pack(
            side="left", padx=(2, 0))
        self.reveal_var = tk.StringVar(value=s.get("automap_reveal") if s.get(
            "automap_reveal") in REVEALS else "iddt")
        ttk.Label(r2, text="   Show:").pack(side="left")
        for k in REVEALS:
            ttk.Radiobutton(r2, text=REVEAL_LABEL[k], value=k, variable=self.reveal_var,
                            command=self._opts).pack(side="left", padx=(4, 0))
        r3 = ttk.Frame(mf)
        r3.grid(row=2, column=0, sticky="ew", pady=(4, 0))
        self.found_var = tk.BooleanVar(value=bool(s.get("automap_found", False)))
        ttk.Checkbutton(r3, text="Secrets found", variable=self.found_var,
                        command=self._opts).pack(side="left")
        self.grid_var = tk.BooleanVar(value=bool(s.get("automap_grid", False)))
        ttk.Checkbutton(r3, text="Grid", variable=self.grid_var,
                        command=self._opts).pack(side="left", padx=(8, 0))
        ttk.Button(r3, text="−", width=3, command=lambda: self.zoom(1 / 1.25)).pack(
            side="left", padx=(12, 0))
        ttk.Button(r3, text="+", width=3, command=lambda: self.zoom(1.25)).pack(
            side="left", padx=(2, 0))
        ttk.Button(r3, text="Fit", width=5, command=self.fit).pack(side="left",
                                                                  padx=(2, 0))
        self.info_var = tk.StringVar()
        ttk.Label(r3, textvariable=self.info_var, foreground="#666").pack(side="left",
                                                                         padx=(10, 0))
        self.cv = tk.Canvas(mf, width=int(640 * ui), height=int(440 * ui),
                            highlightthickness=0, bg="#000000", cursor="fleur")
        self.cv.grid(row=3, column=0, sticky="nsew", pady=(6, 0))
        self.cv.bind("<Configure>", lambda e: self._on_resize())
        self.cv.bind("<ButtonPress-1>", self._press)
        self.cv.bind("<B1-Motion>", self._motion)
        self.cv.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag", None))
        self.cv.bind("<MouseWheel>", lambda e: self.zoom(1.25 if e.delta > 0 else 1 / 1.25,
                                                         e.x, e.y))
        self.cv.bind("<Button-4>", lambda e: self.zoom(1.25, e.x, e.y))
        self.cv.bind("<Button-5>", lambda e: self.zoom(1 / 1.25, e.x, e.y))
        self.cv.bind("<Motion>", self._hover)
        self.note_var = tk.StringVar()
        ttk.Label(mf, textvariable=self.note_var, foreground="#666", justify="left").grid(
            row=4, column=0, sticky="w", pady=(4, 0))
        for k, f in (("<Left>", lambda e: self._key(self.step_wad, -1)),
                     ("<Right>", lambda e: self._key(self.step_wad, 1)),
                     ("<Up>", lambda e: self._key(self.step_map, -1)),
                     ("<Down>", lambda e: self._key(self.step_map, 1)),
                     ("<plus>", lambda e: self._key(self.zoom, 1.25)),
                     ("<equal>", lambda e: self._key(self.zoom, 1.25)),
                     ("<KP_Add>", lambda e: self._key(self.zoom, 1.25)),
                     ("<minus>", lambda e: self._key(self.zoom, 1 / 1.25)),
                     ("<KP_Subtract>", lambda e: self._key(self.zoom, 1 / 1.25)),
                     ("<f>", lambda e: self._key(self.fit)),
                     ("<F>", lambda e: self._key(self.fit))):
            win.bind(k, f)

        # ---------------- list (right)
        lf = ttk.LabelFrame(win, text="mapcolor_* (PLAYPAL indices)", padding=6)
        lf.grid(row=0, column=1, sticky="nsew", padx=(4, 8), pady=8)
        lf.columnconfigure(0, weight=1)
        lf.rowconfigure(2, weight=1)
        b1 = ttk.Frame(lf)
        b1.grid(row=0, column=0, sticky="ew")
        ttk.Button(b1, text="Reset to Classic", command=self.reset_classic).pack(side="left")
        ttk.Button(b1, text="dsda defaults", command=self.reset_dsda).pack(side="left",
                                                                          padx=(6, 0))
        self.undo_btn = ttk.Button(b1, text="Undo", command=self.undo)
        self.undo_btn.pack(side="left", padx=(6, 0))
        self.redo_btn = ttk.Button(b1, text="Redo", command=lambda: self.undo(redo=True))
        self.redo_btn.pack(side="left", padx=(6, 0))
        b2 = ttk.Frame(lf)
        b2.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Button(b2, text="Load OPTIONS...", command=self.load_options).pack(side="left")
        ttk.Button(b2, text="Export OPTIONS...", command=self.export).pack(side="left",
                                                                          padx=(6, 0))
        lw = ttk.Frame(lf)
        lw.grid(row=2, column=0, sticky="nsew", pady=(6, 0))
        lw.columnconfigure(0, weight=1)
        lw.rowconfigure(0, weight=1)
        self.lcv = tk.Canvas(lw, highlightthickness=0, width=int(470 * ui),
                             height=int(440 * ui))
        self.lcv.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(lw, orient="vertical", command=self.lcv.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.lcv.configure(yscrollcommand=sb.set)
        self.inner = ttk.Frame(self.lcv)
        self._inner_id = self.lcv.create_window(0, 0, anchor="nw", window=self.inner)
        self.inner.bind("<Configure>", lambda e: self.lcv.configure(
            scrollregion=self.lcv.bbox("all")))
        self.lcv.bind("<Configure>", lambda e: self.lcv.itemconfigure(
            self._inner_id, width=e.width))
        for w in (self.lcv, self.inner):
            w.bind("<MouseWheel>", self._list_wheel)
        self._build_rows()
        bf = ttk.Frame(win, padding=(8, 0, 8, 8))
        bf.grid(row=1, column=0, columnspan=2, sticky="ew")
        ttk.Label(bf, text="Left / Right = WAD   Up / Down = map   wheel / + / - = zoom   "
                           "drag = pan   F = fit", foreground="#888").pack(side="left")
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")
        focus_on_click(win)
        self._place()
        self._fill_wads(keep=s.get("automap_cur"))
        self.refresh_rows()

    # ---------------------------------------------------------- window bits
    def _place(self):
        a = self.app
        self.win.update_idletasks()
        pos = a.s.get(self.POS_KEY)
        if isinstance(pos, str) and pos.startswith("+"):
            try:
                self.win.geometry(pos)
                return
            except a.tk.TclError:
                pass
        r = a.root
        self.win.geometry("+%d+%d" % (r.winfo_rootx() + 60, r.winfo_rooty() + 40))

    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def close(self):
        a = self.app
        try:
            a.s[self.POS_KEY] = "+%d+%d" % (self.win.winfo_x(), self.win.winfo_y())
        except a.tk.TclError:
            pass
        if self._chooser is not None:
            try:
                self._chooser.destroy()
            except a.tk.TclError:
                pass
        a.automap_win = None
        try:
            self.win.destroy()
        except a.tk.TclError:
            pass
        if hasattr(a, "_refresh_win_btns"):
            a._refresh_win_btns()

    def _key(self, f, *args):
        w = self.win.focus_get()
        if w is not None and w.winfo_class() in ("TEntry", "Entry", "TCombobox",
                                                 "TSpinbox"):
            return None
        f(*args)
        return "break"

    def _list_wheel(self, e):
        self.lcv.yview_scroll(-1 if e.delta > 0 else 1, "units")

    # ---------------------------------------------------------- values
    @property
    def c(self):
        return self.app.automap

    def _pal(self):
        pal = self.app.pal or []
        return [tuple(c) if c is not None else None for c in pal[:256]] + \
            [None] * max(0, 256 - len(pal))

    def colour(self, idx):
        c = self._pal()[idx]
        return hex_of(c) if c is not None else "#000000"

    def _push(self, coalesce=False):
        now = time.time()
        if coalesce and self._undo and now - self._last_push < 0.6:
            self._last_push = now
            return
        self._undo.append(dict(self.c))
        del self._undo[:-200]
        self._redo = []
        self._last_push = now if coalesce else 0.0

    def set_value(self, key, v, push=True):
        v = max(0, min(255, int(v)))
        if self.c.get(key) == v:
            return
        if push:
            self._push()
        old = dict(self.c)
        new = dict(self.c)
        new[key] = v
        self.app.automap = new
        self.changed(old)

    def set_all(self, d, push=True):
        if push:
            self._push()
        old = dict(self.c)
        self.app.automap = dict(d)
        self.changed(old)

    def undo(self, redo=False):
        src, dst = (self._redo, self._undo) if redo else (self._undo, self._redo)
        if not src:
            self.app.status_var.set("Automap: nothing to %s." % ("redo" if redo else "undo"))
            return "break"
        old = dict(self.c)
        dst.append(old)
        self.app.automap = src.pop()
        self.changed(old)
        return "break"

    def changed(self, old):
        """Recolour, or rebuild the map when a feature key went on / off."""
        new = self.c
        rebuild = any(bool(old.get(k)) != bool(new.get(k)) for k in FEATURE)
        self.refresh_rows()
        if rebuild:
            self.draw_map()
        else:
            self.recolour()

    def reset_classic(self):
        self.set_all(classic())
        self.app.status_var.set("Automap: Classic Doom colours.")

    def reset_dsda(self):
        self.set_all(dict(DSDA_DEFAULTS))
        self.app.status_var.set("Automap: dsda-doom's default colours.")

    # ---------------------------------------------------------- list rows
    def _build_rows(self):
        tk = self.app.tk
        from tkinter import ttk

        ui = self.ui
        self.rows = {}
        group = None
        r = 0
        f = self.inner
        f.columnconfigure(4, weight=1)
        for key, grp, label, help_, feat in KEYS:
            if grp != group:
                group = grp
                hdr = {"Lines": "Lines (shown in the preview)",
                       "HUD": "Arrows / crosshair (not drawn in the preview)",
                       "Things": "Things - IDDT (not drawn in the preview)",
                       "Nyan only": "Nyan Doom only (dsda ignores these)"}[grp]
                ttk.Label(f, text=hdr, font=("Segoe UI", 9, "bold")).grid(
                    row=r, column=0, columnspan=5, sticky="w", pady=(8 if r else 0, 2))
                r += 1
            sw = tk.Canvas(f, width=int(30 * ui), height=int(18 * ui), highlightthickness=1,
                           highlightbackground="#888", cursor="hand2")
            sw.grid(row=r, column=0, sticky="w", pady=1)
            sw.bind("<Button-1>", lambda e, k=key: self.pick(k))
            num = ttk.Label(f, width=4, anchor="e")
            num.grid(row=r, column=1, sticky="e", padx=(4, 0))
            ttk.Button(f, text="Pick...", width=6, command=lambda k=key: self.pick(k)).grid(
                row=r, column=2, padx=(4, 0))
            off = None
            if feat:
                off = tk.BooleanVar()
                ttk.Checkbutton(f, text="Off", variable=off,
                                command=lambda k=key: self._off_click(k)).grid(
                    row=r, column=3, padx=(4, 0))
            lab = ttk.Label(f, text="%s  -  %s" % (label, help_), foreground="#333",
                            wraplength=int(300 * ui))
            lab.grid(row=r, column=4, sticky="w", padx=(6, 0))
            ttk.Label(f, text=key, foreground="#999", font=("Consolas", 8)).grid(
                row=r + 1, column=4, sticky="w", padx=(6, 0))
            for w in (sw, num, lab):
                w.bind("<MouseWheel>", self._list_wheel)
            self.rows[key] = (sw, num, off)
            r += 2

    def refresh_rows(self):
        c = self.c
        for key, (sw, num, off) in self.rows.items():
            v = c[key]
            sw.configure(background=self.colour(v))
            num.configure(text=str(v))
            if off is not None:
                off.set(v == 0)
        try:
            self.undo_btn.state(["!disabled"] if self._undo else ["disabled"])
            self.redo_btn.state(["!disabled"] if self._redo else ["disabled"])
        except self.app.tk.TclError:
            pass

    def _off_click(self, key):
        off = self.rows[key][2].get()
        if off:
            self._last_on = getattr(self, "_last_on", {})
            if self.c[key]:
                self._last_on[key] = self.c[key]
            self.set_value(key, 0)
        else:
            v = getattr(self, "_last_on", {}).get(key) or DSDA_DEFAULTS.get(key) or 4
            self.set_value(key, v)

    def pick(self, key):
        """Pop up the WIP pal0: click a cell = that index for this key."""
        tk = self.app.tk
        from tkinter import ttk

        if self._chooser is not None:
            try:
                self._chooser.destroy()
            except tk.TclError:
                pass
        ui = self.ui
        cs = int(18 * ui)
        w = self._chooser = tk.Toplevel(self.win)
        w.title(key)
        w.transient(self.win)
        w.resizable(False, False)
        cv = tk.Canvas(w, width=16 * cs + 2, height=16 * cs + 2, bg="#262626",
                       highlightthickness=0)
        cv.pack(padx=6, pady=6)
        info = tk.StringVar(value="%s = %d - click a cell" % (key, self.c[key]))
        ttk.Label(w, textvariable=info).pack(anchor="w", padx=6, pady=(0, 6))
        pal = self._pal()
        cur = self.c[key]
        for i in range(256):
            x, y = 1 + (i % 16) * cs, 1 + (i // 16) * cs
            col = pal[i]
            cv.create_rectangle(x, y, x + cs - 1, y + cs - 1,
                                fill=hex_of(col) if col is not None else "#444",
                                outline="")
            if i == cur:
                cv.create_rectangle(x - 1, y - 1, x + cs, y + cs, outline="#ffffff",
                                    width=2)

        def at(e):
            gx, gy = (e.x - 1) // cs, (e.y - 1) // cs
            return gy * 16 + gx if 0 <= gx < 16 and 0 <= gy < 16 else None

        def hover(e):
            i = at(e)
            if i is not None:
                info.set("%d  %s" % (i, hex_of(pal[i]) if pal[i] is not None else "empty"))

        def click(e):
            i = at(e)
            if i is not None:
                self.set_value(key, i)
                self._chooser = None
                w.destroy()
        cv.bind("<Motion>", hover)
        cv.bind("<Button-1>", click)
        w.bind("<Escape>", lambda e: w.destroy())
        w.update_idletasks()
        w.geometry("+%d+%d" % (self.win.winfo_pointerx() - w.winfo_reqwidth() // 2,
                               max(0, self.win.winfo_pointery() - 40)))

    # ---------------------------------------------------------- OPTIONS files
    def load_options(self):
        from tkinter import filedialog, messagebox

        from ..cleanpal_lib_wadgfx import WadArchive

        p = filedialog.askopenfilename(
            parent=self.win, title="Load OPTIONS (text file, or a WAD with an OPTIONS lump)",
            initialdir=self.app.s.get("automap_dir") or None,
            filetypes=[("OPTIONS / WAD", "*.txt *.lmp *.wad"), ("All files", "*.*")])
        if not p:
            return
        self.app.s["automap_dir"] = os.path.dirname(p)
        try:
            with open(p, "rb") as fh:
                raw = fh.read()
            if raw[:4] in (b"IWAD", b"PWAD"):
                raw = WadArchive(p).lump("OPTIONS")
                if raw is None:
                    raise ValueError("That WAD has no OPTIONS lump.")
            found, other = parse_options(raw.decode("latin-1"))
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not load OPTIONS:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        new = dict(self.c)
        new.update(found)
        self.app.automap_other = [ln for ln in other
                                  if not ln.startswith("# Automap colours")
                                  and ln.strip() != "# Nyan Doom only"]
        while self.app.automap_other and not self.app.automap_other[-1].strip():
            self.app.automap_other.pop()
        self.set_all(new)
        n_other = sum(1 for ln in self.app.automap_other if ln.strip() and
                      not ln.startswith("#"))
        self.app.status_var.set("Automap: loaded %d colour(s) from %s%s." % (
            len(found), os.path.basename(p),
            ("; %d other option line(s) kept for the export" % n_other) if n_other else ""))

    def export(self):
        from tkinter import filedialog, messagebox

        p = filedialog.asksaveasfilename(
            parent=self.win, title="Export OPTIONS", initialfile="OPTIONS.txt",
            initialdir=self.app.s.get("automap_dir") or self.app.s.get("last_dir") or None,
            defaultextension=".txt",
            filetypes=[("Text", "*.txt"), ("Lump", "*.lmp"), ("All files", "*.*")])
        if not p:
            return
        try:
            with open(p, "w", encoding="ascii", errors="replace", newline="\n") as fh:
                fh.write(options_text(self.c, self.app.automap_other))
        except OSError as e:
            messagebox.showerror("cleanpal", "Could not write:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        self.app.s["automap_dir"] = os.path.dirname(p)
        self.app.status_var.set("Automap: wrote every mapcolor key to %s (import it as the "
                                "OPTIONS lump)." % p)

    # ---------------------------------------------------------- WADs / maps
    def _sources(self):
        """[(label, path)] IWAD first, then the opened WADs."""
        out = []
        ip = self.app.iwad_path()
        if ip:
            out.append(("IWAD: " + os.path.basename(ip), ip))
        for p in self.wads:
            out.append((os.path.basename(p), p))
        return out

    def _archive(self, path):
        from ..cleanpal_lib_wadgfx import WadArchive

        try:
            k = (path, os.path.getmtime(path))
        except OSError:
            return None
        a = self._arch.get(path)
        if a is None or a[0] != k:
            try:
                a = (k, WadArchive(path))
            except (OSError, ValueError):
                a = (k, None)
            self._arch[path] = a
            self._maps.pop(path, None)
        return a[1]

    def _map_list(self, path):
        if path not in self._maps:
            arch = self._archive(path)
            self._maps[path] = find_maps(arch) if arch is not None else []
        return self._maps[path]

    def _fill_wads(self, keep=None):
        src = self._sources()
        self.wad_cb.configure(values=[lbl for lbl, _p in src])
        if not src:
            self.wad_var.set("")
            self.map_cb.configure(values=[])
            self.map_var.set("")
            self._map = None
            self.draw_map()
            self.note_var.set("No IWAD set - set it in the top bar, or Open WAD...")
            return
        idx = 0
        if isinstance(keep, (list, tuple)) and len(keep) == 2:
            idx = next((i for i, (_l, p) in enumerate(src) if p == keep[0]), 0)
        self.wad_var.set(src[idx][0])
        self.choose_wad(want=keep[1] if isinstance(keep, (list, tuple)) and len(keep) == 2
                        else None)

    def _cur_path(self):
        lbl = self.wad_var.get()
        return next((p for l2, p in self._sources() if l2 == lbl), None)

    def choose_wad(self, want=None):
        p = self._cur_path()
        maps = self._map_list(p) if p else []
        self.map_cb.configure(values=[n for n, _i in maps])
        if not maps:
            self.map_var.set("")
            self._map = None
            self.draw_map()
            self.note_var.set("No Doom-format maps in %s." % os.path.basename(p or "?"))
            return
        name = want if want in [n for n, _i in maps] else maps[0][0]
        self.map_var.set(name)
        self.choose_map()

    def choose_map(self):
        p = self._cur_path()
        name = self.map_var.get()
        maps = self._map_list(p) if p else []
        hit = next((i for n, i in maps if n == name), None)
        if hit is None:
            return
        arch = self._archive(p)
        try:
            self._map = DoomMap(arch, hit)
        except Exception as e:                    # broken map lumps
            self._map = None
            self.note_var.set("Could not read %s: %s" % (name, e))
            self.draw_map()
            return
        self.app.s["automap_cur"] = [p, name]
        self.note_var.set("%s - %s: %d lines, %d sectors" % (
            os.path.basename(p), name, len(self._map.lines), len(self._map.sectors)))
        self.fit()

    def step_wad(self, d):
        src = self._sources()
        if not src:
            return
        labels = [l2 for l2, _p in src]
        i = labels.index(self.wad_var.get()) if self.wad_var.get() in labels else 0
        self.wad_var.set(labels[(i + d) % len(labels)])
        self.choose_wad()

    def step_map(self, d):
        vals = list(self.map_cb.cget("values") or ())
        if not vals:
            return
        i = vals.index(self.map_var.get()) if self.map_var.get() in vals else 0
        self.map_var.set(vals[(i + d) % len(vals)])
        self.choose_map()

    def open_wad(self):
        from tkinter import filedialog

        ps = filedialog.askopenfilenames(
            parent=self.win, title="Open WAD(s) for the automap preview",
            initialdir=self.app.s.get("automap_wad_dir") or None,
            filetypes=[("WAD", "*.wad"), ("All files", "*.*")])
        if not ps:
            return
        if isinstance(ps, str):
            ps = [ps]
        last = None
        for p in ps:
            p = os.path.abspath(p)
            if p not in self.wads and p != self.app.iwad_path():
                self.wads.append(p)
            last = p
        self.app.s["automap_wads"] = list(self.wads)
        self.app.s["automap_wad_dir"] = os.path.dirname(last)
        self._fill_wads(keep=[last, None])

    def close_wad(self):
        p = self._cur_path()
        if p is None or p == self.app.iwad_path():
            self.app.status_var.set("Automap: the IWAD stays in the list.")
            return
        self.wads = [x for x in self.wads if x != p]
        self.app.s["automap_wads"] = list(self.wads)
        self._fill_wads()

    def close_all(self):
        self.wads = []
        self.app.s["automap_wads"] = []
        self._fill_wads()

    # ---------------------------------------------------------- drawing
    def _opts(self):
        s = self.app.s
        s["automap_reveal"] = self.reveal_var.get()
        s["automap_found"] = bool(self.found_var.get())
        s["automap_grid"] = bool(self.grid_var.get())
        self.draw_map()

    def palette_changed(self):
        key = hash(tuple(self._pal()))
        if key != self._pal_key:
            self._pal_key = key
            self.refresh_rows()
            self.recolour()

    def _w2s(self, x, y):
        w = max(self.cv.winfo_width(), 2)
        h = max(self.cv.winfo_height(), 2)
        return (x - self.cx) * self.scale + w / 2.0, h / 2.0 - (y - self.cy) * self.scale

    def fit(self):
        m = self._map
        if m is None:
            self.draw_map()
            return
        x0, y0, x1, y1 = m.bbox
        w = max(self.cv.winfo_width(), 50)
        h = max(self.cv.winfo_height(), 50)
        self.cx, self.cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        self.scale = min((w - 20) / float(max(1, x1 - x0)), (h - 20) / float(max(1, y1 - y0)))
        self.draw_map()

    def _on_resize(self):
        self.draw_map()

    def draw_map(self):
        cv = self.cv
        cv.delete("all")
        self._pal_key = hash(tuple(self._pal()))
        c = self.c
        cv.configure(bg=self.colour(c["mapcolor_back"]))
        m = self._map
        if m is None:
            return
        lw = max(1, int(round(self.ui)))
        if self.grid_var.get():
            x0, y0, x1, y1 = m.bbox
            ox, oy = m.bmorg
            g = 128
            gx0 = ox + ((x0 - ox) // g - 1) * g
            gy0 = oy + ((y0 - oy) // g - 1) * g
            col = self.colour(c["mapcolor_grid"])
            x = gx0
            while x <= x1 + g:
                a, b = self._w2s(x, y0 - g), self._w2s(x, y1 + g)
                cv.create_line(a[0], a[1], b[0], b[1], fill=col, width=lw,
                               tags=("map", "k_mapcolor_grid"))
                x += g
            y = gy0
            while y <= y1 + g:
                a, b = self._w2s(x0 - g, y), self._w2s(x1 + g, y)
                cv.create_line(a[0], a[1], b[0], b[1], fill=col, width=lw,
                               tags=("map", "k_mapcolor_grid"))
                y += g
        reveal = self.reveal_var.get()
        found = bool(self.found_var.get())
        verts = m.verts
        cols = {}
        counts = {}
        for ln in m.lines:
            k = line_colour_key(m, ln, c, reveal, found)
            if k is None:
                continue
            col = cols.get(k)
            if col is None:
                col = cols[k] = self.colour(c[k])
            a = self._w2s(*verts[ln[0]])
            b = self._w2s(*verts[ln[1]])
            cv.create_line(a[0], a[1], b[0], b[1], fill=col, width=lw,
                           tags=("map", "k_" + k))
            counts[k] = counts.get(k, 0) + 1
        self._counts = counts

    def recolour(self):
        cv = self.cv
        c = self.c
        cv.configure(bg=self.colour(c["mapcolor_back"]))
        for k in c:
            cv.itemconfigure("k_" + k, fill=self.colour(c[k]))

    def zoom(self, f, x=None, y=None):
        if self._map is None:
            return
        w, h = self.cv.winfo_width(), self.cv.winfo_height()
        x = w / 2.0 if x is None else x
        y = h / 2.0 if y is None else y
        # keep the world point under (x, y) still
        wx = self.cx + (x - w / 2.0) / self.scale
        wy = self.cy - (y - h / 2.0) / self.scale
        self.scale = max(0.002, min(64.0, self.scale * f))
        self.cx = wx - (x - w / 2.0) / self.scale
        self.cy = wy + (y - h / 2.0) / self.scale
        self.draw_map()

    def _press(self, e):
        self._drag = (e.x, e.y, self.cx, self.cy)
        self.cv.focus_set()

    def _motion(self, e):
        if self._drag is None:
            return
        x0, y0, cx, cy = self._drag
        dx, dy = e.x - x0, e.y - y0
        nx, ny = cx - dx / self.scale, cy + dy / self.scale
        self.cv.move("map", (self.cx - nx) * self.scale, (ny - self.cy) * self.scale)
        self.cx, self.cy = nx, ny

    def _hover(self, e):
        if self._map is None:
            return
        w, h = self.cv.winfo_width(), self.cv.winfo_height()
        wx = self.cx + (e.x - w / 2.0) / self.scale
        wy = self.cy - (e.y - h / 2.0) / self.scale
        hit = self.cv.find_overlapping(e.x - 2, e.y - 2, e.x + 2, e.y + 2)
        kk = ""
        for it in reversed(hit):
            for t in self.cv.gettags(it):
                if t.startswith("k_"):
                    kk = t[2:]
                    break
            if kk:
                break
        self.info_var.set("x %d  y %d%s" % (wx, wy, ("   line: %s = %d" % (
            kk, self.c[kk])) if kk else ""))
