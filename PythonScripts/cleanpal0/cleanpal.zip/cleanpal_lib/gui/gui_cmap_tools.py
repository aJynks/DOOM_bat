"""COLORMAP mode tools (App mixin) - v5 rebuild shell.

The tool buttons stay in the side panel (same layout as before) but no tool
is built yet: a button with no window just says so in the status bar. The
framework is kept for the rebuilt tools:

* one tool window at a time, purple button while open (CTOOL_COLOUR)
* every COLORMAP change made while a tool is open is part of its session:
  it shows live, Apply records ONE history entry, Revert / Discard puts
  things back
* windows remember their position (ctool_pos_<name>) and size their
  pixels by app.ui (fonts are fixed point sizes - Tk scales them)

To add a tool: subclass _CWin, implement build(frame), and register it in
WINDOWS under its CTOOLS name. Optional hooks on the window: refresh(),
sel_changed(), external_edit(), log_text(), note_applied(),
note_reverted(), applied_culls(), teardown().
"""

from ..cleanpal_lib_colormap import (
    GEN_DEFAULTS, LIGHT_ROWS, SLADE_GEN, black_slot, build_fades, clean_gen_settings,
    gen_targets,
)

GENSEL_DEFAULTS = dict(GEN_DEFAULTS, gen_match="ladder", gen_blend="classic",
                       gen_metric="rgb", gen_reach=32, gen_dark=0, gen_order="light",
                       gen_pace="curve", gen_black=True)
from ..cleanpal_lib_colour import hex_of
from ..cleanpal_lib_constants import ENTRIES
from .gui_tool_windows import TOOL_NAME

CTOOLS = ("generate", "fade", "ramps", "efades", "elevels", "invul", "slot7", "slot8")
CTOOL_NAME = {"generate": "Generate", "fade": "Generate selected", "ramps": "Edit Ramps",
              "efades": "Edit Fades", "elevels": "Edit Levels", "invul": "Invulnerability",
              "slot7": "", "slot8": ""}
CTOOL_HINT = {"generate": "how the whole COLORMAP is built",
              "fade": "build the selected fades from a colour pool",
              "ramps": "fades from your own ramp",
              "efades": "one fade as a gradient, row by row",
              "elevels": "click a level, edit one index's rows with the picker",
              "invul": "the invulnerability row (row 32) only",
              "slot7": "", "slot8": ""}
CTOOL_COLOUR = "#c9a0ff"
VIEWERS = ()                         # tools that change nothing themselves: no Apply


# ============================================================ window base
class _CWin:
    POS_KEY = ""
    TITLE = ""

    def __init__(self, app, name):
        tk = app.tk
        from tkinter import ttk

        self.app = app
        self.name = name
        self.ui = getattr(app, "ui", 1.0)
        self.win = tk.Toplevel(app.root)
        self.win.title(self.TITLE or CTOOL_NAME[name])
        self.win.transient(app.root)
        self.win.protocol("WM_DELETE_WINDOW", app.close_ctool)
        self.win.bind("<Escape>", lambda e: app.close_ctool())
        self.body = ttk.Frame(self.win, padding=10)
        self.body.pack(fill="both", expand=True)
        self.build(self.body)
        ttk.Separator(self.win).pack(fill="x", padx=10)
        bf = ttk.Frame(self.win, padding=(10, 8, 10, 10))
        bf.pack(fill="x")
        self.pend_var = tk.StringVar()
        if name not in VIEWERS:
            ttk.Label(bf, textvariable=self.pend_var, foreground="#666").pack(side="left")
        ttk.Button(bf, text="Close", command=app.close_ctool).pack(side="right")
        if name not in VIEWERS:
            cb = ttk.Button(bf, text="Hold to compare")
            cb.pack(side="left", padx=(12, 0))
            cb.bind("<ButtonPress-1>", lambda e: self._compare(True))
            cb.bind("<ButtonRelease-1>", lambda e: self._compare(False))
            self.cmp_btn = cb
            self.apply_btn = ttk.Button(bf, text="Apply", command=app.ctool_apply)
            self.apply_btn.pack(side="right", padx=(0, 6))
            self.revert_btn = ttk.Button(bf, text="Revert", command=app.ctool_revert)
            self.revert_btn.pack(side="right", padx=(0, 6))
        if hasattr(self, "buttons_made"):      # e.g. relabel Hold to compare
            self.buttons_made()
        self._place()
        self.refresh()

    def build(self, f):
        pass

    def _compare(self, on):
        """Hold to compare; a tool can replace it with its own compare_hold."""
        if hasattr(self, "compare_hold"):
            self.compare_hold(on)
        else:
            self.app.cmap_compare(on)

    def _place(self):
        a = self.app
        self.win.update_idletasks()
        pos = a.s.get("ctool_pos_" + self.name)
        if isinstance(pos, str) and pos.startswith("+"):
            try:
                self.win.geometry(pos)
                return
            except a.tk.TclError:
                pass
        r = a.root
        x = r.winfo_rootx() + max(0, r.winfo_width() - self.win.winfo_reqwidth() - 60)
        self.win.geometry("+%d+%d" % (x, r.winfo_rooty() + 80))

    def refresh(self):
        if self.name in VIEWERS:
            return
        on = self.app.ctool_pending()
        try:
            self.pend_var.set("Not applied yet" if on else "No changes")
            for b in (self.apply_btn, self.revert_btn):
                b.state(["!disabled"] if on else ["disabled"])
        except self.app.tk.TclError:
            pass

    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def teardown(self):
        try:
            self.app.s["ctool_pos_" + self.name] = "+%d+%d" % (self.win.winfo_x(),
                                                               self.win.winfo_y())
        except self.app.tk.TclError:
            pass
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass


# ============================================================ Generate
class GenerateWin(_CWin):
    """Generate: a standard starting COLORMAP for the WHOLE palette - every
    fade goes to black. Locked fades and empty slots are skipped. Writes
    rows 1-31 as hand edits. SLADE Generation = SLADE's exact maths (each
    channel * (32 - row) / 32, nearest RGB); the sliders adjust from there.
    Live; Apply = one history entry."""
    TITLE = "Generate - whole palette to black"

    def build(self, f):
        from tkinter import ttk
        from .gui_gradslider import GradSlider

        a = self.app
        tk = a.tk
        ui = self.ui
        if a.s.get("gen_ver") != 2:          # 5.0.13 redesign: start from SLADE's maths
            a.s.update(SLADE_GEN)
            a.s["gen_ver"] = 2
        self.o = clean_gen_settings(a.s)
        self.o.update(gen_to="black", gen_fb=False, gen_new=False, gen_from="all")
        self._after = None
        self._n = 0
        self.scope = set()
        self.targets = {}              # true-colour targets (Hold for true colour)
        self.base = a.cm.copy()
        self.scope_var = tk.StringVar()
        ttk.Label(f, textvariable=self.scope_var, foreground="#666").grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        sf = ttk.Frame(f)
        sf.grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 8))
        ttk.Button(sf, text="SLADE Generation", command=self.slade).pack(side="left")
        ttk.Label(sf, text="every setting back to SLADE's maths", foreground="#666").pack(
            side="left", padx=(8, 0))
        # match
        ttk.Label(f, text="Match").grid(row=2, column=0, sticky="w")
        mf = ttk.Frame(f)
        mf.grid(row=2, column=1, columnspan=2, sticky="w", pady=(0, 4))
        self.match_var = tk.StringVar(value=self.o["gen_match"])
        for txt, val in (("Nearest", "nearest"), ("Smart path", "smart")):
            ttk.Radiobutton(mf, text=txt, value=val, variable=self.match_var,
                            command=lambda: self._set("gen_match", self.match_var.get())
                            ).pack(side="left", padx=(0, 10))
        self.metric_var = tk.StringVar(value="RGB" if self.o["gen_metric"] == "rgb"
                                       else "Perceptual")
        self.metric_cb = ttk.Combobox(mf, textvariable=self.metric_var, state="readonly",
                                      values=["RGB", "Perceptual"], width=10)
        self.metric_cb.pack(side="left")
        self.metric_cb.bind("<<ComboboxSelected>>", lambda e: self._set(
            "gen_metric", "rgb" if self.metric_var.get() == "RGB" else "oklab"))
        # blend
        ttk.Label(f, text="Blend").grid(row=3, column=0, sticky="w")
        bf = ttk.Frame(f)
        bf.grid(row=3, column=1, columnspan=2, sticky="w", pady=(0, 4))
        self.blend_var = tk.StringVar(value=self.o["gen_blend"])
        for txt, val in (("Classic (SLADE)", "classic"), ("Around the wheel", "wheel"),
                         ("Straight", "straight")):
            ttk.Radiobutton(bf, text=txt, value=val, variable=self.blend_var,
                            command=lambda: self._set("gen_blend", self.blend_var.get())
                            ).pack(side="left", padx=(0, 10))
        # sliders
        self.sliders = {}
        rows = (("gen_reach", "Reach black at row", 1, 32, 1),
                ("gen_curve", "Darken curve", 0.25, 4.0, 0.01),
                ("gen_dark", "Dark colours finish sooner (%)", 0, 100, 1),
                ("gen_hold", "Colour hold (%)", 0, 100, 1),
                ("gen_hue", "Hue freedom (°)", 0, 60, 1),
                ("gen_keep", "Keep colour (%)", 0, 100, 1))
        for k, (key, label, lo, hi, step) in enumerate(rows, 4):
            ttk.Label(f, text=label).grid(row=k, column=0, sticky="w", pady=2)
            gs = GradSlider(f, a, lo, hi, step, self.o[key],
                            lambda v, key=key: self._set(key, v), None, ui)
            gs.frame.grid(row=k, column=1, columnspan=2, sticky="we", pady=2)
            if key == "gen_curve":           # 1.0 in the middle, fine steps below it
                gs.log = True
                gs.draw()
            self.sliders[key] = gs
        self.mono_var = tk.BooleanVar(value=self.o["gen_mono"])
        self.mono_chk = ttk.Checkbutton(f, text="Never get lighter", variable=self.mono_var,
                                        command=lambda: self._set("gen_mono",
                                                                  bool(self.mono_var.get())))
        self.mono_chk.grid(row=10, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Label(f, foreground="#888", wraplength=int(400 * ui), justify="left",
                  text="Whole palette, everything fades to black (locked fades are "
                       "skipped). Row 0 is the colour itself. Writes rows 1-31 as hand "
                       "edits - a starting point to edit. Classic = SLADE / Doom: each "
                       "channel scaled toward black. Colour hold works with Around the "
                       "wheel; Hue freedom, Keep colour and Never get lighter with Smart "
                       "path.").grid(row=11, column=0, columnspan=3, sticky="w",
                                     pady=(8, 0))
        f.columnconfigure(1, weight=1)
        self.win.bind("<Escape>", lambda e: (a.close_ctool(), "break")[1])
        self._fade_state()
        self.schedule(now=True)

    # ---- settings
    def _set(self, key, v):
        self.o[key] = v
        self.app.s[key] = v
        self._fade_state()
        self.schedule()

    def slade(self):
        """Every setting to SLADE's generateColormaps() maths."""
        for k, v in SLADE_GEN.items():
            self.o[k] = v
            self.app.s[k] = v
        self.match_var.set(self.o["gen_match"])
        self.metric_var.set("RGB")
        self.blend_var.set(self.o["gen_blend"])
        for key, gs in self.sliders.items():
            gs.set(self.o[key])
        self._fade_state()
        self.app.status_var.set("SLADE Generation: SLADE's COLORMAP maths for the whole "
                                "palette - Apply records it.")
        self.schedule(now=True)

    def _fade_state(self):
        """Grey what doesn't apply: Colour hold needs Around the wheel; hue
        freedom / keep colour / never lighter need Smart path; RGB /
        Perceptual is for Nearest."""
        smart = self.match_var.get() == "smart"
        wheel = self.blend_var.get() == "wheel"
        st = lambda on: ["!disabled"] if on else ["disabled"]
        self.metric_cb.state(st(not smart) + ["readonly"])
        for key, gs in self.sliders.items():
            on = True
            if key in ("gen_hue", "gen_keep"):
                on = smart
            elif key == "gen_hold":
                on = wheel
            gs.set_enabled(on)
        self.mono_chk.state(st(smart))

    # ---- live build
    def schedule(self, now=False):
        a = self.app
        if self._after is not None:
            a.root.after_cancel(self._after)
        self._after = a.root.after(1 if now else 120, self.rebuild)

    def rebuild(self):
        a = self.app
        self._after = None
        if a.ctool_win is not self or a.rgbs is None:
            return
        if a._cmap_compare:              # busy comparing: try again after release
            self.schedule()
            return
        cols = [i for i in range(ENTRIES) if a.rgbs[i] is not None]
        scope = [i for i in cols if i not in a.cmap_locks]
        nlock = len(cols) - len(scope)
        self.scope_var.set("Whole palette: %d colours%s" % (
            len(scope), "  (%d locked skipped)" % nlock if nlock else ""))
        cm = self.base.copy()
        ss = set(scope)
        cm.overrides = {k: t for k, t in cm.overrides.items()
                        if not (k[1] in ss and 1 <= k[0] < LIGHT_ROWS)}
        cm.fullbright = set(cm.fullbright) - ss
        cm.overrides.update(build_fades(a.pal, a.deleted, scope, self.o))
        self.scope = ss
        self.targets = gen_targets(a.pal, scope, self.o)
        self._n = len(scope)
        if cm != a.cm:
            a.cm = cm
            a.cm_changed()
            a.recompute()
        self.refresh()

    def log_text(self):
        o = self.o
        if all(o.get(k) == v for k, v in SLADE_GEN.items()):
            return "%d colours, SLADE Generation" % self._n
        t = "%d colours to black by row %d (%s, %s, curve %g, dark %d%%" % (
            self._n, o["gen_reach"], {"classic": "classic", "wheel": "around the wheel",
                                      "straight": "straight"}[o["gen_blend"]],
            "smart path" if o["gen_match"] == "smart" else
            "nearest " + ("RGB" if o["gen_metric"] == "rgb" else "perceptual"),
            o["gen_curve"], o["gen_dark"])
        if o["gen_blend"] == "wheel":
            t += ", hold %d%%" % o["gen_hold"]
        if o["gen_match"] == "smart":
            t += ", hue %d, keep %d%%" % (o["gen_hue"], o["gen_keep"])
        return t + ")"

    def external_edit(self):
        self.base = self.app.cm.copy()
        self.schedule()

    def note_applied(self):
        self.base = self.app.cm.copy()

    def note_reverted(self):
        self.base = self.app.cm.copy()

    def teardown(self):
        a = self.app
        a.cmap_compare(False)
        if self._after is not None:
            a.root.after_cancel(self._after)
            self._after = None
        _CWin.teardown(self)

# ============================================================ Generate selected
class GenSelWin(_CWin):
    """Generate selected: build the fades of the selected colours (fade
    selection, else the palette selection - never the whole palette) from a
    COLOUR POOL - the only colours the fades may use. Select Colour Pool
    turns grid clicks into pool picks (green dots). Ladder (default) walks
    down the pool light to dark. Live; Apply = one history entry."""
    TITLE = "Generate selected - fades from a colour pool"

    def build(self, f):
        from tkinter import ttk
        from .gui_gradslider import GradSlider

        a = self.app
        tk = a.tk
        ui = self.ui
        st = dict(GENSEL_DEFAULTS)
        if isinstance(a.s.get("gensel"), dict):
            st.update(a.s["gensel"])
        self.o = clean_gen_settings(st)
        self.o.update(gen_to="black", gen_fb=False, gen_new=False, gen_from="all")
        self._after = None
        self._n = 0
        self.scope = set()
        self.targets = {}
        self.base = a.cm.copy()
        self.scope_var = tk.StringVar()
        ttk.Label(f, textvariable=self.scope_var, foreground="#666").grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))
        pf = ttk.Frame(f)
        pf.grid(row=1, column=0, columnspan=3, sticky="w")
        self.pool_var = tk.BooleanVar(value=False)
        self.pool_btn = tk.Button(pf, text="Select Colour Pool", width=26, relief="raised",
                                  command=self._pool_click)
        self.pool_btn.pack(side="left")
        self._pool_btn_bg = self.pool_btn.cget("background")
        ttk.Button(pf, text="Clear pool", command=self._pool_clear).pack(side="left",
                                                                        padx=(6, 0))
        self.pool_info = tk.StringVar()
        ttk.Label(pf, textvariable=self.pool_info, foreground="#666").pack(side="left",
                                                                         padx=(10, 0))
        self.black_var = tk.BooleanVar(value=self.o["gen_black"])
        ttk.Checkbutton(f, text="Allow black (always usable as the last step)",
                        variable=self.black_var,
                        command=lambda: self._set("gen_black", bool(self.black_var.get()))
                        ).grid(row=2, column=0, columnspan=3, sticky="w", pady=(4, 8))
        # match
        ttk.Label(f, text="Match").grid(row=3, column=0, sticky="w")
        mf = ttk.Frame(f)
        mf.grid(row=3, column=1, columnspan=2, sticky="w", pady=(0, 4))
        self.match_var = tk.StringVar(value=self.o["gen_match"])
        for txt, val in (("Ladder", "ladder"), ("Smart path", "smart"), ("Nearest", "nearest")):
            ttk.Radiobutton(mf, text=txt, value=val, variable=self.match_var,
                            command=lambda: self._set("gen_match", self.match_var.get())
                            ).pack(side="left", padx=(0, 10))
        self.metric_var = tk.StringVar(value="RGB" if self.o["gen_metric"] == "rgb"
                                       else "Perceptual")
        self.metric_cb = ttk.Combobox(mf, textvariable=self.metric_var, state="readonly",
                                      values=["RGB", "Perceptual"], width=10)
        self.metric_cb.pack(side="left")
        self.metric_cb.bind("<<ComboboxSelected>>", lambda e: self._set(
            "gen_metric", "rgb" if self.metric_var.get() == "RGB" else "oklab"))
        # ladder
        ttk.Label(f, text="Ladder").grid(row=4, column=0, sticky="w")
        lf = ttk.Frame(f)
        lf.grid(row=4, column=1, columnspan=2, sticky="w", pady=(0, 4))
        self.order_var = tk.StringVar(value=self.o["gen_order"])
        self.pace_var = tk.StringVar(value=self.o["gen_pace"])
        self._ladder_widgets = []
        for txt, val in (("By lightness", "light"), ("By index", "index")):
            rb = ttk.Radiobutton(lf, text=txt, value=val, variable=self.order_var,
                                 command=lambda: self._set("gen_order", self.order_var.get()))
            rb.pack(side="left", padx=(0, 8))
            self._ladder_widgets.append(rb)
        ttk.Label(lf, text="|").pack(side="left", padx=(2, 8))
        for txt, val in (("Follow the curve", "curve"), ("Even steps", "even")):
            rb = ttk.Radiobutton(lf, text=txt, value=val, variable=self.pace_var,
                                 command=lambda: self._set("gen_pace", self.pace_var.get()))
            rb.pack(side="left", padx=(0, 8))
            self._ladder_widgets.append(rb)
        # blend
        ttk.Label(f, text="Blend").grid(row=5, column=0, sticky="w")
        bf = ttk.Frame(f)
        bf.grid(row=5, column=1, columnspan=2, sticky="w", pady=(0, 4))
        self.blend_var = tk.StringVar(value=self.o["gen_blend"])
        for txt, val in (("Classic (SLADE)", "classic"), ("Around the wheel", "wheel"),
                         ("Straight", "straight")):
            ttk.Radiobutton(bf, text=txt, value=val, variable=self.blend_var,
                            command=lambda: self._set("gen_blend", self.blend_var.get())
                            ).pack(side="left", padx=(0, 10))
        self.sliders = {}
        rows = (("gen_reach", "Reach black at row", 1, 32, 1),
                ("gen_curve", "Darken curve", 0.25, 4.0, 0.01),
                ("gen_dark", "Dark colours finish sooner (%)", 0, 100, 1),
                ("gen_hold", "Colour hold (%)", 0, 100, 1),
                ("gen_hue", "Hue freedom (°)", 0, 60, 1),
                ("gen_keep", "Keep colour (%)", 0, 100, 1))
        for k, (key, label, lo, hi, step) in enumerate(rows, 6):
            ttk.Label(f, text=label).grid(row=k, column=0, sticky="w", pady=2)
            gs = GradSlider(f, a, lo, hi, step, self.o[key],
                            lambda v, key=key: self._set(key, v), None, ui)
            gs.frame.grid(row=k, column=1, columnspan=2, sticky="we", pady=2)
            if key == "gen_curve":           # 1.0 in the middle, fine steps below it
                gs.log = True
                gs.draw()
            self.sliders[key] = gs
        self.mono_var = tk.BooleanVar(value=self.o["gen_mono"])
        self.mono_chk = ttk.Checkbutton(f, text="Never get lighter", variable=self.mono_var,
                                        command=lambda: self._set("gen_mono",
                                                                  bool(self.mono_var.get())))
        self.mono_chk.grid(row=12, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Label(f, foreground="#888", wraplength=int(420 * ui), justify="left",
                  text="Edits the selected fades only (click fade numbers, else the "
                       "palette selection); locked fades are skipped. Select Colour Pool: "
                       "while it's pressed, clicks in the palette pick the colours the "
                       "fades may use (green dots); the colours being edited are always in it. "
                       "Empty pool = the whole palette. "
                       "Ladder walks down the pool, never back up; Reach / Darken curve "
                       "/ Dark colours pace it.").grid(row=13, column=0, columnspan=3,
                                                       sticky="w", pady=(8, 0))
        f.columnconfigure(1, weight=1)
        self.win.bind("<Escape>", lambda e: (a.close_ctool(), "break")[1])
        self._fade_state()
        self._pool_text()
        self.schedule(now=True)

    # ---- settings
    def _set(self, key, v):
        self.o[key] = v
        d = dict(self.app.s.get("gensel") or {})
        d[key] = v
        self.app.s["gensel"] = d
        self._fade_state()
        self.schedule()

    def _fade_state(self):
        m = self.match_var.get()
        wheel = self.blend_var.get() == "wheel"
        st = lambda on: ["!disabled"] if on else ["disabled"]
        self.metric_cb.state(st(m == "nearest") + ["readonly"])
        for w in self._ladder_widgets:
            w.state(st(m == "ladder"))
        for key, gs in self.sliders.items():
            on = True
            if key in ("gen_hue", "gen_keep"):
                on = m == "smart"
            elif key == "gen_hold":
                on = wheel and m != "ladder"
            gs.set_enabled(on)
        self.mono_chk.state(st(m == "smart"))

    # ---- colour pool
    def _pool_click(self):
        self.pool_var.set(not self.pool_var.get())
        self._pool_toggled()

    def pool_off(self):
        """Esc in the main window: stop picking pool colours."""
        if self.pool_var.get():
            self.pool_var.set(False)
            self._pool_toggled()

    def _pool_toggled(self):
        a = self.app
        on = bool(self.pool_var.get())
        a._pool_mode = on
        bg = CTOOL_COLOUR if on else self._pool_btn_bg
        self.pool_btn.configure(text="Picking pool\u2026 (click to stop)" if on
                                else "Select Colour Pool", relief="sunken" if on else "raised",
                                background=bg, activebackground=bg)
        a.canvas.configure(cursor="plus" if on else "")
        a.status_var.set("Select Colour Pool: click / drag in the palette to pick the "
                         "colours fades may use (Shift adds, Ctrl toggles). Press the "
                         "button again or Esc to go back." if on else "Back to selecting colours.")

    def _pool_clear(self):
        self.app.cmap_pool = set()
        self.app.recompute()
        self.pool_changed()

    def _pool_extra(self):
        """Pool colours beyond the ones being edited (those are always in)."""
        return set(self.app.cmap_pool) - set(self.scope)

    def _pool_text(self):
        n = len(self._pool_extra())
        k = len(self.scope)
        if not n:
            self.pool_info.set("Pool: empty = whole palette")
        else:
            self.pool_info.set("Pool: %d colour%s%s" % (n, "" if n == 1 else "s",
                                                       " + %d selected" % k if k else ""))

    def pool_changed(self):
        self._pool_text()
        self.schedule()

    # ---- live build
    def schedule(self, now=False):
        a = self.app
        if self._after is not None:
            a.root.after_cancel(self._after)
        self._after = a.root.after(1 if now else 120, self.rebuild)

    def rebuild(self):
        a = self.app
        self._after = None
        if a.ctool_win is not self or a.rgbs is None:
            return
        if a._cmap_compare:
            self.schedule()
            return
        scope, label, nlock = a.cmap_targets()
        cm = self.base.copy()
        if label.startswith("Whole palette"):
            self.scope_var.set("Select the colours to edit first (palette selection or "
                               "fade numbers) - nothing is changed.")
            scope = []
        else:
            self.scope_var.set("%s%s" % (label, "  (%d locked skipped)" % nlock
                                         if nlock else ""))
        ss = set(scope)
        if scope:
            extra = set(a.cmap_pool) - ss
            pool = sorted(i for i in (extra | ss if extra else ()) if a.rgbs[i] is not None
                          and i not in a.deleted)
            if pool and self.o["gen_black"]:
                b = black_slot(a.pal, a.deleted)
                if b is not None and b not in pool:
                    pool.append(b)
            cm.overrides = {k: t for k, t in cm.overrides.items()
                            if not (k[1] in ss and 1 <= k[0] < LIGHT_ROWS)}
            cm.fullbright = set(cm.fullbright) - ss
            cm.overrides.update(build_fades(a.pal, a.deleted, scope, self.o, pool or None))
        redraw = self.scope != ss
        self.scope = ss
        self._pool_text()
        if redraw:
            a.redraw()                   # edited colours never show pool dots
        self.targets = gen_targets(a.pal, scope, self.o)
        self._n = len(scope)
        if cm != a.cm:
            a.cm = cm
            a.cm_changed()
            a.recompute()
        self.refresh()

    def log_text(self):
        o = self.o
        n = len(self._pool_extra())
        how = {"ladder": "ladder (%s, %s)" % ("by lightness" if o["gen_order"] == "light"
                                               else "by index",
                                               "follow the curve" if o["gen_pace"] == "curve"
                                               else "even steps"),
               "smart": "smart path",
               "nearest": "nearest " + ("RGB" if o["gen_metric"] == "rgb"
                                        else "perceptual")}[o["gen_match"]]
        return "%d fade%s from %s, %s, reach %d, curve %g" % (
            self._n, "" if self._n == 1 else "s",
            ("a %d-colour pool (+ the fades themselves)" % n) if n else "the whole palette", how, o["gen_reach"],
            o["gen_curve"])

    def sel_changed(self):
        self.schedule()

    def external_edit(self):
        self.base = self.app.cm.copy()
        self.schedule()

    def note_applied(self):
        self.base = self.app.cm.copy()

    def note_reverted(self):
        self.base = self.app.cm.copy()

    def teardown(self):
        a = self.app
        a.cmap_compare(False)
        a._pool_mode = False
        try:
            a.canvas.configure(cursor="")
        except a.tk.TclError:
            pass
        if self._after is not None:
            a.root.after_cancel(self._after)
            self._after = None
        _CWin.teardown(self)


# Rebuilt tools register here
from .gui_ramp_edit import EditRampsWin  # noqa: E402 - needs _CWin above
from .gui_fade_edit import EditFadesWin  # noqa: E402
from .gui_level_edit import EditLevelsWin  # noqa: E402
from .gui_invul_tool import InvulWin  # noqa: E402

WINDOWS = {"generate": GenerateWin, "fade": GenSelWin, "ramps": EditRampsWin,
           "efades": EditFadesWin, "elevels": EditLevelsWin, "invul": InvulWin}


# ============================================================ host mixin
class CmapToolsMixin:
    def _ctool_init(self):
        self.ctool = None
        self.ctool_win = None
        self._ctool_start = None
        self._ctool_log = []
        self.ctool_btns = {}

    # ---- side panel
    def _build_ctools_panel(self, side):
        tk = self.tk
        from tkinter import ttk

        tf = ttk.LabelFrame(side, text="COLORMAP tools", padding=8)
        tf.columnconfigure(1, weight=1)
        # Clean COLORMAP: no window - drops the hand edits (one history entry)
        ttk.Button(tf, text="Clean COLORMAP", command=self.clean_colormap).grid(
            row=0, column=0, sticky="we")
        self.clean_inv_var = tk.BooleanVar(value=bool(self.s.get("cmap_clean_invul", False)))
        ttk.Checkbutton(tf, text="Also reset invulnerability (row 32)",
                        variable=self.clean_inv_var,
                        command=lambda: self.s.__setitem__(
                            "cmap_clean_invul", bool(self.clean_inv_var.get()))).grid(
            row=0, column=1, sticky="w", padx=(8, 0))
        ttk.Separator(tf).grid(row=1, column=0, columnspan=2, sticky="we", pady=(6, 2))
        for k, t in enumerate(CTOOLS):
            row = k + 2
            b = tk.Button(tf, text=CTOOL_NAME[t], width=17, relief="raised",
                          command=lambda t=t: self.toggle_ctool(t))
            b.grid(row=row, column=0, sticky="w", pady=(4, 0))
            self.ctool_btns[t] = b
            ttk.Label(tf, text=CTOOL_HINT[t], foreground="#666").grid(
                row=row, column=1, sticky="w", padx=(8, 0), pady=(4, 0))
        self._ctool_btn_bg = self.ctool_btns[CTOOLS[0]].cget("background")
        ttk.Label(tf, text="Changes show live; Apply = one history entry",
                  foreground="#888").grid(row=len(CTOOLS) + 2, column=0, columnspan=2,
                                          sticky="w", pady=(6, 0))
        return tf

    def _refresh_ctools(self):
        for t, b in self.ctool_btns.items():
            on = self.ctool == t
            b.configure(relief="sunken" if on else "raised",
                        background=CTOOL_COLOUR if on else self._ctool_btn_bg,
                        activebackground=CTOOL_COLOUR if on else self._ctool_btn_bg)

    # ---- session
    def _ctool_snapshot(self):
        self._ctool_start = (self.cm.copy(), dict(self.cmap_set), list(self.rgbs),
                             list(self.labs), self.pairs, set(self.deleted))
        self._ctool_start_locks = dict(self.cmap_locks)
        self._ctool_log = []

    def ctool_pending(self):
        if self.ctool is None or self._ctool_start is None:
            return False
        st = self._ctool_start
        return self.cm != st[0] or self.cmap_set != st[1] or list(self.rgbs) != st[2]

    def ctool_apply(self):
        w = self.ctool_win
        if w is not None and hasattr(w, "before_apply") and not w.before_apply():
            return
        if not self.ctool_pending():
            self.status_var.set("Nothing to apply.")
            return
        name = CTOOL_NAME[self.ctool]
        w = self.ctool_win
        if w is not None and hasattr(w, "log_text") and w.log_text():
            self._ctool_log = [w.log_text()]
        culls = w.applied_culls() if w is not None and hasattr(w, "applied_culls") else []
        if not self._ctool_log and self.cmap_set != self._ctool_start[1]:
            ch = [k[5:] for k in self.cmap_set if self.cmap_set[k] != self._ctool_start[1].get(k)]
            self._ctool_log = ["settings (%s)" % ", ".join(ch)]
        text = "%s: %s" % (name, "; ".join(self._ctool_log) or "edits")
        self.cm_changed()
        self._push_history("COLORMAP %s" % text)
        self._ctool_snapshot()
        self.status_var.set("COLORMAP %s - recorded as #%d (Back undoes it)." % (
            text, self.hist_pos))
        if culls:
            self._save_cull_report(culls)
        if self.ctool_win is not None and hasattr(self.ctool_win, "note_applied"):
            self.ctool_win.note_applied()
        self.recompute()

    def ctool_revert(self):
        if self._ctool_start is None:
            return
        cm, st, rgbs, labs, pairs, deleted = self._ctool_start
        self.rgbs, self.labs, self.pairs = list(rgbs), list(labs), pairs
        self.deleted = set(deleted)
        self.cm = cm.copy()
        self.cmap_locks = dict(getattr(self, "_ctool_start_locks", self.cmap_locks))
        if st != self.cmap_set:
            self.apply_cmap_settings(st)
            self.s.update(st)
        self.cm_changed()
        self._ctool_log = []
        self.status_var.set("COLORMAP changes reverted.")
        self.recompute()
        if self.ctool_win is not None and hasattr(self.ctool_win, "note_reverted"):
            self.ctool_win.note_reverted()

    # ---- open / close
    def toggle_ctool(self, name):
        if self.ctool == name:
            self.close_ctool()
        else:
            self.open_ctool(name)

    def open_ctool(self, name):
        if name not in WINDOWS:
            self.status_var.set(("%s - not built yet." % CTOOL_NAME[name]) if CTOOL_NAME.get(name)
                                else "Empty slot - the next COLORMAP tool goes here.")
            return False
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return False
        if not self.cmap_mode():
            self.status_var.set("The COLORMAP tools are in COLORMAP mode.")
            return False
        if self.ctool == name:
            self.ctool_win.lift()
            return True
        if self._previewing():
            self.status_var.set("A preview is open - Apply or Cancel it first.")
            return False
        if self.ctool is not None and not self.close_ctool(quiet=True):
            return False
        self.ctool = name
        self._ctool_snapshot()
        self.ctool_win = WINDOWS[name](self, name)
        self._refresh_ctools()
        self._refresh_history()
        self.status_var.set("%s tool: changes show live - Apply records them." % CTOOL_NAME[name]
                            if name not in VIEWERS else "%s tool open." % CTOOL_NAME[name])
        self.recompute()
        return True

    def close_ctool(self, quiet=False, force=False):
        t = self.ctool
        if t is None:
            return True
        if self.ctool_pending():
            if force:
                self.ctool_apply()
            else:
                k = self._ask_buttons("%s changes not applied." % CTOOL_NAME[t],
                                      "Apply them as a history entry, or discard them?",
                                      [("apply", "Apply"), ("discard", "Discard"),
                                       ("cancel", "Cancel")])
                if k == "cancel":
                    return False
                if k == "apply":
                    self.ctool_apply()
                else:
                    self.ctool_revert()
        self.ctool_win.teardown()
        self.ctool = None
        self.ctool_win = None
        self._ctool_start = None
        self._ctool_log = []
        self._refresh_ctools()
        self._refresh_history()
        if not quiet:
            self.status_var.set("%s tool closed." % CTOOL_NAME[t])
        self.recompute()
        return True

    def _save_cull_report(self, culls):
        """Culls change what an index means - offer a remap list for the graphics."""
        from tkinter import filedialog
        import os

        k = self._ask_buttons(
            "%d colour%s culled" % (len(culls), "" if len(culls) == 1 else "s"),
            "Each culled slot now holds a new colour. Any graphics using those indices "
            "should be remapped to the kept twin. Save a cull report (old index -> kept "
            "index) for your remap tools?", [("save", "Save report..."), ("skip", "Skip")])
        if k != "save":
            return
        p = filedialog.asksaveasfilename(
            title="Save cull report", defaultextension=".txt",
            initialfile="cleanpal_cull_report.txt",
            initialdir=self.s.get("last_dir") or None, filetypes=[("Text", "*.txt")])
        if not p:
            return
        before = self.history[self.hist_pos - 1]["palette"] if self.hist_pos else self.rgbs
        lines = ["# cleanpal cull report - remap these palette indices in your graphics",
                 "# old_index -> kept_index    old_colour -> kept_colour"]
        for cull, keep in culls:
            lines.append("%3d -> %3d    %s -> %s" % (cull, keep, hex_of(before[cull]),
                                                    hex_of(before[keep])))
        with open(p, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        self.status_var.set("Cull report saved: %s" % os.path.basename(p))

    def cmap_compare(self, on):
        """Hold to compare: while held, show the COLORMAP from before the
        open tool's changes (Matrix / Fades / preview); release = live."""
        on = bool(on and self.ctool is not None and self._ctool_start is not None)
        if on == self._cmap_compare:
            return
        self._cmap_compare = on
        if on:                          # swap in the state from before the tool
            self._cmp_live = (self.rgbs, self.labs, self.pairs, self.deleted, self.cm,
                              self.cmap_set, self.cmap_locks)
            cm, st, rgbs, labs, pairs, deleted = self._ctool_start
            self.rgbs, self.labs, self.pairs = list(rgbs), list(labs), pairs
            self.deleted, self.cm, self.cmap_set = set(deleted), cm.copy(), dict(st)
            self.cmap_locks = dict(getattr(self, "_ctool_start_locks", self.cmap_locks))
        else:
            (self.rgbs, self.labs, self.pairs, self.deleted, self.cm, self.cmap_set,
             self.cmap_locks) = self._cmp_live
            self._cmp_live = None
        self.cm_changed()
        self.status_var.set("Comparing: BEFORE the %s changes - release to go back."
                            % CTOOL_NAME[self.ctool] if on else "Showing the live result.")
        self.recompute()

    # ---- shared: put new colours into the palette (Generate, Lost colours)
    def place_colours(self, cols, place, together, p):
        """Insert `cols` after index p ("insert": everything from there moves
        along, past the red line if needed) or into empty palette slots
        ("empty"). together = one unbroken run of indices. Palette-locked
        cells never move or change; COLORMAP edits / fade locks follow their
        colours. -> (slots, newpos or None, message). No history entry."""
        n = len(cols)
        lk = self.locked
        if not n:
            return [], None, ""
        if place == "empty":
            free = [i for i in range(ENTRIES) if self.rgbs[i] is None and i not in lk]
            if together:
                order = list(range(p, ENTRIES)) + list(range(0, p))
                start = next((i for i in order if i + n <= ENTRIES and
                              all(self.rgbs[j] is None and j not in lk
                                  for j in range(i, i + n))), None)
                if start is None:
                    return [], None, ("No run of %d empty slots - make room, untick Keep "
                                      "together, or use Insert." % n)
                slots = list(range(start, start + n))
            else:
                after = [i for i in free if i >= p]
                before = [i for i in free if i < p][::-1]
                slots = sorted((after + before)[:n])
                if not slots:
                    return [], None, "No empty palette slots - make room or use Insert."
                cols = cols[:len(slots)]
            self._write_cells(slots, cols)
            msg = "" if len(slots) == n else \
                "Only %d empty slot%s - %d colour%s left out." % (
                    len(slots), "" if len(slots) == 1 else "s", n - len(slots),
                    "" if n - len(slots) == 1 else "s")
            return slots, None, msg
        start = p
        if together:
            while True:
                hit = [i for i in range(start, start + n) if i in lk]
                if not hit:
                    break
                start = max(hit) + 1
        below0 = sum(1 for c in self.rgbs[ENTRIES:] if c is not None)
        L = len(self.rgbs)
        self._ensure_len(L + n)
        E = list(range(L, L + n))
        L2 = len(self.rgbs)
        perm = list(range(start)) + E + [i for i in range(start, L2) if i not in E]
        newpos = self._permute(perm)
        slots = [newpos[e] for e in E]
        self._write_cells(slots, cols)
        over = sum(1 for i in range(ENTRIES, len(self.rgbs))
                   if self.rgbs[i] is not None and i not in slots) - below0
        msg = ""
        if over > 0:
            msg = "%d colour%s pushed below the red line." % (over, "" if over == 1 else "s")
        if max(slots) >= ENTRIES:
            msg = ("Some new colours landed below the red line (no room in the palette). "
                   + msg).strip()
        return slots, newpos, msg

    def insert_colours(self, cols, place, together, src):
        """Insert button (Lost colours ...): new colours into the palette as
        one history entry (or a Paint edit while Paint is open). Exact
        duplicates are skipped. -> message for the caller's status line."""
        if self.rgbs is None:
            return "Open a palette first."
        if self._ramp_copy_busy() or self._preview_busy_msg():
            return self.status_var.get()
        if self.tool in ("cull", "move", "reorder"):
            return "Close the %s tools first - they need the palette to stay put." % \
                TOOL_NAME[self.tool]
        if self.ctool is not None:
            return "Apply or Revert the %s tool first, then insert." % CTOOL_NAME[self.ctool]
        cols, skipped = self._unique_new(cols)
        if not cols:
            return ("Nothing inserted - every colour is already in the palette%s. Untick "
                    "Skip identical colours (Clipboard) to insert them anyway."
                    % self._dup_note(skipped))
        sel = [i for i in self.selection if i < ENTRIES]
        if sel:
            p = max(sel) + 1
        else:
            used = [i for i in range(ENTRIES) if self.rgbs[i] is not None]
            p = (max(used) + 1) if used else 0
        slots, _newpos, msg = self.place_colours(cols, place, together, p)
        if not slots:
            return msg
        sl = sorted(slots)
        where = ("%d-%d" % (sl[0], sl[-1])) if sl[-1] - sl[0] == len(sl) - 1 \
            else ", ".join(str(i) for i in sl)
        text = "Inserted %d %s at %s" % (len(sl), src, where)
        detail = text + self._dup_note(skipped) + ((" - " + msg) if msg else "")
        self.cm_changed()
        self._external_commit(sl, text, detail)
        return self.status_var.get()

    def _ctool_sel_changed(self):
        w = getattr(self, "ctool_win", None)
        if w is not None and hasattr(w, "sel_changed"):
            w.sel_changed()

    def _ctool_refresh_win(self):
        if self.ctool_win is not None:
            self.ctool_win.refresh()
