"""COLORMAP mode tools (App mixin): Generate, Fade edit, Limit, Create colours,
Ramps and Diagnostics - one window at a time, like the PLAYPAL tools.

Every COLORMAP change made while a tool is open is part of that tool's
session: it shows live, Apply records ONE history entry, Revert / Discard
puts things back. (Brush strokes in the fade view join the session too.)
"""

from ..cleanpal_lib_colormap import (
    CMAP_METHODS, DARK_ROW, DIAG_TYPES, INVUL_MODES, LIGHT_ROWS,
)
from ..cleanpal_lib_colour import hex_of
from ..cleanpal_lib_constants import ENTRIES, fmt_tol
from ..cleanpal_lib_colormap import fade_within
from ..cleanpal_lib_ramps import (
    LEVELS, auto_ideal, auto_ramps, chain_gap_colours, fit_nodes, light_curve, palette_ramp,
    ramp_misses, ramps_summary, suggest_culls, suggest_global, suggest_new_colours,
)

CTOOLS = ("generate", "fade", "limit", "create", "ramps", "autoramps", "light", "diag")
CTOOL_NAME = {"generate": "Generate", "fade": "Fade edit", "limit": "Limit",
              "create": "Create colours", "ramps": "Ramps", "autoramps": "AutoRamps",
              "light": "Light curve",
              "diag": "Diagnostics"}
CTOOL_HINT = {"generate": "how the whole COLORMAP is built",
              "fade": "fade through the selection (live) + more",
              "limit": "which colours a fade may use",
              "create": "find new colours for better fades",
              "ramps": "build one colour's fade from palette colours",
              "autoramps": "smooth fades for the whole palette at once",
              "light": "lighten / darken the whole COLORMAP",
              "diag": "list problem fades"}
CTOOL_COLOUR = "#c9a0ff"
VIEWERS = ("create", "diag")            # change nothing themselves: no Apply


# ============================================================ windows
class _CWin:
    POS_KEY = ""
    TITLE = ""

    def __init__(self, app, name):
        tk = app.tk
        from tkinter import ttk

        self.app = app
        self.name = name
        self.ui = ui = getattr(app, "ui", 1.0)
        self.win = tk.Toplevel(app.root)
        self.win.title(self.TITLE or CTOOL_NAME[name])
        self.win.transient(app.root)
        self.win.protocol("WM_DELETE_WINDOW", app.close_ctool)
        self.win.bind("<Escape>", lambda e: app.close_ctool())
        self.body = ttk.Frame(self.win, padding=10)
        self.body.pack(fill="both", expand=True)
        self.build(self.body)
        ttk.Separator(self.win).pack(fill="x", padx=10)
        bf = ttk.Frame(self.win, padding=(10, 8, 10, 10))
        bf.pack(fill="x")
        self.pend_var = tk.StringVar()
        if name not in VIEWERS:
            ttk.Label(bf, textvariable=self.pend_var, foreground="#666").pack(side="left")
        ttk.Button(bf, text="Close", command=app.close_ctool).pack(side="right")
        if name not in VIEWERS:
            self.apply_btn = ttk.Button(bf, text="Apply", command=app.ctool_apply)
            self.apply_btn.pack(side="right", padx=(0, 6))
            self.revert_btn = ttk.Button(bf, text="Revert", command=app.ctool_revert)
            self.revert_btn.pack(side="right", padx=(0, 6))
        self._place()
        self.refresh()

    def build(self, f):
        pass

    def _place(self):
        a = self.app
        self.win.update_idletasks()
        pos = a.s.get("ctool_pos_" + self.name)
        if isinstance(pos, str) and pos.startswith("+"):
            try:
                self.win.geometry(pos)
                return
            except a.tk.TclError:
                pass
        r = a.root
        x = r.winfo_rootx() + max(0, r.winfo_width() - self.win.winfo_reqwidth() - 60)
        self.win.geometry("+%d+%d" % (x, r.winfo_rooty() + 80))

    def refresh(self):
        if self.name in VIEWERS:
            return
        on = self.app.ctool_pending()
        try:
            self.pend_var.set("Not applied yet" if on else "No changes")
            for b in (self.apply_btn, self.revert_btn):
                b.state(["!disabled"] if on else ["disabled"])
        except self.app.tk.TclError:
            pass

    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def teardown(self):
        try:
            self.app.s["ctool_pos_" + self.name] = "+%d+%d" % (self.win.winfo_x(),
                                                               self.win.winfo_y())
        except self.app.tk.TclError:
            pass
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass


class GenerateWin(_CWin):
    TITLE = "Generate - how the COLORMAP is built"

    def build(self, f):
        tk = self.app.tk
        from tkinter import ttk

        a = self.app
        ui = self.ui
        ttk.Label(f, text="These settings build every colour's fade. Changes show live;\n"
                          "Apply records them, Revert puts the old ones back.",
                  foreground="#666").pack(anchor="w")
        g = ttk.Frame(f)
        g.pack(fill="x", pady=(8, 0))
        g.columnconfigure(1, weight=1)
        ttk.Label(g, text="Matching").grid(row=0, column=0, sticky="w")
        w = ttk.Combobox(g, textvariable=a.cmap_method_var, values=CMAP_METHODS,
                         state="readonly", width=30)
        w.grid(row=0, column=1, sticky="ew", padx=(6, 0))
        w.bind("<<ComboboxSelected>>", lambda e: a._cmap_set_opt())
        ttk.Label(g, text="Fade curve").grid(row=1, column=0, sticky="w", pady=(4, 0))
        sp = ttk.Spinbox(g, textvariable=a.cmap_curve_var, from_=0.25, to=4.0,
                         increment=0.05, width=7, command=a._cmap_set_opt)
        sp.grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(4, 0))
        sp.bind("<Return>", lambda e: a._cmap_set_opt())
        sp.bind("<FocusOut>", lambda e: a._cmap_set_opt())
        ttk.Label(g, text="Fade toward").grid(row=2, column=0, sticky="w", pady=(4, 0))
        tf = ttk.Frame(g)
        tf.grid(row=2, column=1, sticky="w", padx=(6, 0), pady=(4, 0))
        a.cmap_target_sw = tk.Canvas(tf, width=int(24 * ui), height=int(18 * ui),
                                     highlightthickness=1, highlightbackground="#888")
        a.cmap_target_sw.pack(side="left")
        te = ttk.Entry(tf, textvariable=a.cmap_target_var, width=9)
        te.pack(side="left", padx=(4, 0))
        te.bind("<Return>", lambda e: a._cmap_set_opt())
        te.bind("<FocusOut>", lambda e: a._cmap_set_opt())
        a.register_colour_widget(
            te, lambda: tuple(a.cmap_set["cmap_target"]),
            lambda rgb: (a.cmap_target_var.set(hex_of(rgb)[1:]), a._cmap_set_opt()))
        il = ttk.Label(g, text="Invulnerability")
        il.grid(row=3, column=0, sticky="w", pady=(4, 0))
        w = ttk.Combobox(g, textvariable=a.cmap_invul_var, values=INVUL_MODES,
                         state="readonly", width=30)
        w.grid(row=3, column=1, sticky="ew", padx=(6, 0), pady=(4, 0))
        w.bind("<<ComboboxSelected>>", lambda e: a._cmap_set_opt())
        a._invul_widgets = (il, w)
        ttk.Checkbutton(f, text="Auto-fill smoothly between hand-set steps",
                        variable=a.cmap_smooth_var,
                        command=a._cmap_set_opt).pack(anchor="w", pady=(8, 0))
        a._cmap_target_swatch()
        a._sync_extra_widgets()

    def teardown(self):
        self.app.cmap_target_sw = None
        self.app._invul_widgets = ()
        super().teardown()


class LimitWin(_CWin):
    TITLE = "Limit - which colours fades may use"

    def build(self, f):
        from tkinter import ttk

        a = self.app
        ttk.Label(f, text="1. Select the allowed colours, Store them as targets.\n"
                          "2. Select the colours to limit, then Limit.",
                  foreground="#666").pack(anchor="w")
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(8, 0))
        ttk.Button(r, text="Store selection as targets",
                   command=a.cmap_store_targets).pack(side="left")
        ttk.Label(r, textvariable=a.cmap_tset_var, foreground="#666").pack(side="left",
                                                                         padx=(6, 0))
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(6, 0))
        ttk.Button(r, text="Limit to targets (+ fade colour)",
                   command=lambda: a.cmap_limit(True)).pack(side="left")
        ttk.Button(r, text="Remove limit",
                   command=lambda: a.cmap_limit(False)).pack(side="left", padx=(4, 0))


class CreateWin(_CWin):
    TITLE = "Create colours - better fades"

    def build(self, f):
        from tkinter import ttk

        a = self.app
        ttk.Label(f, text="Finds new colours that would make fades land closer to\n"
                          "their ideal, to add into empty palette slots.",
                  foreground="#666").pack(anchor="w")
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(8, 0))
        ttk.Radiobutton(r, text="Whole palette", value="all",
                        variable=a.cf_scope).pack(side="left")
        ttk.Radiobutton(r, text="Selected", value="selected",
                        variable=a.cf_scope).pack(side="left", padx=(6, 0))
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(6, 0))
        ttk.Label(r, text="Budget (new colours)").pack(side="left")
        ttk.Spinbox(r, textvariable=a.cf_budget, from_=1, to=128, increment=1,
                    width=5).pack(side="left", padx=(4, 0))
        ttk.Button(r, text="Find...", command=a.cmap_find_colours).pack(side="right")
        ttk.Label(f, textvariable=a.cf_free_var, foreground="#666").pack(anchor="w",
                                                                       pady=(6, 0))


class DiagWin(_CWin):
    TITLE = "Diagnostics"

    def build(self, f):
        tk = self.app.tk
        from tkinter import ttk

        a = self.app
        ttk.Checkbutton(f, text="Highlight problem steps", variable=a.cmap_diag_on,
                        command=a._fade_schedule).pack(anchor="w")
        a.diag_vars = {}
        dr = ttk.Frame(f)
        dr.pack(fill="x", pady=(4, 0))
        for k, (label, col) in DIAG_TYPES.items():
            fr = ttk.Frame(dr)
            fr.pack(anchor="w")
            c = tk.Canvas(fr, width=12, height=12, highlightthickness=0)
            c.create_rectangle(1, 1, 11, 11, outline=col, width=2)
            c.pack(side="left")
            v = tk.StringVar(value=label)
            ttk.Label(fr, textvariable=v).pack(side="left", padx=(4, 0))
            a.diag_vars[k] = (v, label)
        lf = ttk.Frame(f)
        lf.pack(fill="both", expand=True, pady=(6, 0))
        a.diag_list = tk.Listbox(lf, height=12, width=44, activestyle="none",
                                 exportselection=False, font=("Consolas", 9))
        sb = ttk.Scrollbar(lf, orient="vertical", command=a.diag_list.yview)
        a.diag_list.configure(yscrollcommand=sb.set)
        a.diag_list.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        a.diag_list.bind("<<ListboxSelect>>", a._on_diag_pick)
        a._diag_rows = []
        ttk.Label(f, text="Click a colour to show its fade.", foreground="#666").pack(
            anchor="w", pady=(4, 0))
        a._fade_schedule()

    def teardown(self):
        self.app.diag_list = None
        self.app.diag_vars = {}
        super().teardown()


# ============================================================ shared: new colours
def _state_of(app):
    return (list(app.rgbs), list(app.labs), app.pairs, set(app.deleted), app.cm.copy())


def _restore_state(app, st):
    app.rgbs, app.labs, app.pairs = list(st[0]), list(st[1]), st[2]
    app.deleted = set(st[3])
    app.cm = st[4].copy()
    app.cm_changed()


def place_colours(app, cols, culls=()):
    """Put new colours into the palette: empty slots first, then slots freed
    by culls (each culled colour merges into its twin - fades that used it
    use the twin). Returns the indices used, in order."""
    slots = [i for i in range(ENTRIES) if app.rgbs[i] is None]
    for cull, keep in culls:
        ov = app.cm.overrides
        for k, t in list(ov.items()):
            if t == cull:
                ov[k] = keep
        app.cm.invalidate([cull])
        slots.append(cull)
    used = slots[:len(cols)]
    if used:
        app._write_cells(used, cols[:len(used)])
    return used


class NewColoursPanel:
    """Suggested new colours: a swatch grid. Click = include / leave out,
    double-click = edit in the colour picker. Owner supplies find() and
    rebuild(); empty slots only, optionally culling to make room."""

    def __init__(self, owner, parent, title, allow_cull=True):
        tk = owner.app.tk
        from tkinter import ttk

        self.owner = owner
        self.app = owner.app
        self.ui = ui = owner.ui
        self.items = []               # {"rgb", "helps", "on"}
        self.culls = []               # [(cull, keep, distance)]
        f = ttk.LabelFrame(parent, text=title, padding=6)
        f.pack(fill="x", pady=(8, 0))
        r = ttk.Frame(f)
        r.pack(fill="x")
        ttk.Label(r, text="How many").pack(side="left")
        self.n_var = tk.StringVar(value=str(owner.app.s.get("newcol_n_" + owner.name, 4)))
        sp = ttk.Spinbox(r, textvariable=self.n_var, from_=1, to=64, increment=1, width=4)
        sp.pack(side="left", padx=(4, 0))
        self.cull_var = tk.BooleanVar(value=False)
        self.cull_mode = tk.StringVar(value="Quick")
        if allow_cull:
            ttk.Checkbutton(r, text="Make room by culling", variable=self.cull_var).pack(
                side="left", padx=(10, 0))
            ttk.Combobox(r, textvariable=self.cull_mode, values=("Quick", "Careful"),
                         state="readonly", width=8).pack(side="left", padx=(4, 0))
        ttk.Button(r, text="Find colours", command=self.find).pack(side="right")
        ttk.Button(r, text="Clear", command=self.clear).pack(side="right", padx=(0, 6))
        self.free_var = tk.StringVar()
        ttk.Label(f, textvariable=self.free_var, foreground="#666").pack(anchor="w",
                                                                       pady=(4, 0))
        self.cell = int(26 * ui)
        self.per_row = 10
        self.cv = tk.Canvas(f, height=self.cell + 4, width=self.per_row * self.cell + 4,
                            bg="#262626", highlightthickness=0)
        self.cv.pack(anchor="w", pady=(4, 0))
        self.cv.bind("<Button-1>", self._click)
        self.cv.bind("<Double-Button-1>", self._edit)
        self.cv.bind("<Motion>", self._hover)
        self.info_var = tk.StringVar(value="Click = include / leave out   double-click = edit")
        ttk.Label(f, textvariable=self.info_var, foreground="#666").pack(anchor="w")
        self.warn_var = tk.StringVar()
        ttk.Label(f, textvariable=self.warn_var, foreground="#c03030",
                  wraplength=int(520 * ui)).pack(anchor="w")
        self.update_free()

    def count(self):
        try:
            n = min(max(int(float(self.n_var.get())), 1), 64)
        except ValueError:
            n = 4
        self.n_var.set(str(n))
        self.app.s["newcol_n_" + self.owner.name] = n
        return n

    def free_slots(self):
        return sum(1 for i in range(ENTRIES) if self.app.rgbs[i] is None)

    def update_free(self):
        self.free_var.set("Free (empty) palette slots: %d" % self.owner.base_free()
                          + ("   |   culling %d" % len(self.culls) if self.culls else ""))

    def colours(self):
        return [tuple(it["rgb"]) for it in self.items if it["on"]]

    def active_culls(self):
        """Only as many culls as the included colours actually need."""
        need = max(0, len(self.colours()) - self.owner.base_free())
        return [(c, k) for c, k, _d in self.culls[:need]]

    def find(self):
        self.owner.find_new(self.count(), self.cull_var.get(), self.cull_mode.get())

    def set_items(self, picks, culls=()):
        self.items = [{"rgb": tuple(rgb), "helps": helps, "on": True} for rgb, helps in picks]
        self.culls = list(culls)
        self.draw()
        self.update_free()
        if self.culls:
            self.warn_var.set(
                "Culls merge each colour into its near twin: %s. Your graphics are indexed - "
                "remap those pixels to the kept colour (Apply can save a cull report)." %
                ", ".join("%d->%d" % (c, k) for c, k, _d in self.culls[:12]))
        else:
            self.warn_var.set("")

    def clear(self):
        self.set_items([])
        self.owner.schedule()

    def _at(self, ev):
        k = int((ev.y - 2) // self.cell) * self.per_row + int((ev.x - 2) // self.cell)
        return k if 0 <= k < len(self.items) and ev.x >= 2 else None

    def _click(self, ev):
        k = self._at(ev)
        if k is None:
            return
        self.items[k]["on"] = not self.items[k]["on"]
        self.draw()
        self.owner.schedule()

    def _edit(self, ev):
        k = self._at(ev)
        if k is None:
            return
        self.items[k]["on"] = True
        p = self.app.open_picker()
        p.owner = self

        def put(rgb, hsl=None, k=k):
            self.items[k]["rgb"] = tuple(int(round(v)) for v in rgb)
            self.draw()
            self.owner.schedule()
        p.set_target(put, tuple(self.items[k]["rgb"]), None, "new colour %d" % (k + 1))

    def _hover(self, ev):
        k = self._at(ev)
        if k is None:
            self.info_var.set("Click = include / leave out   double-click = edit")
            return
        it = self.items[k]
        self.info_var.set("%s  %s%s" % (hex_of(it["rgb"]), "helps %d fades" % it["helps"]
                                        if it["helps"] else "", "" if it["on"] else
                                        "   (left out)"))

    def draw(self):
        cv = self.cv
        c = self.cell
        rows = max(1, (len(self.items) + self.per_row - 1) // self.per_row)
        cv.configure(height=rows * c + 4)
        cv.delete("all")
        for k, it in enumerate(self.items):
            x = 2 + (k % self.per_row) * c
            y = 2 + (k // self.per_row) * c
            cv.create_rectangle(x, y, x + c - 3, y + c - 3, fill=hex_of(it["rgb"]),
                                outline="#ffffff" if it["on"] else "#555555")
            if not it["on"]:
                cv.create_line(x + 3, y + 3, x + c - 6, y + c - 6, fill="#ff4040", width=2)
                cv.create_line(x + c - 6, y + 3, x + 3, y + c - 6, fill="#ff4040", width=2)


# ============================================================ AutoRamps
class AutoRampsWin(_CWin):
    TITLE = "AutoRamps - smooth fades for many colours"
    DEFAULTS = {"scope": "Whole palette", "curve": 1.0, "fade_start": 31, "grey_by": 31,
                "end": "Black", "hue_free": 40.0, "lean": "Warm", "keep": 1.0,
                "wl": 1.0, "wc": 1.0, "wh": 1.0, "only": "All colours"}
    SCOPES = ("Whole palette", "Selected colours")
    LEANS = ("None", "Warm", "Cool")

    def build(self, f):
        tk = self.app.tk
        from tkinter import ttk

        a = self.app
        cfg = dict(self.DEFAULTS)
        saved = a.s.get("autoramps")
        if isinstance(saved, dict):
            cfg.update({k: v for k, v in saved.items() if k in cfg})
        self.cfg = cfg
        self.base = _state_of(a)
        self.ramps = {}
        self.new_idx = []
        self._after = None
        self._vals = {}
        ttk.Label(f, text="Builds a smooth fade to black for every colour in scope. Hue may "
                          "wander (Hue freedom) so fades\nkeep colour instead of going grey. "
                          "Changes show live; Apply records them.",
                  foreground="#666").pack(anchor="w")
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(6, 0))
        ttk.Label(r, text="Colours").pack(side="left")
        self.scope_var = tk.StringVar(value=cfg["scope"])
        cb = ttk.Combobox(r, textvariable=self.scope_var, values=self.SCOPES, state="readonly",
                          width=18)
        cb.pack(side="left", padx=(6, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("scope", self.scope_var.get()))
        self.mono_var = tk.BooleanVar(value=bool(a.s.get("autoramps_mono", True)))
        self.smooth_var = tk.BooleanVar(value=bool(a.s.get("autoramps_smooth", True)))
        ttk.Checkbutton(r, text="Never get lighter", variable=self.mono_var,
                        command=self._opts).pack(side="left", padx=(12, 0))
        ttk.Checkbutton(r, text="Smooth", variable=self.smooth_var,
                        command=self._opts).pack(side="left", padx=(8, 0))

        cols = ttk.Frame(f)                       # two columns: fits at high display scale
        cols.pack(fill="x")
        cols.columnconfigure(0, weight=1)
        cols.columnconfigure(1, weight=1)
        left = ttk.Frame(cols)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        right = ttk.Frame(cols)
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        sf = ttk.LabelFrame(left, text="Shape of every fade", padding=6)
        sf.pack(fill="x", pady=(8, 0))
        for c in (1, 4):
            sf.columnconfigure(c, weight=1)
        self._slider(sf, 0, 0, "Darken curve", "curve", 0.3, 3.0, 0.05)
        self._slider(sf, 1, 0, "Hold colour until", "fade_start", 0, 31, 1)
        self._slider(sf, 2, 0, "Grey by (31=never)", "grey_by", 1, 31, 1)
        ttk.Label(sf, text="End").grid(row=3, column=0, sticky="w", pady=(4, 0))
        self.end_var = tk.StringVar(value=cfg["end"])
        cb = ttk.Combobox(sf, textvariable=self.end_var, values=("Black", "Fade toward colour"),
                          state="readonly", width=18)
        cb.grid(row=3, column=1, sticky="w", padx=(6, 0), pady=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("end", self.end_var.get()))

        hf = ttk.LabelFrame(left, text="Hue - wander rather than go grey", padding=6)
        hf.pack(fill="x", pady=(8, 0))
        hf.columnconfigure(1, weight=1)
        self._slider(hf, 0, 0, "Hue freedom (deg)", "hue_free", 0, 90, 1)
        self._slider(hf, 2, 0, "Keep colour", "keep", 0.0, 4.0, 0.1)
        ttk.Label(hf, text="Lean").grid(row=1, column=0, sticky="w", pady=(4, 0))
        # (Lean sits between the two hue sliders)
        self.lean_var = tk.StringVar(value=cfg["lean"])
        cb = ttk.Combobox(hf, textvariable=self.lean_var, values=self.LEANS, state="readonly",
                          width=10)
        cb.grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("lean", self.lean_var.get()))

        mf = ttk.LabelFrame(right, text="Matching", padding=6)
        mf.pack(fill="x", pady=(8, 0))
        mf.columnconfigure(1, weight=1)
        self._slider(mf, 0, 0, "Lightness", "wl", 0.0, 4.0, 0.1)
        self._slider(mf, 1, 0, "Hue", "wh", 0.0, 4.0, 0.1)
        self._slider(mf, 2, 0, "Colourfulness", "wc", 0.0, 4.0, 0.1)
        ttk.Label(mf, text="Only use").grid(row=3, column=0, sticky="w", pady=(4, 0))
        self.only_var = tk.StringVar(value=cfg["only"])
        cb = ttk.Combobox(mf, textvariable=self.only_var,
                          values=("All colours", "Selected colours", "Limit targets"),
                          state="readonly", width=16)
        cb.grid(row=3, column=1, sticky="w", padx=(6, 0), pady=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("only", self.only_var.get()))

        self.newcols = NewColoursPanel(self, right, "Add new colours (empty slots only)")

        self.sum_var = tk.StringVar()
        ttk.Label(f, textvariable=self.sum_var, font=("Consolas", 9)).pack(anchor="w",
                                                                         pady=(8, 0))
        ttk.Label(f, text="Worst fades (click to view):", foreground="#666").pack(anchor="w")
        self.worst = tk.Listbox(f, height=4, activestyle="none", exportselection=False,
                                font=("Consolas", 9))
        self.worst.pack(fill="x")
        self.worst.bind("<<ListboxSelect>>", self._pick_worst)
        self._worst_rows = []
        self.win.after_idle(self.rebuild)

    # ---- settings
    def _slider(self, parent, row, col, label, key, lo, hi, step):
        tk = self.app.tk
        from tkinter import ttk

        ui = self.ui
        ttk.Label(parent, text=label).grid(row=row, column=col, sticky="w",
                                           padx=(12 if col else 0, 0), pady=(4, 0))
        var = tk.StringVar(value=fmt_tol(self.cfg[key]))
        sc = tk.Scale(parent, from_=lo, to=hi, resolution=step, orient="horizontal",
                      showvalue=0, length=int(140 * ui), sliderlength=int(30 * ui),
                      width=int(18 * ui),
                      command=lambda x, k=key, v=var: self._scaled(k, v, float(x)))
        sc.set(self.cfg[key])
        sc.grid(row=row, column=col + 1, sticky="ew", padx=(6, 4), pady=(4, 0))
        sc.bind("<ButtonRelease-1>", lambda e: self.schedule(now=True))
        ttk.Label(parent, textvariable=var, width=5).grid(row=row, column=col + 2, sticky="w",
                                                          pady=(4, 0))
        self._vals[key] = (sc, var)

    def _scaled(self, key, var, x):
        var.set(fmt_tol(x))
        if self.cfg.get(key) != x:
            self.cfg[key] = x
            self.app.s["autoramps"] = dict(self.cfg)
            if len(self._scope()) <= 48:          # small scopes follow the slider live
                self.schedule()

    def _set(self, key, value):
        self.cfg[key] = value
        self.app.s["autoramps"] = dict(self.cfg)
        self.schedule(now=True)

    def _opts(self):
        self.app.s["autoramps_mono"] = bool(self.mono_var.get())
        self.app.s["autoramps_smooth"] = bool(self.smooth_var.get())
        self.schedule(now=True)

    def schedule(self, now=False):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._after = self.win.after(30 if now else 150, self._run)

    def _run(self):
        self._after = None
        self.rebuild()

    def _scope(self):
        a = self.app
        pal = self.base[0][:ENTRIES]
        if self.cfg["scope"] == "Selected colours":
            return [i for i in sorted(a.selection) if i < ENTRIES and pal[i] is not None]
        return [i for i, c in enumerate(pal) if c is not None]

    def _allowed(self):
        a = self.app
        only = self.cfg["only"]
        if only == "All colours":
            return None
        src = a.selection if only == "Selected colours" else a.cmap_target_set
        return {i for i in src if i < ENTRIES}

    def _opts_dict(self):
        a = self.app
        c = self.cfg
        lean = {"Warm": 1, "Cool": -1}.get(c["lean"], 0)
        end = (0, 0, 0) if c["end"] == "Black" else tuple(a.cmap_set["cmap_target"])
        return dict(curve=float(c["curve"]), drift=0.0, fade_start=int(c["fade_start"]),
                    grey_by=int(c["grey_by"]), end=end,
                    weights=(float(c["wl"]), float(c["wc"]), float(c["wh"])),
                    hue_free=float(c["hue_free"]), keep_colour=float(c["keep"]), lean=lean,
                    monotonic=bool(self.mono_var.get()), smooth=bool(self.smooth_var.get()))

    def base_free(self):
        return sum(1 for c in self.base[0][:ENTRIES] if c is None)

    # ---- build
    def rebuild(self):
        a = self.app
        _restore_state(a, self.base)
        a.root.configure(cursor="watch")
        a.root.update_idletasks()
        try:
            cols = self.newcols.colours()
            culls = self.newcols.active_culls()
            self.new_idx = place_colours(a, cols, culls) if cols else []
            scope = self._scope()
            for c, _k in culls:                     # a culled slot now holds a new colour
                if c not in scope:
                    scope.append(c)
            scope += [i for i in self.new_idx if i not in scope]
            self.ramps = auto_ramps(scope, a.pal, self._opts_dict(), self._allowed(),
                                    self.new_idx)
            for s, (_ideal, res) in self.ramps.items():
                for r in range(LEVELS):
                    a.cm.overrides[(r, s)] = res[r]
            a.cm_changed()
            self._summary()
        finally:
            a.root.configure(cursor="")
        a.recompute()
        self.newcols.update_free()
        self.refresh()

    def _summary(self):
        a = self.app
        if not self.ramps:
            self.sum_var.set("No colours in scope - select colours or choose Whole palette.")
            return
        avg, worst, grey, per = ramps_summary(self.ramps, a.pal)
        self.sum_var.set("%d fades   |   average miss %.2f   |   worst %.1f (colour %s, "
                         "level %s)   |   go grey early: %d%s" % (
                             len(self.ramps), avg, worst[0], worst[1], worst[2], grey,
                             ("   |   +%d new colours" % len(self.new_idx))
                             if self.new_idx else ""))
        rows = sorted(per.items(), key=lambda kv: -kv[1])[:20]
        self._worst_rows = rows
        self.worst.delete(0, "end")
        for s, m in rows:
            self.worst.insert("end", "%3d  %s   worst miss %.1f" % (s, hex_of(a.pal[s]), m))

    def _pick_worst(self, _ev):
        sel = self.worst.curselection()
        if not sel or sel[0] >= len(self._worst_rows):
            return
        s = self._worst_rows[sel[0]][0]
        a = self.app
        a.selection = {s}
        a.cmap_view.set("Fades")
        a._fade_scroll = 0
        a.recompute()

    def find_new(self, n, cull, mode):
        a = self.app
        self.newcols.set_items([])
        self.rebuild()                               # ramps without new colours
        free = self.base_free()
        culls = []
        if n > free and cull:
            res, _f = a.cmap_result()
            usage = {}
            if res is not None:
                for r in range(1, LIGHT_ROWS):
                    for s in range(ENTRIES):
                        t = res.rows[r][s]
                        usage[t] = usage.get(t, 0) + 1
            pairs = self.base[2].get(a.metric_var.get()) or []
            culls = suggest_culls(self.base[0][:ENTRIES], pairs, n - free, usage,
                                  careful=(mode == "Careful"))
        room = free + len(culls)
        if room <= 0:
            a.status_var.set("No empty palette slots - tick 'Make room by culling' or free "
                             "some slots with the Cull tool first.")
            return
        a.root.configure(cursor="watch")
        a.root.update_idletasks()
        try:
            picks = suggest_global(self.ramps, a.pal, min(n, room), self._opts_dict())
        finally:
            a.root.configure(cursor="")
        if not picks:
            a.status_var.set("No new colours would help - the fades already land close to "
                             "their ideal.")
            return
        self.newcols.set_items(picks, culls[:max(0, len(picks) - free)])
        a.status_var.set("Found %d colour%s%s - click to leave one out, double-click to edit."
                         % (len(picks), "" if len(picks) == 1 else "s",
                            " (capped at %d free slots)" % room if n > room else ""))
        self.rebuild()

    def external_edit(self):
        """A brush stroke etc. while AutoRamps is open: keep it. (Fades of
        colours in scope are rebuilt on the next change anyway.)"""
        self.base = _state_of(self.app)
        if self.new_idx:                      # they're in the palette now - don't re-add
            self.newcols.set_items([])
            self.new_idx = []

    def log_text(self):
        culls = self.newcols.active_culls()
        t = "%d fades" % len(self.ramps)
        if self.new_idx:
            t += ", +%d new colour%s" % (len(self.new_idx), "" if len(self.new_idx) == 1 else "s")
        if culls:
            t += ", %d culled" % len(culls)
        return t

    def applied_culls(self):
        return self.newcols.active_culls()

    def note_applied(self):
        self.base = _state_of(self.app)
        self.newcols.set_items([])
        self.new_idx = []
        self.rebuild()

    def note_reverted(self):
        self.base = _state_of(self.app)
        self.newcols.set_items([])            # Revert drops the suggested colours too
        self.new_idx = []
        self.rebuild()

    def teardown(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        super().teardown()


# ============================================================ Fade edit (live fade through)
class FadeEditWin(_CWin):
    TITLE = "Fade edit - selected colours"

    def build(self, f):
        tk = self.app.tk
        from tkinter import ttk

        a = self.app
        self.base = _state_of(a)
        self.new_idx = []
        self._after = None
        ft = ttk.LabelFrame(f, text="Fade through the selection (live)", padding=6)
        ft.pack(fill="x")
        ttk.Label(ft, text="The selected colours fade into each other, light to dark, "
                           "instead of each picking its own darks.\nChange anything (or the "
                           "selection) and the fades update; Apply records them.",
                  foreground="#666").pack(anchor="w")
        r = ttk.Frame(ft)
        r.pack(fill="x", pady=(6, 0))
        self.live_var = tk.BooleanVar(value=bool(a.s.get("fadethrough_live", True)))
        ttk.Checkbutton(r, text="Preview", variable=self.live_var,
                        command=self._live_toggle).pack(side="left")
        ttk.Label(r, text="Order").pack(side="left", padx=(12, 0))
        cb = ttk.Combobox(r, textvariable=a.fw_order, values=["Lightness", "Index"],
                          state="readonly", width=9)
        cb.pack(side="left", padx=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.schedule())
        ttk.Label(r, text="steps/level").pack(side="left", padx=(10, 0))
        sp = ttk.Spinbox(r, textvariable=a.fw_spl, from_=0.05, to=4, increment=0.05, width=5,
                         command=self.schedule)
        sp.pack(side="left", padx=(4, 0))
        sp.bind("<Return>", lambda e: self.schedule())
        sp.bind("<FocusOut>", lambda e: self.schedule())
        ttk.Label(r, text="then").pack(side="left", padx=(10, 0))
        cb = ttk.Combobox(r, textvariable=a.fw_end, values=["Black", "Auto"], state="readonly",
                          width=6)
        cb.pack(side="left", padx=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.schedule())
        self.status = tk.StringVar()
        ttk.Label(ft, textvariable=self.status, foreground="#666").pack(anchor="w",
                                                                      pady=(4, 0))
        self.newcols = NewColoursPanel(self, ft, "Add colours into the chain's biggest gaps "
                                       "(empty slots only)", allow_cull=False)

        mo = ttk.LabelFrame(f, text="More (each acts on the selected colours)", padding=6)
        mo.pack(fill="x", pady=(10, 0))
        for text, cmd, expl in (
                ("Full bright", lambda: a.cmap_fullbright(True),
                 "never darkens - lights, lava, glowing bits (FB in the fade view)"),
                ("Normal", lambda: a.cmap_fullbright(False), "undoes Full bright"),
                ("Clear hand edits", a.cmap_clear,
                 "back to the plain generated fade (ramps, paint, curves, limits)")):
            row = ttk.Frame(mo)
            row.pack(fill="x", pady=(2, 0))
            ttk.Button(row, text=text, width=16,
                       command=lambda c=cmd: self.more(c)).pack(side="left")
            ttk.Label(row, text=expl, foreground="#666").pack(side="left", padx=(8, 0))
        row = ttk.Frame(mo)
        row.pack(fill="x", pady=(6, 0))
        ttk.Label(row, text="Fade curve").pack(side="left")
        ttk.Spinbox(row, textvariable=a.cmap_scurve, from_=0.25, to=4.0, increment=0.05,
                    width=6).pack(side="left", padx=(4, 0))
        ttk.Button(row, text="Set", width=5,
                   command=lambda: self.more(lambda: a.cmap_curve(True))).pack(side="left",
                                                                             padx=(4, 0))
        ttk.Button(row, text="Clear", width=6,
                   command=lambda: self.more(lambda: a.cmap_curve(False))).pack(side="left",
                                                                              padx=(4, 0))
        ttk.Label(row, text=">1 stays bright longer, <1 darkens sooner",
                  foreground="#666").pack(side="left", padx=(8, 0))
        row = ttk.Frame(mo)
        row.pack(fill="x", pady=(6, 0))
        ttk.Button(row, text="Copy fade shape", command=a.cmap_copy_shape).pack(side="left")
        a.paste_shape_btn = ttk.Button(row, text="Paste shape to selected",
                                       command=lambda: self.more(a.cmap_paste_shape))
        a.paste_shape_btn.pack(side="left", padx=(4, 0))
        a.paste_shape_btn.state(["!disabled"] if a._cmap_shape else ["disabled"])
        ttk.Label(row, text="copy how one colour fades, give others the same behaviour",
                  foreground="#666").pack(side="left", padx=(8, 0))
        self.win.after_idle(self.rebuild)

    # ---- live fade through
    def _live_toggle(self):
        self.app.s["fadethrough_live"] = bool(self.live_var.get())
        self.rebuild()

    def schedule(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._after = self.win.after(80, self._run)

    def _run(self):
        self._after = None
        self.rebuild()

    def sel_changed(self):
        if self.live_var.get():
            self.schedule()

    def base_free(self):
        return sum(1 for c in self.base[0][:ENTRIES] if c is None)

    def _chain(self):
        a = self.app
        pal = self.base[0]
        return [i for i in sorted(a.selection) if i < ENTRIES and pal[i] is not None]

    def rebuild(self):
        a = self.app
        _restore_state(a, self.base)
        self.new_idx = []
        if not self.live_var.get():
            self.status.set("Preview off.")
            a.recompute()
            self.refresh()
            return
        chain = self._chain()
        if len(chain) < 2:
            self.status.set("Select at least two colours in the palette grid.")
            a.recompute()
            self.refresh()
            return
        cols = self.newcols.colours()
        if cols:
            self.new_idx = place_colours(a, cols)
            chain = sorted(set(chain) | set(self.new_idx))
        try:
            spl = min(max(float(a.fw_spl.get()), 0.01), 32.0)
        except ValueError:
            spl = 0.5
        res, _f = a.cmap_result()
        dark = res.rows[DARK_ROW][0] if res else None
        ov = fade_within(a.pal, chain, spl, a.fw_order.get(), a.fw_end.get(), dark)
        cs = set(chain)
        a.cm.overrides = {k: t for k, t in a.cm.overrides.items()
                          if not (k[1] in cs and k[0] < LIGHT_ROWS)}
        a.cm.overrides.update(ov)
        a.cm_changed()
        self.status.set("Fading %d colours through each other (%s steps/level)%s." % (
            len(chain), fmt_tol(spl), (", +%d new" % len(self.new_idx)) if self.new_idx
            else ""))
        a.recompute()
        self.newcols.update_free()
        self.refresh()

    def find_new(self, n, _cull, _mode):
        a = self.app
        chain = self._chain()
        if len(chain) < 2:
            a.status_var.set("Select at least two colours to fade through first.")
            return
        free = self.base_free()
        if free <= 0:
            a.status_var.set("No empty palette slots - free some with the Cull tool first.")
            return
        pal = self.base[0]
        order = sorted(chain, key=lambda i: -_oklab_l(pal[i]))
        cols = chain_gap_colours([pal[i] for i in order], min(n, free))
        self.newcols.set_items([(c, 0) for c in cols])
        if not cols:
            a.status_var.set("The chain has no big lightness gaps to fill.")
        self.rebuild()

    def external_edit(self):
        """Another edit (a More button, a brush stroke): keep the live preview
        as it is (baked in) and carry on from here."""
        if self.live_var.get():
            self.live_var.set(False)
            self.app.s["fadethrough_live"] = False
            self.status.set("Preview baked in - tick Preview to fade through again.")
            self.newcols.set_items([])
        self.base = _state_of(self.app)

    def more(self, fn):
        """A 'More' button (its handler reports back via external_edit)."""
        fn()
        self.base = _state_of(self.app)

    def log_text(self):
        t = "fade through %d colours" % len(self._chain())
        if self.new_idx:
            t += ", +%d new colour%s" % (len(self.new_idx), "" if len(self.new_idx) == 1 else "s")
        return t if self.live_var.get() else ""

    def note_applied(self):
        self.base = _state_of(self.app)
        self.newcols.set_items([])
        self.rebuild()

    def note_reverted(self):
        self.base = _state_of(self.app)
        self.newcols.set_items([])            # Revert drops the suggested colours too
        self.new_idx = []
        self.rebuild()

    def teardown(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self.app.paste_shape_btn = None
        super().teardown()


def _oklab_l(c):
    from ..cleanpal_lib_colour import oklab
    return oklab(c)[0]


# ============================================================ Light curve
class LightCurveWin(_CWin):
    TITLE = "Light curve - lighten or darken the COLORMAP"
    DEFAULTS = {"scope": "Whole palette", "brightness": 0.0, "black_at": 31.0, "smooth": True}

    def build(self, f):
        tk = self.app.tk
        from tkinter import ttk

        a = self.app
        cfg = dict(self.DEFAULTS)
        saved = a.s.get("lightcurve")
        if isinstance(saved, dict):
            cfg.update({k: v for k, v in saved.items() if k in cfg})
        cfg["brightness"], cfg["black_at"] = 0.0, 31.0       # always start neutral
        self.cfg = cfg
        self._after = None
        self._vals = {}
        self.changed = 0
        self.n = 0
        ttk.Label(f, text="Moves every fade's darkness up or down, keeping its shape. Works on "
                          "whatever COLORMAP\nyou have now (generated, hand-edited, AutoRamps, "
                          "imported). Level 0 never changes.", foreground="#666").pack(anchor="w")
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(8, 0))
        ttk.Label(r, text="Colours").pack(side="left")
        self.scope_var = tk.StringVar(value=cfg["scope"])
        cb = ttk.Combobox(r, textvariable=self.scope_var,
                          values=("Whole palette", "Selected colours"), state="readonly",
                          width=16)
        cb.pack(side="left", padx=(6, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("scope", self.scope_var.get()))
        self.smooth_var = tk.BooleanVar(value=bool(cfg["smooth"]))
        ttk.Checkbutton(r, text="Smooth in-betweens", variable=self.smooth_var,
                        command=lambda: self._set("smooth", bool(self.smooth_var.get()))).pack(
            side="left", padx=(12, 0))
        g = ttk.Frame(f)
        g.pack(fill="x", pady=(8, 0))
        g.columnconfigure(1, weight=1)
        self._slider(g, 0, "Brightness (+ lighter)", "brightness", -100, 100, 1)
        self._slider(g, 1, "Black at level (31 = now)", "black_at", 12, 48, 1)
        r = ttk.Frame(f)
        r.pack(fill="x", pady=(6, 0))
        ttk.Button(r, text="Reset to neutral", command=self.neutral).pack(side="left")
        ttk.Button(r, text="Palettised preview...", command=a.open_preview).pack(side="right")
        self.info_var = tk.StringVar()
        ttk.Label(f, textvariable=self.info_var, foreground="#666").pack(anchor="w", pady=(6, 0))
        ttk.Label(f, text="Tip: the Palettised preview with COLORMAP lighting (and Corridor) "
                          "shows the result\non your textures as you drag.",
                  foreground="#888").pack(anchor="w", pady=(4, 0))
        self._load_base()
        self.win.after_idle(self.rebuild)

    def _slider(self, parent, row, label, key, lo, hi, step):
        tk = self.app.tk
        from tkinter import ttk

        ui = self.ui
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=(4, 0))
        var = tk.StringVar(value=fmt_tol(self.cfg[key]))
        sc = tk.Scale(parent, from_=lo, to=hi, resolution=step, orient="horizontal",
                      showvalue=0, length=int(220 * ui), sliderlength=int(30 * ui),
                      width=int(18 * ui),
                      command=lambda x, k=key, v=var: self._scaled(k, v, float(x)))
        sc.set(self.cfg[key])
        sc.grid(row=row, column=1, sticky="ew", padx=(6, 4), pady=(4, 0))
        ttk.Label(parent, textvariable=var, width=5).grid(row=row, column=2, sticky="w",
                                                          pady=(4, 0))
        self._vals[key] = (sc, var)

    def _scaled(self, key, var, x):
        var.set(fmt_tol(x))
        if self.cfg.get(key) != x:
            self.cfg[key] = x
            self.app.s["lightcurve"] = dict(self.cfg)
            self.schedule()

    def _set(self, key, value):
        self.cfg[key] = value
        self.app.s["lightcurve"] = dict(self.cfg)
        self.schedule()

    def neutral(self):
        for k, v in (("brightness", 0.0), ("black_at", 31.0)):
            self.cfg[k] = v
            self._vals[k][0].set(v)
            self._vals[k][1].set(fmt_tol(v))
        self.schedule()

    def schedule(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._after = self.win.after(40, self._run)

    def _run(self):
        self._after = None
        self.rebuild()

    def _load_base(self):
        """The fades as they are now: what the curve reshapes."""
        a = self.app
        self.base = _state_of(a)
        res, _f = a.cmap_result()
        self.fades = {s: [res.rows[r][s] for r in range(LEVELS)]
                      for s in range(ENTRIES) if a.pal[s] is not None}

    def rebuild(self):
        a = self.app
        _restore_state(a, self.base)
        c = self.cfg
        if c["scope"] == "Selected colours":
            scope = {s for s in a.selection if s in self.fades}
        else:
            scope = set(self.fades)
        neutral = c["brightness"] == 0 and c["black_at"] == 31
        self.n = len(scope)
        self.changed = 0
        if scope and not neutral:
            new = light_curve({s: self.fades[s] for s in scope}, a.pal, float(c["brightness"]),
                              float(c["black_at"]), bool(c["smooth"]), skip=a.cm.fullbright)
            for s, rows in new.items():
                for r in range(1, LEVELS):
                    if rows[r] != self.fades[s][r]:
                        self.changed += 1
                    a.cm.overrides[(r, s)] = rows[r]
            a.cm_changed()
        a.recompute()
        if a.preview is not None:
            a.preview.schedule()
        if not scope:
            self.info_var.set("No colours in scope - select colours or choose Whole palette.")
        else:
            self.info_var.set("%d fades   |   %d levels changed%s" % (
                self.n, self.changed, "   |   neutral (no change)" if neutral else ""))
        self.refresh()

    def log_text(self):
        c = self.cfg
        return "light curve %+d, black at %d on %d fades" % (
            int(c["brightness"]), int(c["black_at"]), self.n)

    def external_edit(self):
        self._load_base()

    def note_applied(self):
        self._load_base()
        self.neutral()

    def note_reverted(self):
        self._load_base()
        self.neutral()

    def teardown(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        super().teardown()


# ============================================================ palette picker
class PalettePicker:
    """Small modal 16x16 grid of the palette; returns the clicked index."""

    def __init__(self, app, parent, current=None, title="Choose a palette colour"):
        tk = app.tk
        self.app = app
        self.result = None
        ui = getattr(app, "ui", 1.0)
        self.cell = cell = int(22 * ui)
        self.win = tk.Toplevel(parent)
        self.win.title(title)
        self.win.transient(parent)
        self.win.resizable(False, False)
        self.cv = tk.Canvas(self.win, width=cell * 16 + 2, height=cell * 16 + 2,
                            bg="#262626", highlightthickness=0)
        self.cv.pack(padx=8, pady=(8, 4))
        self.info = tk.StringVar(value="Click a colour (Esc = cancel)")
        tk.Label(self.win, textvariable=self.info, font=("Consolas", 9)).pack(pady=(0, 8))
        pal = app.pal
        for i in range(ENTRIES):
            x, y = 1 + (i % 16) * cell, 1 + (i // 16) * cell
            c = pal[i]
            if c is None:
                self.cv.create_rectangle(x, y, x + cell - 1, y + cell - 1, fill="#3a3a3a",
                                         outline="#202020")
            else:
                self.cv.create_rectangle(x, y, x + cell - 1, y + cell - 1, fill=hex_of(c),
                                         outline="#202020")
        if current is not None:
            x, y = 1 + (current % 16) * cell, 1 + (current // 16) * cell
            self.cv.create_rectangle(x + 1, y + 1, x + cell - 2, y + cell - 2,
                                     outline="#000000", width=4)
            self.cv.create_rectangle(x + 1, y + 1, x + cell - 2, y + cell - 2,
                                     outline="#00ffff", width=2)
        self.cv.bind("<Button-1>", self._click)
        self.cv.bind("<Motion>", self._hover)
        self.win.bind("<Escape>", lambda e: self.win.destroy())
        self.win.update_idletasks()
        px, py = parent.winfo_pointerx(), parent.winfo_pointery()
        self.win.geometry("+%d+%d" % (max(0, px - self.win.winfo_reqwidth() // 2),
                                      max(0, py - 40)))
        try:
            self.win.grab_set()
        except tk.TclError:
            pass
        self.win.focus_set()
        parent.wait_window(self.win)

    def _at(self, ev):
        c = self.cell
        i = (int(ev.y - 1) // c) * 16 + int(ev.x - 1) // c
        if 0 <= ev.x - 1 < c * 16 and 0 <= ev.y - 1 < c * 16 and 0 <= i < ENTRIES:
            return i
        return None

    def _hover(self, ev):
        i = self._at(ev)
        c = self.app.pal[i] if i is not None else None
        self.info.set("index %3d  %s" % (i, hex_of(c)) if c else "Click a colour (Esc = cancel)")

    def _click(self, ev):
        i = self._at(ev)
        if i is None or self.app.pal[i] is None:
            return
        self.result = i
        self.win.destroy()


# ============================================================ Ramps
class RampsWin(_CWin):
    TITLE = "Ramps"
    AUTO_DEFAULTS = {"on": False, "curve": 1.0, "drift": 0.0, "fade_start": 16,
                     "grey_by": 31, "end": "Black", "wl": 1.0, "wc": 1.0, "wh": 1.0,
                     "only": "All colours", "new_on": False, "new_n": 2, "misses": True}
    ONLY = ("All colours", "Selected colours", "Limit targets")
    ENDS = ("Black", "Fade toward colour")

    def build(self, f):
        tk = self.app.tk
        from tkinter import font as tkfont
        from tkinter import ttk

        a = self.app
        ui = self.ui
        self.subject = None
        self.nodes = {}
        self.current = []
        self.ideal, self.result, self.misses = [], [], []
        self.orig = None              # state when this colour was picked
        self.base = None              # state each rebuild starts from
        self.new_idx = []
        self._drag = None
        self._after = None
        cfg = dict(self.AUTO_DEFAULTS)
        saved = a.s.get("ramps_auto")
        if isinstance(saved, dict):
            cfg.update({k: v for k, v in saved.items() if k in cfg})
        self.cfg = cfg

        self.title_var = tk.StringVar()
        ttk.Label(f, textvariable=self.title_var, font=("Segoe UI", 10, "bold")).pack(anchor="w")
        ttk.Label(f, text="Manual: click a level to add / recolour a node, drag to move, "
                          "right-click to remove (level 0 = the colour).\nAuto: shape the fade "
                          "with the sliders below. Click another colour's number in the fade "
                          "view to ramp it.", foreground="#666").pack(anchor="w")
        # fixed point size: Tk already scales point sizes for the display
        self.font = tkfont.Font(family="Consolas", size=8)
        self.cell = int(22 * ui)
        self.lw = max(self.font.measure(t) for t in ("nodes", "current", "ideal", "result",
                                                     "misses")) + int(10 * ui)
        self.top = self.font.metrics("linespace") + 4
        self.mh = int(16 * ui)                       # misses band height
        h = self.top + self.cell * 4 + 8 + self.mh + int(10 * ui)
        self.cv = tk.Canvas(f, width=self.lw + self.cell * LEVELS + 6, height=h,
                            bg="#262626", highlightthickness=0)
        self.cv.pack(fill="x", pady=(8, 0))
        self.cv.bind("<ButtonPress-1>", self._press)
        self.cv.bind("<B1-Motion>", self._motion)
        self.cv.bind("<ButtonRelease-1>", self._release)
        self.cv.bind("<Button-3>", self._right)
        self.cv.bind("<Motion>", self._hover)
        self.cv.bind("<Leave>", lambda e: self.hover_var.set(""))
        self.hover_var = tk.StringVar()
        ttk.Label(f, textvariable=self.hover_var, font=("Consolas", 9)).pack(anchor="w")

        o = ttk.Frame(f)
        o.pack(fill="x", pady=(6, 0))
        self.mono_var = tk.BooleanVar(value=bool(a.s.get("ramps_mono", True)))
        self.smooth_var = tk.BooleanVar(value=bool(a.s.get("ramps_smooth", True)))
        self.misses_var = tk.BooleanVar(value=bool(cfg["misses"]))
        ttk.Checkbutton(o, text="Never get lighter", variable=self.mono_var,
                        command=self._opts).pack(side="left")
        ttk.Checkbutton(o, text="Smooth", variable=self.smooth_var,
                        command=self._opts).pack(side="left", padx=(10, 0))
        ttk.Checkbutton(o, text="Show misses", variable=self.misses_var,
                        command=self._opts).pack(side="left", padx=(10, 0))
        ttk.Button(o, text="Reset to current", command=self.reset).pack(side="right")
        ttk.Button(o, text="Clear nodes", command=self.clear).pack(side="right", padx=(0, 6))

        # ---- Auto: shape the fade
        af = ttk.LabelFrame(f, text="Auto - shape the fade", padding=6)
        af.pack(fill="x", pady=(8, 0))
        af.columnconfigure(1, weight=1)
        af.columnconfigure(4, weight=1)
        self.auto_var = tk.BooleanVar(value=bool(cfg["on"]))
        ttk.Checkbutton(af, text="Auto (build from these settings - untick to edit as nodes)",
                        variable=self.auto_var, command=self._auto_toggle).grid(
            row=0, column=0, columnspan=6, sticky="w")
        self._vals = {}
        self._slider(af, 1, 0, "Darken curve", "curve", 0.3, 3.0, 0.05)
        self._slider(af, 1, 3, "Hue drift (deg)", "drift", -90, 90, 1)
        self._slider(af, 2, 0, "Colour fade start", "fade_start", 0, 30, 1)
        self._slider(af, 2, 3, "Grey by level", "grey_by", 1, 31, 1)
        ttk.Label(af, text="End").grid(row=3, column=0, sticky="w", pady=(4, 0))
        self.end_var = tk.StringVar(value=cfg["end"] if cfg["end"] in self.ENDS else "Black")
        cb = ttk.Combobox(af, textvariable=self.end_var, values=self.ENDS, state="readonly",
                          width=20)
        cb.grid(row=3, column=1, sticky="w", padx=(6, 0), pady=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("end", self.end_var.get()))

        # ---- matching (manual + auto)
        mf = ttk.LabelFrame(f, text="Matching - how palette colours are chosen", padding=6)
        mf.pack(fill="x", pady=(8, 0))
        mf.columnconfigure(1, weight=1)
        mf.columnconfigure(4, weight=1)
        self._slider(mf, 0, 0, "Lightness", "wl", 0.0, 4.0, 0.1)
        self._slider(mf, 0, 3, "Hue", "wh", 0.0, 4.0, 0.1)
        self._slider(mf, 1, 0, "Colourfulness", "wc", 0.0, 4.0, 0.1)
        ttk.Label(mf, text="Only use").grid(row=1, column=3, sticky="w", padx=(12, 0))
        self.only_var = tk.StringVar(value=cfg["only"] if cfg["only"] in self.ONLY
                                     else self.ONLY[0])
        cb = ttk.Combobox(mf, textvariable=self.only_var, values=self.ONLY, state="readonly",
                          width=18)
        cb.grid(row=1, column=4, sticky="w", padx=(6, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._set("only", self.only_var.get()))

        # ---- new colours (auto)
        nf = ttk.Frame(f)
        nf.pack(fill="x", pady=(8, 0))
        self.new_var = tk.BooleanVar(value=bool(cfg["new_on"]))
        ttk.Checkbutton(nf, text="Add new colours (Auto):", variable=self.new_var,
                        command=lambda: self._set("new_on", bool(self.new_var.get()))).pack(
            side="left")
        self.newn_var = tk.StringVar(value=str(int(cfg["new_n"])))
        sp = ttk.Spinbox(nf, textvariable=self.newn_var, from_=1, to=16, increment=1, width=4,
                         command=self._newn)
        sp.pack(side="left", padx=(6, 0))
        sp.bind("<Return>", lambda e: self._newn())
        sp.bind("<FocusOut>", lambda e: self._newn())
        ttk.Label(nf, text="  empty slots first, then inserted after the colour",
                  foreground="#888").pack(side="left")
        self.info_var = tk.StringVar()
        ttk.Label(f, textvariable=self.info_var, foreground="#666").pack(anchor="w", pady=(6, 0))
        self.warn_var = tk.StringVar()
        ttk.Label(f, textvariable=self.warn_var, foreground="#c03030").pack(anchor="w")
        self.win.after_idle(self._start)

    # ---- settings widgets
    def _slider(self, parent, row, col, label, key, lo, hi, step):
        tk = self.app.tk
        from tkinter import ttk

        ui = self.ui
        ttk.Label(parent, text=label).grid(row=row, column=col, sticky="w",
                                           padx=(12 if col else 0, 0), pady=(4, 0))
        var = tk.StringVar(value=fmt_tol(self.cfg[key]))
        sc = tk.Scale(parent, from_=lo, to=hi, resolution=step, orient="horizontal",
                      showvalue=0, length=int(150 * ui), sliderlength=int(30 * ui),
                      width=int(18 * ui),
                      command=lambda x, k=key, v=var: self._scaled(k, v, float(x)))
        sc.set(self.cfg[key])
        sc.grid(row=row, column=col + 1, sticky="ew", padx=(6, 4), pady=(4, 0))
        ttk.Label(parent, textvariable=var, width=5).grid(row=row, column=col + 2, sticky="w",
                                                          pady=(4, 0))
        self._vals[key] = (sc, var)

    def _scaled(self, key, var, x):
        var.set(fmt_tol(x))
        if self.cfg.get(key) != x:
            self._set(key, x)

    def _set(self, key, value):
        self.cfg[key] = value
        self.app.s["ramps_auto"] = dict(self.cfg)
        self.schedule()

    def _newn(self):
        try:
            n = min(max(int(float(self.newn_var.get())), 1), 16)
        except ValueError:
            n = int(self.cfg["new_n"])
        self.newn_var.set(str(n))
        if n != self.cfg["new_n"]:
            self._set("new_n", n)

    def _opts(self):
        a = self.app
        a.s["ramps_mono"] = bool(self.mono_var.get())
        a.s["ramps_smooth"] = bool(self.smooth_var.get())
        self.cfg["misses"] = bool(self.misses_var.get())
        a.s["ramps_auto"] = dict(self.cfg)
        self.schedule()

    def schedule(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._after = self.win.after(120, self._run)

    def _run(self):
        self._after = None
        self.rebuild()

    def _auto_toggle(self):
        on = bool(self.auto_var.get())
        self.cfg["on"] = on
        self.app.s["ramps_auto"] = dict(self.cfg)
        if not on and self.subject is not None and self.result:
            # hand the auto result over as editable nodes (new colours stay)
            a = self.app
            s = self.subject
            cm = a.cm.copy()
            for r in range(LEVELS):
                cm.overrides.pop((r, s), None)
            self.base = (list(a.rgbs), list(a.labs), a.pairs, set(a.deleted), cm)
            self.nodes = fit_nodes(self.result, s, a.pal, self._blend(), self.mono_var.get(),
                                   self.smooth_var.get(), self._weights(), self._allowed())
            self.nodes[0] = s
            self.new_idx = []
        self.rebuild()

    # ---- helpers
    def _blend(self):
        return "RGB" if self.app.cmap_set.get("cmap_method", "").startswith("Classic") \
            else "OKLab"

    def _weights(self):
        c = self.cfg
        return (float(c["wl"]), float(c["wc"]), float(c["wh"]))

    def _allowed(self, extra=()):
        """Palette indices the ramp may use (None = all)."""
        a = self.app
        only = self.cfg["only"]
        if only == "All colours":
            return None
        src = a.selection if only == "Selected colours" else a.cmap_target_set
        cols = {tuple(a.pal[i]) for i in src if i < ENTRIES and a.pal[i] is not None}
        allowed = {i for i, c in enumerate(a.pal) if c is not None and tuple(c) in cols}
        allowed |= set(extra)
        if self.subject is not None:
            allowed.add(self.subject)
        return allowed

    def _state(self):
        a = self.app
        return (list(a.rgbs), list(a.labs), a.pairs, set(a.deleted), a.cm.copy())

    def _restore(self, st):
        a = self.app
        a.rgbs, a.labs, a.pairs = list(st[0]), list(st[1]), st[2]
        a.deleted = set(st[3])
        a.cm = st[4].copy()
        a.cm_changed()

    # ---- subject / nodes
    def _start(self):
        a = self.app
        s = a.ramps_subject
        sel = a._sel_colours()
        if s is None or s not in sel:
            s = sel[0] if sel else None
        if s is None:
            self.title_var.set("No colour - select colours in the palette grid, then click "
                               "a colour's number in the fade view.")
            self.draw()
            return
        self.set_subject(s, ask=False)

    def set_subject(self, s, ask=True):
        a = self.app
        if s == self.subject:
            return
        if ask and self.subject is not None and a.ctool_pending():
            k = a._ask_buttons("Ramp for %d not applied." % self.subject,
                               "Apply it before starting colour %d's ramp?" % s,
                               [("apply", "Apply"), ("discard", "Discard"),
                                ("cancel", "Cancel")])
            if k == "cancel":
                return
            if k == "apply":
                a.ctool_apply()
            else:
                a.ctool_revert()
        a.ramps_subject = s
        self.subject = s
        self.orig = self.base = self._state()
        self.base_pal = list(a.pal)
        res, _f = a.cmap_result()
        self.current = [res.rows[r][s] for r in range(LEVELS)]
        self.nodes = fit_nodes(self.current, s, a.pal, self._blend(), self.mono_var.get(),
                               self.smooth_var.get(), self._weights(), self._allowed())
        self.nodes[0] = s
        self.title_var.set("Ramp for colour %d  %s" % (s, hex_of(a.pal[s])))
        self.rebuild(preview=bool(self.cfg["on"]))
        a._fade_schedule()

    def reset(self):
        if self.subject is None:
            return
        self._restore(self.orig)
        self.base = self.orig
        if self.auto_var.get():
            self.auto_var.set(False)
            self.cfg["on"] = False
        self.nodes = fit_nodes(self.current, self.subject, self.app.pal, self._blend(),
                               self.mono_var.get(), self.smooth_var.get(), self._weights(),
                               self._allowed())
        self.nodes[0] = self.subject
        self.rebuild(preview=False)
        self.app.recompute()

    def clear(self):
        if self.subject is None:
            return
        if self.auto_var.get():
            self.app.status_var.set("Untick Auto to work with nodes.")
            return
        res, _f = self.app.cmap_result()
        end = res.rows[DARK_ROW][0] if res is not None else self.current[-1]
        self.nodes = {0: self.subject, LEVELS - 1: end}
        self.rebuild()

    # ---- new colours
    def _place_new(self, cols):
        """Put new colours into the palette: empty slots first, then inserted
        right after the ramp's colour. Returns (indices, colours pushed out)."""
        a = self.app
        s = self.subject
        before = [c for c in a.pal if c is not None]
        empties = [i for i in range(ENTRIES) if a.rgbs[i] is None][:len(cols)]
        idx = list(empties)
        if empties:
            a._write_cells(empties, cols[:len(empties)])
        rest = cols[len(empties):]
        if rest:
            idx += a._insert_block(s + 1, rest)
        after = list(a.pal)
        pushed = list(before)
        for c in after:
            if c is not None and c in pushed:
                pushed.remove(c)
        return idx, pushed

    # ---- build + preview
    def rebuild(self, preview=True):
        a = self.app
        self.warn_var.set("")
        if self.subject is None:
            self.draw()
            return
        s = self.subject
        self._restore(self.base)
        mono, smooth, w = self.mono_var.get(), self.smooth_var.get(), self._weights()
        self.new_idx = []
        pushed = []
        if self.auto_var.get():
            c = self.cfg
            end = (0, 0, 0) if c["end"] == "Black" else tuple(a.cmap_set["cmap_target"])
            ideal = auto_ideal(a.pal[s], end, float(c["curve"]), float(c["drift"]),
                               int(c["fade_start"]), int(c["grey_by"]))
            if c["new_on"] and preview:
                a.root.configure(cursor="watch")
                a.root.update_idletasks()
                try:
                    picks = suggest_new_colours({0: s}, a.pal, ideal, int(c["new_n"]), mono,
                                                smooth, w, self._allowed())
                finally:
                    a.root.configure(cursor="")
                if picks:
                    cols = [rgb for _lv, rgb in sorted(picks)]
                    self.new_idx, pushed = self._place_new(cols)
            self.ideal, self.result = palette_ramp({0: s}, a.pal, monotonic=mono,
                                                   smooth=smooth, ideal=ideal, weights=w,
                                                   allowed=self._allowed(self.new_idx),
                                                   open_end=True)
        else:
            self.ideal, self.result = palette_ramp(self.nodes, a.pal, self._blend(), mono,
                                                   smooth, weights=w,
                                                   allowed=self._allowed())
        self.misses = ramp_misses(self.ideal, self.result, a.pal)
        if preview:
            for r in range(LEVELS):
                a.cm.overrides[(r, s)] = self.result[r]
            a.cm_changed()
            a.recompute()
        ch = sum(1 for r in range(LEVELS)
                 if a.pal[self.result[r]] != self.base_pal[self.current[r]])
        worst = max(range(1, LEVELS), key=lambda r: self.misses[r]) if self.misses else 0
        txt = "%s   |   %d level%s would change   |   worst miss: level %d (%.1f)" % (
            "Auto" if self.auto_var.get() else "%d node%s" % (
                len(self.nodes), "" if len(self.nodes) == 1 else "s"),
            ch, "" if ch == 1 else "s", worst, self.misses[worst] if self.misses else 0)
        if self.new_idx:
            txt += "   |   +%d new: %s" % (len(self.new_idx), " ".join(
                hex_of(a.pal[i]) for i in self.new_idx))
        self.info_var.set(txt)
        if pushed:
            self.warn_var.set("No empty slots left: %d colour%s pushed below the red line "
                              "(out of the palette): %s" % (
                                  len(pushed), "" if len(pushed) == 1 else "s",
                                  " ".join(hex_of(c) for c in pushed[:6])))
        self.draw()
        self.refresh()

    def external_edit(self):
        if self.subject is None:
            return
        a = self.app
        cm = a.cm.copy()
        for r in range(LEVELS):
            cm.overrides.pop((r, self.subject), None)
        self.base = (list(a.rgbs), list(a.labs), a.pairs, set(a.deleted), cm)

    def note_applied(self):
        """After Apply: what's in the palette now is the new starting point."""
        if self.subject is None:
            return
        a = self.app
        self.orig = self.base = self._state()
        self.base_pal = list(a.pal)
        self.current = list(self.result)
        if self.new_idx:                     # don't keep adding colours on top
            self.new_var.set(False)
            self.cfg["new_on"] = False
            a.s["ramps_auto"] = dict(self.cfg)
            a.status_var.set(a.status_var.get() + "  (Add new colours switched off - tick "
                             "it again to add more.)")
        self.new_idx = []
        self.draw()
        self.refresh()

    def note_reverted(self):
        if self.subject is not None:
            self.orig = self.base = self._state()
            self.base_pal = list(self.app.pal)
            res, _f = self.app.cmap_result()
            self.current = [res.rows[r][self.subject] for r in range(LEVELS)]
            self.new_idx = []
            if self.auto_var.get():
                self.rebuild(preview=False)
            else:
                self.reset()

    # ---- drawing
    def _rows_y(self):
        top = self.top
        c = self.cell
        return top, top + c, top + 2 * c + 4, top + 3 * c + 8    # nodes, current, ideal, result

    def draw(self):
        cv = self.cv
        try:
            cv.delete("all")
        except self.app.tk.TclError:
            return
        if self.subject is None or not self.result:
            return
        a = self.app
        c, lw = self.cell, self.lw
        yn, yc, yi, yr = self._rows_y()
        ym = yr + c + 4
        f = self.font
        every = 1 if f.measure("31") + 4 <= c else 2
        for lv in range(LEVELS):
            if lv % every == 0:
                cv.create_text(lw + lv * c + c / 2, self.top / 2, text=str(lv),
                               fill="#bbbbbb", font=f)
        rows = [(yn, "nodes"), (yc, "current"), (yi, "ideal"), (yr, "result")]
        if self.misses_var.get():
            rows.append((ym, "misses"))
        for y, lab in rows:
            hh = self.mh if lab == "misses" else c
            cv.create_text(lw - 6, y + hh / 2, text=lab, anchor="e", fill="#dddddd", font=f)
        auto = self.auto_var.get()
        newset = set(self.new_idx)
        for lv in range(LEVELS):
            x = lw + lv * c
            cur = self.base_pal[self.current[lv]] if self.current else None
            if cur:
                cv.create_rectangle(x, yc, x + c - 1, yc + c - 1, fill=hex_of(cur), outline="")
            idl = tuple(int(round(min(max(v, 0), 255))) for v in self.ideal[lv])
            cv.create_rectangle(x, yi, x + c - 1, yi + c - 1, fill=hex_of(idl), outline="")
            res = a.pal[self.result[lv]]
            cv.create_rectangle(x, yr, x + c - 1, yr + c - 1, fill=hex_of(res), outline="")
            if self.result[lv] in newset:                         # a new colour
                fg = "#000000" if sum(res) > 380 else "#ffffff"
                cv.create_text(x + c / 2, yr + c / 2, text="+", fill=fg, font=f)
            if cur and res != cur:                                # this level changes
                cv.create_line(x + 2, yr + c + 1, x + c - 3, yr + c + 1, fill="#ff9a00",
                               width=2)
            if not auto and lv in self.nodes:
                col = a.pal[self.nodes[lv]]
                cv.create_rectangle(x + 2, yn + 2, x + c - 3, yn + c - 3, fill=hex_of(col),
                                    outline="#ffffff" if lv else "#ffcc33", width=2)
                cv.create_rectangle(x, yr, x + c - 1, yr + c - 1, outline="#ffffff")
            elif lv == 0:
                cv.create_rectangle(x + 2, yn + 2, x + c - 3, yn + c - 3,
                                    fill=hex_of(a.pal[self.subject]), outline="#ffcc33",
                                    width=2)
            elif not auto:
                cv.create_rectangle(x + 4, yn + 4, x + c - 5, yn + c - 5, outline="#555555",
                                    dash=(2, 2))
            if self.misses_var.get() and self.misses:
                m = self.misses[lv]
                if m >= 2.0:
                    hgt = max(2, int(self.mh * min(m / 12.0, 1.0)))
                    colr = "#ff3030" if m >= 6.0 else "#ffd24a"
                    cv.create_rectangle(x + 2, ym + self.mh - hgt, x + c - 3, ym + self.mh,
                                        fill=colr, outline="")
        if auto:
            cv.create_text(lw + c * 1.3, yn + c / 2, anchor="w", fill="#c9a0ff", font=f,
                           text="Auto - untick Auto to edit nodes")

    # ---- mouse
    def _level_at(self, x):
        lv = int((x - self.lw) // self.cell)
        return lv if 0 <= lv < LEVELS and x >= self.lw else None

    def _hover(self, ev):
        lv = self._level_at(ev.x)
        if lv is None or not self.result:
            self.hover_var.set("")
            return
        a = self.app
        idl = tuple(int(round(min(max(v, 0), 255))) for v in self.ideal[lv])
        r = self.result[lv]
        self.hover_var.set("level %2d   ideal %s   result %s (index %d%s)   miss %.1f" % (
            lv, hex_of(idl), hex_of(a.pal[r]), r, ", new" if r in self.new_idx else "",
            self.misses[lv] if self.misses else 0))

    def _press(self, ev):
        lv = self._level_at(ev.x)
        if lv is None or self.subject is None:
            return
        if self.auto_var.get():
            self.app.status_var.set("Auto is on - untick Auto to edit the ramp as nodes.")
            self._drag = None
            return
        self._drag = {"lv": lv, "moved": False, "node": lv in self.nodes and lv != 0}

    def _motion(self, ev):
        d = self._drag
        if not d or not d["node"]:
            return
        lv = self._level_at(ev.x)
        if lv is None or lv == 0 or lv == d["lv"] or lv in self.nodes:
            return
        self.nodes[lv] = self.nodes.pop(d["lv"])
        d["lv"], d["moved"] = lv, True
        self.rebuild()

    def _release(self, ev):
        d, self._drag = self._drag, None
        if not d or d["moved"]:
            return
        lv = d["lv"]
        if lv == 0:
            self.app.status_var.set("Level 0 is the colour itself - it can't change.")
            return
        pk = PalettePicker(self.app, self.win, self.nodes.get(lv), "Colour for level %d" % lv)
        if pk.result is not None:
            self.nodes[lv] = pk.result
            self.rebuild()

    def _right(self, ev):
        lv = self._level_at(ev.x)
        if self.auto_var.get() or lv is None or lv == 0 or lv not in self.nodes:
            return
        del self.nodes[lv]
        self.rebuild()

    def teardown(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self.app.ramps_subject = self.subject
        super().teardown()


WINDOWS = {"generate": GenerateWin, "fade": FadeEditWin, "limit": LimitWin,
           "create": CreateWin, "ramps": RampsWin, "autoramps": AutoRampsWin,
           "light": LightCurveWin,
           "diag": DiagWin}


# ============================================================ host mixin
class CmapToolsMixin:
    def _ctool_init(self):
        self.ctool = None
        self.ctool_win = None
        self._ctool_start = None
        self._ctool_log = []
        self.ramps_subject = None
        self.ctool_btns = {}

    # ---- side panel
    def _build_ctools_panel(self, side):
        tk = self.tk
        from tkinter import ttk

        tf = ttk.LabelFrame(side, text="COLORMAP tools", padding=8)
        tf.columnconfigure(1, weight=1)
        for row, t in enumerate(CTOOLS):
            b = tk.Button(tf, text=CTOOL_NAME[t], width=13, relief="raised",
                          command=lambda t=t: self.toggle_ctool(t))
            b.grid(row=row, column=0, sticky="w", pady=(0 if row == 0 else 4, 0))
            self.ctool_btns[t] = b
            ttk.Label(tf, text=CTOOL_HINT[t], foreground="#666").grid(
                row=row, column=1, sticky="w", padx=(8, 0), pady=(0 if row == 0 else 4, 0))
        self._ctool_btn_bg = self.ctool_btns["generate"].cget("background")
        ttk.Label(tf, text="Changes show live; Apply = one history entry",
                  foreground="#888").grid(row=len(CTOOLS), column=0, columnspan=2,
                                          sticky="w", pady=(6, 0))
        return tf

    def _refresh_ctools(self):
        for t, b in self.ctool_btns.items():
            on = self.ctool == t
            b.configure(relief="sunken" if on else "raised",
                        background=CTOOL_COLOUR if on else self._ctool_btn_bg,
                        activebackground=CTOOL_COLOUR if on else self._ctool_btn_bg)

    # ---- session
    def _ctool_snapshot(self):
        self._ctool_start = (self.cm.copy(), dict(self.cmap_set), list(self.rgbs),
                             list(self.labs), self.pairs, set(self.deleted))
        self._ctool_log = []

    def ctool_pending(self):
        if self.ctool is None or self._ctool_start is None:
            return False
        st = self._ctool_start
        return self.cm != st[0] or self.cmap_set != st[1] or list(self.rgbs) != st[2]

    def ctool_apply(self):
        if not self.ctool_pending():
            self.status_var.set("Nothing to apply.")
            return
        name = CTOOL_NAME[self.ctool]
        if self.ctool == "ramps" and self.ctool_win is not None \
                and self.ctool_win.subject is not None:
            w = self.ctool_win
            how = "auto" if w.auto_var.get() else "%d nodes" % len(w.nodes)
            if w.new_idx:
                how += ", +%d new colour%s" % (len(w.new_idx), "" if len(w.new_idx) == 1
                                              else "s")
            self._ctool_log = ["ramp for %d (%s)" % (w.subject, how)]
        w = self.ctool_win
        if w is not None and hasattr(w, "log_text") and w.log_text():
            self._ctool_log = [w.log_text()]
        culls = w.applied_culls() if w is not None and hasattr(w, "applied_culls") else []
        if not self._ctool_log and self.cmap_set != self._ctool_start[1]:
            ch = [k[5:] for k in self.cmap_set if self.cmap_set[k] != self._ctool_start[1].get(k)]
            self._ctool_log = ["settings (%s)" % ", ".join(ch)]
        text = "%s: %s" % (name, "; ".join(self._ctool_log) or "edits")
        self.cm_changed()
        self._push_history("COLORMAP %s" % text)
        self._ctool_snapshot()
        self.status_var.set("COLORMAP %s - recorded as #%d (Back undoes it)." % (
            text, self.hist_pos))
        if culls:
            self._save_cull_report(culls)
        if self.ctool_win is not None and hasattr(self.ctool_win, "note_applied"):
            self.ctool_win.note_applied()
        self.recompute()

    def ctool_revert(self):
        if self._ctool_start is None:
            return
        cm, st, rgbs, labs, pairs, deleted = self._ctool_start
        self.rgbs, self.labs, self.pairs = list(rgbs), list(labs), pairs
        self.deleted = set(deleted)
        self.cm = cm.copy()
        if st != self.cmap_set:
            self.apply_cmap_settings(st)
            self.s.update(st)
        self.cm_changed()
        self._ctool_log = []
        self.status_var.set("COLORMAP changes reverted.")
        self.recompute()
        if self.ctool_win is not None and hasattr(self.ctool_win, "note_reverted"):
            self.ctool_win.note_reverted()

    # ---- open / close
    def toggle_ctool(self, name):
        if self.ctool == name:
            self.close_ctool()
        else:
            self.open_ctool(name)

    def open_ctool(self, name):
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return False
        if not self.cmap_mode():
            self.status_var.set("The COLORMAP tools are in COLORMAP mode.")
            return False
        if self.ctool == name:
            self.ctool_win.lift()
            return True
        if self._previewing():
            self.status_var.set("A preview is open - Apply or Cancel it first.")
            return False
        if self.ctool is not None and not self.close_ctool(quiet=True):
            return False
        self.ctool = name
        self._ctool_snapshot()
        self.ctool_win = WINDOWS[name](self, name)
        self._refresh_ctools()
        self._refresh_history()
        self.status_var.set("%s tool: changes show live - Apply records them." % CTOOL_NAME[name]
                            if name not in VIEWERS else "%s tool open." % CTOOL_NAME[name])
        self.recompute()
        return True

    def close_ctool(self, quiet=False, force=False):
        t = self.ctool
        if t is None:
            return True
        if self.ctool_pending():
            if force:
                self.ctool_apply()
            else:
                k = self._ask_buttons("%s changes not applied." % CTOOL_NAME[t],
                                      "Apply them as a history entry, or discard them?",
                                      [("apply", "Apply"), ("discard", "Discard"),
                                       ("cancel", "Cancel")])
                if k == "cancel":
                    return False
                if k == "apply":
                    self.ctool_apply()
                else:
                    self.ctool_revert()
        self.ctool_win.teardown()
        self.ctool = None
        self.ctool_win = None
        self._ctool_start = None
        self._ctool_log = []
        self._refresh_ctools()
        self._refresh_history()
        if not quiet:
            self.status_var.set("%s tool closed." % CTOOL_NAME[t])
        self.recompute()
        return True

    def _save_cull_report(self, culls):
        """Culls change what an index means - offer a remap list for the graphics."""
        from tkinter import filedialog
        import os

        k = self._ask_buttons(
            "%d colour%s culled" % (len(culls), "" if len(culls) == 1 else "s"),
            "Each culled slot now holds a new colour. Any graphics using those indices "
            "should be remapped to the kept twin. Save a cull report (old index -> kept "
            "index) for your remap tools?", [("save", "Save report..."), ("skip", "Skip")])
        if k != "save":
            return
        p = filedialog.asksaveasfilename(
            title="Save cull report", defaultextension=".txt",
            initialfile="cleanpal_cull_report.txt",
            initialdir=self.s.get("last_dir") or None, filetypes=[("Text", "*.txt")])
        if not p:
            return
        before = self.history[self.hist_pos - 1]["palette"] if self.hist_pos else self.rgbs
        lines = ["# cleanpal cull report - remap these palette indices in your graphics",
                 "# old_index -> kept_index    old_colour -> kept_colour"]
        for cull, keep in culls:
            lines.append("%3d -> %3d    %s -> %s" % (cull, keep, hex_of(before[cull]),
                                                    hex_of(before[keep])))
        with open(p, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        self.status_var.set("Cull report saved: %s" % os.path.basename(p))

    def _ctool_sel_changed(self):
        w = getattr(self, "ctool_win", None)
        if w is not None and hasattr(w, "sel_changed"):
            w.sel_changed()

    def _ctool_refresh_win(self):
        if self.ctool_win is not None:
            self.ctool_win.refresh()

    # ---- fade view: click a colour's number
    def fade_label_click(self, s):
        self.ramps_subject = s
        if self.ctool == "ramps" and self.ctool_win is not None:
            self.ctool_win.set_subject(s)
        else:
            self.status_var.set("Colour %d chosen for Ramps - open the Ramps tool to build "
                                "its fade." % s)
        self._fade_schedule()
