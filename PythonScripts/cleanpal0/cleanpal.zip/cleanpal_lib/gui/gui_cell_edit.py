"""Cell Edit (pal0 tool): edit single palette cells with the colour picker.

Press the side-panel button -> click a cell in the palette grid -> the Cell
Edit window opens on that cell: the full colour picker (built in), the cell
before / after, and the selected cells as swatches (the one being edited
ringed, edited ones dotted). Clicking another grid cell, or a swatch, edits
that one. The selection never changes while the tool is open. Edits are
live; Apply = one history entry, Cancel = back to how it was, Ctrl+Z undoes
edit by edit."""

import time

from ..cleanpal_lib_analysis import update_pairs
from ..cleanpal_lib_colour import hex_of
from ..cleanpal_lib_constants import ENTRIES
from .gui_tool_windows import _ToolWin, focus_on_click

UNDO_GAP = 0.6          # seconds: picker changes closer than this = one undo step


def _trim(strip):
    """A strip without its trailing empty cells (padding doesn't count)."""
    out = list(strip or [])
    while out and out[-1] is None:
        out.pop()
    return out


class CellEditTool(_ToolWin):
    POS_KEY = "celledit_pos"

    def __init__(self, app):
        self.app = app
        self.ui = getattr(app, "ui", 1.0)
        self.win = None                 # opens on the first cell click
        self.picker = None
        self.cell = None
        self.edits = {}                 # cell -> colour before this session
        self.undo = []                  # [(cell, colour before the step)]
        self._last_t = 0.0
        self._last_cell = None
        self._snapshot()
        self._set_cursor(True)

    # ---------------------------------------------------------- base state
    def _snapshot(self):
        a = self.app
        self.base = (a.rgbs, a.labs, a.pairs, set(a.deleted), a.cm.copy())
        self._expect = a.rgbs

    def _set_cursor(self, on):
        try:
            self.app.canvas.configure(cursor="crosshair" if on else "")
        except Exception:  # noqa: BLE001
            pass

    # ---------------------------------------------------------- window
    def _build(self):
        from tkinter import ttk
        a = self.app
        tk = a.tk
        ui = self.ui
        win = self._make_win(a, "Cell Edit")
        win.resizable(True, True)
        win.bind("<Escape>", lambda e: a.close_tool())
        win.columnconfigure(0, weight=1)
        win.rowconfigure(1, weight=1)
        top = ttk.Frame(win, padding=(8, 8, 8, 0))
        top.grid(row=0, column=0, sticky="ew")
        self.cell_var = tk.StringVar()
        ttk.Label(top, textvariable=self.cell_var, font=("Segoe UI", 10, "bold")).pack(
            side="left")
        self.ba = tk.Canvas(top, width=int(64 * ui), height=int(26 * ui),
                            highlightthickness=1, highlightbackground="#888")
        self.ba.pack(side="left", padx=(10, 0))
        ttk.Label(top, text="before | after", foreground="#888").pack(side="left",
                                                                     padx=(6, 0))
        ttk.Button(top, text="Revert cell", command=self.revert_cell).pack(side="left",
                                                                           padx=(10, 0))
        pf = ttk.Frame(win)
        pf.grid(row=1, column=0, sticky="nsew")
        pf.columnconfigure(0, weight=1)
        pf.rowconfigure(0, weight=1)
        from .gui_picker import ColourPicker
        self.picker = ColourPicker(a, parent=pf)
        self.picker.win.grid(row=0, column=0, sticky="nsew")
        # cells area
        hf = ttk.Frame(win)
        self.cells_title = ttk.Label(hf, text="Cells")
        self.cells_title.pack(side="left")
        bx = ttk.LabelFrame(win, labelwidget=hf, padding=6)
        bx.grid(row=2, column=0, sticky="ew", padx=8, pady=(4, 0))
        bx.columnconfigure(0, weight=1)
        self.sz = max(8, int(round(float(a.s.get("celledit_sz", 26)) * ui)))
        self.cv = tk.Canvas(bx, height=self.sz + 4, highlightthickness=0, bg="#2a2a2a",
                            cursor="hand2")
        self.cv.grid(row=0, column=0, sticky="ew")
        self.cv.bind("<Configure>", lambda e: self.draw_cells())
        self.cv.bind("<Button-1>", self._cells_click)
        self.cv.bind("<Motion>", self._cells_hover)
        g = tk.Canvas(bx, height=max(6, int(7 * ui)), highlightthickness=0, bg="#3c3c3c",
                      cursor="sb_v_double_arrow")
        g.grid(row=1, column=0, sticky="ew")
        g.bind("<Configure>", lambda e: self._grip_dots(g))
        g.bind("<ButtonPress-1>", lambda e: setattr(self, "_grip", (e.y_root, self.sz,
                                                                    self._rows)))
        g.bind("<B1-Motion>", self._grip_move)
        g.bind("<ButtonRelease-1>", lambda e: (setattr(self, "_grip", None),
                                               a.s.__setitem__("celledit_sz",
                                                               round(self.sz / ui, 1))))
        self._grip, self._rows = None, 1
        self.info_var = tk.StringVar()
        ttk.Label(bx, textvariable=self.info_var, font=("Consolas", 9)).grid(
            row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Label(bx, foreground="#888",
                  text="click a swatch (or any cell in the palette grid) = edit it · "
                       "line under = being edited · ••• = edited").grid(row=3, column=0,
                                                                     sticky="w")
        bf = ttk.Frame(win, padding=8)
        bf.grid(row=3, column=0, sticky="ew")
        ttk.Button(bf, text="Apply", command=self.apply).pack(side="left")
        ttk.Button(bf, text="Cancel", command=self.cancel).pack(side="left", padx=(6, 0))
        self.count_var = tk.StringVar()
        ttk.Label(bf, textvariable=self.count_var, foreground="#666").pack(side="left",
                                                                          padx=(10, 0))
        ttk.Button(bf, text="Close", command=a.close_tool).pack(side="right")
        focus_on_click(win)
        try:
            win.geometry(a.s.get("celledit_geometry") or "%dx%d" % (int(780 * ui),
                                                                     int(580 * ui)))
        except tk.TclError:
            pass
        self._place()

    def lift(self):
        if self.win is not None:
            _ToolWin.lift(self)

    # ---------------------------------------------------------- choosing a cell
    def grid_click(self, idx):
        """A click on the palette grid while the tool is open."""
        self.edit_cell(idx)

    def edit_cell(self, idx):
        a = self.app
        if a.rgbs is None:
            return
        if idx in a.locked:
            a.status_var.set("Cell %d is locked (Colour lock) - unlock it to edit it." % idx)
            return
        a._ensure_len(idx + 1)
        if self.win is None:
            self._build()
        self.cell = idx
        rgb = a.rgbs[idx]
        start = tuple(rgb) if rgb is not None else (0, 0, 0)
        self.picker.set_target(self._picked, start, None, "Cell %d" % idx)
        self._last_cell = None
        self._sync()
        a.status_var.set("Cell Edit: editing cell %d - the picker changes it live. Apply "
                         "keeps the edits." % idx)

    # ---------------------------------------------------------- writing
    def _picked(self, rgb, _hsl=None):
        a = self.app
        i = self.cell
        if i is None or a.rgbs is None:
            return
        rgb = tuple(max(0, min(255, int(round(v)))) for v in rgb)
        if i < len(a.rgbs) and a.rgbs[i] == rgb:
            return
        now = time.time()
        if self._last_cell != i or now - self._last_t > UNDO_GAP:
            self.undo.append((i, a.rgbs[i] if i < len(a.rgbs) else None))
            del self.undo[:-200]
        self._last_t, self._last_cell = now, i
        self._write(i, rgb)

    def _write(self, i, rgb):
        a = self.app
        if i not in self.edits:
            b0 = self.base[0]
            self.edits[i] = b0[i] if i < len(b0) else None
        a._ensure_len(i + 1)
        new = list(a.rgbs)
        new[i] = tuple(rgb) if rgb is not None else None
        a.rgbs = new
        a.labs, a.pairs = update_pairs(new, a.labs, a.pairs, [i])
        a.deleted.discard(i)
        if i < ENTRIES:
            a.cm.invalidate([i])
        a.cm_changed()
        self._expect = a.rgbs
        a.recompute()
        self._sync(picker=False)

    def revert_cell(self):
        i = self.cell
        if i is None or i not in self.edits:
            self.app.status_var.set("This cell isn't edited.")
            return
        a = self.app
        self.undo.append((i, a.rgbs[i]))
        self._write(i, self.edits[i])
        self._sync()

    def undo_step(self):
        """Ctrl+Z: the last edit step comes off. -> True if there was one."""
        if not self.undo:
            return False
        i, col = self.undo.pop()
        self._write(i, col)
        self._last_cell = None
        if i == self.cell:
            self._sync()
        self.app.status_var.set("Cell Edit: undid an edit on cell %d." % i)
        return True

    # ---------------------------------------------------------- view
    def changed(self):
        a = self.app
        b0 = self.base[0]
        return sorted(i for i in self.edits
                      if (a.rgbs[i] if i < len(a.rgbs) else None)
                      != (b0[i] if i < len(b0) else None))

    def _sync(self, picker=True):
        a = self.app
        if self.win is None:
            return
        i = self.cell
        if picker and i is not None and self.picker is not None:
            rgb = a.rgbs[i] if i < len(a.rgbs) else None
            self.picker.set_target(self._picked, tuple(rgb) if rgb else (0, 0, 0), None,
                                   "Cell %d" % i)
        if i is not None:
            now = a.rgbs[i] if i < len(a.rgbs) else None
            was = self.edits.get(i, now)
            self.cell_var.set("Cell %d  %s" % (i, hex_of(now).upper() if now else "empty"))
            c = self.ba
            c.delete("all")
            W, H = int(c.cget("width")), int(c.cget("height"))
            for k, col in enumerate((was, now)):
                x0 = k * W / 2.0
                if col is None:
                    c.create_rectangle(x0, 0, x0 + W / 2.0, H, fill="#2a2a2a", outline="")
                    c.create_line(x0, 0, x0 + W / 2.0, H, fill="#666")
                else:
                    c.create_rectangle(x0, 0, x0 + W / 2.0, H, fill=hex_of(col), outline="")
        n = len(self.changed())
        self.count_var.set(("%d cell%s edited - not applied" % (n, "" if n == 1 else "s"))
                           if n else "No edits")
        self.draw_cells()

    def _cells_list(self):
        a = self.app
        sel = sorted(i for i in a.selection if a.rgbs is not None and i < len(a.rgbs))
        if self.cell is not None and self.cell not in sel:
            sel.append(self.cell)
        return sel

    def draw_cells(self):
        if self.win is None:
            return
        a = self.app
        c = self.cv
        c.delete("all")
        self._hits = []
        cells = self._cells_list()
        self.cells_title.configure(text=("Cells - %d selected" % len(a.selection))
                                   if a.selection else "Cells - nothing selected (just "
                                   "the cell being edited)")
        s = self.sz
        u = self.ui
        gap = max(2, int(round(2 * u)))
        dot = max(2.0, 1.6 * u)                     # ••• radius
        lw = max(2, int(round(2 * u)))              # edited-line thickness
        mark_h = int(round(dot * 2 + 3 * u + lw + 3 * u))   # room under a swatch
        W = max(c.winfo_width(), s + 8)
        per = max(1, (W - 4 + gap) // (s + gap))
        rows = max(1, (len(cells) + per - 1) // per)
        self._rows = rows
        pitch = s + mark_h + gap
        h = rows * pitch + 4
        if int(c.cget("height")) != h:
            c.configure(height=h)
        ow = max(1, round(self.ui))
        changed = set(self.changed())
        for k, i in enumerate(cells):
            x = 2 + (k % per) * (s + gap)
            y = 2 + (k // per) * pitch
            col = a.rgbs[i] if i < len(a.rgbs) else None
            if col is None:
                c.create_rectangle(x, y, x + s, y + s, fill="#1c1c1c", outline="#555")
                c.create_line(x, y, x + s, y + s, fill="#555")
            else:
                c.create_rectangle(x, y, x + s, y + s, fill=hex_of(col), outline="#6a6a6a",
                                   width=ow)
            if i in a.locked:
                a._draw_lock_mark(c, x, y, s)
            dy = y + s + 2 * u + dot                 # ••• = edited (just under)
            if i in changed:
                for q in (-1, 0, 1):
                    cx = x + s / 2.0 + q * dot * 3
                    c.create_oval(cx - dot, dy - dot, cx + dot, dy + dot, fill="#ffffff",
                                  outline="")
            if i == self.cell:                      # white line = being edited (lower)
                ly = dy + dot + 2 * u + lw / 2.0
                c.create_line(x, ly, x + s, ly, fill="#ffffff", width=lw)
            self._hits.append((x, y, x + s, y + s, i))

    def _hit(self, ev):
        for x0, y0, x1, y1, i in getattr(self, "_hits", []):
            if x0 <= ev.x <= x1 and y0 <= ev.y <= y1:
                return i
        return None

    def _cells_click(self, ev):
        i = self._hit(ev)
        if i is not None:
            self.edit_cell(i)

    def _cells_hover(self, ev):
        a = self.app
        i = self._hit(ev)
        if i is None:
            self.info_var.set("")
            return
        col = a.rgbs[i] if i < len(a.rgbs) else None
        t = "cell %d   %s" % (i, ("%s  %d,%d,%d" % ((hex_of(col).upper(),) + tuple(col)))
                              if col else "empty")
        if i in self.changed():
            was = self.edits[i]
            t += "   (was %s)" % (hex_of(was).upper() if was else "empty")
        if i in a.locked:
            t += "   LOCKED"
        self.info_var.set(t)

    def _grip_dots(self, g):
        g.delete("all")
        W, H = g.winfo_width(), g.winfo_height()
        u = max(1.0, self.ui)
        for k in (-1, 0, 1):
            x = W / 2.0 + k * 6 * u
            g.create_oval(x - u, H / 2.0 - u, x + u, H / 2.0 + u, fill="#aaaaaa", outline="")

    def _grip_move(self, ev):
        if not self._grip:
            return
        y0, sz0, rows = self._grip
        sz = int(min(max(sz0 + (ev.y_root - y0) / float(max(rows, 1)), 12 * self.ui),
                     120 * self.ui))
        if sz != self.sz:
            self.sz = sz
            self.draw_cells()

    def refresh(self):
        """The palette changed from outside (history jump ...): start over
        from it if it isn't the state this tool wrote."""
        a = self.app
        if a.rgbs is not self._expect and _trim(a.rgbs) != _trim(self._expect):
            self.edits, self.undo = {}, []
            self._snapshot()
            self._sync()

    def sel_changed(self):
        self.draw_cells()

    # ---------------------------------------------------------- apply / cancel / close
    def apply(self):
        a = self.app
        ch = self.changed()
        if not ch:
            a.status_var.set("Cell Edit: nothing to apply.")
            return
        a._push_history("Cell edit: %d cell%s (%s)" % (
            len(ch), "" if len(ch) == 1 else "s",
            ", ".join(str(i) for i in ch[:8]) + (" ..." if len(ch) > 8 else "")))
        a._refresh_history()
        self.edits, self.undo = {}, []
        self._snapshot()
        self._sync(picker=False)
        a.status_var.set("Cell Edit: %d cell%s applied as #%d (Back undoes it)." % (
            len(ch), "" if len(ch) == 1 else "s", a.hist_pos))

    def _restore(self):
        a = self.app
        b = self.base
        a.rgbs, a.labs, a.pairs = b[0], b[1], b[2]
        a.deleted, a.cm = set(b[3]), b[4].copy()
        a.cm_changed()
        self._expect = a.rgbs

    def cancel(self):
        if not self.edits:
            self.app.status_var.set("Cell Edit: nothing to cancel.")
            return
        self._restore()
        self.edits, self.undo = {}, []
        self.app.recompute()
        self._sync()
        self.app.status_var.set("Cell Edit: edits cancelled.")

    def confirm_close(self, force=False):
        if not self.changed():
            return True
        if force:
            self.apply()
            return True
        k = self.app._ask_buttons("Cell edits not applied.",
                                  "%d edited cell(s) haven't been applied." %
                                  len(self.changed()),
                                  [("apply", "Apply"), ("discard", "Discard"),
                                   ("cancel", "Cancel")])
        if k == "cancel":
            return False
        if k == "apply":
            self.apply()
        return True

    def teardown(self):
        a = self.app
        self._set_cursor(False)
        if self.edits and self.changed():
            self._restore()                   # anything unapplied goes
        if self.picker is not None:
            try:
                self.picker.close()
            except Exception:  # noqa: BLE001
                pass
            self.picker = None
        if self.win is not None:
            try:
                a.s["celledit_geometry"] = self.win.geometry()
            except a.tk.TclError:
                pass
            self.store_pos()
            self.win.destroy()
            self.win = None
