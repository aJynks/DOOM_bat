"""Tool windows, ramp preview and direct colour writes (App mixin)."""

import json

from ..cleanpal_lib_analysis import update_pairs
from ..cleanpal_lib_filters import apply_filter
from ..cleanpal_lib_colour import hex_of, parse_colour_list
from ..cleanpal_lib_constants import ENTRIES
from .gui_tool_windows import TOOL_NAME
from .gui_cmap_tools import CTOOL_NAME
from .gui_lock_tool import pin_perm
from .gui_picker import ColourPicker
from .gui_scratch import ScratchPalette


class ToolsMixin:
    """Tool windows, ramp preview and direct colour writes."""

    def open_picker(self):
        if self.picker is not None:
            self.picker.win.deiconify()
            self.picker.win.lift()
            return self.picker
        self.picker = ColourPicker(self)
        self.picker.owner = None
        self.picker.set_target(None, (128, 128, 128), None, "")
        return self.picker

    def open_scratch(self):
        if self.scratch is not None:
            self.scratch.win.deiconify()
            self.scratch.win.lift()
            return self.scratch
        self.scratch = ScratchPalette(self)
        return self.scratch

    def add_recent(self, rgb):
        hx = hex_of(rgb)
        rec = [x for x in self.s.get("recent_colours", []) if isinstance(x, str) and x != hx]
        self.s["recent_colours"] = [hx] + rec[:15]

    def _tools_refresh(self):
        """Palette changed: let the open tool windows redraw their markers."""
        p = getattr(self, "picker", None)
        if p is not None and getattr(p, "pal", None) is not None:
            p.draw_pal()                     # picker in pal0-WIP mode
        if self.ramp is not None:
            self.ramp.draw_strip()
        if self.scratch is not None:
            self.scratch.draw()

    def ramp_preview_start(self):
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return False
        if self.tool != "paint":
            self.status_var.set("Palette ramps are in the Paint tools.")
            return False
        if self._ramp_backup is not None:
            return True
        if self._filt_backup is not None:
            self.status_var.set("Filter preview is open - Apply or Cancel it first.")
            return False
        self._ramp_backup = (self.rgbs, self.labs, self.pairs,
                             set(self.deleted), set(self.selection))
        self._ramp_cm = self.cm.copy()
        self._ramp_retarget()
        self._ramp_paused = False
        self._refresh_history()
        return True

    # ---------------------------------------------------------- Locks mode
    def paint_lock_mode(self):
        """How a Paint ramp treats locked cells in the selection:
        slide = left out, the ramp has one step per unlocked cell;
        drop = one step per selected cell, the locked steps aren't written;
        push = one step per selected cell, written into the unlocked cells
        plus one extra cell after the selection per locked cell (colours
        already there are pushed up)."""
        m = self.s.get("paint_locks", "slide")
        return m if m in ("slide", "drop", "push") else "slide"

    def ramp_plan(self, base=None, sel=None):
        """{"mode", "sel", "steps" (cells, one per ramp step), "base" (strip
        the steps are written onto - pushed for Push), "perm" (Push: the
        permutation perm[new] = old that makes "base", or None), "ext"
        (Push: the extra cells)}."""
        if base is None:
            b = self._ramp_backup
            base = b[0] if b is not None else self.rgbs
        base = list(base or [])
        sel = sorted(self.selection if sel is None else sel)
        mode = self.paint_lock_mode()
        lk = self.locked
        key = (mode, tuple(sel), frozenset(lk), tuple(base))
        c = getattr(self, "_ramp_plan_cache", None)
        if c is not None and c[0] == key:
            return c[1]
        plan = {"mode": mode, "sel": sel, "base": base, "perm": None, "ext": []}
        free = [i for i in sel if i not in lk]
        if mode == "drop":
            plan["steps"] = list(sel)
        elif mode == "push" and len(free) < len(sel):
            work, total, ext = list(base), list(range(len(base))), []
            last = max(sel)

            def grow(n):
                n = ENTRIES + ((n - ENTRIES + 15) // 16) * 16
                while len(work) < n:
                    total.append(len(work))
                    work.append(None)

            for _k in range(len(sel) - len(free)):
                t = last + 1
                while t < ENTRIES and t in lk:
                    t += 1
                if t >= ENTRIES:                     # past 255: below the red line
                    t = max(t, ENTRIES)
                    while t < len(work) and work[t] is not None:
                        t += 1
                    grow(t + 1)
                elif work[t] is not None:           # push the colours up one
                    hole = next((i for i in range(t + 1, ENTRIES) if work[i] is None
                                 and i not in lk), None)
                    if hole is None:
                        hole = next((i for i in range(ENTRIES, len(work))
                                     if work[i] is None), None)
                        if hole is None:
                            hole = len(work)
                            grow(hole + 1)
                    L = len(work)
                    perm = pin_perm(list(range(t)) + [hole] +
                                    [i for i in range(t, L) if i != hole], lk)
                    work = [work[o] for o in perm]
                    total = [total[o] for o in perm]
                ext.append(t)
                last = t
            plan.update(steps=free + ext, base=work, ext=ext,
                        perm=total if total != list(range(len(total))) else None)
        else:
            plan["steps"] = free
        self._ramp_plan_cache = (key, plan)
        return plan

    def _ramp_retarget(self):
        """Work out the live preview's cells from the selection (Locks mode)."""
        b = self._ramp_backup
        self._ramp_plan = self.ramp_plan(b[0] if b is not None else None)
        self._ramp_targets = list(self._ramp_plan["steps"])

    def ramp_preview_set(self, colours):
        if self._ramp_backup is None:
            return
        b = self._ramp_backup
        tg = self._ramp_targets
        plan = getattr(self, "_ramp_plan", None)
        base = plan["base"] if plan is not None and plan["base"] is not None else b[0]
        new = list(base)
        lk = self.locked
        for i, c in zip(tg, colours):
            if i in lk:                        # Locks: Drop - never written
                continue
            new[i] = tuple(c) if c is not None else None
        b0 = b[0]
        changed = set(i for i in tg if i not in lk)
        changed |= {i for i in range(len(new)) if i >= len(b0) or new[i] != b0[i]}
        self.rgbs = new
        self.labs, self.pairs = update_pairs(new, b[1], b[2], changed)
        if plan is not None and plan["perm"]:
            newpos = {old: n for n, old in enumerate(plan["perm"])}
            self.deleted = {newpos.get(i, i) for i in b[3]} - changed
        else:
            self.deleted = set(b[3]) - changed
        self.cm = self._ramp_cm.copy()
        self.cm.invalidate([i for i in changed if i < ENTRIES])
        self.cm_changed()
        n = len([i for i in tg if i not in lk])
        self.status_var.set(("Ramp preview: %d cells - select others to move it. Apply keeps "
                             "it." % n) if tg else
                            "Ramp preview: select the cells to fill.")
        self.recompute()

    # ---------------------------------------------------------- live Paint preview
    def _ramp_restore_base(self):
        b = self._ramp_backup
        self.rgbs, self.labs, self.pairs = b[0], b[1], b[2]
        self.deleted = set(b[3])
        self.cm = self._ramp_cm.copy()
        self.cm_changed()

    def _ramp_suspend(self):
        """Another edit is about to happen: put the real palette back and
        pause the live preview until the selection or the ramp changes."""
        if self._ramp_backup is None:
            return
        self._ramp_restore_base()
        self._ramp_backup = None
        self._ramp_targets = []
        self._ramp_paused = True
        if self.ramp is not None and not getattr(self.ramp, "FADE", False):
            self.ramp.update_buttons()
        self._refresh_history()

    def paint_live(self):
        return bool(self.s.get("paint_preview", True))

    def _ramp_resume(self):
        """(Re)start the live ramp preview on the current selection."""
        if (self.tool != "paint" or self.ramp is None or not self.paint_live()
                or self._filt_backup is not None or self.rgbs is None):
            return
        if self._ramp_backup is None and not self.ramp_preview_start():
            return
        self._ramp_paused = False
        self._ramp_retarget()
        self.ramp.skip_cells &= set(self._ramp_targets)
        self.ramp_preview_set(self.ramp.out_colours())
        self.ramp.update_buttons()
        self.ramp.draw_strip()

    def _ramp_copy_busy(self):
        """Copy ramp (Paint) is on: palette edits wait until it's finished."""
        r = self.ramp if self.tool == "paint" else None
        if r is not None and getattr(r, "copy", None):
            self.status_var.set("Copy ramp is on - press Copy ramp again to finish first.")
            return True
        return False

    def _ramp_sel_changed(self):
        if self.tool != "paint" or not self.paint_live():
            return
        if self._ramp_backup is None and not self._ramp_paused:
            return
        if self._ramp_sel_after is not None:
            self.root.after_cancel(self._ramp_sel_after)
        self._ramp_sel_after = self.root.after(30, self._ramp_sel_run)

    def _ramp_sel_run(self):
        self._ramp_sel_after = None
        if self._ramp_backup is not None:
            self._ramp_restore_base()
        self._ramp_resume()

    def _ramp_end(self):
        self._ramp_backup = None
        self._ramp_targets = []
        if self.ramp is not None:
            self.ramp.update_buttons()
        self._refresh_history()

    def ramp_cancel(self):
        if self._ramp_backup is None:
            return
        self._ramp_restore_base()
        self._ramp_end()
        self.status_var.set("Ramp preview cleared.")
        self.recompute()

    def ramp_apply(self, colours, node_rgbs):
        if self._ramp_backup is None:
            return
        b = self._ramp_backup
        before = b[0]
        tg = list(self._ramp_targets)
        plan = getattr(self, "_ramp_plan", None)
        lk = self.locked
        painted = [i for i in tg if i not in lk]
        n = len(painted)
        if plan is not None and plan["perm"]:
            # Push: redo it for real so COLORMAP edits / locks follow their
            # colours (the preview only moved the strip)
            cols = [self.rgbs[i] for i in painted]
            self.rgbs, self.labs, self.pairs = b[0], b[1], b[2]
            self.deleted = set(b[3])
            self.cm = self._ramp_cm.copy()
            self._ensure_len(len(plan["base"]))
            self._permute(plan["perm"])
            self._write_cells(painted, cols)
            self.cm_changed()
        self._ramp_end()
        mode = plan["mode"] if plan is not None else "slide"
        if mode in ("slide", "push"):          # the selection = the painted cells
            self.selection = (set(plan["sel"] if plan else self.selection) - lk) | set(
                plan["ext"] if plan else [])
        self._ramp_plan = None
        if self.rgbs == before:
            self.status_var.set("The cells already hold that ramp - nothing changed.")
            self.recompute()
            return
        self._paint_ramps += 1
        self._ramp_paused = True          # live preview resumes on the next selection
        self.status_var.set("Ramp applied to %d cells (%s) - Snapshot in the Paint tools "
                            "records it." % (n, " > ".join(hex_of(c) for c in node_rgbs)))
        self.recompute()

    def set_cells_colour(self, indices, rgb, what="Set colour"):
        """Write one colour into palette cells (blank or filled)."""
        if self._ramp_copy_busy():
            return
        if self.rgbs is None or self._preview_busy_msg():
            return
        if self.tool != "paint":
            self.status_var.set("Palette colours can only be changed in the Paint tools "
                                "(pal0 mode).")
            return
        want = set(indices)
        indices = sorted(set(self.editable(want)))
        if not indices:
            if want:
                self.status_var.set("Those cells are locked (Colour lock).")
            return
        rgb = tuple(rgb)
        new = list(self.rgbs)
        for i in indices:
            new[i] = rgb
        if new == self.rgbs:
            self.status_var.set("Those cells already hold %s." % hex_of(rgb))
            return
        self.rgbs = new
        self.labs, self.pairs = update_pairs(new, self.labs, self.pairs, indices)
        self.deleted -= set(indices)
        self.cm.invalidate(indices)
        self.cm_changed()
        if what == "Fill" or len(indices) > 1:
            self._paint_fills += 1
        else:
            self._paint_cells.update(indices)
        self.status_var.set("%s %d cell(s) with %s - Snapshot in the Paint tools records it."
                            % ("Filled" if len(indices) > 1 else "Set", len(indices),
                               hex_of(rgb)))
        self.recompute()

    # ---------------------------------------------------------- Paint session
    def _paint_reset(self):
        self._paint_start = (self.rgbs, self.labs, self.pairs, set(self.deleted),
                             self.cm.copy())
        self._paint_ramps = 0
        self._paint_fills = 0
        self._paint_filters = 0
        self._paint_cuts = 0
        self._paint_pastes = 0
        self._paint_clears = 0
        self._paint_seledits = 0
        self._paint_cells = set()
        self._pu_reset()

    # ---------------------------------------------------------- Paint undo / redo
    # One list per Paint session mixing ramp edits (from the Paint window) and
    # palette edits. Palette edits are noticed in recompute(): whenever the
    # committed palette (no preview showing) differs from the last one seen,
    # the old one becomes an undo step. Snapshot / history jumps drop the
    # palette steps (Back covers them then); ramp steps stay while Paint is open.
    PU_MAX = 50

    def _pu_stacks(self):
        if not hasattr(self, "_pundo"):
            self._pundo, self._predo = [], []
            self._pu_applying = False
        return self._pundo, self._predo

    def _pu_snap(self):
        return (self.rgbs, self.labs, self.pairs, set(self.deleted), self.cm.copy())

    def _pu_reset(self):
        u, r = self._pu_stacks()
        u[:] = [x for x in u if x["kind"] == "ramp"]
        r[:] = [x for x in r if x["kind"] == "ramp"]
        if self.rgbs is not None:
            self._pu_state = self._pu_snap()

    def _pu_push(self, step):
        u, r = self._pu_stacks()
        u.append(step)
        del u[:-self.PU_MAX]
        r[:] = []

    def _pu_watch(self):
        """recompute() hook: record a palette undo step when the palette changed."""
        if (self.tool != "paint" or self.rgbs is None or self._ramp_backup is not None
                or self._filt_backup is not None or getattr(self, "_pu_applying", False)):
            return
        prev = getattr(self, "_pu_state", None)
        if prev is None:
            self._pu_state = self._pu_snap()
            return
        if self.rgbs == prev[0] and self.deleted == prev[3]:
            return
        import time
        now = time.time()
        a, b = prev[0], self.rgbs
        key = (frozenset(i for i in range(max(len(a), len(b)))
                         if (a[i] if i < len(a) else None) != (b[i] if i < len(b) else None))
               if self.deleted == prev[3] else None)
        u, _r = self._pu_stacks()
        top = u[-1] if u else None
        fill = getattr(self, "_fill_live", None)
        if (top is not None and top["kind"] == "pal" and key is not None and len(key) == 1
                and top.get("key") == key and now - top["t"] < 1.5):
            top["t"] = now                     # picker on one cell: one step per session
            self._pu_stacks()[1][:] = []
        elif fill and top is not None and top["kind"] == "pal" and top.get("fill") == fill:
            top["t"] = now                     # Fill cells: one step per fill
            self._pu_stacks()[1][:] = []
        else:
            self._pu_push({"kind": "pal", "state": prev, "key": key, "t": now,
                           "fill": fill})
        self._pu_state = self._pu_snap()

    def _pu_ramp(self, old, new, copying):
        """Paint window: the ramp changed (one finished edit)."""
        import time
        now = time.time()
        u, _r = self._pu_stacks()
        top = u[-1] if u else None
        same_shape = (len(old["nodes"]) == len(new["nodes"])
                      and all(abs(x["pos"] - y["pos"]) < 1e-9
                              for x, y in zip(old["nodes"], new["nodes"]))
                      and all(old[k] == new[k] for k in ("space", "ease", "strength",
                                                          "ease_scope")))
        if top is not None and top["kind"] == "ramp" and (
                (copying and top.get("copy")) or
                (same_shape and top.get("colour") and now - top["t"] < 1.0)):
            top["t"] = now                     # one Copy ramp / one colour drag = one step
            self._pu_stacks()[1][:] = []
            return
        self._pu_push({"kind": "ramp", "state": old, "t": now, "copy": copying,
                       "colour": same_shape})

    def paint_undo(self, redo=False):
        """Ctrl+Z / Ctrl+Y while Paint is open. False = nothing to do here."""
        r = self.ramp
        if self.tool != "paint" or r is None:
            return False
        u, rd = self._pu_stacks()
        src, dst = (rd, u) if redo else (u, rd)
        if not src:
            return False
        if getattr(r, "copy", None):
            self.status_var.set("Copy ramp is on - press Copy ramp again to finish first.")
            return True
        step = src[-1]
        word = "Redo" if redo else "Undo"
        if step["kind"] == "ramp":
            src.pop()
            cur = json.loads(json.dumps(r.st))
            dst.append({"kind": "ramp", "state": cur, "t": 0, "copy": False,
                        "colour": False})
            self._pu_applying = True
            try:
                r.set_state(json.loads(json.dumps(step["state"])))
            finally:
                self._pu_applying = False
            r.ru_sync()
            self.status_var.set("%s: ramp edit (%d left)." % (word, len(src)))
            return True
        if self._filt_backup is not None:
            self.status_var.set("Filter preview is open - Apply or Cancel it first.")
            return True
        src.pop()
        if self._ramp_backup is not None:          # take the live preview off first
            self._ramp_restore_base()
            self._ramp_backup = None
            self._ramp_targets = []
        dst.append({"kind": "pal", "state": self._pu_snap(), "key": None, "t": 0})
        rgbs, labs, pairs, d, cm = step["state"]
        self.rgbs, self.labs, self.pairs = rgbs, labs, pairs
        self.deleted, self.cm = set(d), cm.copy()
        self.cm_changed()
        self._pu_state = self._pu_snap()
        self._refresh_history()
        if self.filter_win is not None:
            self.filter_win.refresh()
        self.status_var.set("%s: palette edit (%d left)%s." % (
            word, len(src), "" if self.paint_pending() else " - no pending edits"))
        self.recompute()
        if self.paint_live():
            self._ramp_paused = True
            self._ramp_sel_changed()               # live preview comes back
        r.update_buttons()
        r.refresh()
        return True

    def paint_pending(self):
        """Real (applied) paint edits - a live ramp preview doesn't count."""
        if self.tool != "paint" or self._paint_start is None:
            return False
        base = self._ramp_backup[0] if self._ramp_backup is not None else self.rgbs
        return base != self._paint_start[0]

    def paint_summary(self):
        parts = []
        for n, one in ((self._paint_ramps, "ramp"), (self._paint_fills, "fill"),
                       (self._paint_filters, "filter"), (self._paint_cuts, "cut"),
                       (self._paint_pastes, "paste"),
                       (getattr(self, "_paint_clears", 0), "clear all"),
                       (getattr(self, "_paint_seledits", 0), "selection edit"),
                       (len(self._paint_cells), "cell")):
            if n:
                parts.append("%d %s%s" % (n, one, "" if n == 1 else "s"))
        return ", ".join(parts) or "edits"

    def paint_snapshot(self):
        if self.ramp is not None and getattr(self.ramp, "copy", None):
            self.ramp.copy_off()
        if self._preview_busy_msg():
            return
        if not self.paint_pending():
            self.status_var.set("No paint edits to snapshot.")
            return
        self._push_history("Painted: %s - %d colours" % (
            self.paint_summary(), sum(1 for e in self.pal if e is not None)))
        self._paint_reset()
        self._refresh_history()                 # Back is usable again (nothing pending)
        self.status_var.set("Paint edits recorded as #%d (Back undoes them)." % self.hist_pos)
        self.recompute()

    def paint_revert(self):
        if self._ramp_copy_busy():
            return
        if self._paint_start is None or self._preview_busy_msg():
            return
        self.rgbs, self.labs, self.pairs, d, cm = self._paint_start
        self.deleted, self.cm = set(d), cm.copy()
        self.cm_changed()
        self._paint_ramps = 0
        self._paint_fills = 0
        self._paint_filters = 0
        self._paint_cuts = 0
        self._paint_pastes = 0
        self._paint_clears = 0
        self._paint_seledits = 0
        self._paint_cells = set()
        self._refresh_history()
        self.status_var.set("Paint edits reverted.")
        if self.filter_win is not None:
            self.filter_win.refresh()
        self.recompute()

    def paint_clear_cells(self):
        """Paint's Clear cells: empty the selected cells (held cells below the
        red line too); with no selection, every palette cell (held cells
        stay). Locked cells are always skipped. Pending until Snapshot."""
        if self._ramp_copy_busy():
            return
        if self.tool != "paint" or self.rgbs is None or self._preview_busy_msg():
            return
        sel = sorted(self.selection)
        pool = sel if sel else range(ENTRIES)
        idx = [i for i in pool if i < len(self.rgbs) and self.rgbs[i] is not None
               and i not in self.locked]
        if not idx:
            self.status_var.set("Nothing to clear%s." % (
                " in the selection" if sel else " - the palette is already empty") +
                (" (locked cells stay)" if self.locked else ""))
            return
        self._write_cells(idx, [None] * len(idx))
        self._paint_clears += 1
        self.status_var.set("Cleared %d %scell(s) - Snapshot records it, Revert undoes it."
                            % (len(idx), "selected " if sel else ""))
        self.recompute()
        if sel:                  # keep the selection: the live ramp preview fills it
            self._ramp_resume()

    # ---------------------------------------------------------- Ramp steps: Edit Selection
    def _paint_sel_ok(self):
        if self._ramp_copy_busy():
            return False
        if self.tool != "paint" or self.rgbs is None or self._preview_busy_msg():
            return False
        return True

    def _paint_sel_done(self, txt, resume=True):
        self._paint_seledits = getattr(self, "_paint_seledits", 0) + 1
        msg = txt + " - Snapshot records it, Revert undoes it."
        self.status_var.set(msg)
        self._reorder_sync_scope()
        self.recompute()
        self._filter_sel_changed()
        self._ctool_sel_changed()
        if resume:
            self._ramp_resume()
        else:
            self._ramp_paused = True      # written colours stay; preview on next change
        self.root.after(60, lambda: self.status_var.set(msg))
        if self.ramp is not None:
            self.ramp.draw_strip()

    def paint_sel_add(self):
        """Add the next index after the highest selected cell to the
        selection. If it holds a colour, the colours from there on are pushed
        up into the nearest empty cell after it (locked cells stay put; past
        the end of the palette they go below the red line)."""
        if not self._paint_sel_ok():
            return
        sel = sorted(self.selection)
        if not sel:
            self.status_var.set("Select the ramp's cells first.")
            return
        t = max(sel) + 1
        while t < ENTRIES and t in self.locked:
            t += 1
        if t >= ENTRIES:
            self.status_var.set("The selection already reaches the end of the palette.")
            return
        if self.rgbs[t] is None:
            self.selection = set(sel) | {t}
            self._paint_sel_done("Cell %d added to the selection" % t)
            return
        r = self.rgbs
        hole = next((i for i in range(t + 1, ENTRIES) if r[i] is None
                     and i not in self.locked), None)
        if hole is None:                       # no room: spill below the red line
            beyond = [i for i in range(ENTRIES, len(r)) if r[i] is None]
            if not beyond:
                self._ensure_len(len(r) + 1)
                r = self.rgbs
                beyond = [i for i in range(ENTRIES, len(r)) if r[i] is None]
            hole = beyond[0]
        L = len(self.rgbs)
        perm = list(range(t)) + [hole] + [i for i in range(t, L) if i != hole]
        newpos = self._permute(perm)
        self.selection = {i for i in self.selection} | {newpos[hole]}
        self._paint_sel_done("Cell %d added to the selection - the colours after it moved "
                             "up one" % newpos[hole])

    def paint_sel_remove(self):
        """Drop the highest selected index from the selection (nothing moves)."""
        if not self._paint_sel_ok():
            return
        if not self.selection:
            self.status_var.set("Nothing selected.")
            return
        top = max(self.selection)
        self.selection = set(self.selection) - {top}
        if self.ramp is not None:
            self.ramp.skip_cells.discard(top)
        self._paint_sel_done("Cell %d removed from the selection" % top)

    def paint_sel_align(self, resume=True, what=None):
        """Apply the X marks and pack the selection: X cells leave the
        selection; the rest move into one run from the lowest selected index,
        X cells that hold colours go straight after it, and everything else
        in that stretch is pushed along in order (nothing lost; locked cells
        stay put; nothing past the old highest selected index moves)."""
        if not self._paint_sel_ok():
            return
        sel = sorted(i for i in self.selection if i not in self.locked)
        if not sel:
            self.status_var.set("Select the ramp's cells first.")
            return
        marks = set(self.ramp.skip_cells) if self.ramp is not None else set()
        keep = [i for i in sel if i not in marks]
        xcol = [i for i in sel if i in marks and self.rgbs[i] is not None]
        lo, hi = sel[0], sel[-1]
        moved = set(keep) | set(xcol)
        order = keep + xcol + [i for i in range(lo, hi + 1) if i not in moved]
        perm = list(range(lo)) + order
        newpos = self._permute(perm)
        self.selection = {newpos[i] for i in keep} | {i for i in self.selection
                                                      if i in self.locked}
        if self.ramp is not None:
            self.ramp.skip_cells = set()
        nx = len(sel) - len(keep)
        txt = what or "Aligned: %d cell%s in one run from %d%s" % (
            len(keep), "" if len(keep) == 1 else "s", lo,
            (", %d X cell%s dropped" % (nx, "" if nx == 1 else "s")) if nx else "")
        self._paint_sel_done(txt, resume=resume)

    def paint_clear_all(self):
        """Empty every palette cell (held cells below the red line stay)."""
        if self._ramp_copy_busy():
            return
        if self.tool != "paint" or self.rgbs is None or self._preview_busy_msg():
            return
        idx = [i for i in range(ENTRIES) if self.rgbs[i] is not None
               and i not in self.locked]
        if not idx:
            self.status_var.set("The palette is already empty (locked cells stay).")
            return
        self._write_cells(idx, [None] * len(idx))
        self.selection = set()
        self._paint_clears += 1
        self.status_var.set("Cleared %d cell(s) - Snapshot records it, Revert undoes it."
                            % len(idx))
        self.recompute()

    def paint_cell_live(self, idx, rgb):
        """Picker on a single cell (Paint double-click): live pending edit."""
        if self.tool != "paint" or self.rgbs is None or self._preview_busy_msg():
            return
        if idx in self.locked:
            self.status_var.set("Index %d is locked (Colour lock)." % idx)
            return
        rgb = tuple(rgb)
        if self.rgbs[idx] == rgb:
            return
        new = list(self.rgbs)
        new[idx] = rgb
        self.rgbs = new
        self.labs, self.pairs = update_pairs(new, self.labs, self.pairs, [idx])
        self.deleted.discard(idx)
        self.cm.invalidate([idx])
        self.cm_changed()
        self._paint_cells.add(idx)
        self.recompute()

    def paint_fill_live(self, cells, rgb):
        """Paint Fill cells: one colour into all these cells, live (pending
        edit; one Paint undo step per fill)."""
        if self.tool != "paint" or self.rgbs is None or not getattr(self, "_fill_live", None):
            return
        if self._preview_busy_msg():
            return
        cells = [i for i in self.editable(cells) if i < len(self.rgbs)]
        rgb = tuple(rgb)
        if not cells or all(self.rgbs[i] == rgb for i in cells):
            return
        new = list(self.rgbs)
        for i in cells:
            new[i] = rgb
        self.rgbs = new
        self.labs, self.pairs = update_pairs(new, self.labs, self.pairs, cells)
        self.deleted -= set(cells)
        self.cm.invalidate([i for i in cells if i < ENTRIES])
        self.cm_changed()
        if not getattr(self, "_fill_wrote", False):
            self._paint_fills += 1
            self._fill_wrote = True
        self.recompute()

    # ---------------------------------------------------------- clipboard
    # Ctrl+C copy (anywhere), Ctrl+X cut, Ctrl+V insert paste, Ctrl+Shift+V
    # paste over (Paint; Move: cut + insert only). One gap-free block,
    # index order, no sorting.
    def clip_text(self):
        n = len(self.clip)
        return "Clipboard: %d colour%s" % (n, "" if n == 1 else "s") if n \
            else "Clipboard: empty"

    def _clip_selected(self, editable=False):
        sel = self.editable(self.selection) if editable else self.selection
        return sorted(i for i in sel if self.rgbs[i] is not None)

    def _clip_busy(self):
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return True
        return self._preview_busy_msg()

    def clip_copy(self):
        if self._clip_busy():
            return False
        idx = self._clip_selected()
        if not idx:
            self.status_var.set("Select colours to copy first.")
            return False
        self.clip_set([self.rgbs[i] for i in idx])
        return True

    def clip_set(self, colours, src=None):
        """Put colours on cleanpal's clipboard (and the system one as hex)."""
        self.clip = [tuple(c) for c in colours]
        self._clip_sys = "\n".join(hex_of(c) for c in self.clip)
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self._clip_sys)
        except self.tk.TclError:
            pass
        self.status_var.set("Copied %d colour(s)%s." % (len(self.clip),
                                                        (" from " + src) if src else ""))
        self._tool_refresh_win()

    def _clip_source(self):
        """Colours to paste: cleanpal's clipboard, or a hex list someone put on
        the system clipboard since our last copy."""
        try:
            sys_text = self.root.clipboard_get()
        except self.tk.TclError:
            sys_text = None
        if sys_text and sys_text != getattr(self, "_clip_sys", None):
            cols = parse_colour_list(sys_text)
            if cols:
                return [tuple(c) for c in cols], "system clipboard"
        return list(self.clip), "clipboard"

    def _clip_target(self):
        """First selected cell, else the cell under the mouse, else None."""
        if self.selection:
            return min(self.selection)
        slot = self.hover_slot
        ent = self._view_entry(slot) if slot is not None else None
        return ent[0] if ent else None

    def _clip_tool_ok(self, what):
        if self.tool in ("paint", "move"):
            return True
        self.status_var.set("%s is in the Paint and Move tools." % what)
        return False

    # ---------------------------------------------------------- strip writes
    def _write_cells(self, idx, cols):
        """Write colours into strip cells; cells past the end grow the strip.
        Locked cells are never written."""
        idx = list(idx)
        if self.locked:
            keep = [(i, c) for i, c in zip(idx, cols) if i not in self.locked]
            idx = [i for i, _c in keep]
            cols = [c for _i, c in keep]
        if not idx:
            return
        self._ensure_len(max(idx) + 1)
        new = list(self.rgbs)
        for i, c in zip(idx, cols):
            new[i] = tuple(c) if c is not None else None
        self.rgbs = new
        self.labs, self.pairs = update_pairs(new, self.labs, self.pairs, idx)
        self.deleted -= set(idx)
        self.cm.invalidate([i for i in idx if i < ENTRIES])
        self.cm_changed()

    def _unique_new(self, cols):
        """cols without exact duplicates: colours already anywhere in the
        strip (palette or below the line) or earlier in cols. -> (new, skipped)
        With "Skip identical colours" (Clipboard panel) unticked nothing is
        skipped; the number of identical colours kept goes to _dup_kept."""
        have = {tuple(c) for c in (self.rgbs or []) if c is not None}
        out, seen = [], set()
        dup = 0
        for c in cols:
            c = tuple(c)
            if c in have or c in seen:
                dup += 1
                if self.s.get("skip_identical", True):
                    continue
            seen.add(c)
            out.append(c)
        if self.s.get("skip_identical", True):
            self._dup_kept = 0
            return out, dup
        self._dup_kept = dup
        return out, 0

    def _dup_note(self, skipped):
        """' (3 identical skipped)' / ' (3 identical included)' / ''."""
        if skipped:
            return " (%d identical skipped)" % skipped
        kept = getattr(self, "_dup_kept", 0)
        return (" (%d identical included)" % kept) if kept else ""

    def _insert_block(self, t, cols):
        """Insert colours in front of cell t. Empty cells after t absorb the
        push, then the nearest ones before t (the colours between shift left -
        so cut + insert works as a move). If there aren't enough the strip
        grows and colours slide past the red line - an insert never fails.
        Returns the cells the colours went into."""
        n = len(cols)
        r = self.rgbs
        # same side of the red line first: empties after t, then the nearest
        # holes before t; only then spill past the line (growing if needed)
        side_end = ENTRIES if t < ENTRIES else len(r)
        side_start = 0 if t < ENTRIES else ENTRIES
        lk = self.locked
        after = [i for i in range(t, side_end) if r[i] is None and i not in lk]
        before = [i for i in range(t - 1, side_start - 1, -1) if r[i] is None
                  and i not in lk]
        use_after = after[:n]
        use_before = sorted(before[:n - len(use_after)])
        need = n - len(use_after) - len(use_before)
        if need > 0:                                    # past the red line
            beyond = [i for i in range(side_end, len(r)) if r[i] is None]
            if len(beyond) < need:
                self._ensure_len(len(r) + need - len(beyond))
                r = self.rgbs
                beyond = [i for i in range(side_end, len(r)) if r[i] is None]
            use_after += beyond[:need]
        ub, ua = set(use_before), set(use_after)
        L = len(self.rgbs)
        perm = ([i for i in range(t) if i not in ub] + use_before + use_after
                + [i for i in range(t, L) if i not in ua])
        newpos = self._permute(perm)
        # where the chosen empty cells ended up (locked cells stay put, so
        # this need not be one run)
        tg = sorted(newpos[o] for o in use_before + use_after)
        self._write_cells(tg, cols)
        return tg

    @staticmethod
    def _held_note(cells):
        h = sum(1 for i in cells if i >= ENTRIES)
        return (" (%d below the red line)" % h) if h else ""

    def clip_cut(self):
        if self._ramp_copy_busy():
            return
        if self._clip_busy() or not self._clip_tool_ok("Cut"):
            return
        idx = self._clip_selected(editable=True)
        if not idx:
            if self._clip_selected():
                self.status_var.set("The selected cells are locked (Colour lock).")
            return
        self.clip_set([self.rgbs[i] for i in idx])
        n = len(idx)
        if self.tool == "paint":
            self._write_cells(idx, [None] * n)
            self.selection = set()
            self._paint_cuts += 1
            self.status_var.set("Cut %d colour(s) - the cells are now empty. Snapshot "
                                "records it." % n)
        else:                                  # Move: take out, the whole strip closes up
            self._move_push_undo()
            cut = set(idx)
            L = len(self.rgbs)
            newpos = self._permute([i for i in range(L) if i not in cut] + idx)
            self._write_cells([newpos[o] for o in idx], [None] * n)
            self.selection = set()
            self.status_var.set("Cut %d colour(s) - the rest closed up; Ctrl+V "
                                "inserts them somewhere else." % n)
        self.recompute()

    def clip_paste(self, insert=False):
        if self._ramp_copy_busy():
            return
        if self._clip_busy():
            return
        if self.tool not in ("paint", "move"):
            # offer to open Paint (it does the clean-snapshot check itself)
            if self.cmap_mode():
                self.status_var.set("Paste works in the Paint tools (pal0 mode).")
                return
            k = self._ask_buttons(
                "Paste needs the Paint tools",
                "Pasting colours into the working palette happens in the Paint tools. "
                "Open them now and paste?",
                [("open", "Open Paint and paste"), ("cancel", "Cancel")])
            if k != "open" or not self.open_tool("paint"):
                return
            if self._preview_busy_msg():          # Paint opens with its live preview
                return
        if self.tool == "move" and not insert:
            self.status_var.set("Overwrite paste is in the Paint tools - use Ctrl+V "
                                "to insert.")
            return
        cols, src = self._clip_source()
        if not cols:
            self.status_var.set("The clipboard is empty - copy some colours first.")
            return
        t = self._clip_target()
        if t is None:
            self.status_var.set("Select a cell (or point at one) to paste at.")
            return
        skipped = 0
        self._dup_kept = 0
        if insert:                              # inserts skip identical colours (option)
            cols, skipped = self._unique_new(cols)
            if not cols:
                self.status_var.set("Nothing inserted - every clipboard colour is already "
                                    "in the palette%s. Untick Skip identical colours "
                                    "(Clipboard) to insert them anyway." % self._dup_note(skipped))
                return
        n = len(cols)
        if self.tool == "move":
            self._move_push_undo()
        if insert:
            tg = self._insert_block(t, cols)
        else:                                   # over the cells from t; runs past the line
            tg = []                             # (locked cells are stepped over)
            i = t
            while len(tg) < n:
                if i not in self.locked:
                    tg.append(i)
                i += 1
            self._write_cells(tg, cols)
        self.selection = set(tg)
        if self.tool == "paint":
            self._paint_pastes += 1
        self.status_var.set("%s %d colour(s) at index %d%s (from the %s)%s%s." % (
            "Inserted" if insert else "Pasted", n, tg[0], self._held_note(tg), src,
            self._dup_note(skipped) if insert else "",
            " - Snapshot records it" if self.tool == "paint" else ""))
        self.recompute()

    def _on_clip_key(self, ev, what):
        if self._typing(ev) or self.rgbs is None:
            return
        if what == "copy":
            self.clip_copy()
        elif what == "cut":
            self.clip_cut()
        else:
            self.clip_paste(insert=(what == "insert"))
        return "break"

    def _bind_clip_keys(self, w):
        for seq, what in (("<Control-c>", "copy"), ("<Control-x>", "cut"),
                          ("<Control-v>", "insert"), ("<Control-V>", "paste"),
                          ("<Control-Shift-V>", "paste"), ("<Control-Shift-v>", "paste")):
            w.bind(seq, lambda e, k=what: self._on_clip_key(e, k))

    # ---------------------------------------------------------- Palette Browser cells
    def _external_edit_ok(self):
        """Can an outside window (Palette Browser) change palette cells right now?
        No tool open = a direct history entry; Paint = a pending paint edit;
        Cull / Move / Reorder need the palette to stay put, so they refuse."""
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return False
        if self.cmap_mode():
            self.status_var.set("Switch to pal0 mode to change palette cells.")
            return False
        if self.tool in ("cull", "move", "reorder"):
            self.status_var.set("Close the %s tools first - they need the palette to stay "
                                "put." % TOOL_NAME[self.tool])
            return False
        return not self._preview_busy_msg()     # (pauses Paint's live ramp preview)

    def pack_cells(self, scope=None):
        """Pack colours toward the start within the scope cells only (the
        selection; None / empty = the whole palette). Unselected cells never
        move and nothing moves into them; locked cells stay put; below the red
        line is untouched. -> True if anything moved."""
        r = self.rgbs
        span = sorted(i for i in (scope or range(ENTRIES))
                      if i < ENTRIES and i < len(r) and i not in self.locked)
        filled = [i for i in span if r[i] is not None]
        empties = [i for i in span if r[i] is None]
        perm = list(range(len(r)))
        for pos, src in zip(span, filled + empties):
            perm[pos] = src
        if perm == list(range(len(r))):
            return False
        self._permute(perm)
        return True

    def remove_unused(self, cells, below=False, pack=False, scope=None, src="unused"):
        """Lost colours > Unused: take palette cells out of pal0 - emptied, or
        moved below the red line (below=True); then (pack) close the gaps
        within the scope only. Locked cells are never touched. One history
        entry (a Paint edit while Paint is open). -> status message."""
        if not self._external_edit_ok():
            return self.status_var.get()
        if self.ctool is not None:
            return "Apply or Revert the %s tool first." % CTOOL_NAME[self.ctool]
        r = self.rgbs
        cells = sorted(i for i in cells if i < ENTRIES and i < len(r) and
                       i not in self.locked and r[i] is not None)
        if not cells:
            return "Nothing to remove."
        scope = sorted(i for i in (scope or []) if i < ENTRIES)
        n = len(cells)
        if below:
            held = [i for i in range(ENTRIES, len(r)) if r[i] is None]
            if len(held) < n:
                self._ensure_len(len(r) + n - len(held))
                r = self.rgbs
                held = [i for i in range(ENTRIES, len(r)) if r[i] is None]
            perm = list(range(len(r)))
            for c, e in zip(cells, held):
                perm[c], perm[e] = e, c
            self._permute(perm)
        else:
            self._write_cells(cells, [None] * n)
        packed = self.pack_cells(scope) if pack else False
        self.cm_changed()
        what = "moved below the red line" if below else "deleted"
        text = "Removed %d %s colour%s (%s%s)" % (n, src, "" if n == 1 else "s", what,
                                                ", gaps closed" if packed else "")
        self._external_commit(scope, text, text)
        return self.status_var.get()

    def _draw_unused_marks(self):
        """Lost colours > Unused 'Show on palette': a red X on those cells."""
        marks = getattr(self, "_unused_marks", None)
        if not marks or self.rgbs is None:
            return
        cv = self.canvas
        for slot, idx, _c in self._pv_cells():
            if idx in marks:
                x, y, C = self._cell_xy(slot)
                m = C * 0.18
                w = max(2, round(C / 14))
                for col, ww in (("#000000", w + 2), ("#ff3050", w)):
                    cv.create_line(x + m, y + m, x + C - m, y + C - m, fill=col, width=ww,
                                   tags="pvmark")
                    cv.create_line(x + C - m, y + m, x + m, y + C - m, fill=col, width=ww,
                                   tags="pvmark")

    def _external_commit(self, cells, text, detail):
        self.selection = set(cells)
        if self.tool == "paint":
            self._paint_pastes += 1
            self.status_var.set(detail + " - Snapshot in the Paint tools records it.")
        else:
            self._push_history("%s - %d colours" % (
                text, sum(1 for e in self.pal if e is not None)))
            self.status_var.set(detail + " - recorded as #%d (Back undoes it)." % self.hist_pos)
        self.recompute()

    def cells_copy_from(self, cols, src):
        """Copy Cells: colours one for one into the selected cells, in index
        order. Extra colours are dropped; extra cells are left alone."""
        if self._ramp_copy_busy():
            return
        if not self._external_edit_ok():
            return
        if not cols:
            self.status_var.set("Select colours in the Palette Browser window first.")
            return
        tg = sorted(self.editable(self.selection))
        if not tg:
            self.status_var.set("Select the cells to copy into in the main grid first "
                                "(locked cells are skipped).")
            return
        k = min(len(cols), len(tg))
        cells = tg[:k]
        self._write_cells(cells, cols[:k])
        extra = []
        if len(cols) > k:
            extra.append("%d colour%s dropped" % (len(cols) - k, "" if len(cols) - k == 1
                                                   else "s"))
        if len(tg) > k:
            extra.append("%d selected cell%s left alone" % (len(tg) - k, "" if len(tg) - k == 1
                                                            else "s"))
        detail = "Copied %d colour%s from %s into %d of %d selected cells%s%s" % (
            k, "" if k == 1 else "s", src, k, len(tg), self._held_note(cells),
            (" (" + ", ".join(extra) + ")") if extra else "")
        self._external_commit(cells, "Copied %d cells from %s" % (k, src), detail)

    def cells_insert_from(self, cols, src):
        """Insert Cells: colours inserted in front of the first selected cell,
        pushing the rest along (never fails - the strip grows if needed)."""
        if self._ramp_copy_busy():
            return
        if not self._external_edit_ok():
            return
        if not cols:
            self.status_var.set("Select colours in the Palette Browser window first.")
            return
        if not self.selection:
            self.status_var.set("Select a cell in the main grid to insert in front of.")
            return
        cols, skipped = self._unique_new(cols)
        dup = self._dup_note(skipped)
        if not cols:
            self.status_var.set("Nothing inserted - those colours are all in the palette "
                                "already%s. Untick Skip identical colours (Clipboard) to "
                                "insert them anyway." % dup)
            return
        tg = self._insert_block(min(self.selection), cols)
        detail = "Inserted %d colour%s from %s at index %d%s%s" % (
            len(cols), "" if len(cols) == 1 else "s", src, tg[0], self._held_note(tg), dup)
        self._external_commit(tg, "Inserted %d cells from %s" % (len(cols), src), detail)

    # ---------------------------------------------------------- Palette Browser
    def open_picked(self):
        if self.picked is not None:
            self.picked.win.deiconify()
            self.picked.win.lift()
            return self.picked
        from .gui_picked_colours import PickedColoursWin
        self.picked = PickedColoursWin(self)
        return self.picked

    def open_analyser(self):
        if self.analyser is not None:
            self.analyser.lift()
            return self.analyser
        from .gui_analyser import AnalyserWindow
        self.analyser = AnalyserWindow(self)
        return self.analyser

    def open_playpals(self):
        if self.playpals is not None:
            self.playpals.win.deiconify()
            self.playpals.win.lift()
            return self.playpals
        from .gui_playpals_tool import PlaypalsWindow
        self.playpals = PlaypalsWindow(self)
        return self.playpals

    # ---------------------------------------------------------- Paint filters
    def filter_open(self):
        """Paint's Filters... button: the filters live in the Adjust tools now."""
        if self._ramp_copy_busy():
            return
        self.open_tool("adjust")

    def _filter_base(self):
        """(rgbs, labs, pairs, deleted, cm) the filter reads from: the
        pre-preview palette while previewing, else the working palette."""
        if self._filt_backup is not None:
            return self._filt_backup
        return (self.rgbs, self.labs, self.pairs, self.deleted, self.cm)

    def _filter_ctx(self):
        w = self.tool_win if self.tool == "paint" else None
        return {"ramp": w.st if w is not None else None,
                "fill": tuple(w.fill_rgb) if w is not None else None}

    def filter_compute(self):
        """(targets, before colours, after colours) for the current selection."""
        if self.rgbs is None or self.filter_win is None:
            return [], [], []
        base = self._filter_base()[0]
        targets = sorted(i for i in self.selection if base[i] is not None
                         and i not in self.locked)
        before = [base[i] for i in targets]
        name, params = self.filter_win.settings()
        return targets, before, apply_filter(name, params, before, self._filter_ctx())

    def filter_preview_start(self):
        if self.rgbs is None or self.tool != "paint":
            return False
        if self._filt_backup is not None:
            return True
        self._ramp_suspend()                    # the filter preview takes over
        self._filt_backup = (self.rgbs, self.labs, self.pairs, set(self.deleted),
                             self.cm.copy())
        self._refresh_history()
        return True

    def _filter_write(self, base, targets, after):
        new = list(base[0])
        for i, c in zip(targets, after):
            new[i] = tuple(c)
        self.rgbs = new
        self.labs, self.pairs = update_pairs(new, base[1], base[2], targets)
        self.deleted = set(base[3]) - set(targets)
        self.cm = base[4].copy()
        self.cm.invalidate(targets)
        self.cm_changed()

    def filter_preview_refresh(self):
        """Re-run the filter on the CURRENT selection from the pre-preview
        palette (so the selection can change while previewing)."""
        if self._filt_backup is None:
            return
        base = self._filt_backup
        targets, _before, after = self.filter_compute()
        self._filter_write(base, targets, after)
        name = self.filter_win.current if self.filter_win is not None else "Filter"
        self.status_var.set("Filter preview: %s on %d colours. Apply keeps it, Cancel "
                            "restores." % (name, len(targets)))
        self.recompute()

    def filter_cancel(self):
        if self._filt_backup is None:
            return
        b = self._filt_backup
        self.rgbs, self.labs, self.pairs = b[0], b[1], b[2]
        self.deleted, self.cm = set(b[3]), b[4].copy()
        self.cm_changed()
        self._filt_backup = None
        self._refresh_history()
        if self.filter_win is not None:
            self.filter_win.update_buttons()
        self.status_var.set("Filter preview cancelled.")
        self.recompute()

    def filter_apply(self):
        """Write the filter into the selection (a pending Paint edit)."""
        if self.rgbs is None or self.tool != "paint" or self.filter_win is None:
            return
        self._ramp_suspend()
        base = self._filter_base()
        before_all = base[0]
        targets, _before, after = self.filter_compute()
        if not targets:
            self.status_var.set("Select the palette colours to filter first.")
            return
        self._filter_write(base, targets, after)
        self._filt_backup = None
        self._refresh_history()
        if self.rgbs == before_all:
            self.status_var.set("The filter changes nothing on those colours.")
        else:
            self._paint_filters += 1
            self.status_var.set("%s applied to %d colours - Snapshot in the Paint tools "
                                "records it." % (self.filter_win.current, len(targets)))
        self.recompute()

    def _filter_sel_changed(self):
        if self.tool == "adjust" and self.tool_win is not None:
            self.tool_win.sel_changed()
        if self.filter_win is not None:
            self.filter_win.schedule()

    def _paint_cell_target(self):
        """Cell the picker is editing (Paint double-click), or None."""
        w = self.tool_win if self.tool == "paint" else None
        p = self.picker
        if w is None or p is None or getattr(p, "owner", None) is not w:
            return None
        return getattr(w, "cell_target", None)

    def _on_b1_double(self, ev):
        """Paint tools: double-click a cell = colour picker on that cell. The
        selection is put back to what it was before the double-click.
        Colour lock: double-click toggles the cell's lock."""
        if getattr(self, "locks_win", None) is not None and self.res is not None:
            slot = self._slot_at(ev.x, ev.y)
            if slot is not None:
                ent = self._view_entry(slot)
                self.selection = set(self._sel_before_click)
                self.lock_toggle(ent[0] if ent is not None else slot)
            return "break"
        if self.tool != "paint" or self.res is None:
            return
        slot = self._slot_at(ev.x, ev.y)
        ent = self._view_entry(slot) if slot is not None else None
        if ent is None:
            return
        if not self._paint_sel_hidden():
            self.selection = set(self._sel_before_click)
        if ent[0] in self.locked:
            self.status_var.set("Index %d is locked (Colour lock) - unlock it to edit."
                                % ent[0])
            self.recompute()
            return "break"
        if self._filt_backup is not None:
            self.status_var.set("A filter preview is open - Apply or Cancel it first.")
            self.recompute()
            return
        if self._ramp_copy_busy():
            self.recompute()
            return "break"
        self._ramp_suspend()                    # picking a single cell pauses the ramp
        self.tool_win.target_cell(ent[0])
        self.recompute()
        return "break"

    def drop_colour_on_grid(self, x_root, y_root, rgb):
        if self._ramp_copy_busy():
            return
        if self.rgbs is None:
            return
        slot = self._slot_at(x_root - self.canvas.winfo_rootx(),
                             y_root - self.canvas.winfo_rooty())
        ent = self._view_entry(slot) if slot is not None else None
        if ent is None:
            self.status_var.set("Drop onto a palette cell.")
            return
        self.set_cells_colour([ent[0]], rgb)
