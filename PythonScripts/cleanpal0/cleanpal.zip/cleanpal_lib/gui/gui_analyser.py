"""Palette Analyser window: one window, a mode dropdown (like the picker).

Modes: Missing colours (default - what the Palette Browser palettes have that the
working palette lacks), censor (the external censor analyser's plot), Hue /
lightness map, Ramps, Close colours, Greyscale, Usage (WAD / PNG folder).

Top bar options apply to every mode: Scope (whole palette / selection;
Missing colours always uses whole palettes), Live / Applied, On top.
Distances use the Cull tools' metric and units, so a closeness of 3.0
means the same thing here as Cull's tolerance."""

import math
import os
import shutil
import subprocess
import tempfile
import threading

from ..cleanpal_lib_colour import (
    dist_de2000, dist_lab, dist_rgb, hex_of, oklab, srgb_to_lab,
)
from ..cleanpal_lib_constants import DEFAULT_TOL, ENTRIES, METRIC_HOVER

MODES = ["Missing colours", "censor", "Hue / lightness map", "Ramps", "Close colours",
         "Greyscale", "Usage"]
ALL_PALS = "All browser palettes"
ILLUMINANTS = ["5500 K", "D50", "D55", "D65"]


def _fg(c):
    return "#000000" if 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2] > 140 else "#ffffff"


class _Dist:
    """Cull's metric as a function of two colours (labs cached)."""

    def __init__(self, metric):
        self.m = metric
        self.labs = {}

    def lab(self, c):
        v = self.labs.get(c)
        if v is None:
            v = self.labs[c] = srgb_to_lab(*c)
        return v

    def __call__(self, a, b):
        if self.m == "rgb":
            return dist_rgb(a, b)
        if self.m == "lab":
            return dist_lab(self.lab(a), self.lab(b))
        return dist_de2000(self.lab(a), self.lab(b))


def _lch(c):
    L, a, b = oklab(c)
    return L, math.hypot(a, b), math.degrees(math.atan2(b, a)) % 360.0


class AnalyserWindow:
    def __init__(self, app):
        from tkinter import ttk
        tk = app.tk
        self.app = app
        s = app.s
        self.ui = ui = getattr(app, "ui", 1.0)
        self.win = tk.Toplevel(app.root)
        self.win.title("cleanpal - Palette analyser")
        self.win.minsize(int(520 * ui), int(380 * ui))
        try:
            self.win.geometry(s.get("analyser_geometry")
                              or "%dx%d" % (int(900 * ui), int(680 * ui)))
        except tk.TclError:
            pass
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.columnconfigure(0, weight=1)
        self.win.rowconfigure(2, weight=1)

        m = s.get("an_mode")
        self.mode_var = tk.StringVar(value=m if m in MODES else MODES[0])
        self.scope_var = tk.StringVar(value=s.get("an_scope", "all"))
        self.live_var = tk.StringVar(value=s.get("an_live", "live"))
        self.pin_var = tk.BooleanVar(value=bool(s.get("an_pin", True)))
        self.info_var = tk.StringVar()
        self.status_var = tk.StringVar()

        top = ttk.Frame(self.win, padding=(8, 8, 8, 2))
        top.grid(row=0, column=0, sticky="ew")
        cb = ttk.Combobox(top, textvariable=self.mode_var, values=MODES, state="readonly",
                          width=18)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self._mode_changed())
        ttk.Label(top, text="Scope").pack(side="left", padx=(14, 4))
        self.scope_rbs = [ttk.Radiobutton(top, text=t, value=v, variable=self.scope_var,
                                          command=self._opt_changed)
                          for t, v in (("Whole palette", "all"), ("Selection", "sel"))]
        for rb in self.scope_rbs:
            rb.pack(side="left", padx=(0, 6))
        ttk.Checkbutton(top, text="On top", variable=self.pin_var,
                        command=self._apply_pin).pack(side="right")
        ttk.Radiobutton(top, text="Applied", value="applied", variable=self.live_var,
                        command=self._opt_changed).pack(side="right", padx=(0, 12))
        ttk.Radiobutton(top, text="Live", value="live", variable=self.live_var,
                        command=self._opt_changed).pack(side="right", padx=(0, 4))

        self.opts = ttk.Frame(self.win, padding=(8, 2, 8, 4))
        self.opts.grid(row=1, column=0, sticky="ew")
        self.body = ttk.Frame(self.win, padding=(8, 0, 8, 0))
        self.body.grid(row=2, column=0, sticky="nsew")
        self.body.columnconfigure(0, weight=1)
        self.body.rowconfigure(0, weight=1)
        bot = ttk.Frame(self.win, padding=(8, 2, 8, 8))
        bot.grid(row=3, column=0, sticky="ew")
        ef = ttk.Frame(bot)                      # analysis PNGs (was in Export)
        ef.pack(fill="x", pady=(0, 4))
        ttk.Button(ef, text="Export analysis PNGs...",
                   command=app.export_analysis).pack(side="left")
        ttk.Checkbutton(ef, text="Split per set / cluster", variable=app.split_var).pack(
            side="left", padx=(8, 0))
        ttk.Label(ef, text="identical / similar / aligned - uses Cull's settings",
                  foreground="#666").pack(side="left", padx=(8, 0))
        ttk.Label(bot, textvariable=self.info_var, font=("Consolas", 10)).pack(anchor="w")
        ttk.Label(bot, textvariable=self.status_var, foreground="#666").pack(anchor="w")

        self._apply_pin()
        self._sig = None
        self._after = None
        self._poll_after = None
        self.hits = []                 # (x0, y0, x1, y1, payload) for hover / click
        self._censor = {"proc": None, "img": None, "tk": None, "key": None, "err": ""}
        self._usage = {"src": None, "hist": {}, "todo": [], "busy": False}
        self._mode_changed()
        self._poll()

    # ---------------------------------------------------------- common
    def _apply_pin(self):
        try:
            self.win.attributes("-topmost", bool(self.pin_var.get()))
        except self.app.tk.TclError:
            pass
        self.app.s["an_pin"] = bool(self.pin_var.get())

    def _opt_changed(self):
        s = self.app.s
        s["an_scope"], s["an_live"] = self.scope_var.get(), self.live_var.get()
        self.schedule(now=True)

    def metric(self):
        return self.app.metric_var.get()

    def unit(self):
        return METRIC_HOVER.get(self.metric(), "")

    def cells(self):
        """Index-aligned 256 cells of the working palette (Live) or the
        current history entry (Applied)."""
        a = self.app
        if self.live_var.get() == "applied" and a.history:
            pal = a.history[a.hist_pos]["palette"]
        else:
            pal = a.rgbs or []
        pal = list(pal[:ENTRIES]) + [None] * max(0, ENTRIES - len(pal))
        return [tuple(c) if c is not None else None for c in pal]

    def scoped(self, whole=False):
        """[(index, colour)] in the scope."""
        cs = self.cells()
        sel = None if whole or self.scope_var.get() != "sel" else self.app.selection
        return [(i, c) for i, c in enumerate(cs) if c is not None and (sel is None or i in sel)]

    def _signature(self):
        a = self.app
        mode = self.mode_var.get()
        sel = tuple(sorted(a.selection)) if self.scope_var.get() == "sel" else None
        return (mode, tuple(self.cells()), sel, self.metric(),
                tuple(sorted(a.reserved)) if hasattr(a, "reserved") else ())

    def _poll(self):
        self._poll_after = None
        try:
            self._censor_collect()
        except Exception:  # noqa: BLE001
            pass
        try:
            if self.win.state() != "withdrawn" and self._signature() != self._sig:
                self.schedule()
        except Exception:  # noqa: BLE001 - mid-edit states: next tick
            pass
        try:
            self._poll_after = self.win.after(
                100 if self._censor.get("key") and self._censor.get("img") is None
                or "result" in self._censor else 300, self._poll)
        except self.app.tk.TclError:
            pass

    def schedule(self, now=False):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._after = self.win.after(10 if now else 250, self.redraw)

    def _mode_changed(self):
        mode = self.mode_var.get()
        self.app.s["an_mode"] = mode
        for w in self.opts.winfo_children():
            w.destroy()
        for w in self.body.winfo_children():
            w.destroy()
        for rb in self.scope_rbs:
            rb.state(["disabled"] if mode == "Missing colours" else ["!disabled"])
        self.info_var.set("")
        self.status_var.set("")
        getattr(self, "_build_" + self._key(mode))()
        self.schedule(now=True)

    @staticmethod
    def _key(mode):
        return {"Missing colours": "missing", "censor": "censor",
                "Hue / lightness map": "huemap", "Ramps": "ramps",
                "Close colours": "close", "Greyscale": "grey", "Usage": "usage"}[mode]

    def redraw(self):
        self._after = None
        self._sig = self._signature()
        try:
            getattr(self, "_draw_" + self._key(self.mode_var.get()))()
        except self.app.tk.TclError:
            pass

    def _canvas(self, row=0, col=0):
        tk = self.app.tk
        c = tk.Canvas(self.body, bg="#262626", highlightthickness=0)
        c.grid(row=row, column=col, sticky="nsew")
        c.bind("<Configure>", lambda e: self.schedule(now=True))
        c.bind("<Motion>", self._hover)
        c.bind("<Leave>", lambda e: self.info_var.set(""))
        c.bind("<Button-1>", self._click)
        self.cv = c
        return c

    def _closeness(self, key):
        """A Closeness spinbox in the options bar (Cull's units)."""
        from tkinter import ttk
        tk = self.app.tk
        m = self.metric()
        v = self.app.s.get("an_close_%s_%s" % (key, m))
        if not isinstance(v, (int, float)):
            v = self.app.tol.get(m, DEFAULT_TOL[m])
        var = tk.StringVar(value="%g" % v)
        ttk.Label(self.opts, text="Closeness").pack(side="left")
        sp = ttk.Spinbox(self.opts, textvariable=var, from_=0, to=100, increment=0.25,
                         width=6, command=lambda: self._close_set(key, var))
        sp.pack(side="left", padx=(4, 2))
        sp.bind("<Return>", lambda e: self._close_set(key, var))
        sp.bind("<FocusOut>", lambda e: self._close_set(key, var))
        ttk.Label(self.opts, text="%s (Cull's metric)" % self.unit(),
                  foreground="#888").pack(side="left", padx=(0, 12))
        self._close_vars = getattr(self, "_close_vars", {})
        self._close_vars[key] = var
        return var

    def _close_set(self, key, var):
        try:
            v = max(0.0, float(var.get()))
        except ValueError:
            return
        self.app.s["an_close_%s_%s" % (key, self.metric())] = v
        self.schedule(now=True)

    def close_val(self, key):
        try:
            return max(0.0, float(self._close_vars[key].get()))
        except (KeyError, ValueError):
            return DEFAULT_TOL[self.metric()]

    def _hover(self, ev):
        for x0, y0, x1, y1, p in self.hits:
            if x0 <= ev.x < x1 and y0 <= ev.y < y1:
                self.info_var.set(p.get("text", ""))
                if "near" in p and hasattr(self, "mine_cv"):
                    self._mine_mark(p["near"])
                return
        self.info_var.set("")

    def _click(self, ev):
        for x0, y0, x1, y1, p in self.hits:
            if x0 <= ev.x < x1 and y0 <= ev.y < y1:
                cells = p.get("select")
                if cells:
                    a = self.app
                    if ev.state & 0x0001:
                        a.selection |= set(cells)
                    else:
                        a.selection = set(cells)
                    a.recompute()
                    a.status_var.set("Analyser: selected cell%s %s." % (
                        "s" if len(cells) > 1 else "", ", ".join(str(c) for c in cells)))
                if p.get("cb"):
                    p["cb"]()
                return

    def _msg(self, text):
        c = self.cv
        c.delete("all")
        self.hits = []
        c.create_text(16, 16, anchor="nw", text=text, fill="#bbbbbb",
                      width=max(200, c.winfo_width() - 32))

    def _swatch(self, c, x, y, s, col, mark=None, empty=False):
        """One cell: colour square (or an empty slot), optional ● / ◢ mark."""
        if empty or col is None:
            c.create_rectangle(x, y, x + s - 2, y + s - 2, fill="#1a1a1a", outline="#3a3a3a")
            return
        c.create_rectangle(x, y, x + s - 2, y + s - 2, fill=hex_of(col), outline="")
        fg = _fg(col)
        if mark == "dot":
            r = max(2, s / 9)
            c.create_oval(x + 3, y + 3, x + 3 + 2 * r, y + 3 + 2 * r, fill=fg, outline="")
        elif mark == "tri":
            q = s / 4
            c.create_polygon(x + s - 2, y + s - 2, x + s - 2 - q, y + s - 2,
                             x + s - 2, y + s - 2 - q, fill=fg, outline="")

    # ================================================================ Missing colours
    def _build_missing(self):
        from tkinter import ttk
        tk = self.app.tk
        from .gui_playpals_tool import playpal_entries
        self.pals = playpal_entries(self.app)
        names = [e["name"] for e in self.pals] + [ALL_PALS]
        want = self.app.s.get("an_missing_pal")
        self.pal_var = tk.StringVar(value=want if want in names else names[0])
        ttk.Button(self.opts, text="◀", width=3,
                   command=lambda: self._pal_step(-1)).pack(side="left")
        ttk.Button(self.opts, text="▶", width=3,
                   command=lambda: self._pal_step(1)).pack(side="left", padx=(2, 4))
        cb = ttk.Combobox(self.opts, textvariable=self.pal_var, values=names,
                          state="readonly", width=26)
        cb.pack(side="left", padx=(0, 12))
        cb.bind("<<ComboboxSelected>>", lambda e: self._pal_pick())
        self._closeness("missing")
        self.hide_var = tk.BooleanVar(value=bool(self.app.s.get("an_hide_marked", False)))
        ttk.Checkbutton(self.opts, text="Hide marked", variable=self.hide_var,
                        command=self._hide_changed).pack(side="left", padx=(0, 12))
        ttk.Button(self.opts, text="To scratch", command=self._missing_scratch).pack(
            side="right")
        ttk.Button(self.opts, text="Copy missing", command=self._missing_copy).pack(
            side="right", padx=(0, 6))
        pw = ttk.Panedwindow(self.body, orient="horizontal")
        pw.grid(row=0, column=0, sticky="nsew")
        left = ttk.Frame(pw)
        right = ttk.Frame(pw)
        pw.add(left, weight=3)
        pw.add(right, weight=2)
        left.rowconfigure(0, weight=1)
        left.columnconfigure(0, weight=1)
        c = tk.Canvas(left, bg="#262626", highlightthickness=0)
        c.grid(row=0, column=0, sticky="nsew")
        c.bind("<Configure>", lambda e: self.schedule(now=True))
        c.bind("<Motion>", self._hover)
        c.bind("<Leave>", lambda e: self.info_var.set(""))
        c.bind("<Button-1>", self._click)
        self.cv = c
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)
        hf = ttk.Frame(right)
        hf.grid(row=0, column=0, columnspan=2, sticky="ew", padx=(8, 0))
        rv = self.app.s.get("an_right")
        self.right_var = tk.StringVar(value=rv if rv in ("Missing list", "My palette")
                                      else "Missing list")
        rcb = ttk.Combobox(hf, textvariable=self.right_var, state="readonly", width=13,
                           values=("Missing list", "My palette"))
        rcb.pack(side="left")
        rcb.bind("<<ComboboxSelected>>", lambda e: self._right_changed())
        self.miss_title = tk.StringVar()
        ttk.Label(hf, textvariable=self.miss_title).pack(side="left", padx=(8, 0))
        mc = tk.Canvas(right, bg="#262626", highlightthickness=0)
        mc.bind("<Configure>", lambda e: self._draw_mine())
        mc.bind("<Motion>", self._mine_hover)
        mc.bind("<Leave>", lambda e: (self.info_var.set(""), self._mine_mark(None)))
        mc.bind("<Button-1>", self._mine_click)
        self.mine_cv = mc
        self.mine_hits = []
        self._mine_hl = None
        from .gui_filters_window import _tree_style
        tv = ttk.Treeview(right, columns=("hex", "near"), show="tree headings",
                          selectmode="extended", style=_tree_style(self.app, "An.Treeview"))
        tv.heading("#0", text="Missing")
        tv.heading("hex", text="Hex")
        tv.heading("near", text="Nearest yours")
        tv.column("#0", width=int(110 * self.ui), stretch=False)
        tv.column("hex", width=int(70 * self.ui), stretch=False)
        tv.column("near", width=int(150 * self.ui))
        sb = ttk.Scrollbar(right, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        tv.grid(row=1, column=0, sticky="nsew", padx=(8, 0))
        sb.grid(row=1, column=1, sticky="ns")
        self.miss_tv = tv
        self.miss_sb = sb
        self._right_show()
        self._icons = {}
        self.missing = []

    # right pane: the missing list, or your own palette side by side
    def _right_changed(self):
        self.app.s["an_right"] = self.right_var.get()
        self._right_show()

    def _right_show(self):
        if self.right_var.get() == "My palette":
            self.miss_tv.grid_remove()
            self.miss_sb.grid_remove()
            self.mine_cv.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=(8, 0))
            self._draw_mine()
        else:
            self.mine_cv.grid_remove()
            self.miss_tv.grid()
            self.miss_sb.grid()

    def _draw_mine(self):
        """Your working palette (Live / Applied) as a 16 x 16 grid."""
        c = self.mine_cv
        if self.right_var.get() != "My palette":
            return
        c.delete("all")
        self.mine_hits = []
        cells = self.cells()
        W, H = max(c.winfo_width(), 50), max(c.winfo_height(), 50)
        cell = max(4.0, min((W - 8) / 16.0, (H - 8) / 16.0))
        gx = (W - cell * 16) / 2
        self._mine_geo = (gx, 4, cell)
        for i, col in enumerate(cells):
            x, y = gx + (i % 16) * cell, 4 + (i // 16) * cell
            self._swatch(c, x, y, cell, col, empty=col is None)
            self.mine_hits.append((x, y, x + cell, y + cell, i, col))
        self._mine_mark(self._mine_hl)

    def _mine_mark(self, i):
        """Outline one of your cells (the nearest to the colour hovered left)."""
        self._mine_hl = i
        c = self.mine_cv
        try:
            c.delete("hl")
            if i is None or self.right_var.get() != "My palette":
                return
            gx, gy, cell = self._mine_geo
            x, y = gx + (i % 16) * cell, gy + (i // 16) * cell
            w = max(2, int(2 * self.ui))
            c.create_rectangle(x - 1, y - 1, x + cell - 1, y + cell - 1, outline="#000000",
                               width=w + 2, tags="hl")
            c.create_rectangle(x - 1, y - 1, x + cell - 1, y + cell - 1, outline="#00ffff",
                               width=w, tags="hl")
        except (AttributeError, self.app.tk.TclError):
            pass

    def _mine_at(self, ev):
        for x0, y0, x1, y1, i, col in self.mine_hits:
            if x0 <= ev.x < x1 and y0 <= ev.y < y1:
                return i, col
        return None, None

    def _mine_hover(self, ev):
        i, col = self._mine_at(ev)
        self.info_var.set("" if i is None else "your cell %d  %s" % (
            i, hex_of(col) if col else "(empty)"))

    def _mine_click(self, ev):
        i, col = self._mine_at(ev)
        if i is None:
            return
        a = self.app
        if ev.state & 0x0001:
            a.selection |= {i}
        else:
            a.selection = {i}
        a.recompute()

    def _hide_changed(self):
        self.app.s["an_hide_marked"] = bool(self.hide_var.get())
        self.schedule(now=True)

    def _pal_pick(self):
        self.app.s["an_missing_pal"] = self.pal_var.get()
        self.schedule(now=True)

    def _pal_step(self, n):
        names = [e["name"] for e in self.pals] + [ALL_PALS]
        try:
            k = names.index(self.pal_var.get())
        except ValueError:
            k = 0
        self.pal_var.set(names[(k + n) % len(names)])
        self._pal_pick()

    def _icon(self, col):
        img = self._icons.get(col)
        if img is None:
            tk = self.app.tk
            s = max(10, int(14 * self.ui))
            img = tk.PhotoImage(width=s, height=s)
            img.put(hex_of(col), to=(0, 0, s, s))
            self._icons[col] = img
        return img

    def _classify(self, other, mine, dist, close):
        """other colours -> ("exact" | "close" | "missing", nearest mine, d)."""
        mine_set = set(mine)
        out = {}
        for c in set(x for x in other if x is not None):
            if c in mine_set:
                out[c] = ("exact", c, 0.0)
                continue
            best, bd = None, float("inf")
            for m in mine:
                d = dist(c, m)
                if d < bd:
                    best, bd = m, d
            out[c] = (("close" if bd <= close else "missing"), best, bd)
        return out

    def _draw_missing(self):
        c = self.cv
        c.delete("all")
        self.hits = []
        cells = self.cells()
        mine = list(dict.fromkeys(x for x in cells if x is not None))
        where = {}
        for i, x in enumerate(cells):
            if x is not None:
                where.setdefault(x, i)
        if not mine:
            self._msg("Your palette is empty.")
            return
        sel = self.pal_var.get()
        pals = self.pals if sel == ALL_PALS else [e for e in self.pals if e["name"] == sel]
        if not pals:
            self._msg("No Palette Browser palettes - add some in the Palette Browser window.")
            return
        dist = _Dist(self.metric())
        close = self.close_val("missing")
        allc = [x for e in pals for x in e["rgbs"][:ENTRIES]]
        cls = self._classify(allc, mine, dist, close)
        hide = self.hide_var.get()
        W, H = max(c.winfo_width(), 50), max(c.winfo_height(), 50)
        n = len(pals)
        cols = 1 if n == 1 else min(3, n)
        rows = (n + cols - 1) // cols
        lab_h = int(18 * self.ui) if n > 1 else 0
        tw, th = (W - 8) / cols, (H - 8) / rows
        cell = max(4.0, min((tw - 8) / 16.0, (th - lab_h - 8) / 16.0))
        unit = self.unit()
        miss_rows = []
        counts = {"exact": 0, "close": 0, "missing": 0}
        for k, e in enumerate(pals):
            gx = 4 + (k % cols) * tw + (tw - cell * 16) / 2
            gy = 4 + (k // cols) * th + lab_h
            if n > 1:
                c.create_text(gx, gy - 2, anchor="sw", text=e["name"][:40], fill="#bbbbbb")
            for idx, col in enumerate(e["rgbs"][:ENTRIES]):
                x, y = gx + (idx % 16) * cell, gy + (idx // 16) * cell
                if col is None:
                    self._swatch(c, x, y, cell, None, empty=True)
                    continue
                col = tuple(col)
                kind, near, d = cls[col]
                counts[kind] += 1
                if hide and kind != "missing":
                    self._swatch(c, x, y, cell, None, empty=True)
                else:
                    self._swatch(c, x, y, cell, col,
                                 {"exact": "dot", "close": "tri"}.get(kind))
                ni = where.get(near)
                if kind == "exact":
                    t = "#%d in %s  %s  - identical: your cell %d" % (idx, e["name"],
                                                                       hex_of(col), ni)
                elif kind == "close":
                    t = "#%d in %s  %s  - %s: your cell %d (%.2f %s)" % (
                        idx, e["name"], hex_of(col), "hidden, similar" if hide else "similar",
                        ni, d, unit)
                else:
                    t = "#%d in %s  %s  - MISSING: nearest yours cell %d (%.2f %s)" % (
                        idx, e["name"], hex_of(col), ni, d, unit)
                    miss_rows.append((d, idx, e["name"], col, ni, near))
                self.hits.append((x, y, x + cell, y + cell,
                                  {"text": t, "near": ni,
                                   "cb": (lambda cc=col: self._miss_pick(cc))
                                   if kind == "missing" else None}))
        # missing list: unique colours, furthest first
        seen = set()
        self.missing = []
        tv = self.miss_tv
        tv.delete(*tv.get_children())
        for d, idx, name, col, ni, near in sorted(miss_rows, key=lambda r: -r[0]):
            if col in seen:
                continue
            seen.add(col)
            self.missing.append(col)
            tv.insert("", "end", iid=hex_of(col), image=self._icon(col),
                      text=" #%d%s" % (idx, "" if n == 1 else " " + name[:10]),
                      values=(hex_of(col), "cell %d  (%.2f %s)" % (ni, d, unit)))
        self._draw_mine()
        self.miss_title.set("%d missing colour%s (furthest first)" % (
            len(self.missing), "" if len(self.missing) == 1 else "s"))
        self.status_var.set("● identical %d   ◢ similar %d   missing %d   "
                            "(closeness %.2f %s)" % (counts["exact"], counts["close"],
                                                     counts["missing"], close, unit))

    def _miss_pick(self, col):
        tv = self.miss_tv
        iid = hex_of(col)
        if tv.exists(iid):
            tv.selection_toggle(iid)
            tv.see(iid)

    def _miss_chosen(self):
        sel = list(self.miss_tv.selection())
        from ..cleanpal_lib_colour import parse_colour
        cols = [parse_colour(i) for i in sel] if sel else list(self.missing)
        return [c for c in cols if c]

    def _missing_copy(self):
        cols = self._miss_chosen()
        if not cols:
            self.status_var.set("Nothing missing to copy.")
            return
        self.app.clip_set(cols, "Analyser - missing colours")
        self.status_var.set("Copied %d colour(s) - Ctrl+V in Paint inserts them." % len(cols))

    def _missing_scratch(self):
        cols = self._miss_chosen()
        if not cols:
            self.status_var.set("Nothing missing to send.")
            return
        self.app.open_scratch().add_colours(cols)
        self.status_var.set("Sent %d colour(s) to the Scratch palette." % len(cols))

    # ================================================================ censor
    def _build_censor(self):
        from tkinter import ttk
        tk = self.app.tk
        s = self.app.s
        ill = s.get("censor_ill")
        self.ill_var = tk.StringVar(value=ill if ill in ILLUMINANTS else ILLUMINANTS[0])
        self.grey_var = tk.BooleanVar(value=bool(s.get("censor_grey", False)))
        self.mt_var = tk.BooleanVar(value=bool(s.get("censor_mt", False)))
        ttk.Label(self.opts, text="Illuminant").pack(side="left")
        cb = ttk.Combobox(self.opts, textvariable=self.ill_var, values=ILLUMINANTS,
                          state="readonly", width=7)
        cb.pack(side="left", padx=(4, 10))
        cb.bind("<<ComboboxSelected>>", lambda e: self._censor_opts())
        ttk.Checkbutton(self.opts, text="Greyscale UI", variable=self.grey_var,
                        command=self._censor_opts).pack(side="left")
        ttk.Checkbutton(self.opts, text="Multithreaded", variable=self.mt_var,
                        command=self._censor_opts).pack(side="left", padx=(8, 0))
        ttk.Button(self.opts, text="Save plot...", command=self._censor_save).pack(
            side="right")
        ttk.Button(self.opts, text="Locate censor...", command=self._censor_locate).pack(
            side="right", padx=(0, 6))
        ttk.Button(self.opts, text="Refresh", command=self._censor_refresh).pack(
            side="right", padx=(0, 6))
        self._canvas()

    def _censor_opts(self):
        s = self.app.s
        s["censor_ill"], s["censor_grey"], s["censor_mt"] = (
            self.ill_var.get(), bool(self.grey_var.get()), bool(self.mt_var.get()))
        self.schedule(now=True)

    def _censor_exe(self):
        p = self.app.s.get("censor_path")
        if p and os.path.isfile(p):
            return p
        return shutil.which("censor") or shutil.which("censor.exe")

    def _censor_locate(self):
        from tkinter import filedialog
        p = filedialog.askopenfilename(
            parent=self.win, title="Locate censor",
            filetypes=[("censor", "censor.exe censor"), ("All files", "*.*")])
        if p:
            self.app.s["censor_path"] = p
            self._censor_refresh()

    def _censor_refresh(self):
        self._censor["key"] = None
        self.schedule(now=True)

    def _censor_save(self):
        from tkinter import filedialog
        img = self._censor.get("img")
        if img is None:
            self.status_var.set("No plot yet.")
            return
        p = filedialog.asksaveasfilename(parent=self.win, title="Save censor plot",
                                         defaultextension=".png", initialfile="plot.png",
                                         filetypes=[("PNG image", "*.png")])
        if p:
            img.save(p)
            self.status_var.set("Saved %s" % p)

    def _draw_censor(self):
        st = self._censor
        exe = self._censor_exe()
        if not exe:
            self._msg("censor isn't installed (or not on PATH).\n\n"
                      "Install it with:   cargo install censor-analyser\n\n"
                      "or press Locate censor... to point at censor.exe.\n"
                      "https://github.com/Quickmarble/censor")
            return
        cols = list(dict.fromkeys(c for _i, c in self.scoped()))
        if len(cols) < 2:
            self._msg("censor needs at least 2 colours%s." % (
                " - select some cells" if self.scope_var.get() == "sel" else ""))
            return
        key = (exe, tuple(cols), self.ill_var.get(), self.grey_var.get(), self.mt_var.get())
        if key != st["key"]:
            st["key"] = key
            self._censor_run(exe, cols, key)
        self._censor_show()

    def _censor_run(self, exe, cols, key):
        st = self._censor
        tmp = tempfile.mkdtemp(prefix="cleanpal_censor_")
        hx = os.path.join(tmp, "pal.hex")
        out = os.path.join(tmp, "plot.png")
        with open(hx, "w", encoding="ascii") as fh:
            fh.write("\n".join(hex_of(c)[1:] for c in cols) + "\n")
        cmd = [exe, "analyse", "-f", hx, "-o", out]
        ill = self.ill_var.get()
        if ill.endswith("K"):
            cmd += ["-T", ill.split()[0]]
        else:
            cmd += ["-" + ill]
        if self.grey_var.get():
            cmd.append("-g")
        if self.mt_var.get():
            cmd.append("-j")
        self.status_var.set("Running censor on %d colours..." % len(cols))

        def work():
            err = ""
            img = None
            try:
                kw = {}
                if os.name == "nt":
                    kw["creationflags"] = 0x08000000         # CREATE_NO_WINDOW
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=120, **kw)
                if r.returncode != 0 or not os.path.isfile(out):
                    err = (r.stderr or r.stdout or "censor failed").strip()[-400:]
                else:
                    from PIL import Image
                    with Image.open(out) as im:
                        im.load()
                        img = im.convert("RGB")
            except Exception as e:  # noqa: BLE001 - report anything
                err = str(e)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            st["result"] = (key, img, err, len(cols))   # picked up by _poll (Tk thread)
        threading.Thread(target=work, daemon=True).start()

    def _censor_collect(self):
        """Main thread: take a finished censor run's plot."""
        st = self._censor
        res = st.pop("result", None)
        if res is None:
            return
        key, img, err, n = res
        if st["key"] != key:
            return                                # a newer run replaced this one
        st["img"], st["err"], st["tk"] = img, err, None
        self.status_var.set(("censor: " + err) if err else "censor: %d colours analysed." % n)
        if self.mode_var.get() == "censor":
            self._censor_show()

    def _censor_show(self):
        from PIL import Image, ImageTk
        st = self._censor
        c = self.cv
        img = st.get("img")
        if img is None:
            self._msg("censor: %s" % (st["err"] or "working..."))
            return
        W, H = max(c.winfo_width(), 50), max(c.winfo_height(), 50)
        k = min(W / img.width, H / img.height)
        size = (max(1, int(img.width * k)), max(1, int(img.height * k)))
        pic = img.resize(size, Image.NEAREST if k >= 1 else Image.LANCZOS)
        st["tk"] = ImageTk.PhotoImage(pic)
        c.delete("all")
        self.hits = []
        c.create_image(W // 2, H // 2, image=st["tk"])

    # ================================================================ Hue / lightness map
    def _build_huemap(self):
        self._canvas()

    def _draw_huemap(self):
        c = self.cv
        c.delete("all")
        self.hits = []
        items = self.scoped()
        if not items:
            self._msg("Nothing to show - select cells, or use Whole palette.")
            return
        W, H = max(c.winfo_width(), 100), max(c.winfo_height(), 100)
        u = self.ui
        pad_l, pad_b, pad_t, pad_r = int(70 * u), int(26 * u), int(10 * u), int(12 * u)
        nx0 = int(8 * u)                      # neutral column on the left
        x0, x1, y0, y1 = pad_l, W - pad_r, pad_t, H - pad_b
        for h in range(0, 361, 30):
            x = x0 + (x1 - x0) * h / 360.0
            c.create_line(x, y0, x, y1, fill="#333333")
            c.create_text(x, y1 + 4, anchor="n", text="%d°" % h, fill="#888888")
        for L in range(0, 101, 20):
            y = y1 - (y1 - y0) * L / 100.0
            c.create_line(x0, y, x1, y, fill="#333333")
            c.create_text(x0 - 4, y, anchor="e", text="L %d" % L, fill="#888888")
        c.create_text(nx0, y0, anchor="nw", text="greys", fill="#888888")
        s = max(6, int(min(x1 - x0, y1 - y0) / 34))
        for i, col in items:
            L, C, h = _lch(col)
            if C < 0.025:
                x = nx0 + int(14 * u)
            else:
                x = x0 + (x1 - x0) * h / 360.0
            y = y1 - (y1 - y0) * min(max(L, 0.0), 1.0)
            c.create_rectangle(x - s / 2, y - s / 2, x + s / 2, y + s / 2, fill=hex_of(col),
                               outline="#000000")
            self.hits.append((x - s / 2, y - s / 2, x + s / 2, y + s / 2,
                              {"text": "cell %d  %s  L %.0f  C %.3f  hue %.0f°" % (
                                  i, hex_of(col), L * 100, C, h), "select": [i]}))
        self.status_var.set("%d colours - hue across, lightness up (OKLCH). Greys (very "
                            "low chroma) on the left. Click = select the cell." % len(items))

    # ================================================================ Ramps
    def _build_ramps(self):
        self._canvas()

    def ramps(self, items):
        """Runs of index-adjacent cells with a steady hue (greys go together)."""
        out, cur = [], []
        prev = None
        for i, col in items:
            L, C, h = _lch(col)
            grey = C < 0.03
            if prev is not None:
                pi, pL, pC, ph, pg = prev
                same = (i == pi + 1 and grey == pg and
                        (grey or min(abs(h - ph), 360 - abs(h - ph)) < 35))
                if not same:
                    if len(cur) >= 3:
                        out.append(cur)
                    cur = []
            cur.append((i, col, L))
            prev = (i, L, C, h, grey)
        if len(cur) >= 3:
            out.append(cur)
        return out

    def _draw_ramps(self):
        c = self.cv
        c.delete("all")
        self.hits = []
        rs = self.ramps(self.scoped())
        if not rs:
            self._msg("No ramps found (3+ neighbouring cells with a steady hue).")
            return
        W = max(c.winfo_width(), 100)
        u = self.ui
        lab_w = int(150 * u)
        row_h = max(int(30 * u), 18)
        gap = int(8 * u)
        y = 4
        flagged = 0
        for r in rs:
            n = len(r)
            cell = max(6.0, min((W - lab_w - 12) / 16.0, (W - lab_w - 12) / n))
            Ls = [p[2] for p in r]
            steps = [Ls[k + 1] - Ls[k] for k in range(n - 1)]
            direction = 1 if Ls[-1] >= Ls[0] else -1
            mags = sorted(abs(d) for d in steps)
            med = mags[len(mags) // 2] if mags else 0
            bad = {}
            for k, d in enumerate(steps):
                if d * direction < -0.005:
                    bad[k + 1] = "reverses"
                elif med > 0.002 and abs(d) > 2.2 * med:
                    bad[k + 1] = "jumps"
            flagged += len(bad)
            c.create_text(4, y + row_h / 2, anchor="w", fill="#cccccc",
                          text="%d-%d  (%d)%s" % (r[0][0], r[-1][0], n,
                                                  ("  ⚠ %d" % len(bad)) if bad else ""))
            x0 = lab_w
            for k, (i, col, L) in enumerate(r):
                x = x0 + k * cell
                c.create_rectangle(x, y, x + cell - 1, y + row_h, fill=hex_of(col), outline="")
                if k in bad:
                    c.create_rectangle(x, y, x + cell - 1, y + row_h, outline="#ff3030",
                                       width=max(2, int(2 * u)))
                t = "cell %d  %s  L %.1f" % (i, hex_of(col), L * 100)
                if k > 0:
                    t += "  step %+.1f" % (steps[k - 1] * 100)
                if k in bad:
                    t += "  <- %s" % bad[k]
                self.hits.append((x, y, x + cell, y + row_h,
                                  {"text": t, "select": [i]}))
            # lightness line under the strip
            ly0, ly1 = y + row_h + 2, y + row_h + 2 + row_h * 0.8
            pts = []
            for k, L in enumerate(Ls):
                pts += [x0 + k * cell + cell / 2, ly1 - (ly1 - ly0) * L]
            if len(pts) >= 4:
                c.create_line(*pts, fill="#dddddd", width=max(1, int(u)))
            for k in bad:
                c.create_oval(pts[2 * k] - 3 * u, pts[2 * k + 1] - 3 * u,
                              pts[2 * k] + 3 * u, pts[2 * k + 1] + 3 * u, fill="#ff3030",
                              outline="")
            y = ly1 + gap
        self.status_var.set("%d ramp%s, %d step%s flagged (red: lightness jumps or goes the "
                            "wrong way). Click a step = select that cell." % (
                                len(rs), "" if len(rs) == 1 else "s", flagged,
                                "" if flagged == 1 else "s"))

    # ================================================================ Close colours
    def _build_close(self):
        self._closeness("close")
        self._canvas()

    def _draw_close(self):
        c = self.cv
        c.delete("all")
        self.hits = []
        items = self.scoped()
        dist = _Dist(self.metric())
        close = self.close_val("close")
        pairs = []
        for a in range(len(items)):
            for b in range(a + 1, len(items)):
                ia, ca = items[a]
                ib, cb = items[b]
                d = 0.0 if ca == cb else dist(ca, cb)
                if d <= close:
                    pairs.append((d, ia, ib, ca, cb))
        pairs.sort()
        if not pairs:
            self._msg("No pairs within %.2f %s." % (close, self.unit()))
            return
        W = max(c.winfo_width(), 100)
        u = self.ui
        row = max(int(26 * u), 16)
        s = row - 4
        col_w = int(300 * u)
        ncol = max(1, int((W - 8) // col_w))
        for k, (d, ia, ib, ca, cb) in enumerate(pairs[:400]):
            x = 4 + (k % ncol) * col_w
            y = 4 + (k // ncol) * row
            c.create_rectangle(x, y, x + s, y + s, fill=hex_of(ca), outline="")
            c.create_rectangle(x + s + 2, y, x + 2 * s + 2, y + s, fill=hex_of(cb), outline="")
            c.create_text(x + 2 * s + 10, y + s / 2, anchor="w", fill="#cccccc",
                          text="%3d ↔ %-3d  %.2f %s" % (ia, ib, d, self.unit()))
            self.hits.append((x, y, x + col_w - 8, y + row,
                              {"text": "cells %d (%s) and %d (%s): %.2f %s - click selects both"
                                       % (ia, hex_of(ca), ib, hex_of(cb), d, self.unit()),
                               "select": [ia, ib]}))
        self.status_var.set("%d pair%s within %.2f %s, closest first%s. Click = select both "
                            "cells (Cull's similar pass would merge these)." % (
                                len(pairs), "" if len(pairs) == 1 else "s", close, self.unit(),
                                " (first 400 shown)" if len(pairs) > 400 else ""))

    # ================================================================ Greyscale
    def _build_grey(self):
        self._canvas()

    def _draw_grey(self):
        c = self.cv
        c.delete("all")
        self.hits = []
        items = self.scoped()
        if not items:
            self._msg("Nothing to show - select cells, or use Whole palette.")
            return
        W, H = max(c.winfo_width(), 100), max(c.winfo_height(), 100)
        u = self.ui

        def grey(col):
            L = min(max(oklab(col)[0], 0.0), 1.0)
            lin = L ** 3                          # OKLab L -> linear luminance
            g = 12.92 * lin if lin <= 0.0031308 else 1.055 * lin ** (1 / 2.4) - 0.055
            v = int(round(min(max(g, 0.0), 1.0) * 255))
            return (v, v, v), L

        bar_h = int(70 * u)
        cell = max(4.0, min((W - 8) / 16.0, (H - bar_h - 24 * u) / 16.0))
        gx = (W - cell * 16) / 2
        got = {i: col for i, col in items}
        for i in range(ENTRIES):
            x, y = gx + (i % 16) * cell, 4 + (i // 16) * cell
            col = got.get(i)
            if col is None:
                self._swatch(c, x, y, cell, None, empty=True)
                continue
            g, L = grey(col)
            self._swatch(c, x, y, cell, g)
            self.hits.append((x, y, x + cell, y + cell,
                              {"text": "cell %d  %s  lightness %.1f" % (i, hex_of(col), L * 100),
                               "select": [i]}))
        # sorted strip: colour above, its grey below
        srt = sorted(items, key=lambda t: grey(t[1])[1])
        y0 = 4 + cell * 16 + 10 * u
        w = (W - 8) / max(len(srt), 1)
        for k, (i, col) in enumerate(srt):
            x = 4 + k * w
            c.create_rectangle(x, y0, x + w + 0.5, y0 + bar_h / 2, fill=hex_of(col), outline="")
            c.create_rectangle(x, y0 + bar_h / 2, x + w + 0.5, y0 + bar_h,
                               fill=hex_of(grey(col)[0]), outline="")
            self.hits.append((x, y0, x + w, y0 + bar_h,
                              {"text": "cell %d  %s  lightness %.1f" % (i, hex_of(col),
                                                                        grey(col)[1] * 100),
                               "select": [i]}))
        self.status_var.set("Lightness only (OKLab L). The strip: every colour sorted dark -> "
                            "light, its grey underneath - look for flat runs and gaps.")

    # ================================================================ Usage
    def _build_usage(self):
        from tkinter import ttk
        tk = self.app.tk
        m = self.app.s.get("an_usage_mode")
        self.um_var = tk.StringVar(value=m if m in ("stored", "pal") else "pal")
        ttk.Button(self.opts, text="Use preview's", command=self._usage_from_preview).pack(
            side="left")
        ttk.Button(self.opts, text="Open WAD...", command=self._usage_wad).pack(
            side="left", padx=(6, 0))
        ttk.Button(self.opts, text="Open folder...", command=self._usage_folder).pack(
            side="left", padx=(6, 12))
        for t, v in (("As stored", "stored"), ("After palettisation", "pal")):
            ttk.Radiobutton(self.opts, text=t, value=v, variable=self.um_var,
                            command=self._usage_mode).pack(side="left", padx=(0, 6))
        self._canvas()
        if self._usage["src"] is None:
            self._usage_from_preview(quiet=True)

    def _usage_mode(self):
        self.app.s["an_usage_mode"] = self.um_var.get()
        self.schedule(now=True)

    def _usage_from_preview(self, quiet=False):
        pv = self.app.preview
        if pv is None or not pv.items:
            if not quiet:
                self.status_var.set("Open a WAD or folder in the preview first, or use the "
                                    "Open buttons here.")
            return
        if pv.mode == "wad":
            self._usage_set("wad", pv.wad.path, pv.wad)
        else:
            self._usage_set("folder", pv.folder, None)

    def _usage_wad(self):
        from tkinter import filedialog, messagebox
        p = filedialog.askopenfilename(parent=self.win, title="WAD to count",
                                       filetypes=[("WAD", "*.wad"), ("All files", "*.*")])
        if not p:
            return
        from ..cleanpal_lib_wadgfx import WadSource
        fallback = [c if c is not None else (0, 0, 0) for c in self.cells()]
        try:
            wad = WadSource(p, fallback, self.app.iwad_archive())
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not open WAD:\n%s" % e, parent=self.win)
            return
        self._usage_set("wad", p, wad)

    def _usage_folder(self):
        from tkinter import filedialog
        d = filedialog.askdirectory(parent=self.win, title="Folder of PNGs to count")
        if d:
            self._usage_set("folder", d, None)

    def _usage_set(self, kind, path, wad):
        u = self._usage
        u.update(src=(kind, path), wad=wad, hist={}, todo=[], done=0, total=0)
        if kind == "wad":
            items = [it for it in wad.items if it["kind"] not in ("texture1", "texture2")]
            u["todo"] = [("wad", it) for it in items]
            u["srcpal"] = [tuple(c) for c in wad.pal]
        else:
            files = []
            for root, dirs, fs in os.walk(path):
                for f in fs:
                    if f.lower().endswith(".png"):
                        files.append(os.path.join(root, f))
            u["todo"] = [("file", f) for f in sorted(files)]
            u["srcpal"] = None
        u["total"] = len(u["todo"])
        if not u["busy"]:
            u["busy"] = True
            self.win.after(1, self._usage_scan)

    def _usage_scan(self):
        """Count colours a few images per tick (the window stays responsive)."""
        from PIL import Image
        u = self._usage
        for _ in range(12):
            if not u["todo"]:
                break
            kind, x = u["todo"].pop()
            try:
                if kind == "wad":
                    img = u["wad"].image(x)
                    if isinstance(img, tuple):
                        img = img[0]
                else:
                    with Image.open(x) as im:
                        im.load()
                        img = im.convert("RGBA")
                if img is not None:
                    for n, (r, g, b, a) in img.getcolors(1 << 24) or ():
                        if a >= 128:
                            u["hist"][(r, g, b)] = u["hist"].get((r, g, b), 0) + n
            except Exception:  # noqa: BLE001 - unreadable image: skip it
                pass
            u["done"] += 1
        if u["todo"]:
            self.status_var.set("Counting colours... %d / %d images" % (u["done"], u["total"]))
            if self.mode_var.get() == "Usage":
                self.schedule()
            self.win.after(1, self._usage_scan)
        else:
            u["busy"] = False
            self.schedule(now=True)

    def _usage_counts(self, cells):
        """cell index -> pixel count, plus pixels that fit no cell."""
        from PIL import Image
        u = self._usage
        hist = u["hist"]
        counts = [0] * ENTRIES
        other = 0
        if not hist:
            return counts, other
        if self.um_var.get() == "stored":
            src = u.get("srcpal")
            if src is None:          # true-colour PNGs: colour == cell colour exactly
                where = {}
                for i, c in enumerate(cells):
                    if c is not None:
                        where.setdefault(c, i)
            else:
                where = {}
                for i, c in enumerate(src[:ENTRIES]):
                    where.setdefault(tuple(c), i)
            for c, n in hist.items():
                i = where.get(c)
                if i is None:
                    other += n
                else:
                    counts[i] += n
            return counts, other
        idx = [i for i, c in enumerate(cells) if c is not None]
        if not idx:
            return counts, other
        flat = []
        for i in idx:
            flat.extend(cells[i])
        flat.extend(list(cells[idx[0]]) * (256 - len(idx)))
        palimg = Image.new("P", (1, 1))
        palimg.putpalette(flat)
        cols = list(hist.keys())
        strip = Image.new("RGB", (len(cols), 1))
        strip.putdata(cols)
        try:
            dither = Image.Dither.NONE
        except AttributeError:
            dither = 0
        q = strip.quantize(palette=palimg, dither=dither)
        for c, k in zip(cols, q.getdata()):
            if k < len(idx):
                counts[idx[k]] += hist[c]
        return counts, other

    def _draw_usage(self):
        c = self.cv
        c.delete("all")
        self.hits = []
        u = self._usage
        if u["src"] is None:
            self._msg("Pick what to count: Use preview's (the WAD / folder open in the "
                      "preview), Open WAD... or Open folder...")
            return
        cells = self.cells()
        counts, other = self._usage_counts(cells)
        tot = sum(counts) + other
        scope = {i for i, _c in self.scoped()}
        W, H = max(c.winfo_width(), 100), max(c.winfo_height(), 100)
        cell = max(6.0, min((W - 8) / 16.0, (H - 8) / 16.0))
        gx = (W - cell * 16) / 2
        mx = max([counts[i] for i in scope] or [0]) or 1
        unused = 0
        for i in range(ENTRIES):
            x, y = gx + (i % 16) * cell, 4 + (i // 16) * cell
            col = cells[i]
            if col is None or i not in scope:
                self._swatch(c, x, y, cell, None, empty=True)
                continue
            n = counts[i]
            self._swatch(c, x, y, cell, col)
            # heat bar along the bottom of the cell (log scale), X when unused
            if n:
                f = math.log1p(n) / math.log1p(mx)
                c.create_rectangle(x + 2, y + cell - 2 - max(2, (cell - 6) * f) - 1,
                                   x + 6 * self.ui + 2, y + cell - 3, fill=_fg(col),
                                   outline="")
            else:
                unused += 1
                fg = _fg(col)
                c.create_line(x + 3, y + 3, x + cell - 5, y + cell - 5, fill=fg,
                              width=max(1, int(self.ui)))
                c.create_line(x + cell - 5, y + 3, x + 3, y + cell - 5, fill=fg,
                              width=max(1, int(self.ui)))
            self.hits.append((x, y, x + cell, y + cell,
                              {"text": "cell %d  %s  used %d px (%.2f%%)" % (
                                  i, hex_of(col), n, 100.0 * n / tot if tot else 0),
                               "select": [i]}))
        kind, path = u["src"]
        busy = (" - counting %d / %d" % (u["done"], u["total"])) if u["busy"] else ""
        how = "as stored" if self.um_var.get() == "stored" else "after palettisation"
        extra = ""
        if self.um_var.get() == "stored" and other:
            extra = "  |  %d px aren't palette colours (true-colour art - use After " \
                    "palettisation)" % other
        self.status_var.set("%s: %d px counted %s, %d cell%s unused (X). Bar = how much "
                            "a cell is used (log)%s%s" % (
                                os.path.basename(path.rstrip("/\\")), tot, how, unused,
                                "" if unused == 1 else "s", busy, extra))

    # ---------------------------------------------------------- window
    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def close(self):
        try:
            self.app.s["analyser_geometry"] = self.win.geometry()
        except self.app.tk.TclError:
            pass
        for a in ("_after", "_poll_after"):
            h = getattr(self, a)
            if h is not None:
                try:
                    self.win.after_cancel(h)
                except self.app.tk.TclError:
                    pass
        self.app.analyser = None
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass
