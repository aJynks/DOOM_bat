"""Colour picker popup and screen eyedropper."""

import math
import os

from ..cleanpal_lib_colour import hex_of, hsl_to_rgb, parse_colour, rgb_round, rgb_to_hsl
from ..cleanpal_lib_constants import PICKER_MODES
from . import gui_picker_models as pm


# ============================================================ eyedropper
class EyeDropper:
    """Full-screen screenshot overlay: click a pixel to pick it, with a
    magnifier loupe. Esc / right-click cancels."""
    LOUPE_SRC = 15
    LOUPE_PX = 9

    def __init__(self, app, callback):
        from PIL import Image, ImageGrab, ImageTk

        tk = app.tk
        self.app = app
        self.cb = callback
        x0 = y0 = 0
        try:
            if os.name == "nt":
                import ctypes
                gm = ctypes.windll.user32.GetSystemMetrics
                x0, y0 = gm(76), gm(77)
                shot = ImageGrab.grab(all_screens=True)
            else:
                shot = ImageGrab.grab()
        except Exception as e:  # noqa: BLE001 - any grab failure
            from tkinter import messagebox
            messagebox.showerror("cleanpal", "Screen capture failed:\n%s" % e)
            self.win = None
            return
        self.shot = shot.convert("RGB")
        self.px = self.shot.load()
        w, h = self.shot.size
        self.win = tk.Toplevel(app.root)
        self.win.overrideredirect(True)
        self.win.geometry("%dx%d%+d%+d" % (w, h, x0, y0))
        try:
            self.win.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.cv = tk.Canvas(self.win, width=w, height=h, highlightthickness=0,
                            cursor="crosshair")
        self.cv.pack()
        self._img = ImageTk.PhotoImage(self.shot)
        self.cv.create_image(0, 0, anchor="nw", image=self._img)
        self._loupe = None
        self._Image = Image
        self._ImageTk = ImageTk
        self.cv.bind("<Motion>", self._motion)
        self.cv.bind("<ButtonPress-1>", self._pick)
        self.cv.bind("<ButtonPress-3>", lambda e: self.close())
        self.win.bind("<Escape>", lambda e: self.close())
        self.win.focus_force()
        self.win.grab_set()

    def _motion(self, ev):
        cv = self.cv
        cv.delete("loupe")
        x, y = ev.x, ev.y
        w, h = self.shot.size
        if not (0 <= x < w and 0 <= y < h):
            return
        n = self.LOUPE_SRC
        half = n // 2
        crop = self.shot.crop((x - half, y - half, x - half + n, y - half + n))
        size = n * self.LOUPE_PX
        big = crop.resize((size, size), self._Image.NEAREST)
        self._loupe = self._ImageTk.PhotoImage(big)
        lx = x + 24 if x + 24 + size < w else x - 24 - size
        ly = y + 24 if y + 24 + size + 22 < h else y - 24 - size - 22
        cv.create_rectangle(lx - 2, ly - 2, lx + size + 2, ly + size + 24,
                            fill="#202020", outline="#ffffff", tags="loupe")
        cv.create_image(lx, ly, anchor="nw", image=self._loupe, tags="loupe")
        c0 = lx + half * self.LOUPE_PX
        r0 = ly + half * self.LOUPE_PX
        cv.create_rectangle(c0, r0, c0 + self.LOUPE_PX, r0 + self.LOUPE_PX,
                            outline="#000000", width=3, tags="loupe")
        cv.create_rectangle(c0, r0, c0 + self.LOUPE_PX, r0 + self.LOUPE_PX,
                            outline="#ffffff", width=1, tags="loupe")
        rgb = self.px[x, y]
        cv.create_text(lx + 4, ly + size + 11, anchor="w", fill="#ffffff",
                       font=("Consolas", 10),
                       text="%s  %d,%d,%d" % ((hex_of(rgb),) + tuple(rgb)), tags="loupe")

    def _pick(self, ev):
        w, h = self.shot.size
        if 0 <= ev.x < w and 0 <= ev.y < h:
            rgb = tuple(self.px[ev.x, ev.y])
            self.close()
            self.cb(rgb)
        else:
            self.close()

    def close(self):
        if self.win is not None:
            try:
                self.win.grab_release()
            except self.app.tk.TclError:
                pass
            self.win.destroy()
            self.win = None


# ============================================================ colour picker
_PICKER_CACHE = {}


def _full_box_image():
    """Hue (x) x lightness (y, 100 top -> 0 bottom) at full saturation."""
    if "box" not in _PICKER_CACHE:
        from PIL import Image
        W, H = 360, 200
        im = Image.new("RGB", (W, H))
        px = im.load()
        for x in range(W):
            for y in range(H):
                px[x, y] = rgb_round(hsl_to_rgb(x * 360.0 / W, 100.0,
                                                100.0 - y * 100.0 / (H - 1)))
        grey = Image.new("RGB", (W, H))
        gp = grey.load()
        for y in range(H):
            v = int(round(255 * (1.0 - y / (H - 1.0))))
            for x in range(W):
                gp[x, y] = (v, v, v)
        _PICKER_CACHE["box"] = im
        _PICKER_CACHE["grey"] = grey
    return _PICKER_CACHE["box"], _PICKER_CACHE["grey"]


def _ring_image():
    """Hue ring (RGBA) at base size; hue runs clockwise from red at 3 o'clock."""
    if "ring" not in _PICKER_CACHE:
        from PIL import Image
        S = 320
        im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        px = im.load()
        c = (S - 1) / 2.0
        ro, ri = S / 2.0 - 1, S / 2.0 * 0.80
        for y in range(S):
            for x in range(S):
                dx, dy = x - c, y - c
                r = math.hypot(dx, dy)
                if ri - 1 <= r <= ro + 1:
                    a = 255
                    if r > ro:
                        a = int(255 * max(0.0, 1.0 - (r - ro)))
                    elif r < ri:
                        a = int(255 * max(0.0, 1.0 - (ri - r)))
                    h = math.degrees(math.atan2(dy, dx)) % 360.0
                    px[x, y] = rgb_round(hsl_to_rgb(h, 100.0, 50.0)) + (a,)
        _PICKER_CACHE["ring"] = im
    return _PICKER_CACHE["ring"]


def _tri_vertices(cx, cy, r, a=0.0):
    """tip (pure hue, pointing at angle a - the hue), black (a + 240),
    white (a + 120). Angles run clockwise on screen, like the hue ring."""
    def pt(d):
        t = math.radians(a + d)
        return (cx + r * math.cos(t), cy + r * math.sin(t))
    return (pt(0.0), pt(240.0), pt(120.0))


def _bary(p, a, b, c):
    """Barycentric weights of p in triangle abc."""
    (x, y), (x1, y1), (x2, y2), (x3, y3) = p, a, b, c
    det = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
    w1 = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / det
    w2 = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / det
    return w1, w2, 1.0 - w1 - w2


def _tri_masks():
    """Tip weight, white weight and inside mask for the triangle at base size."""
    if "tri" not in _PICKER_CACHE:
        from PIL import Image
        S = 256
        c = (S - 1) / 2.0
        A, B, C = _tri_vertices(c, c, S / 2.0 - 1)
        tip = Image.new("L", (S, S))
        wht = Image.new("L", (S, S))
        msk = Image.new("L", (S, S))
        tp, wp, mp = tip.load(), wht.load(), msk.load()
        for y in range(S):
            for x in range(S):
                wt, wk, ww = _bary((x, y), A, B, C)
                inside = min(wt, wk, ww) >= -0.004
                wt, ww = max(wt, 0.0), max(ww, 0.0)
                tp[x, y] = int(round(min(wt, 1.0) * 255))
                wp[x, y] = int(round(min(ww, 1.0) * 255))
                mp[x, y] = 255 if inside else 0
        _PICKER_CACHE["tri"] = (tip, wht, msk)
    return _PICKER_CACHE["tri"]




class ColourPicker:
    """Non-modal picker. One colour (kept as HSL floats + RGB floats), shown
    by three interchangeable modes. Hue / saturation survive greys."""
    FINE = 0.25

    def __init__(self, app):
        from tkinter import ttk

        tk = app.tk
        self.app = app
        s = app.s
        self.win = tk.Toplevel(app.root)
        self.win.title("Colour picker")
        ui0 = getattr(app, "ui", 1.0)
        self.win.minsize(int(560 * ui0), int(380 * ui0))
        try:
            self.win.geometry(s.get("picker_geometry") or
                              "%dx%d" % (int(820 * ui0), int(500 * ui0)))
        except tk.TclError:
            pass
        self.pin_var = tk.BooleanVar(value=bool(s.get("picker_pin", True)))
        self._apply_pin()
        self.mode_var = tk.StringVar(value=s.get("picker_mode", PICKER_MODES[0]))
        if self.mode_var.get() not in PICKER_MODES:
            self.mode_var.set(PICKER_MODES[0])
        self.h, self.s, self.l = 0.0, 0.0, 50.0
        self.rgbf = (127.5, 127.5, 127.5)
        self.old = (128, 128, 128)
        self.target = None             # callable(rgb, hsl) or None
        self.target_label = ""
        self._drag = None
        self.active = None             # control taking arrow keys
        self._lock = False
        self._imgs = {}
        self._vals = {}                # model -> (values, rgb) last set from it
        self.sliders = {}
        self.gsliders = {}
        self.grev = set()
        self.gfields = {}
        self.box = self.wheel = self.sq = self.strip = self.bx = None
        self._dropper = None
        ui = getattr(app, "ui", 1.0)
        self.ui = ui

        self.win.columnconfigure(0, weight=1)
        self.win.rowconfigure(0, weight=1)
        self.left = ttk.Frame(self.win, padding=8)
        self.left.grid(row=0, column=0, sticky="nsew")
        right = ttk.Frame(self.win, padding=(0, 8, 8, 8))
        right.grid(row=0, column=1, sticky="ns")

        top = ttk.Frame(right)
        top.pack(fill="x")
        cb = ttk.Combobox(top, textvariable=self.mode_var, values=PICKER_MODES,
                          state="readonly", width=18)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self._build_mode())
        self.sw = tk.Canvas(top, width=int(76 * ui), height=int(30 * ui),
                            highlightthickness=1, highlightbackground="#888")
        self.sw.pack(side="left", padx=(8, 0))
        self.sw.bind("<Button-1>", self._on_swatch)
        self.target_var = tk.StringVar(value="")
        ttk.Label(right, textvariable=self.target_var, foreground="#666").pack(anchor="w",
                                                                               pady=(4, 0))

        ff = ttk.Frame(right)
        ff.pack(fill="x", pady=(8, 0))
        self.fvars = {}
        self.fwidgets = {}
        for row, (k, hi) in enumerate((("R", 255), ("G", 255), ("B", 255))):
            self._field(ff, k, hi, row, 0)
        for row, (k, hi) in enumerate((("H", 360), ("S", 100), ("L", 100))):
            self._field(ff, k, hi, row, 2)
        hf = ttk.Frame(right)
        hf.pack(fill="x", pady=(10, 0))
        self.hvars = {}
        for row, k in enumerate(("R#", "G#", "B#")):
            ttk.Label(hf, text=k).grid(row=row, column=0, sticky="e", pady=1)
            v = tk.StringVar()
            e = ttk.Entry(hf, textvariable=v, width=5)
            e.grid(row=row, column=1, sticky="w", padx=(4, 0), pady=1)
            e.bind("<Return>", lambda ev, kk=k: self._on_hexpart(kk))
            e.bind("<FocusOut>", lambda ev, kk=k: self._on_hexpart(kk))
            self.hvars[k] = v
        ttk.Label(hf, text="#").grid(row=3, column=0, sticky="e", pady=(4, 1))
        self.hex_var = tk.StringVar()
        self.hex_entry = ttk.Entry(hf, textvariable=self.hex_var, width=12)
        self.hex_entry.grid(row=3, column=1, columnspan=2, sticky="w", padx=(4, 0),
                            pady=(4, 1))
        self.hex_entry.bind("<Return>", lambda e: self._on_hex())
        self.hex_entry.bind("<FocusOut>", lambda e: self._on_hex(quiet=True))
        self.hex_entry.bind("<<Paste>>", lambda e: self.win.after(1, self._on_hex))
        self.hex_var.trace_add("write", lambda *a: self._on_hex(live=True))

        ef = ttk.Frame(right)
        ef.pack(fill="x", pady=(10, 0))
        ttk.Button(ef, text="Eyedropper", command=self.eyedropper).pack(side="left")
        self.last_cv = tk.Canvas(ef, width=int(22 * ui), height=int(22 * ui),
                                 highlightthickness=1, highlightbackground="#888")
        self.last_cv.pack(side="left", padx=(6, 0))
        self.last_cv.bind("<Button-1>", lambda e: self._use_last())
        self._last_pick = None
        ttk.Label(right, text="Recent").pack(anchor="w", pady=(10, 0))
        self.recent_cv = tk.Canvas(right, height=int(40 * ui), width=int(200 * ui),
                                   highlightthickness=0)
        self.recent_cv.pack(fill="x")
        self.recent_cv.bind("<Button-1>", self._on_recent)
        bf = ttk.Frame(right)
        bf.pack(side="bottom", fill="x", pady=(8, 0))
        ttk.Checkbutton(bf, text="On top", variable=self.pin_var,
                        command=self._apply_pin).pack(side="left")
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")

        get = self.rgb

        def put(rgb):
            self.set_rgb(rgb)
            self._commit()
        for w in list(self.fwidgets.values()) + [self.hex_entry]:
            app.register_colour_widget(w, get, put)
        for w in hf.winfo_children():
            if w.winfo_class() == "TEntry":
                app.register_colour_widget(w, get, put)
        self.sw.bind("<Button-3>", lambda e: app.colour_menu(e, get, put))

        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.bind("<Escape>", lambda e: self.close())
        for k in ("Left", "Right", "Up", "Down"):
            self.win.bind("<%s>" % k, lambda e, kk=k: self._on_arrow(e, kk, 1))
            self.win.bind("<Shift-%s>" % k, lambda e, kk=k: self._on_arrow(e, kk, 10))
        self._build_mode()
        self._draw_recent()

    # ---------------------------------------------------------- setup helpers
    def _apply_pin(self):
        try:
            self.win.attributes("-topmost", bool(self.pin_var.get()))
        except self.app.tk.TclError:
            pass

    def _field(self, parent, k, hi, row, col):
        from tkinter import ttk
        ttk.Label(parent, text=k + ":").grid(row=row, column=col, sticky="e", pady=1,
                                             padx=(8 if col else 0, 0))
        v = self.app.tk.StringVar()
        sp = ttk.Spinbox(parent, textvariable=v, from_=0, to=hi, increment=1, width=5,
                         command=lambda kk=k: self._on_field(kk))
        sp.grid(row=row, column=col + 1, sticky="w", padx=(4, 0), pady=1)
        v.trace_add("write", lambda *a, kk=k: self._on_field(kk))
        sp.bind("<Return>", lambda e: self.refresh())
        sp.bind("<FocusOut>", lambda e: (self.refresh(), self._commit()))
        sp.bind("<MouseWheel>", lambda e, kk=k: self._wheel_field(kk, e))
        sp.bind("<Shift-MouseWheel>", lambda e, kk=k: self._wheel_field(kk, e, 10))
        self.fvars[k] = v
        self.fwidgets[k] = sp

    # box / slider mode layouts
    HB_XY = "Hue + X/Y"
    HB_CHOICES = ("Hue", "Saturation", "Lightness", HB_XY)
    # HSL Box: dropdown -> (strip channel, square x, square y)
    HB_AXES = {"Hue": (0, 1, 2), "Saturation": (1, 0, 2), "Lightness": (2, 0, 1),
               HB_XY: (0, 1, 2)}
    # Photoshop: radio key -> (space, strip channel, square x, square y)
    PS_AXES = {"H": ("hsb", 0, 1, 2), "S": ("hsb", 1, 0, 2), "Bv": ("hsb", 2, 0, 1),
               "R": ("rgb", 0, 2, 1), "G": ("rgb", 1, 2, 0), "Bb": ("rgb", 2, 0, 1),
               "L": ("lab", 0, 1, 2), "a": ("lab", 1, 2, 0), "b": ("lab", 2, 1, 0)}
    PS_ROWS = (("H", "H:", "hsb", 0), ("S", "S:", "hsb", 1), ("Bv", "B:", "hsb", 2),
               None,
               ("R", "R:", "rgb", 0), ("G", "G:", "rgb", 1), ("Bb", "B:", "rgb", 2),
               None,
               ("L", "L:", "lab", 0), ("a", "a:", "lab", 1), ("b", "b:", "lab", 2))
    GS_MODES = {"OKLCH Sliders": "oklch", "LAB Sliders": "lab", "Greyscale Slider": "grey"}

    def _build_mode(self):
        from tkinter import ttk

        for ch in self.left.winfo_children():
            ch.destroy()
        self.sliders = {}
        self.gsliders = {}
        self.grev = set()              # gslider keys drawn high -> low
        self.gfields = {}
        self.box = None
        self.wheel = None
        self.sq = None
        self.strip = None
        self.bx = None
        mode = self.mode_var.get()
        L = self.left
        tk = self.app.tk
        for r in range(12):
            L.rowconfigure(r, weight=0)
        for c in range(4):
            L.columnconfigure(c, weight=0)
        L.columnconfigure(1, weight=1)
        if mode == "HSL Colour Wheel":
            L.rowconfigure(0, weight=1)
            self.wheel = tk.Canvas(L, highlightthickness=0, cursor="crosshair")
            self.wheel.grid(row=0, column=0, columnspan=3, sticky="nsew")
            self._bind_drag(self.wheel, "wheel")
            self.wheel.bind("<Configure>", lambda e: self._draw_wheel(full=True))
        elif mode == "HSL Box":
            L.columnconfigure(0, weight=1)
            L.columnconfigure(1, weight=0)
            L.rowconfigure(1, weight=1)
            want = self.app.s.get("picker_hslbox", "Hue")
            self.hb_var = tk.StringVar(value=want if want in self.HB_CHOICES else "Hue")
            self.strip = tk.Canvas(L, height=int(26 * self.ui), highlightthickness=0,
                                   cursor="hand2")
            self.strip.grid(row=0, column=0, sticky="ew", pady=(0, 6))
            cb = ttk.Combobox(L, textvariable=self.hb_var, values=self.HB_CHOICES,
                              state="readonly", width=11)
            cb.grid(row=0, column=1, sticky="e", padx=(8, 0), pady=(0, 6))
            cb.bind("<<ComboboxSelected>>", lambda e: self._hb_changed())
            self.sq = tk.Canvas(L, highlightthickness=1, highlightbackground="#555",
                                cursor="crosshair")
            self.sq.grid(row=1, column=0, columnspan=2, sticky="nsew")
            if self.hb_var.get() == self.HB_XY:
                # X bar: drag left = point left. Y bar: drag left = point up.
                for r, (i, name, rev) in enumerate(((1, "X  (left / right)", False),
                                                    (2, "Y  (up / down)", True)), 2):
                    c = tk.Canvas(L, height=int(26 * self.ui), highlightthickness=0,
                                  cursor="hand2")
                    c.grid(row=r, column=0, sticky="ew", pady=(6, 0))
                    ttk.Label(L, text=name).grid(row=r, column=1, sticky="w",
                                                 padx=(8, 0), pady=(6, 0))
                    key = "gs:hsl:%d" % i
                    c.bind("<Configure>", lambda e, kk=key: self._draw_gslider(kk))
                    self._bind_drag(c, key)
                    c.bind("<MouseWheel>", lambda e, kk=key: self._wheel_slider(kk, e, 1))
                    c.bind("<Shift-MouseWheel>",
                           lambda e, kk=key: self._wheel_slider(kk, e, 10))
                    self.gsliders[key] = c
                    if rev:
                        self.grev.add(key)
            self._bx_setup()
        elif mode == "Photoshop":
            L.columnconfigure(0, weight=1)
            L.columnconfigure(1, weight=0)
            L.rowconfigure(0, weight=1)
            want = self.app.s.get("picker_ps", "H")
            self.ps_var = tk.StringVar(value=want if want in self.PS_AXES else "H")
            self.sq = tk.Canvas(L, highlightthickness=1, highlightbackground="#555",
                                cursor="crosshair")
            self.sq.grid(row=0, column=0, sticky="nsew")
            self.strip = tk.Canvas(L, width=int(26 * self.ui), highlightthickness=0,
                                   cursor="hand2")
            self.strip.grid(row=0, column=1, sticky="ns", padx=(6, 0))
            rf = ttk.Frame(L)
            rf.grid(row=0, column=2, sticky="n", padx=(10, 0))
            for r, row in enumerate(self.PS_ROWS):
                if row is None:
                    ttk.Frame(rf, height=int(6 * self.ui)).grid(row=r, column=0)
                    continue
                key, label, space, i = row
                ttk.Radiobutton(rf, text=label, value=key, variable=self.ps_var,
                                command=self._bx_choice).grid(row=r, column=0, sticky="w")
                self._gfield(rf, space, i, r, 1)
            self._bx_setup()
        elif mode in self.GS_MODES:
            space = self.GS_MODES[mode]
            chans = pm.channels(space)
            for r, (name, _lo, _hi) in enumerate(chans):
                ttk.Label(L, text=name + ":").grid(row=r, column=0, sticky="w")
                c = tk.Canvas(L, height=int(26 * self.ui), highlightthickness=0,
                              cursor="hand2")
                c.grid(row=r, column=1, sticky="ew", padx=(6, 0), pady=3)
                key = "gs:%s:%d" % (space, r)
                c.bind("<Configure>", lambda e, kk=key: self._draw_gslider(kk))
                self._bind_drag(c, key)
                c.bind("<MouseWheel>", lambda e, kk=key: self._wheel_slider(kk, e, 1))
                c.bind("<Shift-MouseWheel>", lambda e, kk=key: self._wheel_slider(kk, e, 10))
                self.gsliders[key] = c
                self._gfield(L, space, r, r, 2)
            L.rowconfigure(len(chans), weight=1)
            self.box = tk.Canvas(L, highlightthickness=1,
                                 highlightbackground="#555", cursor="crosshair")
            self.box.grid(row=len(chans), column=0, columnspan=3, sticky="nsew",
                          pady=(8, 0))
            self.box.bind("<Configure>", lambda e: self._draw_box(full=True))
            self._bind_drag(self.box, "box")
        else:
            keys = "RGB" if mode == "RGB Sliders" else "HSL"
            for r, k in enumerate(keys):
                ttk.Label(L, text=k + ":").grid(row=r, column=0, sticky="w")
                c = tk.Canvas(L, height=int(26 * self.ui), highlightthickness=0,
                              cursor="hand2")
                c.grid(row=r, column=1, sticky="ew", padx=(6, 0), pady=3)
                c.bind("<Configure>", lambda e, kk=k: self._draw_slider(kk))
                self._bind_drag(c, k)
                c.bind("<MouseWheel>", lambda e, kk=k: self._wheel_slider(kk, e, 1))
                c.bind("<Shift-MouseWheel>", lambda e, kk=k: self._wheel_slider(kk, e, 10))
                self.sliders[k] = c
            L.rowconfigure(3, weight=1)
            self.box = tk.Canvas(L, highlightthickness=1,
                                 highlightbackground="#555", cursor="crosshair")
            self.box.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=(8, 0))
            self.box.bind("<Configure>", lambda e: self._draw_box(full=True))
            self._bind_drag(self.box, "box")
        self.s_app_mode()
        self.refresh()
        self._fit_window()

    def _fit_window(self):
        """Grow the window if this mode needs more room than it has."""
        w = self.win
        try:
            w.update_idletasks()
            rw, rh = w.winfo_reqwidth(), w.winfo_reqheight()
            cw, ch = w.winfo_width(), w.winfo_height()
            if cw > 1 and (cw < rw or ch < rh):
                w.geometry("%dx%d" % (max(cw, rw), max(ch, rh)))
        except self.app.tk.TclError:
            pass

    def _bx_setup(self):
        self._bind_drag(self.sq, "sq")
        self._bind_drag(self.strip, "strip")
        self.sq.bind("<Configure>", lambda e: self._draw_bx())
        self.strip.bind("<Configure>", lambda e: self._draw_bx())
        self.strip.bind("<MouseWheel>", lambda e: self._wheel_slider("strip", e, 1))
        self.strip.bind("<Shift-MouseWheel>", lambda e: self._wheel_slider("strip", e, 10))
        self._bx_choice(save=False)

    def _hb_changed(self):
        """HSL Box dropdown: rebuild when the X/Y bars come or go."""
        had = bool(self.gsliders)
        if had != (self.hb_var.get() == self.HB_XY):
            self.app.s["picker_hslbox"] = self.hb_var.get()
            self._build_mode()
        else:
            self._bx_choice()

    def _bx_choice(self, save=True):
        """(Re)read the HSL Box dropdown / Photoshop radio into self.bx."""
        if self.mode_var.get() == "HSL Box":
            ch = self.hb_var.get()
            si, xi, yi = self.HB_AXES[ch]
            self.bx = {"space": "hsl", "si": si, "xi": xi, "yi": yi, "orient": "h"}
            if save:
                self.app.s["picker_hslbox"] = ch
        else:
            k = self.ps_var.get()
            space, si, xi, yi = self.PS_AXES[k]
            self.bx = {"space": space, "si": si, "xi": xi, "yi": yi, "orient": "v"}
            if save:
                self.app.s["picker_ps"] = k
        self.active = "sq"
        if save:
            self._draw_bx()

    def _gfield(self, parent, space, i, row, col):
        """Number field for one channel of a model (Photoshop / slider modes)."""
        from tkinter import ttk
        name, lo, hi = pm.channels(space)[i]
        v = self.app.tk.StringVar()
        sp = ttk.Spinbox(parent, textvariable=v, from_=lo, to=hi,
                         increment=0.5 if (space, i) == ("oklch", 1) else 1, width=6,
                         command=lambda: self._on_gfield(space, i))
        sp.grid(row=row, column=col, sticky="w", padx=(6, 0), pady=1)
        v.trace_add("write", lambda *a: self._on_gfield(space, i))
        sp.bind("<Return>", lambda e: self.refresh())
        sp.bind("<FocusOut>", lambda e: (self.refresh(), self._commit()))
        sp.bind("<MouseWheel>", lambda e: self._wheel_gfield(space, i, e, 1))
        sp.bind("<Shift-MouseWheel>", lambda e: self._wheel_gfield(space, i, e, 10))
        self.gfields[(space, i)] = (v, sp)

    def s_app_mode(self):
        self.app.s["picker_mode"] = self.mode_var.get()

    # ---------------------------------------------------------- state
    def rgb(self):
        return rgb_round(self.rgbf)

    def hsl(self):
        return [self.h, self.s, self.l]

    def _set_hsl(self, h, s, l, emit=True):
        self.h = h % 360.0
        self.s = min(max(s, 0.0), 100.0)
        self.l = min(max(l, 0.0), 100.0)
        self.rgbf = hsl_to_rgb(self.h, self.s, self.l)
        self.refresh()
        if emit:
            self._emit()

    def set_rgb(self, rgb, emit=True, keep_hue=False):
        """New colour from RGB. Hue (and saturation for black / white) are
        kept when the colour can't define them."""
        r, g, b = (float(v) for v in rgb)
        h, s, l = rgb_to_hsl(r, g, b)
        if max(r, g, b) - min(r, g, b) < 1e-9 or keep_hue:
            h = self.h
        if l <= 1e-9 or l >= 100.0 - 1e-9:
            s = self.s
        self.h, self.s, self.l = h, s, l
        self.rgbf = (r, g, b)
        self.refresh()
        if emit:
            self._emit()

    def set_target(self, cb, rgb, hsl=None, label=""):
        """Edit another colour (a ramp node etc.) - no change is sent."""
        self.target = cb
        self.target_label = label
        self.target_var.set(("Editing: " + label) if label else "No target - pick freely")
        rgb = tuple(rgb)
        self.old = rgb
        if hsl and rgb_round(hsl_to_rgb(*hsl)) == rgb:
            self.h, self.s, self.l = hsl[0] % 360.0, hsl[1], hsl[2]
            self.rgbf = hsl_to_rgb(*hsl)
        else:
            self.set_rgb(rgb, emit=False)
        self.refresh()

    def _emit(self):
        if self.target is not None:
            self.target(self.rgb(), self.hsl())

    def _commit(self):
        """End of a gesture: remember the colour in Recent."""
        self.app.add_recent(self.rgb())
        self._draw_recent()

    # ---------------------------------------------------------- drawing
    def refresh(self):
        self._lock = True
        try:
            r, g, b = self.rgb()
            vals = {"R": r, "G": g, "B": b, "H": int(round(self.h)) % 360,
                    "S": int(round(self.s)), "L": int(round(self.l))}
            for k, v in vals.items():
                w = self.fwidgets[k]
                if self.win.focus_get() is not w or not self._typed_ok(k):
                    self.fvars[k].set(str(v))
            for k, v in (("R#", r), ("G#", g), ("B#", b)):
                self.hvars[k].set("%02X" % v)
            if self.win.focus_get() is not self.hex_entry \
                    or parse_colour(self.hex_var.get()) != self.rgb():
                self.hex_var.set(hex_of(self.rgb())[1:])
            self._refresh_gfields()
        finally:
            self._lock = False
        sw = self.sw
        sw.delete("all")
        W, H = int(sw.cget("width")), int(sw.cget("height"))
        sw.create_rectangle(0, 0, W // 2, H, fill=hex_of(self.rgb()), outline="")
        sw.create_rectangle(W // 2, 0, W, H, fill=hex_of(self.old), outline="")
        for k in self.sliders:
            self._draw_slider(k)
        for k in self.gsliders:
            self._draw_gslider(k)
        if self.sq is not None:
            self._draw_bx()
        if self.box is not None:
            self._draw_box(full=self.mode_var.get() == "HSL Sliders")
        if self.wheel is not None:
            self._draw_wheel()

    def _typed_ok(self, k):
        try:
            return int(float(self.fvars[k].get())) == int(round(
                {"R": self.rgbf[0], "G": self.rgbf[1], "B": self.rgbf[2],
                 "H": self.h, "S": self.s, "L": self.l}[k]))
        except ValueError:
            return False

    def _track(self, k):
        """(function t -> rgb float, value 0..1) for slider k."""
        r, g, b = self.rgbf
        h, s, l = self.h, self.s, self.l
        if k == "R":
            return (lambda t: (t * 255, g, b)), r / 255.0
        if k == "G":
            return (lambda t: (r, t * 255, b)), g / 255.0
        if k == "B":
            return (lambda t: (r, g, t * 255)), b / 255.0
        if k == "H":
            return (lambda t: hsl_to_rgb(t * 360, 100, 50)), h / 360.0
        if k == "S":
            return (lambda t: hsl_to_rgb(h, t * 100, l)), s / 100.0
        return (lambda t: hsl_to_rgb(h, s, t * 100)), l / 100.0

    def _slider_geom(self, c):
        W, H = max(c.winfo_width(), 20), max(c.winfo_height(), 10)
        pad = H // 2
        return pad, W - pad, H

    def _draw_slider(self, k):
        from PIL import Image, ImageTk

        c = self.sliders.get(k)
        if c is None:
            return
        x0, x1, H = self._slider_geom(c)
        if x1 - x0 < 4:
            return
        f, v = self._track(k)
        strip = Image.new("RGB", (128, 1))
        strip.putdata([rgb_round(f(i / 127.0)) for i in range(128)])
        th = max(6, H // 3)
        img = strip.resize((int(x1 - x0), th), Image.BILINEAR)
        tki = ImageTk.PhotoImage(img)
        self._imgs["sl" + k] = tki
        c.delete("all")
        c.create_image(x0, (H - th) // 2, anchor="nw", image=tki)
        x = x0 + v * (x1 - x0)
        rad = H / 2.0 - 2
        c.create_oval(x - rad, H / 2 - rad, x + rad, H / 2 + rad, outline="#000000",
                      width=3)
        c.create_oval(x - rad, H / 2 - rad, x + rad, H / 2 + rad, outline="#ffffff",
                      width=2, fill=hex_of(self.rgb()))

    def _draw_box(self, full=False):
        from PIL import Image, ImageTk

        c = self.box
        W, H = c.winfo_width(), c.winfo_height()
        if W < 10 or H < 10:
            return
        hsl_mode = self.mode_var.get() == "HSL Sliders"
        key = ("box", W, H, round(self.s, 1) if hsl_mode else None)
        if full or self._imgs.get("boxkey") != key:
            fb, grey = _full_box_image()
            base = Image.blend(grey, fb, self.s / 100.0) if hsl_mode else fb
            self._imgs["box"] = ImageTk.PhotoImage(base.resize((W, H), Image.BILINEAR))
            self._imgs["boxkey"] = key
        c.delete("all")
        c.create_image(0, 0, anchor="nw", image=self._imgs["box"])
        x = self.h / 360.0 * (W - 1)
        y = (1.0 - self.l / 100.0) * (H - 1)
        self._crosshair(c, x, y)

    def _crosshair(self, c, x, y):
        g, n = 4, 10
        for col, w in (("#000000", 3), ("#ffffff", 1)):
            c.create_line(x - g - n, y, x - g, y, fill=col, width=w)
            c.create_line(x + g, y, x + g + n, y, fill=col, width=w)
            c.create_line(x, y - g - n, x, y - g, fill=col, width=w)
            c.create_line(x, y + g, x, y + g + n, fill=col, width=w)

    # ---------------------------------------------------------- colour models
    def _get_vals(self, space):
        """Current colour as channel values of a model. Values set from that
        model are remembered so undefined channels (hue of a grey, saturation
        of black, clipped Lab) stay where they were put."""
        if space == "hsl":
            return [self.h, self.s, self.l]
        mem = self._vals.get(space)
        if mem and mem[1] == self.rgb():
            return list(mem[0])
        return pm.to_vals(space, self.rgbf, self.h)

    def _set_vals(self, space, vals):
        vals = [pm.clamp_val(space, i, v) for i, v in enumerate(vals)]
        if space == "hsl":
            self._set_hsl(min(vals[0], 359.999), vals[1], vals[2])
            return
        rgbf, _ok = pm.from_vals(space, vals)
        self._vals[space] = (list(vals), rgb_round(rgbf))
        if space == "hsb":
            self.h = min(vals[0], 359.999) % 360.0
            self.set_rgb(rgbf, keep_hue=True)
        else:
            self.set_rgb(rgbf)

    @staticmethod
    def _fmt(space, i, v):
        if (space, i) == ("oklch", 1):
            return "%.1f" % v
        if pm.HUE_CH.get(space) == i:
            return str(int(round(v)) % 360)
        return str(int(round(v)))

    def _step_model(self, space, i, n):
        vals = self._get_vals(space)
        step = 0.5 if (space, i) == ("oklch", 1) else 1.0
        v = round(vals[i] / step) * step + n * step
        if pm.HUE_CH.get(space) == i:
            v %= 360.0
        vals[i] = v
        self._set_vals(space, vals)

    def _ring_marker(self, c, x, y, r=7):
        r = r * self.ui
        c.create_oval(x - r, y - r, x + r, y + r, outline="#000000", width=3)
        c.create_oval(x - r, y - r, x + r, y + r, outline="#ffffff", width=1)

    def _draw_bx(self):
        """Square + strip for HSL Box / Photoshop."""
        from PIL import ImageTk

        if self.bx is None or self.sq is None:
            return
        b = self.bx
        space = b["space"]
        vals = self._get_vals(space)
        chans = pm.channels(space)

        def pos(i):
            _n, lo, hi = chans[i]
            return min(max((vals[i] - lo) / (hi - lo), 0.0), 1.0)

        c = self.sq
        W, H = c.winfo_width(), c.winfo_height()
        if W >= 10 and H >= 10:
            fixed = [k for k in range(3) if k not in (b["xi"], b["yi"])][0]
            key = ("sq", space, b["xi"], b["yi"], round(vals[fixed], 2), W, H)
            if self._imgs.get("sqkey") != key:
                img, mask = pm.plane_image(space, b["xi"], b["yi"], vals, res=72)
                self._imgs["sq"] = ImageTk.PhotoImage(pm.finish(img, mask, (W, H)))
                self._imgs["sqkey"] = key
            c.delete("all")
            c.create_image(0, 0, anchor="nw", image=self._imgs["sq"])
            self._ring_marker(c, pos(b["xi"]) * (W - 1), (1.0 - pos(b["yi"])) * (H - 1))
        c = self.strip
        W, H = c.winfo_width(), c.winfo_height()
        if W < 10 or H < 10:
            return
        img, mask = pm.strip_image(space, b["si"], vals)
        horiz = b["orient"] == "h"
        a0, a1, th = self._strip_geom(c)
        if a1 - a0 < 4:
            return
        if horiz:
            pic = pm.finish(img, mask, (a1 - a0, th))
        else:
            from PIL import Image
            pic = pm.finish(img, mask, (a1 - a0, th)).transpose(Image.ROTATE_90)
        tki = ImageTk.PhotoImage(pic)
        self._imgs["strip"] = tki
        c.delete("all")
        t = pos(b["si"])
        rad = min(W, H) / 2.0 - 2 if not horiz else H / 2.0 - 2
        if horiz:
            c.create_image(a0, (H - th) // 2, anchor="nw", image=tki)
            x, y = a0 + t * (a1 - a0), H / 2.0
        else:
            c.create_image((W - th) // 2, a0, anchor="nw", image=tki)
            x, y = W / 2.0, a1 - t * (a1 - a0)
            rad = W / 2.0 - 2
        c.create_oval(x - rad, y - rad, x + rad, y + rad, outline="#000000", width=3)
        c.create_oval(x - rad, y - rad, x + rad, y + rad, outline="#ffffff", width=2,
                      fill=hex_of(self.rgb()))

    def _strip_geom(self, c):
        """(start, end, thickness) of the strip along its long axis."""
        W, H = max(c.winfo_width(), 10), max(c.winfo_height(), 10)
        if self.bx is not None and self.bx["orient"] == "v" and c is self.strip:
            pad = W // 2
            return pad, H - pad, max(6, W // 2)
        pad = H // 2
        return pad, W - pad, max(6, H // 3)

    def _draw_gslider(self, key):
        from PIL import ImageTk

        c = self.gsliders.get(key)
        if c is None:
            return
        _g, space, i = key.split(":")
        i = int(i)
        x0, x1, H = self._slider_geom(c)
        if x1 - x0 < 4:
            return
        vals = self._get_vals(space)
        img, mask = pm.strip_image(space, i, vals, n=128)
        th = max(6, H // 3)
        pic = pm.finish(img, mask, (int(x1 - x0), th))
        rev = key in self.grev
        if rev:
            from PIL import Image
            pic = pic.transpose(Image.FLIP_LEFT_RIGHT)
        tki = ImageTk.PhotoImage(pic)
        self._imgs[key] = tki
        c.delete("all")
        c.create_image(x0, (H - th) // 2, anchor="nw", image=tki)
        _n, lo, hi = pm.channels(space)[i]
        t = min(max((vals[i] - lo) / (hi - lo), 0.0), 1.0)
        if rev:
            t = 1.0 - t
        x = x0 + t * (x1 - x0)
        rad = H / 2.0 - 2
        c.create_oval(x - rad, H / 2 - rad, x + rad, H / 2 + rad, outline="#000000",
                      width=3)
        c.create_oval(x - rad, H / 2 - rad, x + rad, H / 2 + rad, outline="#ffffff",
                      width=2, fill=hex_of(self.rgb()))

    def _refresh_gfields(self):
        cache = {}
        for (space, i), (v, w) in self.gfields.items():
            if space not in cache:
                cache[space] = self._get_vals(space)
            txt = self._fmt(space, i, cache[space][i])
            if self.win.focus_get() is w:
                try:
                    if self._fmt(space, i, float(v.get())) == txt:
                        continue
                except ValueError:
                    pass
            if v.get() != txt:
                v.set(txt)

    def _on_gfield(self, space, i):
        if self._lock:
            return
        v, _w = self.gfields[(space, i)]
        try:
            x = float(v.get())
        except ValueError:
            return
        _n, lo, hi = pm.channels(space)[i]
        vals = self._get_vals(space)
        if not lo <= x <= hi or self._fmt(space, i, x) == self._fmt(space, i, vals[i]):
            return
        vals[i] = x
        self._set_vals(space, vals)

    def _wheel_gfield(self, space, i, ev, n):
        self._step_model(space, i, n if ev.delta > 0 else -n)
        self._commit()
        return "break"

    def _wheel_geom(self):
        c = self.wheel
        W, H = c.winfo_width(), c.winfo_height()
        S = max(min(W, H) - 8, 40)
        cx, cy = W / 2.0, H / 2.0
        ro = S / 2.0
        ri = ro * 0.80
        rt = ri * 0.96
        return cx, cy, ro, ri, rt, S

    def _draw_wheel(self, full=False):
        from PIL import Image, ImageChops, ImageTk

        c = self.wheel
        if c is None or c.winfo_width() < 50:
            return
        cx, cy, ro, ri, rt, S = self._wheel_geom()
        key = ("ring", S)
        if full or self._imgs.get("ringkey") != key:
            self._imgs["ring"] = ImageTk.PhotoImage(
                _ring_image().resize((int(S), int(S)), Image.BILINEAR))
            self._imgs["ringkey"] = key
        tkey = ("tri", int(2 * rt), round(self.h, 1))
        if full or self._imgs.get("trikey") != tkey:
            tip, wht, msk = _tri_masks()
            pr, pg, pb = hsl_to_rgb(self.h, 100, 50)
            bands = [ImageChops.add(tip.point(lambda v, p=p: v * p / 255.0), wht)
                     for p in (pr, pg, pb)]
            im = Image.merge("RGB", bands)
            im.putalpha(msk)
            c0 = (im.size[0] - 1) / 2.0           # tip follows the ring marker
            im = im.rotate(-self.h, resample=Image.BICUBIC, center=(c0, c0))
            sz = max(int(2 * rt), 8)
            self._imgs["tri"] = ImageTk.PhotoImage(im.resize((sz, sz), Image.BILINEAR))
            self._imgs["trikey"] = tkey
        c.delete("all")
        c.create_image(cx, cy, image=self._imgs["ring"])
        c.create_image(cx, cy, image=self._imgs["tri"])
        # ring marker
        a = math.radians(self.h)
        rm = (ro + ri) / 2.0
        mx, my = cx + rm * math.cos(a), cy + rm * math.sin(a)
        rr = (ro - ri) / 2.0 - 1
        c.create_oval(mx - rr, my - rr, mx + rr, my + rr, outline="#000000", width=3)
        c.create_oval(mx - rr, my - rr, mx + rr, my + rr, outline="#ffffff", width=2)
        # triangle marker
        px, py = self._tri_point()
        self._crosshair(c, px, py)
        c.create_text(8, c.winfo_height() - 8, anchor="sw", fill="#888",
                      font=("Consolas", 10),
                      text="H: %d\nS: %d\nL: %d" % (round(self.h) % 360, round(self.s),
                                                    round(self.l)))

    def _tri_weights(self):
        r, g, b = self.rgbf
        mx, mn = max(r, g, b), min(r, g, b)
        wc = (mx - mn) / 255.0
        ww = mn / 255.0
        return wc, ww, max(0.0, 1.0 - wc - ww)

    def _tri_point(self):
        cx, cy, ro, ri, rt, S = self._wheel_geom()
        A, B, C = _tri_vertices(cx, cy, rt, self.h)
        wc, ww, wk = self._tri_weights()
        return (wc * A[0] + wk * B[0] + ww * C[0], wc * A[1] + wk * B[1] + ww * C[1])

    # ---------------------------------------------------------- dragging
    def _bind_drag(self, c, ctl):
        c.bind("<ButtonPress-1>", lambda e: self._press(e, ctl))
        c.bind("<B1-Motion>", lambda e: self._motion(e, ctl))
        c.bind("<ButtonRelease-1>", lambda e: self._release(e, ctl))

    def _press(self, ev, ctl):
        self.win.focus_set()
        if ctl == "wheel":
            cx, cy, ro, ri, rt, S = self._wheel_geom()
            r = math.hypot(ev.x - cx, ev.y - cy)
            ctl = "ring" if r >= ri - 2 else "tri"
        self.active = ctl
        self._drag = {"ctl": ctl, "vx": float(ev.x), "vy": float(ev.y),
                      "lx": ev.x, "ly": ev.y, "ax": float(ev.x), "ay": float(ev.y),
                      "axis": None}
        self._apply_point(ctl, ev.x, ev.y, ev.widget)

    def _motion(self, ev, ctl):
        d = self._drag
        if not d:
            return
        f = self.FINE if ev.state & 0x0001 else 1.0
        d["vx"] += (ev.x - d["lx"]) * f
        d["vy"] += (ev.y - d["ly"]) * f
        d["lx"], d["ly"] = ev.x, ev.y
        x, y = d["vx"], d["vy"]
        if ev.state & 0x0004:                      # Ctrl: lock to one axis
            if d["axis"] is None and abs(x - d["ax"]) + abs(y - d["ay"]) > 3:
                d["axis"] = "x" if abs(x - d["ax"]) >= abs(y - d["ay"]) else "y"
            if d["axis"] == "x":
                y = d["ay"]
            elif d["axis"] == "y":
                x = d["ax"]
        else:
            d["axis"] = None
            d["ax"], d["ay"] = x, y
        self._apply_point(d["ctl"], x, y, ev.widget)

    def _release(self, _ev, _ctl):
        if self._drag:
            self._drag = None
            self._commit()

    def _apply_point(self, ctl, x, y, widget):
        if ctl == "sq" and self.bx is not None:
            b = self.bx
            W, H = widget.winfo_width(), widget.winfo_height()
            tx = min(max(x / max(W - 1, 1), 0.0), 1.0)
            ty = 1.0 - min(max(y / max(H - 1, 1), 0.0), 1.0)
            chans = pm.channels(b["space"])
            vals = self._get_vals(b["space"])
            for i, t in ((b["xi"], tx), (b["yi"], ty)):
                _n, lo, hi = chans[i]
                vals[i] = lo + t * (hi - lo)
                if pm.HUE_CH.get(b["space"]) == i:
                    vals[i] = min(vals[i], 359.999)
            self._set_vals(b["space"], vals)
            return
        if ctl == "strip" and self.bx is not None:
            b = self.bx
            a0, a1, _th = self._strip_geom(widget)
            p = x if b["orient"] == "h" else y
            t = min(max((p - a0) / max(a1 - a0, 1), 0.0), 1.0)
            if b["orient"] == "v":
                t = 1.0 - t
            _n, lo, hi = pm.channels(b["space"])[b["si"]]
            vals = self._get_vals(b["space"])
            vals[b["si"]] = lo + t * (hi - lo)
            if pm.HUE_CH.get(b["space"]) == b["si"]:
                vals[b["si"]] = min(vals[b["si"]], 359.999)
            self._set_vals(b["space"], vals)
            return
        if ctl.startswith("gs:"):
            _g, space, i = ctl.split(":")
            i = int(i)
            x0, x1, _H = self._slider_geom(widget)
            t = min(max((x - x0) / max(x1 - x0, 1), 0.0), 1.0)
            if ctl in self.grev:
                t = 1.0 - t
            _n, lo, hi = pm.channels(space)[i]
            vals = self._get_vals(space)
            vals[i] = lo + t * (hi - lo)
            if pm.HUE_CH.get(space) == i:
                vals[i] = min(vals[i], 359.999)
            self._set_vals(space, vals)
            return
        if ctl in ("R", "G", "B", "H", "S", "L"):
            x0, x1, _H = self._slider_geom(widget)
            t = min(max((x - x0) / max(x1 - x0, 1), 0.0), 1.0)
            self._set_channel(ctl, t)
        elif ctl == "box":
            W, H = widget.winfo_width(), widget.winfo_height()
            hh = min(max(x / max(W - 1, 1), 0.0), 1.0) * 360.0
            ll = (1.0 - min(max(y / max(H - 1, 1), 0.0), 1.0)) * 100.0
            if hh >= 360.0:
                hh = 359.999
            if self.mode_var.get() != "HSL Sliders":
                self._set_hsl(hh, 100.0, ll)
            else:
                self._set_hsl(hh, self.s, ll)
        elif ctl == "ring":
            cx, cy, ro, ri, rt, S = self._wheel_geom()
            hh = math.degrees(math.atan2(y - cy, x - cx)) % 360.0
            wc, ww, wk = self._tri_weights()
            pr = hsl_to_rgb(hh, 100, 50)
            self.h = hh
            self.set_rgb(tuple(wc * p + ww * 255.0 for p in pr), keep_hue=True)
        elif ctl == "tri":
            cx, cy, ro, ri, rt, S = self._wheel_geom()
            A, B, C = _tri_vertices(cx, cy, rt, self.h)
            wc, wk, ww = _bary((x, y), A, B, C)
            wc, wk, ww = max(wc, 0.0), max(wk, 0.0), max(ww, 0.0)
            tot = wc + wk + ww or 1.0
            wc, ww = wc / tot, ww / tot
            pr = hsl_to_rgb(self.h, 100, 50)
            self.set_rgb(tuple(min(255.0, wc * p + ww * 255.0) for p in pr), keep_hue=True)

    def _set_channel(self, k, t):
        if k in "RGB":
            v = list(self.rgbf)
            v["RGB".index(k)] = t * 255.0
            self.set_rgb(v)
        elif k == "H":
            self._set_hsl(min(t, 0.99999) * 360.0, self.s, self.l)
        elif k == "S":
            self._set_hsl(self.h, t * 100.0, self.l)
        else:
            self._set_hsl(self.h, self.s, t * 100.0)

    def _step_ctl(self, k, n, axis="x"):
        """Step the channel a control drives (strip / square axis / slider)."""
        if k == "strip" and self.bx is not None:
            self._step_model(self.bx["space"], self.bx["si"], n)
        elif k == "sq" and self.bx is not None:
            self._step_model(self.bx["space"], self.bx["xi" if axis == "x" else "yi"], n)
        elif k.startswith("gs:"):
            _g, space, i = k.split(":")
            self._step_model(space, int(i), n)
        else:
            self._step_channel(k, n)

    def _channel_value(self, k):
        return {"R": self.rgbf[0], "G": self.rgbf[1], "B": self.rgbf[2],
                "H": self.h, "S": self.s, "L": self.l}[k]

    def _step_channel(self, k, n):
        hi = {"R": 255.0, "G": 255.0, "B": 255.0, "H": 360.0, "S": 100.0, "L": 100.0}[k]
        v = round(self._channel_value(k)) + n
        if k == "H":
            v %= 360
        v = min(max(v, 0.0), hi)
        self._set_channel(k, v / hi if k != "H" else (v % 360) / 360.0)

    def _wheel_slider(self, k, ev, n):
        self.active = k
        self._step_ctl(k, n if ev.delta > 0 else -n)
        self._commit()
        return "break"

    def _on_arrow(self, ev, key, n):
        cls = ev.widget.winfo_class() if hasattr(ev.widget, "winfo_class") else ""
        if cls in ("TEntry", "Entry", "TSpinbox", "Spinbox", "TCombobox"):
            return
        ctl = self.active
        if ctl is None:
            return
        sign = 1 if key in ("Right", "Up") else -1
        if ctl in self.grev and key in ("Left", "Right"):
            sign = -sign
        if ctl in ("R", "G", "B", "H", "S", "L"):
            self._step_channel(ctl, sign * n)
        elif ctl in ("box", "tri"):
            if key in ("Left", "Right"):
                if ctl == "box":
                    self._step_channel("H", sign * n)
                else:
                    self._step_channel("S", sign * n)
            else:
                self._step_channel("L", sign * n)
        elif ctl == "ring":
            self._step_channel("H", sign * n)
        elif ctl == "sq":
            self._step_ctl("sq", sign * n, "x" if key in ("Left", "Right") else "y")
        elif ctl == "strip" or ctl.startswith("gs:"):
            self._step_ctl(ctl, sign * n)
        else:
            return
        self._commit()
        return "break"

    # ---------------------------------------------------------- fields
    def _on_field(self, k):
        if self._lock:
            return
        try:
            v = float(self.fvars[k].get())
        except ValueError:
            return
        hi = {"R": 255, "G": 255, "B": 255, "H": 360, "S": 100, "L": 100}[k]
        if not 0 <= v <= hi or abs(v - round(self._channel_value(k))) < 1e-9:
            return
        if k == "H":
            self._set_hsl(v % 360.0, self.s, self.l)
        else:
            self._set_channel(k, v / hi)

    def _wheel_field(self, k, ev, n=1):
        self._step_channel(k, n if ev.delta > 0 else -n)
        self._commit()
        return "break"

    def _on_hexpart(self, k):
        try:
            v = int(self.hvars[k].get().strip().lstrip("#"), 16)
        except ValueError:
            self.refresh()
            return
        if 0 <= v <= 255:
            rgb = list(self.rgb())
            rgb[("R#", "G#", "B#").index(k)] = v
            self.set_rgb(rgb)
            self._commit()
        else:
            self.refresh()

    def _on_hex(self, live=False, quiet=False):
        if self._lock:
            return
        txt = self.hex_var.get().strip()
        if live and not (len(txt.lstrip("#")) == 6 or "," in txt):
            return                                 # wait for a full value
        c = parse_colour(txt)
        if c is None:
            if not live and not quiet:
                self.refresh()
            return
        if c != self.rgb():
            self.set_rgb(c)
        if not live:
            self._commit()

    # ---------------------------------------------------------- swatches
    def _on_swatch(self, ev):
        W = int(self.sw.cget("width"))
        if ev.x >= W // 2:                         # old half: revert
            self.set_rgb(self.old)
            self._commit()

    def _draw_recent(self):
        c = self.recent_cv
        c.delete("all")
        sz = int(18 * self.ui)
        for k, hx in enumerate(self.app.s.get("recent_colours", [])[:16]):
            x = (k % 8) * (sz + 3)
            y = (k // 8) * (sz + 3)
            c.create_rectangle(x, y, x + sz, y + sz, fill=hx, outline="#777")

    def _on_recent(self, ev):
        sz = int(18 * self.ui) + 3
        k = (ev.y // sz) * 8 + ev.x // sz
        rec = self.app.s.get("recent_colours", [])
        if ev.x // sz < 8 and 0 <= k < len(rec):
            c = parse_colour(rec[k])
            if c:
                self.set_rgb(c)

    def eyedropper(self):
        self._dropper = EyeDropper(self.app, self._picked)

    def _picked(self, rgb):
        self._last_pick = rgb
        self.last_cv.configure(background=hex_of(rgb))
        self.set_rgb(rgb)
        self._commit()

    def _use_last(self):
        if self._last_pick:
            self.set_rgb(self._last_pick)
            self._commit()

    def close(self):
        try:
            self.app.s["picker_geometry"] = self.win.geometry()
        except self.app.tk.TclError:
            pass
        self.app.s["picker_pin"] = bool(self.pin_var.get())
        self.app.s["picker_mode"] = self.mode_var.get()
        if self._dropper is not None:
            self._dropper.close()
        self.app.picker = None
        self.win.destroy()
