"""cleanpal GUI (tkinter)."""
