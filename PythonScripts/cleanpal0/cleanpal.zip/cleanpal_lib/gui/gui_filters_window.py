"""Preview filters window: a tick-box tree of stock + custom filter groups,
custom entry editor, and export / import of custom entries (.cpfilters)."""

import json
import os

from ..cleanpal_lib_constants import PRESET_DIR, VERSION
from ..cleanpal_lib_gfxfilters import (
    ALL_BLOCKS, STOCK_SECTIONS, TYPE_BLOCKS, clean_custom, new_custom_id, parse_patterns,
    stock_tree,
)

ON, OFF, PART = "☑", "☐", "▣"
EDIT_MARK = "  ✎"
FILE_EXT = ".cpfilters"


def _tree_style(app, name):
    """A Treeview style whose rows fit the (DPI-scaled) font."""
    from tkinter import font as tkfont
    from tkinter import ttk
    st = ttk.Style(app.root)
    try:
        ls = tkfont.nametofont("TkDefaultFont").metrics("linespace")
    except Exception:  # noqa: BLE001
        ls = 16
    st.configure(name, rowheight=int(ls * 1.35),
                 indent=int(18 * getattr(app, "ui", 1.0)))
    return name


class CheckTree:
    """Treeview of tick boxes. Leaf ids live in node_own; a node's state is
    taken from every leaf under it (its own + descendants)."""

    def __init__(self, parent, app, ticked, on_change, height=18):
        from tkinter import ttk
        self.app = app
        self.ticked = ticked                     # shared set of leaf ids
        self.on_change = on_change
        self.tv = ttk.Treeview(parent, show="tree", selectmode="none", height=height,
                               style=_tree_style(app, "Filters.Treeview"))
        sb = ttk.Scrollbar(parent, orient="vertical", command=self.tv.yview)
        self.tv.configure(yscrollcommand=sb.set)
        self.tv.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        parent.rowconfigure(0, weight=1)
        parent.columnconfigure(0, weight=1)
        self.node_own = {}                       # iid -> leaf id or None
        self.label = {}                          # iid -> text
        self.groups = {}                         # node iid -> [leaf ids]: one at a time
        self.tv.bind("<Button-1>", self._click)

    def clear(self):
        self.tv.delete(*self.tv.get_children())
        self.node_own.clear()
        self.label.clear()
        self.groups.clear()

    def add(self, parent, iid, text, own=None, open_=False):
        self.tv.insert(parent, "end", iid=iid, text=text, open=open_)
        self.node_own[iid] = own
        self.label[iid] = text

    def leaves(self, iid):
        out = []
        if self.node_own.get(iid):
            out.append(self.node_own[iid])
        for ch in self.tv.get_children(iid):
            out.extend(self.leaves(ch))
        return out

    def state(self, iid):
        lv = self.leaves(iid)
        if not lv:
            return OFF
        units = {}                               # a one-at-a-time group counts once
        member = {x: g for g, xs in self.groups.items() for x in xs}
        for x in lv:
            k = member.get(x, x)
            units[k] = units.get(k, False) or x in self.ticked
        n = sum(1 for v in units.values() if v)
        return ON if n == len(units) else OFF if n == 0 else PART

    def refresh(self):
        def walk(p):
            for ch in self.tv.get_children(p):
                self.tv.item(ch, text="%s  %s" % (self.state(ch), self.label[ch]))
                walk(ch)
        walk("")

    def toggle(self, iid):
        grp = iid if iid in self.groups else (
            self.tv.parent(iid) if self.tv.parent(iid) in self.groups else None)
        if grp is not None:                      # one at a time
            xs = self.groups[grp]
            own = self.node_own.get(iid)
            if iid == grp:
                if any(x in self.ticked for x in xs):
                    self.ticked.difference_update(xs)
                else:
                    self.ticked.add(xs[0])
            elif own in self.ticked:
                self.ticked.discard(own)
            else:
                self.ticked.difference_update(xs)
                self.ticked.add(own)
            self.refresh()
            self.on_change()
            return
        lv = self.leaves(iid)
        if not lv:
            return
        if self.state(iid) == ON:
            self.ticked.difference_update(lv)
        else:
            self.ticked.update(lv)
            for xs in self.groups.values():      # ticking a block: first of each group
                on = [x for x in xs if x in self.ticked]
                if len(on) > 1:
                    self.ticked.difference_update(xs)
                    self.ticked.add(xs[0])
        self.refresh()
        self.on_change()

    def _click(self, ev):
        iid = self.tv.identify_row(ev.y)
        if not iid:
            return
        if "indicator" in self.tv.identify_element(ev.x, ev.y):
            return                                # the open / close arrow
        self.toggle(iid)
        return "break"


class FiltersWindow:
    def __init__(self, preview):
        from tkinter import ttk
        app = preview.app
        tk = app.tk
        self.pv = preview
        self.app = app
        ui = getattr(app, "ui", 1.0)
        self.win = tk.Toplevel(preview.win)
        self.win.title("Preview filters")
        self.win.transient(preview.win)
        self.win.minsize(int(300 * ui), int(300 * ui))
        try:
            self.win.geometry(app.s.get("pfilters_geometry")
                              or "%dx%d" % (int(380 * ui), int(520 * ui)))
        except tk.TclError:
            pass
        if preview.pin_var.get():
            try:
                self.win.attributes("-topmost", True)
            except tk.TclError:
                pass
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.columnconfigure(0, weight=1)
        self.win.rowconfigure(1, weight=1)

        self.info_var = tk.StringVar()
        ttk.Label(self.win, text="Tick what to show. Nothing ticked = no filter.\n"
                                 "Right-click: add / edit your own (\u270e).",
                  foreground="#666", padding=(8, 6, 8, 0), justify="left").grid(
            row=0, column=0, sticky="w")
        tf = ttk.Frame(self.win, padding=(8, 6, 8, 0))
        tf.grid(row=1, column=0, sticky="nsew")
        self.ticks = set(app.s.get("preview_filter_ticks") or [])
        self.ct = CheckTree(tf, app, self.ticks, self._changed)
        self.ct.tv.bind("<Button-3>", self._menu)
        self.ct.tv.bind("<<TreeviewOpen>>", lambda e: self._remember_open())
        self.ct.tv.bind("<<TreeviewClose>>", lambda e: self._remember_open())

        ttk.Label(self.win, textvariable=self.info_var, foreground="#666",
                  padding=(8, 4, 8, 0)).grid(row=2, column=0, sticky="w")
        b1 = ttk.Frame(self.win, padding=(8, 6, 8, 0))
        b1.grid(row=3, column=0, sticky="ew")
        ttk.Button(b1, text="Add...", command=lambda: self.edit_dialog()).pack(side="left")
        ttk.Button(b1, text="Clear ticks", command=self.clear_ticks).pack(side="left",
                                                                          padx=(6, 0))
        b2 = ttk.Frame(self.win, padding=(8, 6, 8, 8))
        b2.grid(row=4, column=0, sticky="ew")
        ttk.Button(b2, text="Export custom...", command=self.export_dialog).pack(side="left")
        ttk.Button(b2, text="Import custom...", command=self.import_file).pack(
            side="left", padx=(6, 0))
        ttk.Button(b2, text="Close", command=self.close).pack(side="right")
        self._type = None
        self.rebuild()

    # ---------------------------------------------------------- tree
    def _blocks(self):
        if self.pv.mode != "wad":
            return list(ALL_BLOCKS)
        return TYPE_BLOCKS.get(self.pv.type_var.get(), list(ALL_BLOCKS))

    def rebuild(self):
        ct = self.ct
        opened = set(self.app.s.get("pfilters_open") or ["b:sprite", "b:graphic", "b:flat",
                                                        "b:texture", "b:custom"])
        ct.clear()
        custom = self.app.custom_filters
        by_sec = {}
        for c in custom:
            by_sec.setdefault(c["section"], []).append(c)
        want = self._blocks()
        self._type = self.pv.type_var.get()
        for bid, blabel, secs in stock_tree():
            if bid not in want:
                continue
            biid = "b:" + bid
            ct.add("", biid, blabel, open_="b:" + bid in opened)
            for s in secs:
                siid = "s:" + s["id"]
                kids = s["children"] + [
                    {"id": c["id"], "name": c["name"], "custom": True}
                    for c in sorted(by_sec.get(s["name"], []), key=lambda c: c["name"].lower())]
                if s["own"] is None and not s.get("exclusive"):
                    kids.sort(key=lambda e: e["name"].lower())
                ct.add(biid, siid, s["name"], own=s["own"]["id"] if s["own"] else None,
                       open_=siid in opened)
                if s.get("exclusive"):
                    ct.groups[siid] = [e["id"] for e in s["children"]]
                for e in kids:
                    ct.add(siid, "e:" + e["id"],
                           e["name"] + (EDIT_MARK if e.get("custom") else ""), own=e["id"])
        own_secs = sorted({c["section"] for c in custom if c["section"] not in STOCK_SECTIONS},
                          key=str.lower)
        if own_secs:
            ct.add("", "b:custom", "Custom sections", open_="b:custom" in opened)
            for sec in own_secs:
                siid = "cs:" + sec
                ct.add("b:custom", siid, sec, open_=siid in opened)
                for c in sorted(by_sec[sec], key=lambda c: c["name"].lower()):
                    ct.add(siid, "e:" + c["id"], c["name"] + EDIT_MARK, own=c["id"])
        ct.refresh()
        self.update_info()

    def _remember_open(self):
        tv = self.ct.tv
        opened = []

        def walk(p):
            for ch in tv.get_children(p):
                if tv.item(ch, "open"):
                    opened.append(ch)
                walk(ch)
        self.win.after_idle(lambda: (walk(""), self.app.s.__setitem__("pfilters_open",
                                                                      opened)))

    def type_changed(self):
        if self.pv.type_var.get() != self._type:
            self.rebuild()

    def update_info(self):
        pv = self.pv
        n = len(pv.view)
        tot = len(pv.items)
        self.info_var.set("Showing %d of %d images" % (n, tot) if tot else "No images loaded")

    def _changed(self):
        self.app.s["preview_filter_ticks"] = sorted(self.ticks)
        self.pv.filters_changed()
        self.update_info()

    def clear_ticks(self):
        self.ticks.clear()
        self.ct.refresh()
        self._changed()

    # ---------------------------------------------------------- custom entries
    def _custom(self, eid):
        for c in self.app.custom_filters:
            if c["id"] == eid:
                return c
        return None

    def _menu(self, ev):
        tk = self.app.tk
        iid = self.ct.tv.identify_row(ev.y)
        m = tk.Menu(self.win, tearoff=0)
        sec = None
        if iid.startswith("e:") and self._custom(iid[2:]):
            c = self._custom(iid[2:])
            m.add_command(label="Edit \"%s\"..." % c["name"],
                          command=lambda: self.edit_dialog(c))
            m.add_command(label="Delete \"%s\"" % c["name"],
                          command=lambda: self.delete(c))
            m.add_separator()
            sec = c["section"]
        elif iid.startswith("s:"):
            sec = self.ct.label.get(iid)
        elif iid.startswith("cs:"):
            sec = iid[3:]
        elif iid.startswith("e:"):
            sec = self.ct.label.get(self.ct.tv.parent(iid))
        if sec in ("Misc", "Player"):
            sec = None
        m.add_command(label="Add here (%s)..." % sec if sec else "Add...",
                      command=lambda: self.edit_dialog(None, sec))
        try:
            m.tk_popup(ev.x_root, ev.y_root)
        finally:
            m.grab_release()
        return "break"

    def _custom_changed(self):
        self.app.exported = False
        self.pv.custom_changed()
        self.rebuild()

    def delete(self, c):
        self.app.custom_filters[:] = [x for x in self.app.custom_filters if x is not c]
        self.ticks.discard(c["id"])
        self.app.s["preview_filter_ticks"] = sorted(self.ticks)
        self._custom_changed()

    def edit_dialog(self, c=None, section=None):
        from tkinter import ttk
        tk = self.app.tk
        d = tk.Toplevel(self.win)
        d.title("Edit filter entry" if c else "Add filter entry")
        d.transient(self.win)
        d.resizable(True, False)
        try:
            d.attributes("-topmost", True)
        except tk.TclError:
            pass
        f = ttk.Frame(d, padding=10)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        name_v = tk.StringVar(value=c["name"] if c else "")
        secs = STOCK_SECTIONS + sorted({x["section"] for x in self.app.custom_filters
                                        if x["section"] not in STOCK_SECTIONS}, key=str.lower)
        sec_v = tk.StringVar(value=c["section"] if c else (section or ""))
        pat_v = tk.StringVar(value=" ".join(c["match"]) if c else "")
        ttk.Label(f, text="Name").grid(row=0, column=0, sticky="w")
        e1 = ttk.Entry(f, textvariable=name_v, width=34)
        e1.grid(row=0, column=1, sticky="ew", padx=(8, 0), pady=2)
        ttk.Label(f, text="Section").grid(row=1, column=0, sticky="w")
        ttk.Combobox(f, textvariable=sec_v, values=secs, width=32).grid(
            row=1, column=1, sticky="ew", padx=(8, 0), pady=2)
        ttk.Label(f, text="Match").grid(row=2, column=0, sticky="w")
        ttk.Entry(f, textvariable=pat_v, width=34).grid(row=2, column=1, sticky="ew",
                                                        padx=(8, 0), pady=2)
        ttk.Label(f, text="Section: pick one, or type a new name to make your own.\n"
                          "Match: names, space or comma separated.\n"
                          "  4 letters (QWER) = a sprite and all its frames\n"
                          "  else a whole lump name, * and ? wildcards (MYTEX*, BRICK??)",
                  foreground="#666", justify="left").grid(row=3, column=0, columnspan=2,
                                                          sticky="w", pady=(6, 0))
        err = tk.StringVar()
        ttk.Label(f, textvariable=err, foreground="#c03030").grid(row=4, column=0,
                                                                   columnspan=2, sticky="w")
        bf = ttk.Frame(f)
        bf.grid(row=5, column=0, columnspan=2, sticky="e", pady=(8, 0))

        def ok():
            name = name_v.get().strip()
            sec = sec_v.get().strip()
            pats = parse_patterns(pat_v.get())
            if not name:
                err.set("Give it a name.")
                return
            if not sec or sec.lower() == "misc":
                err.set("Pick or type a section (not Misc).")
                return
            if not pats:
                err.set("Add at least one name to match.")
                return
            if c is not None:
                c.update(name=name[:60], section=sec[:60], match=pats)
            else:
                self.app.custom_filters.append(
                    {"id": new_custom_id({x["id"] for x in self.app.custom_filters}),
                     "name": name[:60], "section": sec[:60], "match": pats})
            d.destroy()
            self._custom_changed()

        ttk.Button(bf, text="OK", command=ok).pack(side="left")
        ttk.Button(bf, text="Cancel", command=d.destroy).pack(side="left", padx=(6, 0))
        d.bind("<Return>", lambda e: ok())
        d.bind("<Escape>", lambda e: d.destroy())
        e1.focus_set()
        d.grab_set()

    # ---------------------------------------------------------- export / import
    def export_dialog(self):
        from tkinter import ttk
        tk = self.app.tk
        custom = self.app.custom_filters
        if not custom:
            self.app.status_var.set("No custom filter entries to export yet.")
            self.info_var.set("No custom entries yet - right-click to add one.")
            return
        ui = getattr(self.app, "ui", 1.0)
        d = tk.Toplevel(self.win)
        d.title("Export custom filters")
        d.transient(self.win)
        try:
            d.attributes("-topmost", True)
            d.geometry("%dx%d" % (int(340 * ui), int(420 * ui)))
        except tk.TclError:
            pass
        ttk.Label(d, text="Tick the entries to export:", padding=(8, 8, 8, 0)).pack(
            anchor="w")
        tf = ttk.Frame(d, padding=(8, 6, 8, 0))
        tf.pack(fill="both", expand=True)
        sel = {c["id"] for c in custom}
        ct = CheckTree(tf, self.app, sel, lambda: None, height=12)
        by_sec = {}
        for c in custom:
            by_sec.setdefault(c["section"], []).append(c)
        for sec in sorted(by_sec, key=str.lower):
            ct.add("", "s:" + sec, sec, open_=True)
            for c in sorted(by_sec[sec], key=lambda c: c["name"].lower()):
                ct.add("s:" + sec, "e:" + c["id"], c["name"], own=c["id"])
        ct.refresh()
        bf = ttk.Frame(d, padding=8)
        bf.pack(fill="x")

        def go():
            from tkinter import filedialog, messagebox
            out = [dict(c) for c in custom if c["id"] in sel]
            if not out:
                return
            initdir = self.app.s.get("filters_dir") or PRESET_DIR
            try:
                os.makedirs(initdir, exist_ok=True)
            except OSError:
                initdir = None
            p = filedialog.asksaveasfilename(
                parent=d, title="Export custom filters", initialdir=initdir,
                initialfile="filters" + FILE_EXT, defaultextension=FILE_EXT,
                filetypes=[("cleanpal filters", "*" + FILE_EXT)])
            if not p:
                return
            try:
                with open(p, "w", encoding="utf-8") as fh:
                    json.dump({"cleanpal_filters": 1, "version": VERSION, "filters": out},
                              fh, indent=2)
            except OSError as e:
                messagebox.showerror("cleanpal", "Could not save:\n%s" % e, parent=d)
                return
            self.app.s["filters_dir"] = os.path.dirname(p)
            self.app.status_var.set("Exported %d custom filter entr%s to %s" % (
                len(out), "y" if len(out) == 1 else "ies", p))
            d.destroy()

        ttk.Button(bf, text="Export...", command=go).pack(side="left")
        ttk.Button(bf, text="Cancel", command=d.destroy).pack(side="right")

    def import_file(self):
        from tkinter import filedialog, messagebox
        initdir = self.app.s.get("filters_dir") or PRESET_DIR
        if not os.path.isdir(initdir):
            initdir = None
        p = filedialog.askopenfilename(
            parent=self.win, title="Import custom filters", initialdir=initdir,
            filetypes=[("cleanpal filters", "*" + FILE_EXT), ("All files", "*.*")])
        if not p:
            return
        try:
            with open(p, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict) or data.get("cleanpal_filters") != 1:
                raise ValueError("Not a cleanpal filters file.")
            new = clean_custom(data.get("filters"))
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not import:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        self.app.s["filters_dir"] = os.path.dirname(p)
        cur = self.app.custom_filters
        key = {(c["section"].lower(), c["name"].lower()): c for c in cur}
        clash = [n for n in new if (n["section"].lower(), n["name"].lower()) in key]
        how = "skip"
        if clash:
            how = self.app._ask_buttons(
                "Some entries already exist.",
                "%d of the %d imported entries have the same section and name as one "
                "you already have (e.g. %s / %s)." % (len(clash), len(new),
                                                     clash[0]["section"], clash[0]["name"]),
                [("replace", "Replace"), ("both", "Keep both"), ("skip", "Skip")])
        taken = {c["id"] for c in cur}
        added = 0
        for n in new:
            k = (n["section"].lower(), n["name"].lower())
            if k in key:
                if how == "replace":
                    key[k]["match"] = n["match"]
                    added += 1
                    continue
                if how == "skip":
                    continue
                names = {c["name"].lower() for c in cur if c["section"].lower() == k[0]}
                i = 2
                while ("%s (%d)" % (n["name"], i)).lower() in names:
                    i += 1
                n["name"] = "%s (%d)" % (n["name"], i)
            n["id"] = new_custom_id(taken)
            taken.add(n["id"])
            cur.append(n)
            added += 1
        self.app.status_var.set("Imported %d custom filter entr%s from %s" % (
            added, "y" if added == 1 else "ies", os.path.basename(p)))
        self._custom_changed()

    # ---------------------------------------------------------- window
    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def close(self):
        try:
            self.app.s["pfilters_geometry"] = self.win.geometry()
        except self.app.tk.TclError:
            pass
        self.pv.filt_win = None
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass
