"""COLORMAP mode fade area (App mixin): the bar under the palette grid
(Lock / Unlock, Hold for true colour, hide buttons) and TWO panes stacked
in their own split - Matrix and Fades - each with its own header (zoom,
Selected only for the Matrix), canvas and scrollbars. Either pane can be
hidden (▼ Matrix / ▼ Fades); both hidden folds the whole fade area away.

* Palette selection = filter: which colours the views show.
* Fade selection (self.fade_sel) = what tools work on: click a fade's index
  number (Fades) or the band above its column (Matrix); Ctrl toggles,
  Shift adds a range. With no fade selection, tools work on every visible
  fade (cmap_targets).
* Right-click an index number / band = lock or unlock that fade.
* Zoom: - / + / Fit, Ctrl + wheel. Wheel scrolls, Shift + wheel sideways.
  Each view keeps its own zoom (settings cmap_zoom_matrix / cmap_zoom_fades:
  None = Fit, else cell size in pixels at 100%).
"""

from ..cleanpal_lib_colormap import INVUL_ROW, LIGHT_ROWS, lock_values
from ..cleanpal_lib_colour import hex_of
from ..cleanpal_lib_constants import ENTRIES

SEL_MARK = "#00ffff"                 # palette selection marker (Matrix, unticked)
FADE_LOCK_COLOUR = "#ffc61a"         # gold: fade locks (palette locks are their own colour)
FADE_SEL_BG = "#ffffff"              # fade selection: white box, black text
ZOOM_STEP = 1.25
MAX_PIXELS = 12000000                # Matrix image size cap


class _Pane:
    """One fade pane (Matrix or Fades): its canvas and what was drawn."""

    def __init__(self, kind):
        self.kind = kind
        self.cv = self.frame = self.header = None
        self.cells, self.labels, self.cols = [], [], []
        self.geom = self.cell_now = self.img = self.hgeom = None


class FadeViewMixin:

    # ---------------------------------------------------------- UI build
    def _build_fade_frame(self, parent):
        from tkinter import ttk

        tk = self.tk
        f = ttk.Frame(parent)
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(0, 4))
        self._lock_btn = ttk.Button(bar, text="Lock", width=7,
                                    command=lambda: self.fade_lock(True))
        self._lock_btn.pack(side="left")
        ttk.Button(bar, text="Unlock", width=7, command=lambda: self.fade_lock(False)).pack(
            side="left", padx=(4, 0))
        tb = ttk.Button(bar, text="Hold for true colour")
        tb.pack(side="left", padx=(14, 0))
        tb.bind("<ButtonPress-1>", lambda e: self._truecol_set(True))
        tb.bind("<ButtonRelease-1>", lambda e: self._truecol_set(False))
        self.min_fades_btn = ttk.Button(bar, text="▼ Fades", width=9,
                                        command=lambda: self.pane_toggle("fades"))
        self.min_fades_btn.pack(side="right")
        self.min_matrix_btn = ttk.Button(bar, text="▼ Matrix", width=10,
                                         command=lambda: self.pane_toggle("matrix"))
        self.min_matrix_btn.pack(side="right", padx=(0, 4))
        self.min_pal_btn = ttk.Button(bar, text="▲ Palette", width=10,
                                      command=lambda: self.pane_minimise("palette"))
        self.min_pal_btn.pack(side="right", padx=(0, 4))
        bar.bind("<Double-Button-1>", lambda e: self.pane_restore())
        self.fade_bar = bar
        self.fade_inner = tk.PanedWindow(f, orient="vertical", sashwidth=8,
                                         sashrelief="raised", bd=0, bg="#c8c8c8")
        self.fade_inner.pack(fill="both", expand=True)
        self.fade_inner.bind("<ButtonRelease-1>", lambda e: self._inner_dragged(), add="+")
        self._panes = {}
        for kind in ("matrix", "fades"):
            self._panes[kind] = self._build_pane(self.fade_inner, kind)
        self._pane_show = {"matrix": bool(self.s.get("cmap_show_matrix", True)),
                           "fades": bool(self.s.get("cmap_show_fades", True))}
        self._inner_layout()
        self.fade_frame = f
        return f

    def _build_pane(self, parent, kind):
        from tkinter import ttk

        tk = self.tk
        ui = getattr(self, "ui", 1.0)
        p = _Pane(kind)
        fr = ttk.Frame(parent)
        hd = ttk.Frame(fr)
        hd.pack(fill="x", pady=(2, 2))
        ttk.Label(hd, text="Matrix" if kind == "matrix" else "Fades", width=7,
                  font=("Segoe UI", 9, "bold")).pack(side="left")
        ttk.Button(hd, text="−", width=3, command=lambda: self.fade_zoom(-1, kind)).pack(
            side="left", padx=(6, 0))
        ttk.Button(hd, text="+", width=3, command=lambda: self.fade_zoom(1, kind)).pack(
            side="left", padx=(4, 0))
        ttk.Button(hd, text="Fit", width=5, command=lambda: self.fade_zoom_fit(kind)).pack(
            side="left", padx=(4, 0))
        if kind == "matrix":
            ttk.Checkbutton(hd, text="Selected only", variable=self.cmap_sel_only,
                            command=self._on_sel_only).pack(side="left", padx=(12, 0))
        box = ttk.Frame(fr)
        box.pack(fill="both", expand=True)
        box.rowconfigure(0, weight=1)
        box.columnconfigure(0, weight=1)
        cv = tk.Canvas(box, bg="#262626", highlightthickness=0, height=int(110 * ui),
                       xscrollincrement=int(20 * ui), yscrollincrement=int(20 * ui))
        cv.grid(row=0, column=0, sticky="nsew")
        vs = ttk.Scrollbar(box, orient="vertical", command=cv.yview)
        hs = ttk.Scrollbar(box, orient="horizontal", command=cv.xview)
        cv.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        p.cv, p.frame, p.header = cv, fr, hd
        cv.bind("<Configure>", lambda e: self._fade_schedule())
        cv.bind("<ButtonPress-1>", lambda e: self._fade_press(e, p))
        cv.bind("<ButtonPress-3>", lambda e: self._fade_right(e, p))
        cv.bind("<Motion>", lambda e: self._fade_hover(e, p))
        cv.bind("<Leave>", lambda e: self.info_var.set(""))
        cv.bind("<MouseWheel>", lambda e: self._fade_wheel(e, p))
        cv.bind("<Button-4>", lambda e: self._fade_wheel(e, p, -1))
        cv.bind("<Button-5>", lambda e: self._fade_wheel(e, p, 1))
        return p

    # ---------------------------------------------------------- panes (Matrix / Fades)
    def _shown(self):
        return [k for k in ("matrix", "fades") if self._pane_show[k]]

    def _inner_layout(self):
        inner = self.fade_inner
        for k in ("matrix", "fades"):
            fr = self._panes[k].frame
            if str(fr) in [str(x) for x in inner.panes()]:
                inner.forget(fr)
        hd = max(p.header.winfo_reqheight() for p in self._panes.values())
        shown = self._shown()
        for k in shown:
            # Fades keeps its height: only the Matrix takes or gives space
            # when the palette divider / the window size changes
            st = "never" if k == "fades" and len(shown) == 2 else "always"
            inner.add(self._panes[k].frame, stretch=st, minsize=hd + 20)
        if len(shown) == 2:
            self.root.after_idle(self._inner_restore)
        self._fade_schedule()

    def _fades_px(self):
        ui = getattr(self, "ui", 1.0)
        v = self.s.get("cmap_fades_px")
        if not isinstance(v, (int, float)) or isinstance(v, bool) or v <= 0:
            v = 230.0
        return float(v) * ui

    def _inner_restore(self):
        try:
            h = max(self.fade_inner.winfo_height(), 1)
            self.fade_inner.sash_place(0, 0, int(max(h * 0.1, h - self._fades_px())))
        except self.tk.TclError:
            pass

    def _inner_dragged(self):
        if len(self._shown()) != 2:
            return
        try:
            y = self.fade_inner.sash_coord(0)[1]
        except self.tk.TclError:
            return
        h = max(self.fade_inner.winfo_height(), 1)
        ui = getattr(self, "ui", 1.0)
        self.s["cmap_fades_px"] = round(max(h - y, 20) / ui, 1)

    def pane_toggle(self, kind):
        """Hide / show the Matrix or Fades pane. Hiding both folds the whole
        fade area down to its bar (like the old ▼ Fades)."""
        if not self.cmap_mode():
            return
        if self._pane_min == "fades" and not self._shown():
            self._pane_show[kind] = True
            self.pane_restore()
        else:
            self._pane_show[kind] = not self._pane_show[kind]
        self.s["cmap_show_" + kind] = self._pane_show[kind]
        self._inner_layout()
        if not self._shown():
            if self._pane_min is None:
                self._sash_prev = self._sash_y()
            self._pane_min = "fades"
            self._sash_place(self._pane_total() - self._bar_height())
        elif self._pane_min == "fades":
            self.pane_restore()
        self._fade_sel_prune()
        self._update_min_btns()
        self._ctool_sel_changed()

    def _on_sel_only(self):
        self.s["cmap_sel_only"] = bool(self.cmap_sel_only.get())
        self._fade_schedule()
        self._ctool_sel_changed()

    # ---------------------------------------------------------- true colour (held)
    def _truecol_set(self, on):
        if bool(getattr(self, "_truecol", False)) == on:
            return
        self._truecol = on
        self.status_var.set("Showing TRUE-COLOUR targets - release to see the palette."
                            if on else "Showing the palette result.")
        self.draw_fades()

    def _cell_rgb(self, res, r, s):
        """Colour drawn for row r of fade s: the palette result, or while
        Hold for true colour is held, the true-colour target (Generate's for
        the fades in its run, else the generator's ideal; hand-set / locked
        cells have none and show their palette colour)."""
        held = getattr(self, "_truecol", False)
        w = getattr(self, "ctool_win", None)
        auto = w is not None and hasattr(w, "show_true") and w.show_true()
        if not held and (not auto or s not in getattr(w, "scope", ())) and w is not None \
                and hasattr(w, "view_rgb") and 0 < r < LIGHT_ROWS and s not in self.cmap_locks:
            v = w.view_rgb(r, s)                 # e.g. Edit Ramps: palette + new colours
            if v is not None:
                return tuple(v)
        if r == INVUL_ROW and auto and hasattr(w, "invul_rgb"):
            v = w.invul_rgb(s)                   # Invulnerability: the colour aimed for
            if v is not None:
                return tuple(v)
        if (held or auto) and 0 < r < LIGHT_ROWS:
            if w is not None and s in getattr(w, "scope", ()) and s not in self.cmap_locks:
                t = w.targets.get((r, s))
                if t is not None:
                    return tuple(t)
        if held and 0 < r < LIGHT_ROWS:
            ideal = res.ideal.get((r, s))
            if ideal is not None and res.source.get((r, s)) == "auto":
                return tuple(int(round(min(max(v, 0), 255))) for v in ideal)
        t = res.rows[r][s]
        c = self.rgbs[t] if 0 <= t < len(self.rgbs) else None
        return tuple(c) if c is not None else (0, 0, 0)

    def _new_cells(self):
        """Cells a tool's preview puts on a colour not in the palette yet."""
        if getattr(self, "_truecol", False):
            return set()
        w = getattr(self, "ctool_win", None)
        if w is None or not hasattr(w, "marked_cells"):
            return set()
        return w.marked_cells() or set()

    def _new_dot(self, cv, x, y, cw, ch):
        d = max(3.0, min(cw, ch) * 0.34)
        cx, cy = x + cw / 2.0, y + ch / 2.0
        cv.create_oval(cx - d / 2, cy - d / 2, cx + d / 2, cy + d / 2, fill="#ffffff",
                       outline="#000000")

    # ---------------------------------------------------------- zoom / scroll
    def _zoom_key(self, kind):
        return "cmap_zoom_" + kind

    def fade_zoom(self, step, kind):
        ui = getattr(self, "ui", 1.0)
        cur = self._panes[kind].cell_now or 12.0 * ui
        new = cur * (ZOOM_STEP if step > 0 else 1.0 / ZOOM_STEP)
        new = min(max(new / ui, 1.0), 96.0)
        self.s[self._zoom_key(kind)] = round(new, 3)
        self.draw_fades()

    def fade_zoom_fit(self, kind):
        self.s[self._zoom_key(kind)] = None
        cv = self._panes[kind].cv
        cv.xview_moveto(0)
        cv.yview_moveto(0)
        self.draw_fades()

    def _zoom_px(self, kind):
        """Cell size in pixels, or None for Fit."""
        z = self.s.get(self._zoom_key(kind))
        if isinstance(z, (int, float)) and not isinstance(z, bool) and z > 0:
            return float(z) * getattr(self, "ui", 1.0)
        return None

    def _fade_wheel(self, ev, p, n=None):
        if n is None:
            n = -1 if ev.delta > 0 else 1
        if ev.state & 0x0004:                      # Ctrl: zoom
            self.fade_zoom(-n, p.kind)
        elif ev.state & 0x0001:                    # Shift: sideways
            p.cv.xview_scroll(n * 3, "units")
        else:
            p.cv.yview_scroll(n * 3, "units")
        return "break"

    def _cxy(self, ev, p):
        return p.cv.canvasx(ev.x), p.cv.canvasy(ev.y)

    # ---------------------------------------------------------- eyedropper
    def cmap_pick_start(self, cb):
        """Next click on a palette cell (top grid) or a Matrix / Fades cell
        picks that palette colour: cb(slot). Esc cancels (cb(None))."""
        self._cmap_pick = cb
        for w in [self.canvas] + [p.cv for p in self._panes.values()]:
            w.configure(cursor="crosshair")
        self.status_var.set("Pick: click a palette cell, or a cell in the Matrix / Fades "
                            "view. Esc cancels.")

    def _cmap_pick_end(self, idx):
        cb = self._cmap_pick
        self._cmap_pick = None
        for w in [self.canvas] + [p.cv for p in self._panes.values()]:
            try:
                w.configure(cursor="")
            except self.tk.TclError:
                pass
        if cb is not None:
            cb(idx)

    def cmap_pick_cancel(self):
        if self._cmap_pick is not None:
            self._cmap_pick_end(None)
            self.status_var.set("Pick cancelled.")

    def cmap_pick_grid(self, ev):
        """Top grid click while picking. True = handled."""
        if self._cmap_pick is None or not self.cmap_mode():
            return False
        slot = self._slot_at(ev.x, ev.y)
        ent = self._view_entry(slot) if slot is not None else None
        if ent and ent[1] != "empty" and self.rgbs[ent[0]] is not None:
            self._cmap_pick_end(ent[0])
        return True

    def cmap_escape(self):
        """Esc in the main window: cancel a pick, then clear the fade
        selection, then the palette selection."""
        if self._cmap_pick is not None:
            self.cmap_pick_cancel()
        elif self.ctool == "elevels":
            self.close_ctool()
        elif self._pool_mode and hasattr(self.ctool_win, "pool_off"):
            self.ctool_win.pool_off()
        elif self.cmap_mode() and self.fade_sel:
            self.fade_sel = set()
            self._fade_anchor = None
            self.status_var.set("Fade selection cleared - tools work on every visible fade.")
            self.draw_fades()
            self._ctool_sel_changed()
        else:
            self.clear_selection()

    # ---------------------------------------------------------- what is visible / targeted
    def _fade_visible(self, kind):
        """Colours a pane shows, in its order."""
        sel = self._sel_colours()
        if kind == "matrix":
            if self.cmap_sel_only.get() and sel:
                return sel
            return [i for i in range(ENTRIES) if self.rgbs[i] is not None]
        return sel

    def _fade_sel_prune(self):
        """Fades that no shown pane shows drop out of the fade selection."""
        if not self.fade_sel or self.rgbs is None:
            return
        vis = set()
        for k in self._shown():
            vis |= set(self._fade_visible(k))
        self.fade_sel &= vis

    def cmap_targets(self):
        """What a COLORMAP tool works on: (colours minus locked, label,
        number of locked skipped). Fade selection first, else the palette
        selection, else the whole palette."""
        if self.rgbs is None:
            return [], "No palette", 0
        self._fade_sel_prune()
        sel = self._sel_colours()
        if self.fade_sel:
            cols = sorted(self.fade_sel)
            label = "Selected fades: %d" % len(cols)
        elif sel:
            cols = sel
            label = "Visible (palette selection): %d colour%s" % (
                len(cols), "" if len(cols) == 1 else "s")
        else:
            cols = [i for i in range(ENTRIES) if self.rgbs[i] is not None]
            label = "Whole palette: %d colours" % len(cols)
        locked = [i for i in cols if i in self.cmap_locks]
        return [i for i in cols if i not in self.cmap_locks], label, len(locked)

    # ---------------------------------------------------------- fade selection / locks
    def _fade_label_at(self, p, x, y):
        """Index number (Fades) or the band above a column (Matrix) -> slot."""
        if p.kind == "matrix":
            g = p.geom
            if not g or not p.cols:
                return None
            ox, oy, cw, ch = g
            if not 0 <= y < oy:
                return None
            k = int((x - ox) // cw)
            return p.cols[k] if 0 <= k < len(p.cols) else None
        for y0, cell, s, lw in p.labels:
            if 0 <= x < lw and y0 <= y < y0 + cell:
                return s
        return None

    def _fade_press(self, ev, p):
        x, y = self._cxy(ev, p)
        if self.ctool == "elevels" and self.ctool_win is not None:
            hit = self._fade_at(p, x, y)         # Edit Levels: a level cell = edit it
            if hit is not None:
                self.ctool_win.pick(hit[1], hit[0])
                return
            s = self._fade_label_at(p, x, y)
            if s is not None:
                self.ctool_win.pick(s, 1)
            return
        if self._cmap_pick is not None:
            hit = self._fade_at(p, x, y)
            if hit is None:
                return
            res, _f = self.cmap_result()
            t = res.rows[hit[0]][hit[1]]
            if self.rgbs[t] is not None:
                self._cmap_pick_end(t)
            return
        s = self._fade_label_at(p, x, y)
        if s is None:
            return
        ctrl, shift = ev.state & 0x0004, ev.state & 0x0001
        vis = self._fade_visible(p.kind)
        if shift and self._fade_anchor in vis and s in vis:
            a, b = sorted((vis.index(self._fade_anchor), vis.index(s)))
            rng = set(vis[a:b + 1])
            self.fade_sel = (self.fade_sel | rng) if ctrl else rng
        elif ctrl:
            self.fade_sel ^= {s}
            self._fade_anchor = s
        else:
            self.fade_sel = {s}
            self._fade_anchor = s
        n = len(self.fade_sel)
        self.status_var.set(("Fades selected: %d - tools work on these. Esc clears." % n)
                            if n else "No fades selected - tools work on every visible fade.")
        self.draw_fades()
        self._ctool_sel_changed()

    def _fade_right(self, ev, p):
        x, y = self._cxy(ev, p)
        w = getattr(self, "ctool_win", None)
        if w is not None and hasattr(w, "main_add_node") and self._alt_down(ev):
            # Edit Fades: Alt+right-click a cell of ANY fade = that cell's
            # colour as a node on that row of the edited fade; a lighting
            # number in the Fades header = a node in the gradient's colour
            hit = self._fade_at(p, x, y)
            if hit is not None and w.src is not None:
                res, _f = self.cmap_result()
                w.main_add_node(hit[0], self._cell_rgb(res, hit[0], hit[1]))
                return
            g = getattr(p, "hgeom", None)
            if p.kind == "fades" and g is not None and y < g[1] and x >= g[0]:
                r = int((x - g[0]) // g[2])
                if 0 <= r < g[3]:
                    w.main_add_node(r)
                    return
            self.status_var.set("Alt+right-click a fade cell (or a lighting number) to add a "
                                "node to fade %s on that row." % w.src)
            return
        s = self._fade_label_at(p, x, y)
        if s is None or self.rgbs[s] is None:
            return
        self.fade_lock(s not in self.cmap_locks, [s])

    def fade_lock(self, on, slots=None):
        """Lock: freeze rows 1-31 of the fades exactly as they are now.
        Unlock: make them editable again - the values stay. Works on the
        given slots, else the fade selection, else the palette selection.
        Not history entries (like palette locks); saved in projects."""
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return
        if slots is None:
            self._fade_sel_prune()
            slots = sorted(self.fade_sel) or self._sel_colours()
        slots = [s for s in slots if self.rgbs[s] is not None]
        if not slots:
            self.status_var.set("Select fades (click their numbers) or colours in the "
                                "palette first, then %s." % ("Lock" if on else "Unlock"))
            return
        res, _f = self.cmap_result()
        if on:
            new = [s for s in slots if s not in self.cmap_locks]
            for s in new:
                self.cmap_locks[s] = lock_values(res, s)
            self.status_var.set("Locked %s%s." % (
                ("fade %d" % new[0]) if len(new) == 1 else "%d fades" % len(new),
                " (%d already locked)" % (len(slots) - len(new))
                if len(slots) > len(new) else ""))
            self.recompute()
            self._ctool_sel_changed()
            return
        gone = [s for s in slots if s in self.cmap_locks]
        if not gone:
            self.status_var.set("None of those fades are locked.")
            return
        keep = {s: self.cmap_locks.pop(s) for s in gone}
        free, _f = self.cmap_result()
        kept = {}
        for s, vals in keep.items():          # unlocking never changes what you see
            for r, t in enumerate(vals, 1):
                if free.rows[r][s] != res.rows[r][s]:
                    kept[(r, s)] = res.rows[r][s]
        what = ("fade %d" % gone[0]) if len(gone) == 1 else "%d fades" % len(gone)
        self._ctool_sel_changed()
        if kept:
            self.cm.overrides.update(kept)
            self._cmap_commit("unlocked %s (kept %d step%s as hand edits)" % (
                what, len(kept), "" if len(kept) == 1 else "s"))
            return
        self.status_var.set("Unlocked %s." % what)
        self.recompute()

    def _draw_fade_lock(self, cv, x, y, C, colour=FADE_LOCK_COLOUR, left=True):
        """Small gold padlock in a box of size C (top-left corner by default,
        so it doesn't sit on a palette lock in the grid)."""
        if C < 10:
            cv.create_rectangle(x, y, x + C, y + C, outline=colour)
            return
        s = C * 0.34
        bx0 = x + C * 0.06 if left else x + C - s - C * 0.06
        by0 = y + C * 0.06 + s * 0.35
        bx1, by1 = bx0 + s, by0 + s * 0.7
        w = max(1, round(C / 22))
        sh = s * 0.28
        for col, ww in (("#000000", w + 2), (colour, w)):
            cv.create_arc(bx0 + sh * 0.6, by0 - sh * 1.6, bx1 - sh * 0.6, by0 + sh * 0.6,
                          start=0, extent=180, style="arc", outline=col, width=ww)
        cv.create_rectangle(bx0, by0, bx1, by1, fill=colour, outline="#000000", width=1)

    def _padlock(self, cv, x, y, size):
        """A padlock filling a size x size box (for the fade views)."""
        if size < 7:
            cv.create_rectangle(x, y, x + size, y + size, fill=FADE_LOCK_COLOUR, outline="")
            return
        w = max(1, round(size / 12))
        bx0, bx1 = x + size * 0.18, x + size * 0.82
        by0, by1 = y + size * 0.45, y + size * 0.95
        cv.create_arc(x + size * 0.3, y + size * 0.08, x + size * 0.7, y + size * 0.72,
                      start=0, extent=180, style="arc", outline="#000000", width=w + 2)
        cv.create_arc(x + size * 0.3, y + size * 0.08, x + size * 0.7, y + size * 0.72,
                      start=0, extent=180, style="arc", outline=FADE_LOCK_COLOUR, width=w)
        cv.create_rectangle(bx0, by0, bx1, by1, fill=FADE_LOCK_COLOUR, outline="#000000")

    # ---------------------------------------------------------- drawing
    def _fade_schedule(self):
        if not self.cmap_mode():
            return
        if self._fade_after is not None:
            self.root.after_cancel(self._fade_after)
        self._fade_after = self.root.after(15, self.draw_fades)

    def draw_fades(self):
        self._fade_after = None
        if not hasattr(self, "_panes"):
            return
        for p in self._panes.values():
            p.cv.delete("all")
            p.cells, p.labels, p.cell_now = [], [], None
        if not self.cmap_mode() or self.rgbs is None:
            return
        self._fade_sel_prune()
        res, _flags = self.cmap_result()
        for k in self._shown():
            if k == "matrix":
                self._draw_matrix(res, self._panes[k])
            else:
                self._draw_fades_view(res, self._panes[k])

    def _area(self, p):
        return max(p.cv.winfo_width(), 100), max(p.cv.winfo_height(), 40)

    def _draw_fades_view(self, res, p):
        cv = p.cv
        ui = getattr(self, "ui", 1.0)
        W, H = self._area(p)
        sel = self._sel_colours()
        if not sel:
            cv.configure(scrollregion=(0, 0, W, H))
            cv.create_text(12, 20, anchor="nw", fill="#bbbbbb",
                           text="Select colours in the palette grid to see their fades "
                                "(rows 0-31 = light levels, 0 = the colour itself).\n"
                                "Click a fade's number to pick it for the tools (Ctrl / "
                                "Shift add), right-click it to lock / unlock.")
            return
        ncol = self._fade_cols()
        lw = int(64 * ui)
        top = int(16 * ui)
        w = getattr(self, "ctool_win", None)
        marks = None
        if w is not None and hasattr(w, "new_rows"):   # Edit Fades: room for markers
            marks = w.new_rows()
            top_n = top
            top += int(8 * ui)
        fit = max(2.0, min((W - lw - 8) / float(ncol), (H - top - 4) / float(len(sel))))
        z = self._zoom_px("fades")
        cell = z if z is not None else fit
        p.cell_now = cell
        p.hgeom = (lw, top, cell, ncol)
        cv.configure(scrollregion=(0, 0, lw + ncol * cell + 8, top + len(sel) * cell + 4))
        every = 1 if cell >= 14 * ui else 2 if cell >= 8 * ui else 4 if cell >= 4 * ui else 8
        fs = 8 if cell >= 16 * ui else 7
        for c in range(ncol):
            if c % every and c != INVUL_ROW:
                continue
            cx = lw + c * cell + cell / 2
            if c == 0:                           # row 0 = the colour itself (fixed)
                th = top_n if marks is not None else top
                cv.create_rectangle(lw, 1, lw + max(cell, 10 * ui) - 1, th - 1,
                                    fill="#ffffff", outline="")
                cv.create_text(lw + max(cell, 10 * ui) / 2, th / 2, fill="#000000",
                               font=("Consolas", fs), text="0")
                continue
            ty = top_n / 2 if marks is not None else top / 2
            cv.create_text(cx, ty, fill="#ffcc66" if c == INVUL_ROW else "#bbbbbb",
                           font=("Consolas", fs), text="I" if c == INVUL_ROW else str(c))
        if marks:                                # rows of the edited fade on a NEW colour
            d = max(2.0, 2.5 * ui)
            for c in marks:
                cx = lw + c * cell + cell / 2
                cy = top_n + 4 * ui
                cv.create_oval(cx - d, cy - d, cx + d, cy + d, fill="#00e5ff", outline="")
        if ncol > LIGHT_ROWS:                     # separate the view-only I column
            xs = lw + LIGHT_ROWS * cell - 1
            cv.create_line(xs, top, xs, top + len(sel) * cell, fill="#ffcc66")
        show_text = cell >= 8 * ui
        newc = self._new_cells()
        for k, s in enumerate(sel):
            y = top + k * cell
            p.labels.append((y, cell, s, lw))
            picked = s in self.fade_sel
            if picked:
                cv.create_rectangle(0, y, lw - 2, y + cell - 1, fill=FADE_SEL_BG, outline="")
            sw = min(cell, 28 * ui)
            cv.create_rectangle(2, y + 1, 2 + sw - 2, y + cell - 1,
                                fill=hex_of(self.rgbs[s]), outline="")
            lk = s in self.cmap_locks
            if show_text:
                lab = "%3d%s" % (s, " FB" if s in self.cm.fullbright else
                                 " L" if s in self.cm.limits else "")
                cv.create_text(sw + 4, y + cell / 2, anchor="w",
                               fill="#000000" if picked else "#dddddd",
                               font=("Consolas", 8, "bold" if picked else ""), text=lab)
            if lk:
                ps = min(cell - 2, 16 * ui)
                self._padlock(cv, lw - ps - 4, y + (cell - ps) / 2.0, ps)
            for r in range(ncol):
                x = lw + r * cell
                col = self._cell_rgb(res, r, s)
                cv.create_rectangle(x, y, x + cell - 1 if cell > 3 else x + cell,
                                    y + cell - 1 if cell > 3 else y + cell,
                                    fill=hex_of(col), outline="")
                if (r, s) in newc and cell >= 5:
                    self._new_dot(cv, x, y, cell - 1, cell - 1)
                p.cells.append((x, y, cell, r, s))

    def _draw_matrix(self, res, p):
        """Columns (one per colour) x light rows. Selected only (default):
        just the palette selection, side by side (all 256 when nothing is
        selected); unticked: all 256 with a cyan mark above each selected
        column. The band above row 0: white = fade selected (click /
        right-click it), cyan = palette selected, gold padlock = locked."""
        from PIL import Image, ImageTk

        cv = p.cv
        ui = getattr(self, "ui", 1.0)
        W, H = self._area(p)
        nrows = self._matrix_rows()
        sel = self._sel_colours()
        only = bool(self.cmap_sel_only.get() and sel)
        cols = list(sel) if only else list(range(ENTRIES))
        p.cols = cols
        n = len(cols)
        band = max(10, int(round(16 * ui)))
        ox, oy = 4, 4 + band
        z = self._zoom_px("matrix")
        if z is None:
            ch = max(1.0, (H - oy - 6) / float(nrows))
            cw = max(1.0, min((W - 10) / float(n), ch))
        else:
            cw = ch = z
        if n * cw * nrows * ch > MAX_PIXELS:
            k = (MAX_PIXELS / float(n * cw * nrows * ch)) ** 0.5
            cw, ch = cw * k, ch * k
        p.cell_now = cw
        IW, IH = max(n, int(round(n * cw))), max(nrows, int(round(nrows * ch)))
        cw, ch = IW / float(n), IH / float(nrows)
        img = Image.new("RGB", (n, nrows))
        px = img.load()
        for r in range(nrows):
            for k, s in enumerate(cols):
                px[k, r] = self._cell_rgb(res, r, s) if self.rgbs[s] is not None \
                    else (38, 38, 38)
        p.img = ImageTk.PhotoImage(img.resize((IW, IH), Image.NEAREST))
        cv.create_image(ox, oy, anchor="nw", image=p.img)
        cv.configure(scrollregion=(0, 0, max(W, ox + IW + 6), max(H, oy + IH + 6)))
        p.geom = (ox, oy, cw, ch)
        newc = self._new_cells()
        if newc and min(cw, ch) >= 5:
            at = {s: k for k, s in enumerate(cols)}
            for r, s in newc:
                if s in at and r < nrows:
                    self._new_dot(cv, ox + at[s] * cw, oy + r * ch, cw, ch)
        palsel = set(sel) if not only else set()
        for k, s in enumerate(cols):
            x0 = ox + k * cw
            x1 = max(ox + (k + 1) * cw - 1, x0 + 1)
            if s in self.fade_sel:
                cv.create_rectangle(x0, 2, x1, oy - 2, fill=FADE_SEL_BG, outline="")
            if s in palsel:
                cv.create_rectangle(x0, 2, x1, 2 + band * 0.3, fill=SEL_MARK, outline="")
            if s in self.cmap_locks:
                if cw >= band * 0.7:
                    ps = min(band - 4, cw - 2)
                    self._padlock(cv, x0 + (cw - ps) / 2.0, 3, ps)
                else:
                    cv.create_rectangle(x0, oy - 2 - band * 0.35, x1, oy - 2,
                                        fill=FADE_LOCK_COLOUR, outline="")
            if cw >= 30 * ui:
                cv.create_text(x0 + 3, 2 + band / 2.0, anchor="w",
                               fill="#000000" if s in self.fade_sel else "#bbbbbb",
                               font=("Consolas", 7), text=str(s))

    def _fade_at(self, p, x, y):
        """(row, colour) under canvas point x, y."""
        if p.kind == "matrix":
            g = p.geom
            if not g or not p.cols:
                return None
            ox, oy, cw, ch = g
            k = int((x - ox) // cw)
            r = int((y - oy) // ch)
            if 0 <= k < len(p.cols) and y >= oy and \
                    0 <= r < min(self._matrix_rows(), INVUL_ROW + 1):
                s = p.cols[k]
                if self.rgbs[s] is not None:
                    return r, s
            return None
        for cx, cy, cell, r, s in p.cells:
            if cx <= x < cx + cell and cy <= y < cy + cell:
                return r, s
        return None

    def _fade_hover(self, ev, p):
        if self.rgbs is None:
            return
        x, y = self._cxy(ev, p)
        lab = self._fade_label_at(p, x, y)
        if lab is not None:
            self.info_var.set("fade %d %s%s - click: pick for the tools (Ctrl / Shift add), "
                              "right-click: %s" % (
                                  lab, hex_of(self.rgbs[lab]) or "(empty)",
                                  "  LOCKED" if lab in self.cmap_locks else "",
                                  "unlock" if lab in self.cmap_locks else "lock"))
            return
        hit = self._fade_at(p, x, y)
        if hit is None:
            self.info_var.set("")
            return
        r, s = hit
        res, _flags = self.cmap_result()
        t = res.rows[r][s]
        how = res.source.get((r, s), "auto")
        txt = "colour %d %s  %s -> %d %s  (%s)" % (
            s, hex_of(self.rgbs[s]) or "(empty)",
            "I (invulnerability, view-only)" if r == INVUL_ROW else "row %d" % r,
            t, hex_of(self.rgbs[t]) if self.rgbs[t] else "?",
            {"override": "hand-set", "bad": "hand-set target gone - auto",
             "bright": "full bright", "locked": "LOCKED"}.get(how, "auto"))
        if r == 0:
            txt += "  - row 0 is the colour itself (fixed)"
        elif s in self.cmap_locks and how != "locked" and r < LIGHT_ROWS:
            txt += "  - fade LOCKED (this step's colour is gone)"
        if getattr(self, "_truecol", False):
            txt += "  TRUE COLOUR shown: %s" % hex_of(self._cell_rgb(res, r, s))
        else:
            ideal = res.ideal.get((r, s))
            if ideal:
                txt += "  ideal %s" % hex_of(tuple(int(round(min(max(v, 0), 255)))
                                                    for v in ideal))
        self.info_var.set(txt)
