"""Adjust tools (PLAYPAL): a stack of colour adjustments over the selected
cells (or the whole palette when nothing is selected), previewed live.
Apply = one history entry; Cancel = back to how it was."""


from ..cleanpal_lib_adjust import ADJ_NAMES, ADJUSTMENTS, FADES, apply_stack, curve_y, defaults
from ..cleanpal_lib_colour import hex_of, parse_colour
from ..cleanpal_lib_constants import ENTRIES
from .gui_tool_windows import _ToolWin, focus_on_click

ON, OFF = "☑", "☐"


class AdjustTool(_ToolWin):
    POS_KEY = "adjust_pos"

    def __init__(self, app):
        from tkinter import ttk
        tk = app.tk
        self.app = app
        self.ui = ui = getattr(app, "ui", 1.0)
        win = self._make_win(app, "Adjust tools")
        win.resizable(True, True)
        try:
            win.geometry(app.s.get("adjust_geometry") or "%dx%d" % (int(560 * ui),
                                                                     int(660 * ui)))
        except tk.TclError:
            pass
        win.bind("<Escape>", lambda e: app.close_tool())
        win.columnconfigure(0, weight=1)
        win.rowconfigure(3, weight=1)
        self.stack = []
        self.cur = None                       # index of the adjustment being edited
        self._after = None
        self._snapshot()

        # add row
        af = ttk.Frame(win, padding=(8, 8, 8, 0))
        af.grid(row=0, column=0, sticky="ew")
        want = app.s.get("adjust_last")
        self.add_var = tk.StringVar(value=want if want in ADJ_NAMES else ADJ_NAMES[0])
        ttk.Combobox(af, textvariable=self.add_var, values=ADJ_NAMES, state="readonly",
                     width=24).pack(side="left")
        ttk.Button(af, text="Add", command=self.add).pack(side="left", padx=(6, 0))
        self.scope_var = tk.StringVar()
        ttk.Label(af, textvariable=self.scope_var, foreground="#666").pack(side="right")

        # stack
        sf = ttk.LabelFrame(win, text="Stack (top runs first)", padding=6)
        sf.grid(row=1, column=0, sticky="ew", padx=8, pady=(8, 0))
        sf.columnconfigure(0, weight=1)
        from .gui_filters_window import _tree_style
        self.tv = ttk.Treeview(sf, show="tree", selectmode="browse", height=5,
                               style=_tree_style(app, "Adj.Treeview"))
        self.tv.grid(row=0, column=0, rowspan=4, sticky="ew")
        self.tv.bind("<<TreeviewSelect>>", lambda e: self._pick())
        self.tv.bind("<Double-Button-1>", lambda e: self.toggle())
        for r, (t, cmd) in enumerate((("On / off", self.toggle), ("Up", lambda: self.move(-1)),
                                      ("Down", lambda: self.move(1)), ("Remove", self.remove))):
            ttk.Button(sf, text=t, width=9, command=cmd).grid(row=r, column=1, sticky="e",
                                                              padx=(6, 0), pady=1)

        # params
        self.pf = ttk.LabelFrame(win, text="Settings", padding=6)
        self.pf.grid(row=2, column=0, sticky="ew", padx=8, pady=(8, 0))
        self.pf.columnconfigure(1, weight=1)

        # steps box: before (top half) / after (bottom half)
        self.match_var = tk.BooleanVar(value=bool(app.s.get("adjust_match_rows", False)))
        hf = ttk.Frame(win)
        ttk.Label(hf, text="Cells (top = before, bottom = after)").pack(side="left")
        ttk.Checkbutton(hf, text="Match palette rows", variable=self.match_var,
                        command=self._match).pack(side="left", padx=(10, 0))
        bx = ttk.LabelFrame(win, labelwidget=hf, padding=6)
        bx.grid(row=3, column=0, sticky="nsew", padx=8, pady=(8, 0))
        bx.columnconfigure(0, weight=1)
        bx.rowconfigure(0, weight=1)
        self.cv = tk.Canvas(bx, height=int(80 * ui), highlightthickness=0, bg="#2a2a2a")
        self.cv.grid(row=0, column=0, sticky="nsew")
        self.cv.bind("<Configure>", lambda e: self.draw_cells())
        self.cv.bind("<Motion>", self._cell_hover)
        g = tk.Canvas(bx, height=max(6, int(7 * ui)), highlightthickness=0, bg="#3c3c3c",
                      cursor="sb_v_double_arrow")
        g.grid(row=1, column=0, sticky="ew")
        g.bind("<ButtonPress-1>", lambda e: setattr(self, "_grip", (
            e.y_root, win.winfo_height())))
        g.bind("<B1-Motion>", self._grip_move)
        self.info_var = tk.StringVar()
        ttk.Label(bx, textvariable=self.info_var, font=("Consolas", 9)).grid(
            row=2, column=0, sticky="w", pady=(4, 0))
        self._cells = []

        # buttons
        bf = ttk.Frame(win, padding=8)
        bf.grid(row=4, column=0, sticky="ew")
        cmp = ttk.Button(bf, text="Hold to compare")
        cmp.pack(side="left")
        cmp.bind("<ButtonPress-1>", lambda e: self._compare(True))
        cmp.bind("<ButtonRelease-1>", lambda e: self._compare(False))
        ttk.Button(bf, text="Apply", command=self.apply).pack(side="left", padx=(6, 0))
        ttk.Button(bf, text="Cancel", command=self.cancel).pack(side="left", padx=(6, 0))
        ttk.Button(bf, text="Close", command=app.close_tool).pack(side="right")
        ttk.Checkbutton(bf, text="Hide selection outline", variable=app.adjust_hide_var,
                        command=lambda: (app.s.__setitem__("adjust_hide_sel",
                                                           bool(app.adjust_hide_var.get())),
                                         app.redraw())).pack(side="right", padx=(0, 10))
        focus_on_click(win)
        self._compare_on = False
        self._fill_stack()
        self._build_params()
        self.refresh_now()
        self._place()

    # ---------------------------------------------------------- base / targets
    def _snapshot(self):
        a = self.app
        self.base = (a.rgbs, a.labs, a.pairs, set(a.deleted), a.cm.copy())

    def targets(self):
        a = self.app
        base = self.base[0]
        sel = {i for i in a.selection if i < ENTRIES}
        pool = sel or set(range(ENTRIES))
        return sorted(i for i in pool if i < len(base) and base[i] is not None
                      and i not in a.locked)

    def _ctx(self):
        from ..cleanpal_lib_ramps import clean_ramp_state
        try:
            ramp = clean_ramp_state(self.app.s.get("ramp") or {})
        except ValueError:
            ramp = None
        return {"ramp": ramp, "fill": parse_colour(self.app.s.get("paint_fill") or ""),
                "clip": list(self.app.clip)}

    def compute(self):
        tg = self.targets()
        before = [self.base[0][i] for i in tg]
        after = apply_stack(self.stack, before, self._ctx()) if self.stack else list(before)
        return tg, before, after

    # ---------------------------------------------------------- live preview
    def schedule(self):
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._after = self.win.after(40, self.refresh_now)

    def refresh_now(self):
        self._after = None
        a = self.app
        tg, before, after = self.compute()
        self._last = (tg, before, after)
        if self._compare_on:
            after = before
        a._filter_write(self.base, tg, after)
        n_sel = len([i for i in a.selection if i < ENTRIES])
        self.scope_var.set("%d colour%s (%s)" % (len(tg), "" if len(tg) == 1 else "s",
                                                 "selection" if n_sel else "whole palette"))
        on = [x["name"] for x in self.stack if x.get("on", True)]
        a.status_var.set(("Adjust preview: %s on %d colours - Apply keeps it." % (
            " > ".join(on), len(tg))) if on else "Adjust: add an adjustment to start.")
        a.recompute()
        self.draw_cells()

    def _compare(self, on):
        self._compare_on = on
        self.refresh_now()

    def sel_changed(self):
        self.schedule()

    # ---------------------------------------------------------- stack
    def add(self):
        name = self.add_var.get()
        self.app.s["adjust_last"] = name
        self.stack.append({"name": name, "params": defaults(name), "on": True,
                           "mix": 100, "fade": "Even"})
        self.cur = len(self.stack) - 1
        self._fill_stack()
        self._build_params()
        self.schedule()

    def _label(self, x):
        extra = []
        if x.get("mix", 100) != 100:
            extra.append("%d%%" % x["mix"])
        if x.get("fade", "Even") != "Even":
            extra.append(x["fade"].lower())
        return "%s  %s%s" % (ON if x.get("on", True) else OFF, x["name"],
                             ("  (" + ", ".join(extra) + ")") if extra else "")

    def _fill_stack(self):
        tv = self.tv
        tv.delete(*tv.get_children())
        for k, x in enumerate(self.stack):
            tv.insert("", "end", iid=str(k), text=self._label(x))
        if self.cur is not None and self.cur < len(self.stack):
            tv.selection_set(str(self.cur))

    def _pick(self):
        sel = self.tv.selection()
        k = int(sel[0]) if sel else None
        if k != self.cur:
            self.cur = k
            self._build_params()

    def toggle(self):
        if self.cur is None:
            return
        x = self.stack[self.cur]
        x["on"] = not x.get("on", True)
        self.tv.item(str(self.cur), text=self._label(x))
        self.schedule()

    def move(self, d):
        k = self.cur
        if k is None or not 0 <= k + d < len(self.stack):
            return
        self.stack[k], self.stack[k + d] = self.stack[k + d], self.stack[k]
        self.cur = k + d
        self._fill_stack()
        self.schedule()

    def remove(self):
        if self.cur is None:
            return
        del self.stack[self.cur]
        self.cur = min(self.cur, len(self.stack) - 1) if self.stack else None
        self._fill_stack()
        self._build_params()
        self.schedule()

    def undo_last(self):
        """Ctrl+Z in Adjust: take the last adjustment off the stack."""
        if self.stack:
            self.cur = len(self.stack) - 1
            self.remove()
            self.app.status_var.set("Removed the last adjustment.")

    # ---------------------------------------------------------- params
    def _build_params(self):
        from tkinter import ttk
        tk = self.app.tk
        pf = self.pf
        for w in pf.winfo_children():
            w.destroy()
        if self.cur is None:
            ttk.Label(pf, text="Pick an adjustment above and press Add. Everything previews "
                               "live; Apply makes it one history entry.",
                      foreground="#666", wraplength=int(480 * self.ui)).grid(
                row=0, column=0, columnspan=2, sticky="w")
            pf.configure(text="Settings")
            return
        x = self.stack[self.cur]
        spec = ADJUSTMENTS[x["name"]]
        pf.configure(text=x["name"])
        ttk.Label(pf, text=spec.get("desc", ""), foreground="#666",
                  wraplength=int(480 * self.ui), justify="left").grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))
        r = 1
        self._grads = []
        r = self._num(pf, r, "Mix %", 0, 100, 1, x.get("mix", 100),
                      lambda v: self._set_meta("mix", v))
        ttk.Label(pf, text="Fade").grid(row=r, column=0, sticky="w")
        fv = tk.StringVar(value=x.get("fade", "Even"))
        cb = ttk.Combobox(pf, textvariable=fv, values=FADES, state="readonly", width=12)
        cb.grid(row=r, column=1, sticky="w", pady=1)
        cb.bind("<<ComboboxSelected>>", lambda e: self._set_meta("fade", fv.get()))
        r += 1
        for p in spec["params"]:
            key, label, kind = p[0], p[1], p[2]
            val = x["params"].get(key)
            if kind == "num":
                r = self._num(pf, r, label, p[3], p[4], p[5], val,
                              lambda v, k=key: self._set(k, v), key=key)
            elif kind == "choice":
                ttk.Label(pf, text=label).grid(row=r, column=0, sticky="w")
                v = tk.StringVar(value=val)
                c = ttk.Combobox(pf, textvariable=v, values=p[3], state="readonly",
                                 width=max(10, max(len(o) for o in p[3]) + 2))
                c.grid(row=r, column=1, sticky="w", pady=1)
                c.bind("<<ComboboxSelected>>", lambda e, k=key, vv=v: self._set(k, vv.get()))
                r += 1
            elif kind == "bool":
                v = tk.BooleanVar(value=bool(val))
                ttk.Checkbutton(pf, text=label, variable=v,
                                command=lambda k=key, vv=v: self._set(k, bool(vv.get()))).grid(
                    row=r, column=0, columnspan=2, sticky="w", pady=1)
                r += 1
            elif kind == "colour":
                ttk.Label(pf, text=label).grid(row=r, column=0, sticky="w")
                fr = ttk.Frame(pf)
                fr.grid(row=r, column=1, sticky="w", pady=1)
                v = tk.StringVar(value=val)
                sw = tk.Canvas(fr, width=int(22 * self.ui), height=int(16 * self.ui),
                               highlightthickness=1, highlightbackground="#888",
                               background=val)
                sw.pack(side="left")
                e = ttk.Entry(fr, textvariable=v, width=9)
                e.pack(side="left", padx=(6, 0))

                def commit(_e=None, k=key, vv=v, s=sw):
                    c = parse_colour(vv.get())
                    if c is not None:
                        s.configure(background=hex_of(c))
                        self._set(k, hex_of(c))
                e.bind("<Return>", commit)
                e.bind("<FocusOut>", commit)
                self.app.register_colour_widget(
                    e, lambda vv=v: parse_colour(vv.get()) or (128, 128, 128),
                    lambda rgb, *a, vv=v, cm=commit: (vv.set(hex_of(rgb)), cm()))
                r += 1
            elif kind == "curve":
                r = self._curve(pf, r, key, val)

    def _avg(self):
        from .gui_gradslider import avg_of
        return avg_of(getattr(self, "_last", ([], [], []))[1])

    def _num(self, pf, r, label, lo, hi, step, val, cb, key=None):
        from tkinter import ttk
        from .gui_gradslider import GradSlider, grad_fn
        ttk.Label(pf, text=label).grid(row=r, column=0, sticky="w", padx=(0, 8))
        x = self.stack[self.cur]
        fn = grad_fn(x["name"], key, x["params"], self._avg()) if key else None
        gs = GradSlider(pf, self.app, lo, hi, step, val, cb, fn, self.ui)
        gs.frame.grid(row=r, column=1, sticky="ew", pady=1)
        if key:
            self._grads.append((key, gs))
        return r + 1

    def _regrad(self):
        """Bars that depend on other settings (e.g. Colorise's hue) follow them."""
        from .gui_gradslider import grad_fn
        if self.cur is None:
            return
        x = self.stack[self.cur]
        avg = self._avg()
        for key, gs in getattr(self, "_grads", []):
            try:
                gs.set_fn(grad_fn(x["name"], key, x["params"], avg))
            except Exception:  # noqa: BLE001 - widget gone
                pass

    def _set_meta(self, k, v):
        x = self.stack[self.cur]
        x[k] = v
        self.tv.item(str(self.cur), text=self._label(x))
        self.schedule()

    def _set(self, k, v):
        self.stack[self.cur]["params"][k] = v
        self._regrad()
        self.schedule()

    # curve editor
    def _curve(self, pf, r, key, pts):
        tk = self.app.tk
        S = int(180 * self.ui)
        c = tk.Canvas(pf, width=S, height=S, bg="#202020", highlightthickness=1,
                      highlightbackground="#555")
        c.grid(row=r, column=0, columnspan=2, sticky="w", pady=(4, 0))
        st = {"drag": None}
        m = 6 * self.ui

        def xy(p):
            return m + p[0] * (S - 2 * m), S - m - p[1] * (S - 2 * m)

        def val(x, y):
            return (min(max((x - m) / (S - 2 * m), 0.0), 1.0),
                    min(max((S - m - y) / (S - 2 * m), 0.0), 1.0))

        def draw():
            c.delete("all")
            for k in range(1, 4):
                v = m + k * (S - 2 * m) / 4
                c.create_line(v, m, v, S - m, fill="#333")
                c.create_line(m, v, S - m, v, fill="#333")
            c.create_line(*xy((0, 0)), *xy((1, 1)), fill="#444", dash=(3, 3))
            line = []
            for k in range(65):
                line += xy((k / 64.0, curve_y(pts, k / 64.0)))
            c.create_line(*line, fill="#e0e0e0", width=max(1, int(2 * self.ui)))
            rr = 4 * self.ui
            for p in pts:
                X, Y = xy(p)
                c.create_oval(X - rr, Y - rr, X + rr, Y + rr, fill="#ffb36b", outline="#000")

        def near(ev):
            best, bd = None, 12 * self.ui
            for i, p in enumerate(pts):
                X, Y = xy(p)
                d = abs(X - ev.x) + abs(Y - ev.y)
                if d < bd:
                    best, bd = i, d
            return best

        def press(ev):
            st["drag"] = near(ev)

        def motion(ev):
            i = st["drag"]
            if i is None:
                return
            x, y = val(ev.x, ev.y)
            if i == 0:
                x = 0.0
            elif i == len(pts) - 1:
                x = 1.0
            else:
                x = min(max(x, pts[i - 1][0] + 0.01), pts[i + 1][0] - 0.01)
            pts[i] = [x, y]
            draw()
            self.schedule()

        def dbl(ev):
            x, y = val(ev.x, ev.y)
            if 0.01 < x < 0.99:
                pts.append([x, y])
                pts.sort()
                draw()
                self.schedule()

        def rclick(ev):
            i = near(ev)
            if i is not None and 0 < i < len(pts) - 1:
                del pts[i]
                draw()
                self.schedule()

        c.bind("<ButtonPress-1>", press)
        c.bind("<B1-Motion>", motion)
        c.bind("<ButtonRelease-1>", lambda e: st.update(drag=None))
        c.bind("<Double-Button-1>", dbl)
        c.bind("<Button-3>", rclick)
        draw()
        return r + 1

    # ---------------------------------------------------------- cells box
    def _match(self):
        self.app.s["adjust_match_rows"] = bool(self.match_var.get())
        self.draw_cells()

    def _grip_move(self, ev):
        g = getattr(self, "_grip", None)
        if not g:
            return
        y0, h0 = g
        h = max(int(400 * self.ui), min(h0 + ev.y_root - y0, self.win.winfo_screenheight() - 40))
        try:
            self.win.geometry("%dx%d" % (self.win.winfo_width(), h))
        except self.app.tk.TclError:
            pass

    def draw_cells(self):
        from .gui_ramp_tool import RampTool
        c = self.cv
        c.delete("all")
        self._cells = []
        tg, before, after = getattr(self, "_last", ([], [], []))
        n = len(tg)
        if not n:
            c.create_text(10, 16, anchor="w", fill="#bbbbbb",
                          text="No colours - select palette cells (or none for the whole "
                               "palette).")
            return
        aw = max(c.winfo_width(), 40) - 8
        ah = max(c.winfo_height(), 20) - 8
        if self.match_var.get():
            pos = RampTool.palette_slots(tg)
            rows = max(p[0] for p in pos) + 1
            cell = min(aw / 17.0, ah / rows)
        else:
            cols, cell = RampTool.best_cols(n, aw, ah)
            pos = [((k // cols), (k % cols), k) for k in range(n)]
        cell = max(cell, 3.0)
        for line, cx, k in pos:
            x, y = 4 + cx * cell, 4 + line * cell
            if k is None:
                c.create_rectangle(x, y, x + cell - 2, y + cell - 2, fill="#1a1a1a",
                                   outline="#555555")
                m = (cell - 2) / 2.0
                c.create_line(x + cell * 0.2, y + m, x + cell * 0.8 - 2, y + m, fill="#bbb",
                              arrow="last")
                continue
            h = (cell - 2) / 2.0
            c.create_rectangle(x, y, x + cell - 2, y + h, fill=hex_of(before[k]), outline="")
            c.create_rectangle(x, y + h, x + cell - 2, y + cell - 2, fill=hex_of(after[k]),
                               outline="")
            self._cells.append((x, y, cell, k))

    def _cell_hover(self, ev):
        tg, before, after = getattr(self, "_last", ([], [], []))
        for x, y, cell, k in self._cells:
            if x <= ev.x < x + cell and y <= ev.y < y + cell:
                self.info_var.set("cell %d   %s -> %s" % (tg[k], hex_of(before[k]),
                                                         hex_of(after[k])))
                return
        self.info_var.set("")

    # ---------------------------------------------------------- apply / cancel / close
    def changed_anything(self):
        tg, before, after = self.compute()
        return any(tuple(a) != tuple(b) for a, b in zip(before, after))

    def apply(self):
        a = self.app
        if not self.changed_anything():
            a.status_var.set("Nothing to apply - the stack changes no colours.")
            return
        self._compare_on = False
        self.refresh_now()
        names = [x["name"] for x in self.stack if x.get("on", True)]
        n = len(self._last[0])
        a._push_history("Adjusted: %s - %d colours" % (", ".join(names), n))
        self._snapshot()
        self.stack, self.cur = [], None
        self._fill_stack()
        self._build_params()
        a._refresh_history()
        self.refresh_now()
        a.status_var.set("Adjustments applied to %d colours as #%d (Back undoes it)."
                         % (n, a.hist_pos))

    def _restore(self):
        a = self.app
        b = self.base
        a.rgbs, a.labs, a.pairs = b[0], b[1], b[2]
        a.deleted, a.cm = set(b[3]), b[4].copy()
        a.cm_changed()

    def cancel(self):
        self.stack, self.cur = [], None
        self._fill_stack()
        self._build_params()
        self._restore()
        self.app.recompute()
        self._last = self.compute()
        self.draw_cells()
        self.app.status_var.set("Adjustments cancelled.")

    def confirm_close(self, force=False):
        """close_tool: unapplied adjustments -> Apply / Discard / Cancel."""
        if not self.stack or not self.changed_anything():
            return True
        if force:
            self.apply()
            return True
        k = self.app._ask_buttons("Adjustments not applied.",
                                  "The stack (%s) hasn't been applied." % ", ".join(
                                      x["name"] for x in self.stack),
                                  [("apply", "Apply"), ("discard", "Discard"),
                                   ("cancel", "Cancel")])
        if k == "cancel":
            return False
        if k == "apply":
            self.apply()
        return True

    def teardown(self):
        a = self.app
        try:
            a.s["adjust_geometry"] = self.win.geometry()
        except a.tk.TclError:
            pass
        if self._after is not None:
            self.win.after_cancel(self._after)
        self._restore()                       # anything unapplied goes
        self.store_pos()
        self.win.destroy()

    def refresh(self):
        pass
