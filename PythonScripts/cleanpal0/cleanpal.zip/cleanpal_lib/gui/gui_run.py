"""Run: test the palette in the real game.

The Run button (top bar, before New...) opens a small box: PLAYPAL,
COLORMAP and DSDACR (DSDA Colours, off by default) ticks, the IWAD (click = another one), the Doom exe (asked for the
first time), extra arguments. Run writes a PWAD with the ticked lumps from
the LIVE state (unapplied tool edits included) and starts
    <exe> -iwad <iwad> [-file <that wad>] <extra arguments>
Everything in the box is saved in the project (key "run"); with no project
the last values used are the default (setting "run_last")."""

import os
import shlex
import struct
import subprocess

from ..cleanpal_lib_constants import ENTRIES

RUN_DEFAULTS = {"exe": "", "iwad": "", "playpal": True, "colormap": True, "dsdacr": False,
                "args": "",
                "repal_iwad": False, "pwads": []}


def clean_run(d):
    out = dict(RUN_DEFAULTS)
    if isinstance(d, dict):
        for k in ("exe", "iwad", "args"):
            if isinstance(d.get(k), str):
                out[k] = d[k][:2000]
        for k in ("playpal", "colormap", "dsdacr", "repal_iwad"):
            if isinstance(d.get(k), bool):
                out[k] = d[k]
        if isinstance(d.get("pwads"), list):
            out["pwads"] = [{"path": x["path"], "repal": bool(x.get("repal"))}
                            for x in d["pwads"][:50]
                            if isinstance(x, dict) and isinstance(x.get("path"), str)]
    return out


def build_wad(lumps):
    """[(name, bytes)] -> PWAD bytes."""
    data = bytearray()
    dirs = []
    pos = 12
    for name, b in lumps:
        dirs.append((pos, len(b), name))
        data += b
        pos += len(b)
    out = bytearray(b"PWAD" + struct.pack("<ii", len(lumps), pos))
    out += data
    for p, n, name in dirs:
        out += struct.pack("<ii", p, n) + name.encode("ascii")[:8].ljust(8, b"\0")
    return bytes(out)


def split_args(text):
    """Extra arguments: Windows-style splitting, quotes respected."""
    text = (text or "").strip()
    if not text:
        return []
    try:
        return [a.strip('"') for a in shlex.split(text, posix=False)]
    except ValueError:
        return text.split()


class RunMixin:
    def run_cfg(self):
        c = getattr(self, "_run", None)
        if c is None:
            c = clean_run(self.s.get("run_last"))
            self._run = c
        return c

    def run_set(self, d):
        """From a project (or None = back to the last used defaults)."""
        self._run = clean_run(d) if d else clean_run(self.s.get("run_last"))

    def run_lumps(self, playpal=True, colormap=True, dsdacr=False):
        """The ticked lumps from the live state (what Export would write).
        DSDACR = all 14 DSDA Colours ranges (Export DSDACR's text)."""
        from ..cleanpal_lib_analysis import result_entries
        from ..cleanpal_lib_palette_io import pal_bytes, palette_rows
        lumps = []
        if playpal:
            entries = result_entries(self.rgbs, self.res, self._align_on())
            lumps.append(("PLAYPAL", pal_bytes(palette_rows(entries, True))))
        if colormap:
            _entries, rows = self.export_colormap_rows()
            lumps.append(("COLORMAP", bytes(v & 0xFF for row in rows for v in row)))
        if dsdacr:
            from ..cleanpal_lib_dsdacr import dsdacr_text
            lumps.append(("DSDACR", dsdacr_text(self.dsdacr).encode("ascii")))
        return lumps

    def run_dialog(self):
        from tkinter import ttk
        tk = self.tk
        if self.res is None:
            self.status_var.set("Open a palette first.")
            return
        c = self.run_cfg()
        if not c["iwad"] or not os.path.isfile(c["iwad"]):
            c["iwad"] = self.iwad_path() or ""
        ui = getattr(self, "ui", 1.0)
        w = tk.Toplevel(self.root)
        w.title("Run in game")
        w.transient(self.root)
        w.resizable(False, False)
        f = ttk.Frame(w, padding=10)
        f.pack(fill="both", expand=True)
        pp = tk.BooleanVar(value=c["playpal"])
        cmv = tk.BooleanVar(value=c["colormap"])
        dcv = tk.BooleanVar(value=c["dsdacr"])
        ttk.Label(f, text="Load into the game").grid(row=0, column=0, sticky="w")
        tf = ttk.Frame(f)
        tf.grid(row=0, column=1, sticky="w")
        ttk.Checkbutton(tf, text="PLAYPAL", variable=pp).pack(side="left")
        ttk.Checkbutton(tf, text="COLORMAP", variable=cmv).pack(side="left", padx=(10, 0))
        ttk.Checkbutton(tf, text="DSDACR", variable=dcv).pack(side="left", padx=(10, 0))
        st = {"iwad": c["iwad"], "exe": c["exe"]}
        iw_var, ex_var = tk.StringVar(), tk.StringVar()

        def names():
            iw_var.set(os.path.basename(st["iwad"]) if st["iwad"] else "(choose an IWAD)")
            ex_var.set(os.path.basename(st["exe"]) if st["exe"] else "(choose the Doom exe)")

        def pick(kind):
            from tkinter import filedialog
            if kind == "iwad":
                p = filedialog.askopenfilename(
                    parent=w, title="IWAD to run",
                    initialdir=os.path.dirname(st["iwad"]) if st["iwad"] else None,
                    filetypes=[("WAD files", "*.wad *.WAD"), ("All files", "*.*")])
            else:
                p = filedialog.askopenfilename(
                    parent=w, title="Doom exe (dsda-doom, Nyan ...)",
                    initialdir=os.path.dirname(st["exe"]) if st["exe"] else None,
                    filetypes=[("Programs", "*.exe"), ("All files", "*.*")])
            if p:
                st[kind] = os.path.abspath(p)
                names()

        for row, (lab, var, kind) in enumerate((("IWAD", iw_var, "iwad"),
                                                ("Exe", ex_var, "exe")), 1):
            ttk.Label(f, text=lab).grid(row=row, column=0, sticky="w", pady=(6, 0))
            b = ttk.Button(f, textvariable=var, command=lambda k=kind: pick(k))
            b.grid(row=row, column=1, sticky="w", pady=(6, 0))
        rep_iwad = tk.BooleanVar(value=c["repal_iwad"])
        ttk.Checkbutton(f, text="Repalettise", variable=rep_iwad).grid(row=1, column=1,
                                                                      sticky="e", pady=(6, 0))
        # PWADs: in -file order, each with its own Repalettise tick
        pw = [dict(x) for x in c["pwads"]]
        sel = tk.IntVar(value=0)
        pf = ttk.LabelFrame(f, text="PWADs (loaded in this order)", padding=6)
        pf.grid(row=10, column=0, columnspan=2, sticky="we", pady=(8, 0))
        rows = ttk.Frame(pf)
        rows.pack(fill="x")

        def draw_pw():
            for ch in rows.winfo_children():
                ch.destroy()
            if not pw:
                ttk.Label(rows, text="(none - only the IWAD)", foreground="#888").pack(
                    anchor="w")
            for k, x in enumerate(pw):
                r_ = ttk.Frame(rows)
                r_.pack(fill="x")
                ttk.Radiobutton(r_, text=os.path.basename(x["path"]), value=k,
                                variable=sel).pack(side="left")
                v = tk.BooleanVar(value=x["repal"])
                ttk.Checkbutton(r_, text="Repalettise", variable=v,
                                command=lambda x=x, v=v: x.__setitem__("repal",
                                                                       bool(v.get()))
                                ).pack(side="right")

        def add_pw():
            from tkinter import filedialog
            ps = filedialog.askopenfilenames(parent=w, title="Add PWADs",
                                             filetypes=[("WAD files", "*.wad *.WAD"),
                                                        ("All files", "*.*")])
            for p_ in ps or ():
                pw.append({"path": os.path.abspath(p_), "repal": False})
            draw_pw()

        def mv(dk):
            k = sel.get()
            j = k + dk
            if 0 <= k < len(pw) and 0 <= j < len(pw):
                pw[k], pw[j] = pw[j], pw[k]
                sel.set(j)
                draw_pw()

        def rm():
            k = sel.get()
            if 0 <= k < len(pw):
                del pw[k]
                sel.set(max(0, k - 1))
                draw_pw()
        bb = ttk.Frame(pf)
        bb.pack(anchor="w", pady=(4, 0))
        for t_, cmd_ in (("Add...", add_pw), ("Remove", rm), ("Up", lambda: mv(-1)),
                         ("Down", lambda: mv(1))):
            ttk.Button(bb, text=t_, command=cmd_).pack(side="left", padx=(0, 4))
        draw_pw()
        ttk.Label(f, text="Extra arguments").grid(row=3, column=0, sticky="w", pady=(6, 0))
        args = tk.StringVar(value=c["args"])
        e = ttk.Entry(f, textvariable=args, width=44)
        e.grid(row=3, column=1, sticky="we", pady=(6, 0))
        ttk.Label(f, foreground="#888",
                  text="e.g. -warp 1 -skill 4   ·   in game: IDBEHOLDV = invulnerability"
                  ).grid(row=4, column=1, sticky="w")
        msg = tk.StringVar()
        ttk.Label(f, textvariable=msg, foreground="#b03000").grid(row=5, column=0,
                                                                   columnspan=2, sticky="w")
        bf = ttk.Frame(f)
        bf.grid(row=11, column=0, columnspan=2, sticky="e", pady=(10, 0))
        names()
        res = {"ok": False}

        def go(_e=None):
            if not st["exe"] or not os.path.isfile(st["exe"]):
                msg.set("Choose the Doom exe first.")
                pick("exe")
                if not st["exe"]:
                    return
            if not st["iwad"] or not os.path.isfile(st["iwad"]):
                msg.set("Choose an IWAD first.")
                return
            c.update(exe=st["exe"], iwad=st["iwad"], playpal=bool(pp.get()),
                     colormap=bool(cmv.get()), dsdacr=bool(dcv.get()), args=args.get(),
                     repal_iwad=bool(rep_iwad.get()), pwads=[dict(x) for x in pw])
            self.s["run_last"] = dict(c)
            res["ok"] = True
            w.destroy()

        ttk.Button(bf, text="Run", command=go).pack(side="left")
        ttk.Button(bf, text="Cancel", command=w.destroy).pack(side="left", padx=(6, 0))
        w.bind("<Return>", go)
        w.bind("<Escape>", lambda ev: w.destroy())
        w.update_idletasks()
        r = self.root
        w.geometry("+%d+%d" % (r.winfo_rootx() + int(60 * ui), r.winfo_rooty() + int(60 * ui)))
        if not st["exe"]:
            w.after(50, lambda: pick("exe"))
        w.grab_set()
        e.focus_set()
        self.root.wait_window(w)
        if res["ok"]:
            self.run_game()

    def run_command(self, wad_path, files=()):
        """<exe> -iwad <iwad> -file [repalettised IWAD gfx] [PWADs] [palette wad]
        <extra args> - the palette WAD last so it always wins."""
        c = self.run_cfg()
        cmd = [c["exe"], "-iwad", c["iwad"]]
        fl = list(files) + ([wad_path] if wad_path else [])
        if fl:
            cmd += ["-file"] + fl
        return cmd + split_args(c["args"])

    def _run_dir(self):
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "cleanpal", "run")
        os.makedirs(d, exist_ok=True)
        return d

    def _repal_file(self, src_path, out_name, dst, fallback, only_bitmaps):
        """Repalettised copy, cached on (source file, its size / time, palette)."""
        import hashlib
        from ..cleanpal_lib_repal import repal_wad
        st = os.stat(src_path)
        key = hashlib.sha1(repr((os.path.abspath(src_path), st.st_size, int(st.st_mtime),
                                 [tuple(c) if c else None for c in dst],
                                 only_bitmaps)).encode()).hexdigest()
        out = os.path.join(self._run_dir(), out_name)
        kp = out + ".key"
        try:
            if os.path.isfile(out) and open(kp).read() == key:
                return out, None
        except OSError:
            pass
        lumps, n = repal_wad(src_path, dst, fallback, only_bitmaps)
        with open(out, "wb") as fh:
            fh.write(build_wad(lumps))
        with open(kp, "w") as fh:
            fh.write(key)
        return out, n

    def run_game(self):
        """Write the test WADs and start the game (doesn't wait)."""
        from ..cleanpal_lib_analysis import result_entries
        from ..cleanpal_lib_repal import pal_from
        from ..cleanpal_lib_wadgfx import WadArchive
        c = self.run_cfg()
        lumps = self.run_lumps(c["playpal"], c["colormap"], c["dsdacr"])
        files, notes = [], []
        if c["repal_iwad"] or any(x["repal"] for x in c["pwads"]):
            dst = result_entries(self.rgbs, self.res, self._align_on())
            ipal = pal_from(WadArchive(c["iwad"]).lump("PLAYPAL"))
            self.status_var.set("Repalettising ... (first time can take a few seconds)")
            self.root.update_idletasks()
        if c["repal_iwad"]:
            p, n = self._repal_file(c["iwad"], "iwad_repal.wad", dst, ipal, True)
            files.append(p)
            notes.append("IWAD gfx %s" % ("cached" if n is None else "%d lumps" % n))
        for k, x in enumerate(c["pwads"]):
            if not os.path.isfile(x["path"]):
                notes.append("missing %s" % os.path.basename(x["path"]))
                continue
            if x["repal"]:
                p, _n = self._repal_file(x["path"], "pwad%02d_%s" % (
                    k, os.path.basename(x["path"])), dst, ipal, False)
                files.append(p)
            else:
                files.append(x["path"])
        wad = None
        if lumps:
            wad = os.path.join(self._run_dir(), "cleanpal_run.wad")
            with open(wad, "wb") as fh:
                fh.write(build_wad(lumps))
        cmd = self.run_command(wad, files)
        try:
            subprocess.Popen(cmd, cwd=os.path.dirname(c["exe"]) or None)
        except OSError as e:
            from tkinter import messagebox
            messagebox.showerror("cleanpal", "Couldn't start the game:\n%s" % e)
            return None
        what = " + ".join(n for n, _b in lumps) or "no lumps"
        self.status_var.set("Running %s with %s (%s%s%s) - IDBEHOLDV in game = "
                            "invulnerability." % (
                                os.path.basename(c["exe"]), os.path.basename(c["iwad"]), what,
                                ", %d PWAD%s" % (len(c["pwads"]), "" if len(c["pwads"]) == 1
                                                 else "s") if c["pwads"] else "",
                                "; " + ", ".join(notes) if notes else ""))
        return cmd
