"""Edit Fades (COLORMAP tool 4): edit ONE fade as a gradient over its 32
light rows.

* The fade: the fade selection (one fade - the last one clicked when more are
  selected), else a single selected palette colour. Locked fades can't be
  edited.
* Row 0 is the colour itself (start node: fixed, can't move or change). The
  end node sits on row 31 (colour editable). Node rules as every gradient bar:
  right-click a node = select, left-drag the selected node, ◀ ▶ = one row,
  Alt+right-click = add (not selected), Alt+click = delete, Delete node.
* Palettised (default): the bar and the 32 steps show the gradient snapped to
  the palette - exactly the indices the COLORMAP gets (repeats show as runs);
  nodes snap to whole rows; node colours come from the palette (Palette...
  chooser / Pick index). True colour: the smooth gradient, nodes anywhere,
  any colour (Picker). The Matrix / Fades views follow the toggle.
* On load the gradient is fitted to the fade as it is (fewest nodes; grey
  holes left out unless Fit greys too). Until a node is edited the fade keeps
  its exact current rows, so opening + Apply changes nothing.
* Apply ramp to selection: every other fade of the palette selection joins
  the ramp where it is as dark as its own colour and carries on down from
  there (Reach the end at row / Pace / Blend in); swatch clicks leave fades
  out. Snapped like the edited fade (pal0 first, new colours in the preview).
* Apply writes rows 1-31 (palettised) as hand edits - one history entry.
"""

import copy
import math
import time

from ..cleanpal_lib_colormap import LIGHT_ROWS
from ..cleanpal_lib_colour import hex_of, parse_colour, rgb_round
from ..cleanpal_lib_constants import ENTRIES
from ..cleanpal_lib_fadeedit import (
    LAST, NEW_TOL, ROWS, MasterRamp, RowSnap, clean_fe_settings, fit_fade, make_snapper,
    make_state, node, snap_rows, snap_with_new, spread_targets, suggest_new,
)
from ..cleanpal_lib_ramps import RAMP_EASES, RAMP_SPACES, ramp_colour_at
from .gui_cmap_tools import CTOOL_COLOUR, _CWin
from .gui_gradslider import GradSlider, draw_node
from .gui_picker import EyeDropper

BG = "#262626"
HIDE_BG = "#c8b8f0"             # lavender: indicators hidden


class PaletteChooser:
    """Small 16x16 window of the current palette: click a cell -> cb(index)."""

    def __init__(self, app, owner, cb, title="Choose a palette colour"):
        tk = app.tk
        self.app, self.cb = app, cb
        ui = getattr(app, "ui", 1.0)
        self.cs = int(18 * ui)
        self.win = tk.Toplevel(owner)
        self.win.title(title)
        self.win.transient(owner)
        self.win.resizable(False, False)
        self.c = tk.Canvas(self.win, width=16 * self.cs + 2, height=16 * self.cs + 2,
                           bg=BG, highlightthickness=0)
        self.c.pack(padx=6, pady=6)
        self.info = tk.StringVar()
        from tkinter import ttk
        ttk.Label(self.win, textvariable=self.info).pack(anchor="w", padx=6, pady=(0, 6))
        self.c.bind("<Button-1>", self._click)
        self.c.bind("<Motion>", self._hover)
        self.win.bind("<Escape>", lambda e: self.close())
        self.draw()

    def draw(self):
        c, cs = self.c, self.cs
        c.delete("all")
        pal = self.app.pal
        for i in range(ENTRIES):
            x, y = 1 + (i % 16) * cs, 1 + (i // 16) * cs
            col = pal[i] if i < len(pal) else None
            if col is None or i in self.app.deleted:
                c.create_rectangle(x, y, x + cs - 1, y + cs - 1, fill="#444", outline="")
            else:
                c.create_rectangle(x, y, x + cs - 1, y + cs - 1, fill=hex_of(col),
                                   outline="")

    def _at(self, ev):
        gx, gy = (ev.x - 1) // self.cs, (ev.y - 1) // self.cs
        if 0 <= gx < 16 and 0 <= gy < 16:
            i = gy * 16 + gx
            col = self.app.pal[i]
            if col is not None and i not in self.app.deleted:
                return i
        return None

    def _hover(self, ev):
        i = self._at(ev)
        self.info.set("" if i is None else "%d  %s" % (i, hex_of(self.app.pal[i])))

    def _click(self, ev):
        i = self._at(ev)
        if i is not None:
            self.cb(i)
            self.close()

    def close(self):
        try:
            self.win.destroy()
        except Exception:
            pass


class EditFadesWin(_CWin):
    TITLE = "Edit Fades - one fade as a gradient"

    def build(self, f):
        from tkinter import ttk

        a = self.app
        tk = a.tk
        ui = self.ui
        self.o = clean_fe_settings(a.s.get("fadeedit"))
        self._after = None
        self.base = a.cm.copy()
        self.src = None
        self.orig = None            # the fade's rows when loaded (index per row)
        self.dirty = False          # a node was edited -> the gradient is written
        self.nodes = [node(0, (128, 128, 128)), node(LAST, (0, 0, 0))]
        self.active = 1
        self.scope = set()
        self.targets = {}
        self.rows_true, self.rows_idx = [], []
        self.flagged, self.misses = set(), []
        self._drag = None
        self._chooser = None
        self._flip = False          # Hold button: show the other view while held
        self._undo, self._redo = [], []
        self._last_state = None
        self._last_push = 0.0
        self._fit_text = ""
        self.newc = []              # new colours, most useful first: {row, rgb, x}
        self.new_n = 0              # how many of them are in the strip (spinner)
        self.sug_on = False         # Suggest pressed: the new colours are on the ramp
        self.active_new = None      # selected diamond (index into newc) or None
        self.new_cols = []          # in use now: on, within new_n, not crossed out
        self.new_rowset = set()     # rows that land on a new colour
        self.view_cols = None       # rows snapped to pal0 + new colours
        self._new_hits = []
        self._sel_base = (set(a.selection), set(a.fade_sel))
        self._wrote = False
        self.spread = {}            # apply ramp: fade -> (pal0 idx, view rgb, true rgb)
        self.spread_new = set()     # ... (row, fade) cells on a new colour
        self.spread_off = set()     # fades left out (swatch clicks)
        self._strip_hits = []
        # ---- top line
        top = ttk.Frame(f)
        top.grid(row=0, column=0, columnspan=3, sticky="we", pady=(0, 6))
        self.head_var = tk.StringVar()
        ttk.Label(top, textvariable=self.head_var).pack(side="left")
        self.true_btn = tk.Button(top, text="True colour", width=14, relief="raised",
                                  command=self._true_click)
        self.true_btn.pack(side="right")
        self._true_bg = self.true_btn.cget("background")
        self.hide_btn = tk.Button(top, text="Hide indicators", width=16, relief="raised",
                                  command=self._hide_click)
        self.hide_btn.pack(side="right", padx=(0, 6))
        # ---- gradient bar
        gf = ttk.LabelFrame(f, padding=(4, 2, 4, 4),
                            text="Gradient (right-click node = select · drag = move · "
                                 "◀ ▶ = one row · Alt+right-click = add · Alt+click = "
                                 "delete)")
        gf.grid(row=1, column=0, columnspan=3, sticky="we")
        gf.columnconfigure(0, weight=1)
        self.cell = max(10, int(round(20 * ui)))
        self.bar = tk.Canvas(gf, width=ROWS * self.cell + 2, height=int(74 * ui),
                             bg=BG, highlightthickness=0)
        self.bar.grid(row=0, column=0, sticky="w")
        self.bar.bind("<ButtonPress-1>", self._bar_press)
        self.bar.bind("<B1-Motion>", self._bar_motion)
        self.bar.bind("<ButtonRelease-1>", self._bar_release)
        self.bar.bind("<ButtonPress-3>", self._bar_right)
        self.bar.bind("<Double-Button-1>", self._bar_double)
        # ---- node row
        nf = ttk.Frame(f)
        nf.grid(row=2, column=0, columnspan=3, sticky="w", pady=(6, 4))
        self.node_var = tk.StringVar()
        ttk.Label(nf, textvariable=self.node_var, width=22).pack(side="left")
        self.swatch = tk.Canvas(nf, width=int(40 * ui), height=int(20 * ui),
                                highlightthickness=1, highlightbackground="#555",
                                cursor="hand2")
        self.swatch.pack(side="left")
        self.swatch.bind("<Button-1>", lambda e: self.choose_colour())
        ttk.Label(nf, text="#").pack(side="left", padx=(8, 0))
        self.hex_var = tk.StringVar()
        self.hex_e = ttk.Entry(nf, textvariable=self.hex_var, width=8)
        self.hex_e.pack(side="left")
        self.hex_e.bind("<Return>", lambda e: self._on_hex())
        self.pick_btn = ttk.Button(nf, text="Pick index", command=self.pick_index)
        self.pick_btn.pack(side="left", padx=(8, 0))
        self.drop_btn = ttk.Button(nf, text="Eyedropper", command=self.eyedropper)
        self.drop_btn.pack(side="left", padx=(4, 0))
        self.choose_btn = ttk.Button(nf, text="Picker...", command=self.open_picker)
        self.choose_btn.pack(side="left", padx=(4, 0))
        self.left_btn = ttk.Button(nf, text="◀", width=3, command=lambda: self.nudge(-1))
        self.left_btn.pack(side="left", padx=(8, 0))
        self.right_btn = ttk.Button(nf, text="▶", width=3, command=lambda: self.nudge(1))
        self.right_btn.pack(side="left", padx=(2, 0))
        self.del_btn = ttk.Button(nf, text="Delete node", command=self.delete_active)
        self.del_btn.pack(side="left", padx=(4, 0))
        # ---- blend / ease
        of = ttk.Frame(f)
        of.grid(row=3, column=0, columnspan=3, sticky="w", pady=(0, 4))
        ttk.Label(of, text="Blend").pack(side="left")
        self.space_var = tk.StringVar(value=self.o["fe_space"])
        w = ttk.Combobox(of, textvariable=self.space_var, values=RAMP_SPACES,
                         state="readonly", width=16)
        w.pack(side="left", padx=(4, 0))
        w.bind("<<ComboboxSelected>>", lambda e: self._set("fe_space", self.space_var.get()))
        ttk.Label(of, text="Ease").pack(side="left", padx=(10, 0))
        self.ease_var = tk.StringVar(value=self.o["fe_ease"])
        w = ttk.Combobox(of, textvariable=self.ease_var, values=RAMP_EASES,
                         state="readonly", width=11)
        w.pack(side="left", padx=(4, 0))
        w.bind("<<ComboboxSelected>>", lambda e: self._set("fe_ease", self.ease_var.get()))
        ttk.Label(of, text="Strength").pack(side="left", padx=(10, 0))
        self.str_var = tk.StringVar(value=str(self.o["fe_strength"]))
        sp = ttk.Spinbox(of, textvariable=self.str_var, from_=1, to=6, increment=0.25,
                         width=5, command=self._on_strength)
        sp.pack(side="left", padx=(4, 0))
        sp.bind("<Return>", lambda e: self._on_strength())
        ttk.Label(of, text="Match").pack(side="left", padx=(14, 0))
        self.metric_var = tk.StringVar(value=self.o["fe_metric"])
        for txt, val in (("RGB", "rgb"), ("Perceptual", "oklab")):
            ttk.Radiobutton(of, text=txt, value=val, variable=self.metric_var,
                            command=lambda: self._set("fe_metric", self.metric_var.get())
                            ).pack(side="left", padx=(4, 0))
        self.mono_var = tk.BooleanVar(value=self.o["fe_mono"])
        ttk.Checkbutton(of, text="Never get lighter", variable=self.mono_var,
                        command=self._mono_toggled).pack(side="left", padx=(14, 0))
        # ---- steps
        sf = ttk.LabelFrame(f, padding=(4, 2, 4, 4),
                            text="Fade rows 0-31 (hover a row for its index)")
        sf.grid(row=4, column=0, columnspan=3, sticky="we", pady=(4, 0))
        self.steps = tk.Canvas(sf, width=ROWS * self.cell + 2,
                               height=int(self.cell * 1.3) + 4, bg=BG,
                               highlightthickness=0)
        self.steps.grid(row=0, column=0, sticky="w")
        self.steps.bind("<Motion>", self._steps_hover)
        self.steps.bind("<Leave>", lambda e: self.info_var.set(""))
        self.steps.bind("<ButtonPress-1>", self._steps_click)
        self.steps.bind("<ButtonPress-3>", self._steps_right)
        self.info_var = tk.StringVar()
        ttk.Label(sf, textvariable=self.info_var, font=("Consolas", 9)).grid(
            row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Label(sf, foreground="#888",
                  text="••• under a row = the selected node · row clicks: click / "
                       "right-click = select its node · Alt+right-click = add · Alt+click "
                       "= delete").grid(row=2, column=0, sticky="w")
        # ---- fit
        ff = ttk.Frame(f)
        ff.grid(row=5, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Button(ff, text="Reload fade", command=self.reload).pack(side="left")
        self.fitg_var = tk.BooleanVar(value=self.o["fe_fitgreys"])
        ttk.Checkbutton(ff, text="Fit greys too", variable=self.fitg_var,
                        command=self._fitg_toggled).pack(side="left", padx=(10, 0))
        self.fit_var = tk.StringVar()
        ttk.Label(f, textvariable=self.fit_var, foreground="#666", wraplength=int(660 * ui),
                  justify="left").grid(row=6, column=0, columnspan=3, sticky="w",
                                       pady=(4, 0))
        ttk.Separator(f).grid(row=7, column=0, columnspan=3, sticky="we", pady=(10, 4))
        nc = ttk.Frame(f)
        nc.grid(row=8, column=0, columnspan=3, sticky="we")
        hd = ttk.Frame(nc)
        hd.pack(anchor="w", pady=(0, 4))
        ttk.Label(hd, text="New colours", font=("Segoe UI", 10, "bold")).pack(side="left")
        ttk.Label(hd, text="   diamonds under the bar - only in this tool until you write "
                           "them; pal0 colours are used wherever they're close enough",
                  foreground="#888").pack(side="left")
        r1 = ttk.Frame(nc)
        r1.pack(anchor="w")
        self.sug_btn = tk.Button(r1, text="Suggest", width=14, relief="raised",
                                 command=self.suggest)
        self.sug_btn.pack(side="left")
        ttk.Label(r1, text="New colours").pack(side="left", padx=(10, 4))
        self.n_var = tk.StringVar(value="0")
        self.n_spin = ttk.Spinbox(r1, textvariable=self.n_var, from_=0, to=0, increment=1,
                                  width=4, command=self._n_changed)
        self.n_spin.pack(side="left")
        self.n_spin.bind("<Return>", lambda e: self._n_changed())
        ttk.Button(r1, text="Clear", command=self.clear_new).pack(side="left", padx=(6, 0))
        self.write_btn = ttk.Button(r1, text="Write new colours to pal0",
                                    command=self.write_new)
        self.write_btn.pack(side="left", padx=(16, 0))
        self.new_cv = tk.Canvas(nc, height=int(18 * ui), width=ROWS * self.cell, bg=BG,
                                highlightthickness=0, cursor="hand2")
        self.new_cv.pack(anchor="w", pady=(4, 0))
        self.new_cv.bind("<Button-1>", self._new_click)
        ttk.Label(nc, foreground="#888", wraplength=int(660 * ui), justify="left",
                  text="click a swatch = cross it out (off the ramp, not written) / back in "
                       "· diamonds: right-click = select · drag = move · Alt+right-click "
                       "under the bar = add one · Alt+click = delete").pack(anchor="w")
        self.new_var = tk.StringVar()
        ttk.Label(nc, textvariable=self.new_var, foreground="#666").pack(anchor="w")
        self._sug_ui()
        # ---- apply ramp to selection
        ttk.Separator(f).grid(row=9, column=0, columnspan=3, sticky="we", pady=(10, 4))
        ap = ttk.Frame(f)
        ap.grid(row=10, column=0, columnspan=3, sticky="we")
        hd = ttk.Frame(ap)
        hd.pack(anchor="w", pady=(0, 4))
        ttk.Label(hd, text="Apply ramp to selection",
                  font=("Segoe UI", 10, "bold")).pack(side="left")
        ttk.Label(hd, text="   each selected fade joins this ramp where it is as dark as "
                           "its own colour and carries on down from there",
                  foreground="#888").pack(side="left")
        self.spread_on = False
        self.spread_btn = tk.Button(ap, text="Apply ramp to selection", width=26,
                                    relief="raised", command=self._spread_click)
        self.spread_btn.pack(anchor="w")
        sl = ttk.Frame(ap)
        sl.pack(anchor="w", fill="x", pady=(4, 0))
        self.sp_sliders = {}
        rows = (("fe_end", "Reach the end at row", 1, LAST, 1),
                ("fe_curve", "Darken curve", 0.25, 4.0, 0.01),
                ("fe_dark", "Dark colours finish sooner (%)", 0, 100, 1),
                ("fe_blendin", "Blend in (rows)", 0, 8, 1))
        for k, (key, label, lo, hi, step) in enumerate(rows):
            ttk.Label(sl, text=label).grid(row=k, column=0, sticky="w", pady=1)
            gs = GradSlider(sl, a, lo, hi, step, self.o[key],
                            lambda v, key=key: self._slider(key, v), None, ui)
            gs.frame.grid(row=k, column=1, sticky="we", pady=1, padx=(8, 0))
            if key == "fe_curve":               # 1.0 in the middle, fine steps below
                gs.log = True
                gs.draw()
            self.sp_sliders[key] = gs
        sl.columnconfigure(1, weight=1)
        self.strip = tk.Canvas(ap, width=ROWS * self.cell + 2, height=int(10 * ui), bg=BG,
                               highlightthickness=0, cursor="hand2")
        self.strip.pack(anchor="w", pady=(4, 0))
        self.strip.bind("<Button-1>", self._strip_click)
        ttk.Label(ap, foreground="#888",
                  text="click a swatch = leave that fade out / put it back (small = left "
                       "out) · ringed = the fade whose ramp is used · gold = locked"
                  ).pack(anchor="w")
        self.spinfo_var = tk.StringVar()
        ttk.Label(ap, textvariable=self.spinfo_var, foreground="#666").pack(anchor="w")
        self.win.bind("<Delete>", lambda e: self.delete_active())
        for k in ("<Control-z>", "<Control-Z>"):
            self.win.bind(k, a._on_undo_key)
        self.win.bind("<Control-y>", a._on_redo_key)
        self._true_ui()
        self._hide_ui()
        self._spread_ui()
        self.schedule(now=True)

    # ---------------------------------------------------------- settings / mode
    def _set(self, key, v, redo=True):
        self.o[key] = v
        d = dict(self.app.s.get("fadeedit") or {})
        d[key] = v
        self.app.s["fadeedit"] = d
        if key in ("fe_space", "fe_ease", "fe_strength"):
            self.dirty = True
            self._push()
        if redo:
            self.schedule()

    def _on_strength(self):
        try:
            v = min(max(float(self.str_var.get()), 1.0), 6.0)
        except ValueError:
            return
        self._set("fe_strength", v)

    def _hide_click(self):
        self._set("fe_hideind", not self.o["fe_hideind"], False)
        self._hide_ui()
        self.status("New-colour dots %s." % ("hidden" if self.o["fe_hideind"] else "shown"))
        self.app.draw_fades()

    def _hide_ui(self):
        on = bool(self.o["fe_hideind"])
        bg = HIDE_BG if on else self._true_bg
        self.hide_btn.configure(relief="sunken" if on else "raised", background=bg,
                                activebackground=bg,
                                text="Indicators hidden" if on else "Hide indicators")

    def _slider(self, key, v):
        self._set(key, float(v) if key == "fe_curve" else int(round(v)))

    def _spread_click(self):
        self.spread_on = not self.spread_on
        self._spread_ui()
        self.status("Ramp %s the selection." % ("applied to" if self.spread_on
                                                else "no longer applied to"))
        self.schedule(now=True)

    def _spread_ui(self):
        on = self.spread_on
        bg = CTOOL_COLOUR if on else self._true_bg
        self.spread_btn.configure(relief="sunken" if on else "raised", background=bg,
                                  activebackground=bg,
                                  text="Apply ramp to selection (on)" if on
                                  else "Apply ramp to selection")
        for gs in self.sp_sliders.values():
            gs.set_enabled(on)
        self.strip.configure(cursor="hand2" if on else "")

    def truecol(self):
        return bool(self.o["fe_true"]) != self._flip

    def compare_hold(self, on):
        """Hold button = the OTHER view while held (true colour <-> palettised)."""
        self._flip = bool(on)
        self.redraw_local()
        self.app.draw_fades()

    def _true_click(self):
        self._flip = False
        self._set("fe_true", not self.o["fe_true"], False)
        if not self.truecol():                     # palettised: nodes onto whole rows
            for n in self.nodes:
                n["pos"] = round(n["pos"] * LAST) / float(LAST)
            self._dedupe()
        self._true_ui()
        self.status("Showing %s." % ("the true-colour gradient" if self.truecol()
                                     else "the palettised fade (what the COLORMAP gets)"))
        self.schedule(now=True)

    def _true_ui(self):
        on = bool(self.o["fe_true"])
        bg = CTOOL_COLOUR if on else self._true_bg
        self.true_btn.configure(relief="sunken" if on else "raised", background=bg,
                                activebackground=bg,
                                text="True colour (on)" if on else "True colour")
        if hasattr(self, "cmp_btn"):
            self.cmp_btn.configure(text="Hold: palettised" if on else "Hold: true colour")
        self._free_ui()

    def _free_ui(self):
        """Picker / hex: true colour mode, or a diamond (a new colour can be
        anything) - never the row 0 node."""
        sel_new = self._sel_new() is not None
        ok = sel_new or (self.truecol() and self.active not in (0, None))
        self.choose_btn.state(["!disabled"] if ok else ["disabled"])
        self.hex_e.state(["!disabled"] if ok else ["disabled"])

    def show_true(self):
        return self.truecol()

    def status(self, txt):
        self.app.status_var.set(txt)

    def _mono_toggled(self):
        self._set("fe_mono", bool(self.mono_var.get()), False)
        self.dirty = True
        self.schedule(now=True)

    def _fitg_toggled(self):
        self._set("fe_fitgreys", bool(self.fitg_var.get()), False)
        self.reload()

    # ---------------------------------------------------------- which fade
    def _pick_src(self):
        a = self.app
        fs = [s for s in a.fade_sel if s < ENTRIES]
        if fs:
            anc = getattr(a, "_fade_anchor", None)
            return anc if anc in fs else min(fs)
        sel = [s for s in a.selection if s < ENTRIES and a.rgbs[s] is not None]
        if len(sel) == 1:
            return sel[0]
        return None

    def load(self, src):
        """Fit the gradient to the fade as it is now."""
        a = self.app
        self.src = src
        self.dirty = False
        self.base = a.cm.copy()
        res, _f = a.cmap_result()
        idxs = [res.rows[r][src] for r in range(ROWS)]
        idxs[0] = src
        cols = [tuple(a.rgbs[i]) if a.rgbs[i] is not None else (0, 0, 0) for i in idxs]
        snap = make_snapper(a.pal, a.deleted, self.o["fe_metric"])
        self.nodes, self.flagged, self.misses = fit_fade(cols, idxs, snap, src, self.o)
        self.orig = idxs
        self.active = len(self.nodes) - 1
        txt = "Fitted with %d node%s" % (len(self.nodes), "" if len(self.nodes) == 1 else "s")
        if self.flagged:
            fl = sorted(self.flagged)
            txt += " - rows %s land on grey (no close palette colour; left out of the fit)" \
                % _ranges(fl)
        if self.misses:
            txt += " - %d row%s would differ slightly once you edit (until then the fade " \
                   "keeps its exact rows)" % (len(self.misses), "" if len(self.misses) == 1
                                             else "s")
        elif not self.flagged:
            txt += " - matches the fade exactly"
        self._fit_text = txt + "."
        self.fit_var.set(self._fit_text)
        self._undo, self._redo = [], []
        self._last_state = self._state()
        if getattr(self, "_loaded_src", None) != src:
            self.newc, self.new_n, self.sug_on, self.active_new = [], 0, False, None
            self._loaded_src = src
            self._sug_ui()
            self._last_state = self._state()

    def reload(self):
        """Refit the fade (Reload fade / Fit greys too) - one undo step."""
        if self.src is None:
            return
        a = self.app
        prev, undo = self._state(), list(self._undo)
        a.cm = self.base.copy()
        a.cm_changed()
        self.load(self.src)
        self._undo = undo + [prev]
        self._redo = []
        self.schedule(now=True)

    # ---------------------------------------------------------- nodes
    def _row(self, n):
        return n["pos"] * LAST

    def _dedupe(self):
        seen, out = set(), []
        act = self.nodes[self.active] if self.active < len(self.nodes) else None
        for n in sorted(self.nodes, key=lambda q: q["pos"]):
            k = round(n["pos"], 6)
            if k in seen:
                continue
            seen.add(k)
            out.append(n)
        self.nodes = out
        self.active = out.index(act) if act in out else len(out) - 1

    def _edited(self):
        self.dirty = True
        self._push()
        self.schedule()

    # ---------------------------------------------------------- undo / redo
    def _state(self):
        return (copy.deepcopy(self.nodes), self.active, self.o["fe_space"],
                self.o["fe_ease"], self.o["fe_strength"], copy.deepcopy(self.newc),
                self.new_n, self.sug_on, self.active_new)

    def _push(self):
        """Record the state before this edit (the last committed one). Edits
        within 0.4 s (picker drags) count as one step."""
        now = time.time()
        if self._last_state is not None and now - self._last_push > 0.4:
            self._undo.append(self._last_state)
            del self._undo[:-100]
            self._redo = []
        self._last_push = now
        self._last_state = self._state()

    def _restore(self, st):
        nodes, act, sp, ea, stg, newc, nn, son, an = st
        self.nodes = copy.deepcopy(nodes)
        self.active = min(act, len(self.nodes) - 1)
        for key, v, var in (("fe_space", sp, self.space_var), ("fe_ease", ea, self.ease_var),
                            ("fe_strength", stg, self.str_var)):
            self.o[key] = v
            var.set(str(v))
        self.newc, self.new_n, self.sug_on = copy.deepcopy(newc), nn, son
        self.active_new = an
        self.n_var.set(str(nn))
        self._sug_ui()
        self._last_state = self._state()
        self.dirty = True
        self.schedule(now=True)
        self._retarget_picker()

    def undo(self, redo=False):
        """Ctrl+Z / Ctrl+Y: step node edits. False when there's nothing to step."""
        src, dst = (self._redo, self._undo) if redo else (self._undo, self._redo)
        if not src or self.src is None:
            return False
        dst.append(self._state())
        self._restore(src.pop())
        self.status("%s - %d more." % ("Redone" if redo else "Undone", len(src)))
        return True

    def main_add_node(self, r, rgb=None):
        """Alt+right-click in the main Fades / Matrix view: a cell of ANY fade
        -> a node on that row of the edited fade in that cell's colour (an
        existing node on the row / the row 31 end node takes the colour); a
        lighting number -> a node in the gradient's own colour."""
        if r <= 0 or r > LAST:
            self.status("Row 0 is the colour itself - it can't take a node.")
            return
        k = self._node_on_row(r)
        if k is not None:
            if rgb is None:
                self.status("Row %d already has a node - right-click it in the tool to "
                            "select it." % r)
                return
            self.nodes[k]["rgb"] = list(rgb)
            self.status("Node on row %d = %s." % (r, hex_of(rgb)))
            self._edited()
            return
        self.add_node(float(r), col=rgb)

    def _geo(self):
        """Bar geometry: (y0, y1 colour band, sz node size, yd diamond row,
        dd diamond half size)."""
        H = int(self.bar.cget("height"))
        y0, y1 = 2, H - int(28 * self.ui)
        sz = 8 * self.ui
        yd = y1 + 2 + sz * 1.4 + 5 * self.ui
        return y0, y1, sz, yd, 4.5 * self.ui

    def _in_lane(self, y):
        _y0, y1, sz, yd, dd = self._geo()
        return y >= y1 + 2 + sz * 1.4

    def _hit(self, x):
        best, bd = None, self.cell * 0.6
        for k, n in enumerate(self.nodes):
            d = abs(self._x(self._row(n)) - x)
            if d <= bd:
                best, bd = k, d
        return best

    def _shown_new(self):
        """Indices (into newc) of the diamonds on the ramp now."""
        if not self.sug_on:
            return []
        return [j for j, c in enumerate(self.newc[:self.new_n]) if not c["x"]]

    def _hit_new(self, x):
        best, bd = None, self.cell * 0.6
        for j in self._shown_new():
            d = abs(self._x(self.newc[j]["row"]) - x)
            if d <= bd:
                best, bd = j, d
        return best

    def _eff_nodes(self):
        """The gradient as it's used: the nodes plus the diamonds on the ramp
        (a diamond = a node carrying a new colour; on a node's row it gives
        that node its colour - never the row 0 node)."""
        nodes = [dict(n, rgb=list(n["rgb"])) for n in self.nodes]
        for j in self._shown_new():
            c = self.newc[j]
            p = c["row"] / float(LAST)
            hit = next((n for n in nodes if abs(n["pos"] - p) < 1e-6), None)
            if hit is not None:
                if hit is not nodes[0]:
                    hit["rgb"] = list(c["rgb"])
            else:
                nodes.append(node(c["row"], c["rgb"]))
        nodes.sort(key=lambda q: q["pos"])
        return nodes

    def _eff_state(self):
        return make_state(self._eff_nodes(), self.o)

    def _new_edited(self):
        """A diamond moved / recoloured / added / deleted: the gradient
        changed."""
        self.dirty = True
        self._push()
        self.schedule()

    def _sel_new(self):
        j = self.active_new
        return j if j is not None and j in self._shown_new() else None

    def _x(self, row):
        return 1 + row * self.cell + self.cell / 2.0

    def _row_at(self, x):
        r = (x - 1 - self.cell / 2.0) / self.cell
        r = min(max(r, 0.0), float(LAST))
        return r if self.truecol() else float(round(r))

    def _bar_press(self, ev):
        self._drag = None
        if self._in_lane(ev.y):
            j = self._hit_new(ev.x)
            if j is None:
                return
            if self.app._alt_down(ev):
                self.delete_new(j)
                return
            if j != self._sel_new():
                self.status("Right-click a diamond to select it, then drag it.")
                return
            self._drag = ("new", j)
            return
        k = self._hit(ev.x)
        if self.app._alt_down(ev):
            if k is not None:
                self.delete_node(k)
            return
        if k is None:
            return
        if k != self.active or self._sel_new() is not None:
            self.status("Right-click a node to select it, then drag it.")
            return
        if 0 < k < len(self.nodes) - 1:
            self._drag = k

    def _bar_motion(self, ev):
        k = self._drag
        if k is None:
            return
        if isinstance(k, tuple):                       # a diamond: whole rows
            r = int(min(max(round(self._row_at(ev.x)), 1), LAST))
            c = self.newc[k[1]]
            if c["row"] != r:
                c["row"] = r
                self._moved_new = True
                self.redraw_local()
            return
        r = min(max(self._row_at(ev.x), 0.5 if self.truecol() else 1.0),
                LAST - (0.5 if self.truecol() else 1.0))
        p = r / float(LAST)
        if any(i != k and abs(n["pos"] - p) < 1e-6 for i, n in enumerate(self.nodes)):
            return
        n = self.nodes[k]
        n["pos"] = p
        self.nodes.sort(key=lambda q: q["pos"])
        self.active = self._drag = self.nodes.index(n)
        self.dirty = True
        self.redraw_local()

    def _bar_release(self, _ev):
        if self._drag is not None:
            was = self._drag
            self._drag = None
            if isinstance(was, tuple):
                if getattr(self, "_moved_new", False):
                    self._moved_new = False
                    self._new_edited()
                return
            self._edited()

    def _bar_right(self, ev):
        if self._in_lane(ev.y):
            j = self._hit_new(ev.x)
            if self.app._alt_down(ev):
                if j is not None:
                    self.status("There's a diamond there already - right-click selects it.")
                    return
                self.add_new(int(round(self._row_at(ev.x))))
                return
            if j is not None:
                self.select_new(j)
            return
        k = self._hit(ev.x)
        if self.app._alt_down(ev):
            if k is not None:
                self.status("There's a node there already - right-click selects it.")
                return
            self.add_node(self._row_at(ev.x))
            return
        if k is not None:
            self.select(k)

    def _bar_double(self, ev):
        if self.app._alt_down(ev):
            return
        if self._in_lane(ev.y):
            j = self._hit_new(ev.x)
            if j is not None and j == self._sel_new():
                self.open_picker()
            return
        k = self._hit(ev.x)
        if k is not None and k == self.active and self._sel_new() is None:
            self.choose_colour()

    def select(self, k):
        self.active = k
        self.active_new = None
        self.redraw_local()
        self._free_ui()
        self._retarget_picker()

    def select_new(self, j):
        self.active_new = j
        self.redraw_local()
        self._free_ui()
        self._retarget_picker()

    def add_node(self, row, select=False, col=None):
        if row <= 0 or row >= LAST:
            self.status("Row 0 and row 31 already have their nodes.")
            return
        st = self._eff_state()
        if col is not None:
            col = tuple(int(v) for v in col)
        elif self.truecol():
            col = rgb_round(ramp_colour_at(st, row / float(LAST)))
        else:
            r = int(round(row))
            col = tuple(self.app.rgbs[self.rows_idx[r]]) if self.rows_idx and \
                self.rows_idx[r] is not None else rgb_round(ramp_colour_at(st, r / float(LAST)))
        act = self.nodes[self.active]
        n = node(row, col)
        self.nodes.append(n)
        self.nodes.sort(key=lambda q: q["pos"])
        self.active = self.nodes.index(n if select else act)
        self.status("Node added at row %s - right-click it to select it." % _rowtxt(row))
        self._edited()

    def delete_node(self, k):
        if k in (0, len(self.nodes) - 1):
            self.status("The row 0 and row 31 nodes always stay.")
            return
        act = self.nodes[self.active]
        del self.nodes[k]
        self.active = self.nodes.index(act) if act in self.nodes else min(k, len(self.nodes) - 1)
        self.status("Node deleted.")
        self._edited()

    def delete_active(self):
        j = self._sel_new()
        if j is not None:
            self.delete_new(j)
        else:
            self.delete_node(self.active)

    def nudge(self, d):
        j = self._sel_new()
        if j is not None:
            c = self.newc[j]
            r = c["row"] + d
            if r < 1 or r > LAST:
                self.status("The diamond can't go further that way.")
                return
            c["row"] = r
            self.status("New colour on row %d." % r)
            self._new_edited()
            return
        k = self.active
        if k in (0, len(self.nodes) - 1):
            return
        n = self.nodes[k]
        r = self._row(n)
        j = (math.floor(r + 1e-6) + 1) if d > 0 else (math.ceil(r - 1e-6) - 1)
        if j <= 0 or j >= LAST:
            self.status("The node can't go further that way.")
            return
        p = j / float(LAST)
        if any(i != k and abs(q["pos"] - p) < 1e-6 for i, q in enumerate(self.nodes)):
            self.status("There's another node on row %d." % j)
            return
        n["pos"] = p
        self.nodes.sort(key=lambda q: q["pos"])
        self.active = self.nodes.index(n)
        self.status("Node on row %d." % j)
        self._edited()

    def set_colour(self, rgb):
        j = self._sel_new()
        if j is not None:
            self.newc[j]["rgb"] = tuple(int(v) for v in rgb)
            self._new_edited()
            return
        k = self.active
        if k == 0:
            self.status("Row 0 is the colour itself - it can't change.")
            return
        self.nodes[k]["rgb"] = list(rgb)
        self._edited()

    def choose_colour(self):
        """Double-click the selected node: picker (true colour / a diamond) or
        the pal0 popup."""
        if self.truecol() or self._sel_new() is not None:
            self.open_picker()
        else:
            self.pick_index()

    def open_picker(self):
        if self._sel_new() is None and self.active == 0:
            self.status("Row 0 is the colour itself - it can't change.")
            return
        if not self.truecol() and self._sel_new() is None:
            self.status("Picker is for True colour mode - use Pick index or Eyedropper.")
            return
        p = self.app.open_picker()
        p.owner = self.win
        self._retarget_picker(force=True)

    def eyedropper(self):
        """Screen eyedropper; in Palettised mode the colour snaps to the
        nearest pal0 colour."""
        if self._sel_new() is None and self.active == 0:
            self.status("Row 0 is the colour itself - it can't change.")
            return

        def got(rgb):
            if rgb is None:
                return
            rgb = tuple(int(v) for v in rgb)
            if not self.truecol() and self._sel_new() is None:
                a = self.app
                snap = make_snapper(a.pal, a.deleted, self.o["fe_metric"])
                from ..cleanpal_lib_colour import oklab
                i = snap.nearest(oklab(rgb), rgb)
                if i is None:
                    return
                self.status("Eyedropper %s -> nearest pal0 colour %d %s." % (
                    hex_of(rgb), i, hex_of(a.rgbs[i])))
                rgb = tuple(a.rgbs[i])
            self.set_colour(rgb)
        EyeDropper(self.app, got)

    def _retarget_picker(self, force=False):
        p = self.app.picker
        if p is None or (getattr(p, "owner", None) is not self.win and not force):
            return
        j = self._sel_new()
        if j is not None:
            p.set_target(lambda rgb, hsl: self.set_colour(tuple(int(v) for v in rgb)),
                         tuple(self.newc[j]["rgb"]), None, "Edit Fades new colour %d" % (j + 1))
            return
        k = self.active
        if k == 0 or not self.truecol():
            p.set_target(None, (128, 128, 128), None, "")
            return
        p.set_target(lambda rgb, hsl: self.set_colour(tuple(int(v) for v in rgb)),
                     tuple(self.nodes[k]["rgb"]), None, "Edit Fades node %d" % (k + 1))

    def pick_index(self):
        """pal0 popup (click a cell); a click on a palette / Matrix / Fades
        cell in the main window works too while it's open."""
        if self._sel_new() is None and self.active == 0:
            self.status("Row 0 is the colour itself - it can't change.")
            return
        a = self.app
        if self._chooser is not None:
            self._chooser.close()

        def done(i):
            if self._chooser is not None:
                self._chooser.close()
                self._chooser = None
            if a._cmap_pick is not None:
                a._cmap_pick = lambda _i: None      # end the main-window pick quietly
                a.cmap_pick_cancel()
            if i is None:
                return
            self.set_colour(tuple(a.rgbs[i]))
            self.status("%s = palette colour %d %s." % (
                "New colour" if self._sel_new() is not None else "Node %d" % (self.active + 1),
                i, hex_of(a.rgbs[i])))
        self._chooser = PaletteChooser(a, self.win, done)
        a.cmap_pick_start(lambda i: done(i) if i is not None else None)

    def _on_hex(self):
        c = parse_colour(self.hex_var.get())
        if c is not None and (self.truecol() or self._sel_new() is not None):
            self.set_colour(c)

    def suggest(self):
        """Suggest toggle. First press: the fewest new colours that get every
        row close to the true-colour ramp (fixed from then on - move / edit
        them as diamonds). Unpress: off the ramp, kept. Press again: back as
        they were. Clear forgets them."""
        if self.src is None:
            return
        if self.sug_on:
            self.sug_on = False
            self.active_new = None
            self.status("New colours off the ramp (kept - press Suggest to put them back).")
        elif self.newc:
            self.sug_on = True
            self.status("New colours back on the ramp.")
        else:
            a = self.app
            snap = make_snapper(a.pal, a.deleted, self.o["fe_metric"])
            order = suggest_new(self.rows_true, snap, self.src, self.o["fe_mono"],
                                limit=ENTRIES)
            if not order:
                self.status("Nothing to add - every row is already close to the true colour.")
                self._sug_ui()
                return
            self.newc = [{"row": r, "rgb": tuple(self.rows_true[r]), "x": False}
                         for r in order]
            self.new_n = len(order)
            self.n_var.set(str(self.new_n))
            self.sug_on = True
            self.status("Suggest: %d new colour%s get every row close - lower the spinner "
                        "or cross some out to use fewer." % (len(order),
                                                             "" if len(order) == 1 else "s"))
        self._sug_ui()
        self._push()
        self.schedule(now=True)

    def _sug_ui(self):
        on = self.sug_on
        bg = CTOOL_COLOUR if on else self._true_bg
        self.sug_btn.configure(relief="sunken" if on else "raised", background=bg,
                               activebackground=bg, text="Suggest (on)" if on else "Suggest")
        self.n_spin.configure(to=len(self.newc))

    def clear_new(self):
        if not self.newc:
            return
        self.newc, self.new_n, self.sug_on, self.active_new = [], 0, False, None
        self.n_var.set("0")
        self._sug_ui()
        self._push()
        self.status("New colours cleared - Suggest works them out fresh.")
        self.schedule(now=True)

    def add_new(self, r):
        """Alt+right-click under the bar: a new colour by hand on row r (the
        gradient's colour there), shown on the ramp."""
        r = int(min(max(r, 1), LAST))
        st = self._eff_state()
        col = rgb_round(ramp_colour_at(st, r / float(LAST)))
        self.newc.insert(self.new_n, {"row": r, "rgb": col, "x": False})
        self.new_n += 1
        self.n_var.set(str(self.new_n))
        self.sug_on = True
        self._sug_ui()
        self.status("New colour added on row %d - right-click it to select it." % r)
        self._new_edited()

    def delete_new(self, j):
        del self.newc[j]
        if j < self.new_n:
            self.new_n -= 1
        self.n_var.set(str(self.new_n))
        if self.active_new == j:
            self.active_new = None
        elif self.active_new is not None and self.active_new > j:
            self.active_new -= 1
        self._sug_ui()
        self.status("New colour deleted.")
        self._new_edited()

    def _new_click(self, ev):
        for x0, x1, j in self._new_hits:
            if x0 <= ev.x <= x1:
                c = self.newc[j]
                c["x"] = not c["x"]
                if c["x"] and self.active_new == j:
                    self.active_new = None
                self.dirty = True
                self._push()
                self.status("New colour %d %s." % (j + 1, "crossed out - off the ramp, "
                                                   "won't be written" if c["x"] else "back in"))
                self.schedule(now=True)
                return

    def _n_changed(self):
        try:
            n = int(float(self.n_var.get()))
        except ValueError:
            return
        self._set_n(n)

    def _set_n(self, n):
        n = max(0, min(int(n), len(self.newc)))
        if n == self.new_n:
            self.n_var.set(str(n))
            return
        self.new_n = n
        self.n_var.set(str(n))
        self.dirty = True
        self._push()
        self.schedule(now=True)

    def view_rgb(self, r, s):
        """Main window: the edited fade snapped to pal0 + the new colours;
        with Apply ramp to selection, the other fades too (both modes)."""
        if s == self.src:
            if self.truecol():
                return None
            return None if self.view_cols is None else self.view_cols[r]
        sp = self.spread.get(s)
        if sp is not None:
            return sp[2][r] if self.truecol() else sp[1][r]
        return None

    def new_rows(self):
        """Rows of the edited fade that land on a new colour (main-window
        markers under the lighting numbers)."""
        if self.truecol() or self.o["fe_hideind"]:
            return set()
        return set(self.new_rowset)

    def write_new(self):
        """Put the new colours into pal0: after the end of the palette
        selection (light to dark, pushing the rest along), else at the end
        of the palette - even into the overflow below the red line."""
        a = self.app
        use = [self.newc[j] for j in self._shown_new()]
        cols = list(dict.fromkeys(tuple(c["rgb"]) for c in use))
        if not cols or self.src is None:
            self.status("No new colours to write - press Suggest first.")
            return
        from ..cleanpal_lib_colour import oklab
        cols.sort(key=lambda c: -oklab(c)[0])
        sel = [i for i in a.selection if i < ENTRIES]
        if sel:
            p = max(sel) + 1
            where = "after the palette selection (cell %d)" % max(sel)
        else:
            last = max((i for i in range(len(a.rgbs)) if a.rgbs[i] is not None), default=-1)
            p = last + 1
            where = "at the end of the palette"
        held0 = sum(1 for c in a.rgbs[ENTRIES:] if c is not None)
        a.cm = self.base.copy()
        src_before = self.src
        slots, newpos, msg = a.place_colours(cols, "insert", True, p)
        if not slots:
            a.cm_changed()
            self.status("Couldn't write the new colours: %s" % msg)
            self.schedule()
            return
        if newpos is not None:
            a.fade_sel = {newpos[i] for i in a.fade_sel if newpos[i] < len(a.rgbs)}
            if getattr(a, "_fade_anchor", None) is not None and a._fade_anchor < len(newpos):
                a._fade_anchor = newpos[a._fade_anchor]
            self.src = newpos[src_before] if src_before < len(newpos) else src_before
            self._loaded_src = self.src
            self.spread_off = {newpos[i] for i in self.spread_off if i < len(newpos)}
        self.base = a.cm.copy()
        self._wrote = True
        self._written = getattr(self, "_written", 0) + len(slots)
        if sel:                                      # they extend the ramp's selection
            a.selection = set(a.selection) | {x for x in slots if x < ENTRIES}
        over = sum(1 for c in a.rgbs[ENTRIES:] if c is not None) - held0
        a.cm_changed()
        a.recompute()
        txt = "Wrote %d new colour%s to pal0 %s - cells %s." % (
            len(slots), "" if len(slots) == 1 else "s", where,
            ", ".join(str(x) for x in slots[:10]) + ("..." if len(slots) > 10 else ""))
        if over > 0:
            txt += " WARNING: %d colour%s went past 255 into the overflow below the red " \
                   "line." % (over, "" if over == 1 else "s")
        self.status(txt)
        # the diamonds become ordinary gradient nodes (now pal0 colours)
        for c in use:
            r = int(c["row"])
            k = self._node_on_row(r)
            if k is not None:
                if k:
                    self.nodes[k]["rgb"] = list(c["rgb"])
            else:
                self.nodes.append(node(r, c["rgb"]))
        self.nodes.sort(key=lambda q: q["pos"])
        self.active = min(self.active, len(self.nodes) - 1)
        self.newc, self.new_n, self.sug_on, self.active_new = [], 0, False, None
        self.n_var.set("0")
        self._sug_ui()
        self._undo, self._redo = [], []          # pal0 changed: old steps don't fit
        self._last_state = self._state()
        self.dirty = True
        self.schedule(now=True)

    def _spread_scope(self):
        """Fades the ramp is applied to: the palette selection minus the fade
        being edited, locked fades, empty cells and fades left out."""
        a = self.app
        return [s_ for s_ in sorted(a.selection) if s_ < ENTRIES and s_ != self.src
                and a.rgbs[s_] is not None and s_ not in a.cmap_locks
                and s_ not in self.spread_off]

    def _spread(self, st, snap):
        """Carry the ramp down every fade in scope -> self.spread. The pal0-only
        snap is what gets written; the view uses pal0 + the new colours."""
        self.spread, self.spread_new = {}, set()
        if not self.spread_on or self.src is None:
            return
        a, o = self.app, self.o
        scope = self._spread_scope()
        if not scope:
            return
        m = MasterRamp(st)
        for s_ in scope:
            tr, _t0 = spread_targets(m, a.rgbs[s_], o["fe_end"], o["fe_curve"],
                                     o["fe_dark"], o["fe_blendin"])
            rs = RowSnap(snap, tr)
            idx, cols, _e = rs.path(s_, (), o["fe_mono"], NEW_TOL, ENTRIES)
            if self.new_cols:
                vidx, cols, _e = rs.path(s_, self.new_cols, o["fe_mono"], NEW_TOL, ENTRIES)
                self.spread_new.update((r, s_) for r in range(1, ROWS)
                                       if vidx[r] is not None and vidx[r] >= ENTRIES)
            self.spread[s_] = (idx, cols, tr)

    def marked_cells(self):
        """Main window: dots on cells that would use a new colour."""
        if self.o["fe_hideind"] or self.truecol():
            return set()
        return self.spread_new

    def _strip_click(self, ev):
        a = self.app
        if not self.spread_on:
            self.status("Press Apply ramp to selection first.")
            return
        for x0, y0, x1, y1, s_ in self._strip_hits:
            if x0 <= ev.x <= x1 and y0 <= ev.y <= y1:
                if s_ == self.src:
                    self.status("Fade %d is the one you're editing - it's always included."
                                % s_)
                elif s_ in a.cmap_locks:
                    self.status("Fade %d is locked - unlock it to include it." % s_)
                elif s_ in self.spread_off:
                    self.spread_off.discard(s_)
                    self.status("Fade %d put back in." % s_)
                else:
                    self.spread_off.add(s_)
                    self.status("Fade %d left out." % s_)
                self.schedule(now=True)
                return

    def _draw_strip(self):
        """The palette selection as swatches with their index numbers."""
        a, c, cs, ui = self.app, self.strip, self.cell, self.ui
        c.delete("all")
        self._strip_hits = []
        sel = [s_ for s_ in sorted(a.selection) if s_ < ENTRIES and a.rgbs[s_] is not None]
        if not sel:
            c.configure(height=int(18 * ui))
            c.create_text(4, int(9 * ui), anchor="w", fill="#999",
                          text="Select palette colours to apply the ramp to.")
            return
        lab_h = int(12 * ui)
        row_h = cs + lab_h + int(4 * ui)
        per = ROWS
        nrow = (len(sel) + per - 1) // per
        c.configure(height=nrow * row_h + 2)
        for k, s_ in enumerate(sel):
            x = 1 + (k % per) * cs
            y = 1 + (k // per) * row_h
            off = s_ in self.spread_off
            lk = s_ in a.cmap_locks
            pad = 2 if not (off or lk) else cs * 0.32
            col = hex_of(a.rgbs[s_])
            c.create_rectangle(x + pad, y + pad, x + cs - 2 - pad, y + cs - 2 - pad,
                               fill=col, outline="#d4a017" if lk else "",
                               width=max(1, round(ui)))
            if s_ == self.src:                  # the ramp's own fade: white + black ring
                w = max(2, round(2 * ui))
                b = max(1, round(ui))
                c.create_rectangle(x + 1 + w / 2.0, y + 1 + w / 2.0, x + cs - 3 - w / 2.0,
                                   y + cs - 3 - w / 2.0, outline="#ffffff", width=w)
                c.create_rectangle(x + 1 + w + b / 2.0, y + 1 + w + b / 2.0,
                                   x + cs - 3 - w - b / 2.0, y + cs - 3 - w - b / 2.0,
                                   outline="#000000", width=b)
            dim = off or lk or not self.spread_on
            c.create_text(x + (cs - 2) / 2.0, y + cs + lab_h / 2.0, text=str(s_),
                          fill="#666" if dim else "#cccccc", font=("Consolas", 7))
            self._strip_hits.append((x, y, x + cs, y + row_h, s_))

    def _draw_new(self):
        """The strip: the first new_n new colours; crossed out = red X."""
        cv = self.new_cv
        cv.delete("all")
        self._new_hits = []
        s_ = int(18 * self.ui)
        for j, c in enumerate(self.newc[:self.new_n]):
            x0 = 1 + j * (s_ + 2)
            cv.create_rectangle(x0, 1, x0 + s_, s_ - 1, fill=hex_of(c["rgb"]), outline="")
            if c["x"]:
                w = max(2, round(2 * self.ui))
                cv.create_line(x0 + 2, 3, x0 + s_ - 2, s_ - 3, fill="#ff2020", width=w)
                cv.create_line(x0 + s_ - 2, 3, x0 + 2, s_ - 3, fill="#ff2020", width=w)
            elif j == self._sel_new():
                cv.create_rectangle(x0, 1, x0 + s_, s_ - 1, outline="#00e5ff",
                                    width=max(2, round(2 * self.ui)))
            self._new_hits.append((x0, x0 + s_, j))

    def _steps_row(self, ev):
        r = int((ev.x - 1) // self.cell)
        return r if 0 <= r < ROWS else None

    def _node_on_row(self, r):
        for k, n in enumerate(self.nodes):
            if abs(self._row(n) - r) < 0.5:
                return k
        return None

    def _steps_click(self, ev):
        r = self._steps_row(ev)
        if r is None:
            return
        k = self._node_on_row(r)
        if self.app._alt_down(ev):
            if k is not None:
                self.delete_node(k)
            return
        if k is not None:
            self.select(k)

    def _steps_right(self, ev):
        r = self._steps_row(ev)
        if r is None:
            return
        k = self._node_on_row(r)
        if self.app._alt_down(ev):
            if k is None:
                self.add_node(float(r))
            else:
                self.status("Row %d has a node - right-click selects it." % r)
            return
        if k is not None:
            self.select(k)

    def _steps_hover(self, ev):
        r = self._steps_row(ev)
        if r is None or not self.rows_idx:
            self.info_var.set("")
            return
        i = self.rows_idx[r]
        t = self.rows_true[r]
        txt = "Row %d -> index %s %s" % (r, i, hex_of(self.app.rgbs[i]) if i is not None
                                          else "")
        if self.truecol() and r:
            txt += "   true %s" % hex_of(t)
        if r in self.flagged:
            txt += "   (grey hole - left out of the fit)"
        if r in self.new_rowset and not self.truecol():
            txt += "   -> NEW colour %s" % hex_of(self.view_cols[r])
        self.info_var.set(txt)

    # ---------------------------------------------------------- build / draw
    def schedule(self, now=False):
        a = self.app
        if self._after is not None:
            a.root.after_cancel(self._after)
        self._after = a.root.after(1 if now else 60, self.rebuild)

    def rebuild(self):
        a = self.app
        self._after = None
        if a.ctool_win is not self or a.rgbs is None:
            return
        if a._cmap_compare:
            self.schedule()
            return
        self.spread, self.spread_new = {}, set()
        src = self._pick_src()
        if src is None or a.rgbs[src] is None:
            if self.src is not None:
                a.cm = self.base.copy()
                a.cm_changed()
                a.recompute()
            self.src = None
            self.scope = set()
            self.head_var.set("Click one fade's number (Matrix / Fades), or select one "
                              "palette colour.")
            self.fit_var.set("")
            self.rows_idx = []
            self.redraw_local()
            return
        if src in a.cmap_locks:
            self.head_var.set("Fade %d is locked - unlock it to edit." % src)
            self.src, self.scope, self.rows_idx = None, set(), []
            self.redraw_local()
            return
        if src != self.src:
            self.load(src)
        self.nodes[0]["rgb"] = list(a.rgbs[src])
        self.nodes[0]["pos"] = 0.0
        self.nodes[-1]["pos"] = 1.0
        self.scope = {src}
        snap = make_snapper(a.pal, a.deleted, self.o["fe_metric"])
        st = self._eff_state()
        tr, idx = snap_rows(st, snap, src, self.o["fe_mono"])
        if not self.dirty and self.orig is not None:
            idx = list(self.orig)                 # untouched: keep the fade exactly
        self.rows_true, self.rows_idx = tr, idx
        # new colours: the fixed diamonds that are on the ramp now
        self.view_cols, self.new_rowset = None, set()
        if self.active_new is not None and self._sel_new() is None:
            self.active_new = None
        shown = self._shown_new()
        self.new_cols = [tuple(self.newc[j]["rgb"]) for j in shown]
        if self.new_cols:
            force = {int(self.newc[j]["row"]): k for k, j in enumerate(shown)}
            vidx, vcols = snap_with_new(tr, a.rgbs, a.deleted, self.o["fe_metric"],
                                        self.new_cols, src, limit=ENTRIES,
                                        mono=self.o["fe_mono"], force=force)
            self.view_cols = vcols
            self.new_rowset = {r for r in range(1, ROWS) if vidx[r] is not None
                               and vidx[r] >= ENTRIES}
        self.n_spin.configure(to=len(self.newc))
        self.targets = {(r, src): tr[r] for r in range(1, ROWS)}
        cm = self.base.copy()                    # untouched: the fade stays as it is
        if self.dirty:
            cm.overrides = {k: v for k, v in cm.overrides.items()
                            if not (k[1] == src and 1 <= k[0] < LAST + 1)}
            cm.fullbright = set(cm.fullbright) - {src}
            for r in range(1, ROWS):
                if idx[r] is not None and r < LIGHT_ROWS:
                    cm.overrides[(r, src)] = idx[r]
        self.head_var.set("Fade %d  %s%s" % (src, hex_of(a.rgbs[src]),
                                             "" if self.dirty else "   (as loaded)"))
        self.fit_var.set("Edited - %d node%s." % (len(self.nodes), "" if len(self.nodes) == 1
                                                  else "s") if self.dirty else self._fit_text)
        if self.new_cols:
            worst = 0.0
            from ..cleanpal_lib_colour import oklab
            for r in range(1, ROWS):
                p_, q_ = oklab(tr[r]), oklab(self.view_cols[r])
                worst = max(worst, sum((p_[j] - q_[j]) ** 2 for j in range(3)) ** 0.5)
            nx = sum(1 for c in self.newc[:self.new_n] if c["x"])
            self.new_var.set("%d new colour%s%s - %d row%s use them - worst row now %.3f off "
                             "(not in pal0 until you write them)" % (
                                 self.new_n, "" if self.new_n == 1 else "s",
                                 " (%d crossed out)" % nx if nx else "",
                                 len(self.new_rowset), "" if len(self.new_rowset) == 1
                                 else "s", worst))
        elif self.newc and not self.sug_on:
            self.new_var.set("Suggest is off - %d new colour%s kept; press Suggest to put "
                             "them back." % (len(self.newc), "" if len(self.newc) == 1
                                             else "s"))
        elif self.newc:
            self.new_var.set("No new colours on the ramp (all crossed out or the spinner "
                             "is at 0).")
        else:
            self.new_var.set("Suggest finds the fewest new colours that get every row close "
                             "to the true-colour ramp.")
        self._spread(st, snap)
        for s_, (sidx, _c, _t) in self.spread.items():
            cm.overrides = {k: v for k, v in cm.overrides.items()
                            if not (k[1] == s_ and 1 <= k[0] < LAST + 1)}
            cm.fullbright = set(cm.fullbright) - {s_}
            for r in range(1, ROWS):
                if sidx[r] is not None and r < LIGHT_ROWS:
                    cm.overrides[(r, s_)] = sidx[r]
        self._spread_info()
        self._draw_new()
        self._draw_strip()
        if cm != a.cm:
            a.cm = cm
            a.cm_changed()
            a.recompute()
        else:
            a.draw_fades()
        self.redraw_local()
        self._true_ui()
        self.refresh()

    def _spread_info(self):
        a = self.app
        if not self.spread_on:
            self.spinfo_var.set("Off - press Apply ramp to selection to carry this fade's "
                                "ramp down the other selected fades.")
            return
        sel = [s_ for s_ in a.selection if s_ < ENTRIES and a.rgbs[s_] is not None
               and s_ != self.src]
        n = len(self.spread)
        out = sum(1 for s_ in sel if s_ in self.spread_off and s_ not in a.cmap_locks)
        lk = sum(1 for s_ in sel if s_ in a.cmap_locks)
        txt = "Applied to %d fade%s" % (n, "" if n == 1 else "s")
        if out:
            txt += ", %d left out" % out
        if lk:
            txt += ", %d locked" % lk
        if self.spread_new:
            nf = len({s_ for _r, s_ in self.spread_new})
            txt += " - %d use new colours in %d cell%s (white dots; written once the new " \
                   "colours are in pal0)" % (nf, len(self.spread_new),
                                             "" if len(self.spread_new) == 1 else "s")
        self.spinfo_var.set(txt + ".")

    def redraw_local(self):
        self._draw_bar()
        self._draw_steps()
        self._node_ui()

    def _cols(self):
        if not self.rows_idx:
            return None
        if self.truecol():
            return self.rows_true
        if self.view_cols is not None:
            return self.view_cols
        return [tuple(self.app.rgbs[i]) if i is not None else (0, 0, 0)
                for i in self.rows_idx]

    def _draw_bar(self):
        c, cs = self.bar, self.cell
        c.delete("all")
        H = int(c.cget("height"))
        y0, y1 = 2, H - int(28 * self.ui)
        cols = self._cols()
        if cols is None:
            return
        if self.truecol():
            st = self._eff_state()
            n = ROWS * 4
            for k in range(n):
                t = k / float(n - 1)
                x = 1 + cs / 2.0 + t * LAST * cs
                w = LAST * cs / float(n - 1) + 1
                c.create_rectangle(x - w / 2, y0, x + w / 2, y1,
                                   fill=hex_of(rgb_round(ramp_colour_at(st, t))), outline="")
            c.create_rectangle(1, y0, 1 + cs / 2.0, y1, fill=hex_of(cols[0]), outline="")
            c.create_rectangle(1 + LAST * cs + cs / 2.0, y0, 1 + ROWS * cs, y1,
                               fill=hex_of(cols[-1]), outline="")
        else:
            for r, col in enumerate(cols):
                c.create_rectangle(1 + r * cs, y0, 1 + (r + 1) * cs, y1, fill=hex_of(col),
                                   outline="")
        _y0, _y1, sz, yd, dd = self._geo()                # new-colour diamonds
        sel_j = self._sel_new()
        for j in self._shown_new():
            nc_ = self.newc[j]
            x = self._x(nc_["row"])
            on = j == sel_j
            d2 = dd * (1.35 if on else 1.0)
            c.create_polygon(x, yd - d2, x + d2, yd, x, yd + d2, x - d2, yd,
                             fill=hex_of(nc_["rgb"]),
                             outline="#00e5ff" if on else "#ffffff",
                             width=max(2, round(2.5 * self.ui)) if on
                             else max(1, round(self.ui)))
        for k, n in enumerate(self.nodes):
            x = self._x(self._row(n))
            on = k == self.active and sel_j is None
            if on:
                c.create_line(x, y0, x, y1, fill="#000000")
            pts = (x, y1 + 2, x - sz * 0.8, y1 + 2 + sz * 1.4, x + sz * 0.8, y1 + 2 + sz * 1.4)
            draw_node(c, pts, hex_of(n["rgb"]), on, self.ui)

    def _draw_steps(self):
        c, cs = self.steps, self.cell
        c.delete("all")
        cols = self._cols()
        if cols is None:
            return
        for r, col in enumerate(cols):
            c.create_rectangle(1 + r * cs, 1, 1 + (r + 1) * cs - 2, cs - 1, fill=hex_of(col),
                               outline="")
        j = self._sel_new()
        if j is not None or self.active < len(self.nodes):
            row = self.newc[j]["row"] if j is not None else self._row(self.nodes[self.active])
            cx = 1 + row * cs + (cs - 2) / 2.0
            cy = cs + (cs * 0.3) / 2.0 + 1
            r = max(1.5, cs / 16.0)
            for d in (-3.2, 0.0, 3.2):
                c.create_oval(cx + d * r - r, cy - r, cx + d * r + r, cy + r,
                              fill="#ffffff", outline="")

    def _node_ui(self):
        if not self.nodes:
            return
        j = self._sel_new()
        if j is not None:
            c = self.newc[j]
            self.node_var.set("New colour %d at row %d" % (j + 1, c["row"]))
            col = c["rgb"]
            for b in (self.left_btn, self.right_btn, self.del_btn, self.pick_btn,
                      self.drop_btn):
                b.state(["!disabled"])
        else:
            k = min(self.active, len(self.nodes) - 1)
            n = self.nodes[k]
            last = len(self.nodes) - 1
            self.node_var.set("Node %d/%d at row %s%s" % (
                k + 1, last + 1, _rowtxt(self._row(n)),
                " (start - the colour)" if k == 0 else " (end)" if k == last else ""))
            col = n["rgb"]
            mid = ["disabled"] if k in (0, last) else ["!disabled"]
            for b in (self.left_btn, self.right_btn, self.del_btn):
                b.state(mid)
            for b in (self.pick_btn, self.drop_btn):
                b.state(["disabled"] if k == 0 else ["!disabled"])
        self.swatch.delete("all")
        self.swatch.create_rectangle(0, 0, 400, 400, fill=hex_of(col), outline="")
        self.hex_var.set(hex_of(col)[1:])
        self._free_ui()

    def log_text(self):
        w = getattr(self, "_written", 0)
        return "fade %s edited (%d nodes, %s)%s" % (
            self.src, len(self.nodes), "true colour" if self.truecol() else "palettised",
            (", %d new colour%s written to pal0" % (w, "" if w == 1 else "s")) if w else "") \
            + ((", ramp applied to %d selection fade%s" % (
                len(self.spread), "" if len(self.spread) == 1 else "s"))
               if self.spread else "")

    # ---------------------------------------------------------- session hooks
    def sel_changed(self):
        self.schedule()

    def external_edit(self):
        self.base = self.app.cm.copy()
        self.src = None
        self.schedule()

    def note_applied(self):
        self._fit_text = "Applied - %d nodes." % len(self.nodes)
        self._sel_base = (set(self.app.selection), set(self.app.fade_sel))
        self._wrote = False
        self._written = 0
        self.base = self.app.cm.copy()
        if self.src is not None:
            res, _f = self.app.cmap_result()
            self.orig = [res.rows[r][self.src] for r in range(ROWS)]
            self.orig[0] = self.src
        self.dirty = False

    def note_reverted(self):
        a = self.app
        if self._wrote:
            a.selection, a.fade_sel = (set(x) for x in self._sel_base)
            a._fade_anchor = None
            self._wrote = False
            self._written = 0
            a.recompute()
        self.base = self.app.cm.copy()
        self.src = None                  # reload + refit the fade
        self.schedule()

    def teardown(self):
        a = self.app
        if self._chooser is not None:
            self._chooser.close()
        if a._cmap_pick is not None:
            a.cmap_pick_cancel()
        p = a.picker
        if p is not None and getattr(p, "owner", None) is self.win:
            p.owner = None
            try:
                p.set_target(None, (128, 128, 128), None, "")
            except a.tk.TclError:
                pass
        if self._after is not None:
            a.root.after_cancel(self._after)
            self._after = None
        _CWin.teardown(self)


def _rowtxt(r):
    return "%d" % int(round(r)) if abs(r - round(r)) < 1e-6 else "%.1f" % r


def _ranges(rows):
    out, a = [], None
    for r in rows + [None]:
        if a is None:
            a = b = r
        elif r is not None and r == b + 1:
            b = r
        else:
            out.append("%d" % a if a == b else "%d-%d" % (a, b))
            a = b = r
    return ", ".join(out)
