"""COLORMAP mode (App mixin): the side panel (tools strip + COLORMAP files),
the fade area under the palette (Fades / Matrix views, minimise buttons),
COLORMAP files and the preview's lighting hooks.

v5 rebuild: the editing tools were emptied. The working COLORMAP is still
generated from the palette + the saved Generate settings + any hand edits
already in the history (CmapState), so the preview, the Matrix view and
export always show a real COLORMAP. New tools plug in through
gui_cmap_tools.py."""

import os

from ..cleanpal_lib_colormap import (
    CMAP_EXPORTS, INVUL_ROW, LIGHT_ROWS,
    CmapState, clean_cmap_settings, default_cmap_settings, generate, import_overrides,
    load_colormap, locks_remap, read_wad_lump, rows_from_bytes, write_colormap,
)
from ..cleanpal_lib_constants import ENTRIES

MODES = ["pal0", "COLORMAP"]          # "pal0" was called PLAYPAL before 5.2.5


class CmapMixin:
    """COLORMAP mode for the main window."""

    # ---------------------------------------------------------- state
    def _cmap_init(self):
        tk = self.tk
        s = self.s
        self.cm = CmapState()
        self.cmap_loaded = None          # {"rows", "pal", "name"}
        self.cmap_set = default_cmap_settings()
        try:
            self.cmap_set.update(clean_cmap_settings(s))
        except ValueError:
            pass
        self._cm_ver = 0
        self._cmap_cache = (None, None)  # (signature, result)
        self.mode_var = tk.StringVar(value=MODES[0])
        self.cmap_view = tk.StringVar(value="Matrix")
        self._cmap_pick = None           # eyedropper callback (Generate's Fade to colour)
        self._cmap_compare = False       # Hold to compare: show the tool's "before"
        self.fade_sel = set()            # fades picked in the Matrix / Fades view
        self._fade_anchor = None
        self._fade_cells = []
        self._fade_labels = []
        self._fade_after = None
        self._sort_cm = None
        self._ramp_cm = None
        hide = s.get("cmap_hide_extra", True)
        self.cmap_hide_extra = tk.BooleanVar(value=bool(hide))
        self.cmap_show_extra = tk.BooleanVar(value=not bool(hide))   # read by the preview
        self.cmap_sel_only = tk.BooleanVar(value=bool(s.get("cmap_sel_only", True)))
        self.cmap_locks = {}             # fade locks: src -> 31 frozen slots (rows 1-31)
        self._matrix_cols = []
        self._pane_min = None            # None / "palette" / "fades"
        self._sash_prev = None

    def cm_changed(self):
        self._cm_ver += 1

    def cmap_signature(self, applied=False):
        if applied and self.history:
            h = self.history[self.hist_pos]
            return ("applied", self.hist_pos, id(h), id(h.get("cmap")), id(h["palette"]),
                    id(self.cmap_loaded), tuple(sorted(self.cmap_locks.items())))
        rg = tuple(self.pal) if self.rgbs is not None else None
        return (rg, frozenset(self.deleted), self._cm_ver, self._compare_on(),
                tuple(sorted(self.cmap_locks.items())),
                tuple(sorted((k, tuple(v) if isinstance(v, list) else v)
                             for k, v in self.cmap_set.items())),
                id(self.cmap_loaded))

    def cmap_result(self, base=False):
        """Generated COLORMAP for the working palette, cached.
        Returns (result, flags); flags is empty until a diagnostics tool
        is rebuilt (kept as a pair so tools can add them back)."""
        if self.rgbs is None:
            return None, {}
        sig = self.cmap_signature()
        if self._cmap_cache[0] == sig:
            return self._cmap_cache[1], {}
        res = generate(self.pal, self.deleted, self.cmap_set, self.cm, self.cmap_loaded,
                       self.cmap_locks)
        self._cmap_cache = (sig, res)
        return res, {}

    def cmap_applied_result(self):
        """(palette, COLORMAP result) of the current history entry - what the
        preview's Applied view shows. Cached per entry."""
        if not self.history:
            return None, None
        h = self.history[self.hist_pos]
        sig = (id(h), id(h.get("cmap")), id(h["palette"]), id(self.cmap_loaded),
               tuple(sorted(self.cmap_locks.items())))
        cache = getattr(self, "_applied_cache", (None, None, None))
        if cache[0] == sig:
            return cache[1], cache[2]
        pal = list(h["palette"][:ENTRIES])
        res = generate(pal, set(), h.get("cmap_set") or self.cmap_set,
                       (h.get("cmap") or CmapState()).copy(), self.cmap_loaded,
                       self.cmap_locks)
        self._applied_cache = (sig, pal, res)
        return pal, res

    def cmap_mode(self):
        return self.mode_var.get() == MODES[1]

    def _compare_on(self):
        return bool(self._cmap_compare and getattr(self, "ctool", None) is not None
                    and getattr(self, "_ctool_start", None) is not None)

    # ---------------------------------------------------------- UI build
    def _build_cmap_panel(self, side):
        """COLORMAP side panel: the tools strip + COLORMAP files."""
        from tkinter import ttk

        tk = self.tk
        ui = getattr(self, "ui", 1.0)
        frames = [self._build_ctools_panel(side)]

        gf = ttk.LabelFrame(side, text="COLORMAP files", padding=8)
        frames.append(gf)
        self.cmap_status = tk.StringVar(value="Generated from the palette")
        ttk.Label(gf, textvariable=self.cmap_status, foreground="#666",
                  wraplength=int(300 * ui)).pack(anchor="w")
        r = ttk.Frame(gf)
        r.pack(fill="x", pady=(6, 0))
        ttk.Button(r, text="Open COLORMAP...", command=self.cmap_open).pack(side="left")
        self.cmap_import_btn = ttk.Button(r, text="Import as hand edits",
                                          command=self.cmap_import)
        self.cmap_import_btn.pack(side="left", padx=(6, 0))
        ttk.Checkbutton(gf, text="Hide invulnerability + dark rows",
                        variable=self.cmap_hide_extra,
                        command=self._on_show_extra).pack(anchor="w", pady=(8, 0))
        self._cmap_frames = frames

    # ---------------------------------------------------------- mode switch
    def set_mode(self, mode=None):
        if mode == "PLAYPAL":                       # old name (projects, settings)
            mode = MODES[0]
        if mode:
            self.mode_var.set(mode)
        cm = self.cmap_mode()
        if cm:
            self._cancel_previews()
            self.selection = {i for i in self.selection if i < ENTRIES}
            if self.tool is not None:              # PLAYPAL tools close first
                self.mode_var.set(MODES[0])
                ok = self.close_tool(quiet=True)
                self.mode_var.set(MODES[1])
                if not ok:
                    self.mode_var.set(MODES[0])
                    return
            for fr in self._pp_frames:
                fr.pack_forget()
            for fr in self._cmap_frames:
                fr.pack(fill="x", pady=(8, 0), before=self.snap_frame)
            if str(self.fade_frame) not in [str(p) for p in self.main_pane.panes()]:
                self.root.update_idletasks()
                self.main_pane.add(self.fade_frame, stretch="always",
                                   minsize=self._bar_height())
                self.main_pane.paneconfigure(self.grid_pane, stretch="never")
                self._pane_min = None
                self.root.after_idle(self._sash_restore_saved)
        else:
            if getattr(self, "ctool", None) is not None:
                self.mode_var.set(MODES[1])
                ok = self.close_ctool(quiet=True)
                self.mode_var.set(MODES[0])
                if not ok:
                    self.mode_var.set(MODES[1])
                    return
            for fr in self._cmap_frames:
                fr.pack_forget()
            for fr in self._pp_frames_before:
                fr.pack(fill="x", pady=(8, 0), before=self.snap_frame)
            for fr in self._pp_frames_after:
                fr.pack(fill="x", pady=(8, 0), before=self.btn_frame)
            if str(self.fade_frame) in [str(p) for p in self.main_pane.panes()]:
                self.main_pane.forget(self.fade_frame)
                self.main_pane.paneconfigure(self.grid_pane, stretch="always")
            self._pane_min = None
        self._pp_frames[0].pack_configure(pady=(0, 0)) if not cm else None
        if cm and self._cmap_frames:
            self._cmap_frames[0].pack_configure(pady=(0, 0))
        self.root.update_idletasks()
        self._side_layout()
        self.fit_view()
        self.recompute()

    # ---------------------------------------------------------- split / minimise
    def _bar_height(self):
        return self.fade_bar.winfo_reqheight() + 6

    def _pane_total(self):
        return max(self.main_pane.winfo_height(), 1)

    def _sash_y(self):
        try:
            return self.main_pane.sash_coord(0)[1]
        except self.tk.TclError:
            return None

    def _sash_place(self, y):
        try:
            self.main_pane.sash_place(0, 0, int(max(0, min(y, self._pane_total()))))
        except self.tk.TclError:
            pass

    def _sash_restore_saved(self):
        frac = self.s.get("cmap_sash_frac", 0.42)
        if not isinstance(frac, (int, float)) or not 0.0 <= frac <= 1.0:
            frac = 0.42
        self._sash_place(self._pane_total() * frac)
        if hasattr(self, "_panes") and len(self._shown()) == 2:
            self.root.update_idletasks()
            self._inner_restore()
        self._update_min_btns()

    def _sash_dragged(self):
        """Sash released after a drag: remember the split."""
        if not self.cmap_mode():
            return
        y = self._sash_y()
        if y is None:
            return
        self._pane_min = None
        self._update_min_btns()
        self.s["cmap_sash_frac"] = round(y / float(self._pane_total()), 4)

    def pane_minimise(self, which):
        """Minimise the palette or the fade view; again = restore."""
        if not self.cmap_mode():
            return
        if self._pane_min == which:
            self.pane_restore()
            return
        if self._pane_min is None:
            self._sash_prev = self._sash_y()
        self._pane_min = which
        if which == "palette":
            if not self._shown():                 # show the fade panes again
                self._pane_show = {"matrix": True, "fades": True}
                self.s["cmap_show_matrix"] = self.s["cmap_show_fades"] = True
                self._inner_layout()
            self._sash_place(0)
        else:
            self._sash_place(self._pane_total() - self._bar_height())
        self._update_min_btns()

    def pane_restore(self):
        if self._pane_min is None:
            return
        if self._pane_min == "fades" and hasattr(self, "_panes") and not self._shown():
            self._pane_show = {"matrix": True, "fades": True}
            self.s["cmap_show_matrix"] = self.s["cmap_show_fades"] = True
            self._inner_layout()
        self._pane_min = None
        if self._sash_prev is not None:
            self._sash_place(self._sash_prev)
        else:
            self._sash_restore_saved()
        self._update_min_btns()

    def _update_min_btns(self):
        self.min_pal_btn.configure(text="▼ Palette" if self._pane_min == "palette"
                                   else "▲ Palette")
        sh = getattr(self, "_pane_show", {"matrix": True, "fades": True})
        self.min_matrix_btn.configure(text="▼ Matrix" if sh["matrix"] else "▲ Matrix")
        self.min_fades_btn.configure(text="▼ Fades" if sh["fades"] else "▲ Fades")

    # ---------------------------------------------------------- invul / dark rows
    def _fade_cols(self):
        """Strip columns: light rows 0-31, plus I (invulnerability) when shown."""
        return INVUL_ROW + 1 if self.cmap_show_extra.get() else LIGHT_ROWS

    def _matrix_rows(self):
        """Light rows 0-31, plus the invulnerability row when shown (never row 33)."""
        return INVUL_ROW + 1 if self.cmap_show_extra.get() else LIGHT_ROWS

    def _on_show_extra(self):
        self.s["cmap_hide_extra"] = bool(self.cmap_hide_extra.get())
        self.cmap_show_extra.set(not self.cmap_hide_extra.get())
        if self.preview is not None and hasattr(self.preview, "sync_extra"):
            self.preview.sync_extra()
        self._fade_schedule()

    # ---------------------------------------------------------- settings / history
    def apply_cmap_settings(self, d):
        """Generate settings from a history entry / project."""
        s = dict(self.cmap_set)
        s.update({k: v for k, v in d.items() if k.startswith("cmap_")})
        self.cmap_set = s

    def _cmap_commit(self, text):
        """Hand edits changed. With a COLORMAP tool open the change joins its
        session (Apply records it); otherwise it's a history entry now."""
        self.cm_changed()
        if getattr(self, "ctool", None) is not None:
            self._ctool_log.append(text)
            w = self.ctool_win
            if w is not None and hasattr(w, "external_edit"):
                w.external_edit()
            self.status_var.set("COLORMAP: %s - Apply in the tool records it." % text)
            self.recompute()
            return
        self._push_history("COLORMAP: %s" % text)
        self.status_var.set("COLORMAP: %s - recorded as #%d." % (text, self.hist_pos))
        self.recompute()

    def _sel_colours(self):
        return [i for i in sorted(self.selection)
                if self.rgbs is not None and self.rgbs[i] is not None]

    # ---------------------------------------------------------- files
    def _loaded_from_wad(self, path, rgbs):
        try:
            raw = read_wad_lump(path, "COLORMAP")
            if raw is None:
                return None
            return {"rows": rows_from_bytes(raw), "pal": list(rgbs),
                    "name": "%s COLORMAP" % os.path.basename(path)}
        except (OSError, ValueError):
            return None

    def _wad_colormap_in(self):
        """Opening a WAD with its own COLORMAP: that COLORMAP becomes the
        working one - every cell of rows 1-31 + the invulnerability row 32 as
        hand edits (row 0 is the colour itself, row 33 black). -> number of
        cells, or None (no WAD COLORMAP)."""
        ld = self.cmap_loaded
        if not ld or ld.get("iwad") or self.rgbs is None:
            return None
        self.cm = CmapState()
        self.cm_changed()
        res, _f = self.cmap_result()
        if res is None:
            return None
        # the WAD's COLORMAP was made for THIS palette: index for index (by-colour
        # matching would give duplicate colours the first copy's fade)
        rows = ld["rows"]
        pal = self.pal
        ov = {}
        for r in range(1, min(INVUL_ROW + 1, len(rows), len(res.rows))):
            for s_, c in enumerate(pal):
                if c is None or s_ >= len(rows[r]):
                    continue
                t = rows[r][s_]
                if 0 <= t < len(pal) and pal[t] is not None:
                    ov[(r, s_)] = t          # EVERY cell: hand edits re-path the fade,
                                             # so "only where different" isn't enough
        self.cm.overrides.update(ov)
        self.cm_changed()
        return len(ov)

    def clean_colormap(self):
        """Clean COLORMAP (side panel): drop the hand edits - back to the
        COLORMAP generated from the palette. Rows 1-31 only, unless "Also
        reset invulnerability" is ticked (then row 32 too). Locked fades stay
        (locks always win). One history entry."""
        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return
        if getattr(self, "ctool", None) is not None:
            from .gui_cmap_tools import CTOOL_NAME
            self.status_var.set("Apply or Revert the %s tool first, then Clean COLORMAP."
                                % CTOOL_NAME.get(self.ctool, "COLORMAP"))
            return
        inv = bool(self.s.get("cmap_clean_invul", False))
        cm = self.cm
        keep = {k: t for k, t in cm.overrides.items() if k[0] == INVUL_ROW and not inv}
        gone = len(cm.overrides) - len(keep)
        if not gone and not (cm.fullbright or cm.limits or cm.curves):
            self.status_var.set("Clean COLORMAP: nothing to clean - it's already the "
                                "generated one%s." % ("" if inv else
                                                      " (row 32 kept, not ticked)"))
            return
        cm.overrides = keep
        cm.fullbright, cm.limits, cm.curves = set(), {}, {}
        self._cmap_commit("Clean COLORMAP - %d hand-set cells removed%s" % (
            gone, ", invulnerability reset" if inv else ", row 32 kept"))

    def _cmap_status_text(self):
        if self.cmap_loaded:
            self.cmap_status.set("Loaded for compare / import: %s.\nThe working COLORMAP is "
                                 "generated from the palette plus your hand edits."
                                 % self.cmap_loaded["name"])
            self.cmap_import_btn.state(["!disabled"])
        else:
            self.cmap_status.set("Generated from the palette plus your hand edits "
                                 "(no COLORMAP loaded).")
            self.cmap_import_btn.state(["disabled"])

    def cmap_open(self):
        from tkinter import filedialog, messagebox

        if self.rgbs is None:
            self.status_var.set("Open a palette first.")
            return
        p = filedialog.askopenfilename(
            title="Open COLORMAP", initialdir=self.s.get("last_dir") or None,
            filetypes=[("COLORMAP sources", "*.wad *.lmp *.png *.raw *.cmp"),
                       ("WAD", "*.wad"), ("Raw lump", "*.lmp *.raw *.cmp"),
                       ("COLORMAP image", "*.png"), ("All files", "*.*")])
        if not p:
            return
        try:
            rows = load_colormap(p, self.pal)
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not open COLORMAP:\n%s\n\n%s" % (p, e))
            return
        self.cmap_loaded = {"rows": rows, "pal": list(self.pal),
                            "name": os.path.basename(p)}
        self._cmap_status_text()
        self.status_var.set("Loaded COLORMAP %s (%d rows) - its indices are read against "
                            "the current palette." % (os.path.basename(p), len(rows)))
        self.recompute()

    def cmap_import(self):
        if not self.cmap_loaded or self.rgbs is None:
            return
        res, _f = self.cmap_result()
        ov = {(r, s): t for (r, s), t in
              import_overrides(self.pal, res, self.cmap_loaded).items()
              if 1 <= r < LIGHT_ROWS and s not in self.cmap_locks}     # fade rows only
        if not ov:
            self.status_var.set("The loaded COLORMAP already matches the generated one.")
            return
        self.cm.overrides.update(ov)
        self._cmap_commit("imported %d hand-set cells from %s" % (len(ov),
                                                                  self.cmap_loaded["name"]))

    def export_mapping(self):
        """(entries, mapping old->new, owner) for what an export writes now."""
        r = self.res
        align = self._align_on()
        entries = [None] * ENTRIES
        mapping = {}
        if align:
            for new, old in enumerate(r["aligned"]):
                if old is not None:
                    mapping[old] = new
        else:
            for i in r["kept"]:
                mapping[i] = i
        for old, new in mapping.items():
            entries[new] = self.rgbs[old]
        owner = {i: r["owner"][i] for i in range(ENTRIES)
                 if r["status"][i] in ("exact", "similar")}
        return entries, mapping, owner

    def export_colormap_rows(self):
        entries, mapping, owner = self.export_mapping()
        cm2 = self.cm.copy()
        cm2.remap(mapping, owner)
        res = generate(entries, set(), self.cmap_set, cm2, self.cmap_loaded,
                       locks_remap(self.cmap_locks, mapping, owner))
        return entries, res.rows

    def cmap_export(self):
        """Old entry point: the Export dialog (top bar) does it now."""
        self.export_dialog()

    # ---------------------------------------------------------- preview lighting
    def light_palette(self, row, cols, compare=False, applied=False):
        """Lit colours for a list of preview colours at COLORMAP row `row`."""
        if compare and self.cmap_loaded:
            pal = self.cmap_loaded["pal"]
            rows = self.cmap_loaded["rows"]
        elif applied and self.history:
            pal, res = self.cmap_applied_result()
            if res is None:
                return list(cols)
            rows = res.rows
        else:
            res, _f = self.cmap_result()
            if res is None:
                return list(cols)
            pal = self.pal
            rows = res.rows
        if row >= len(rows):
            return list(cols)
        first = {}
        for i, c in enumerate(pal):
            if c is not None:
                first.setdefault(tuple(c), i)
        out = []
        for c in cols:
            i = first.get(tuple(c))
            if i is None:
                out.append(tuple(c))
                continue
            t = rows[row][i]
            tc = pal[t] if 0 <= t < len(pal) else None
            out.append(tuple(tc) if tc is not None else (0, 0, 0))
        return out

    def compare_palette(self):
        if not self.cmap_loaded:
            return None
        return list(dict.fromkeys(tuple(c) for c in self.cmap_loaded["pal"] if c is not None))
