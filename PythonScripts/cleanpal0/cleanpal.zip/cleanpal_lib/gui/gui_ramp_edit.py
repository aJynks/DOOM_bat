"""Edit Ramps (COLORMAP tool 3): build the selected fades from ONE shared
ramp you draw yourself.

* Ramp type (chosen first): Gradient = colour nodes; Lightness + colour =
  a grey lightness strip (how dark each row is) and a colour strip (hue and
  colourfulness only).
* Each selected fade enters the ramp where the ramp is as dark as its own
  colour (markers above the strip), then walks down it - Same speed (dark
  colours reach the end sooner) or Stretch to fit (every fade uses all 31
  rows). Blend in eases each fade's own colour into the ramp.
* Node 0 is always the brightest selected colour and can't move or go.
  Nodes take a palette colour (Pick index: click a palette / fade cell) or
  any true colour (Picker...).
* While the tool is open the edited fades show the TRUE-COLOUR ramp in the
  main window; Show switches to the palettised result (nearest palette
  colour, RGB or Perceptual) or to Palettised + new colours (the palette plus
  the suggestions - white dots in the main window).
* Add missing colours: the worst misses (up to Max) can be added to the
  palette in one click; the fades then palettise to them. Apply = one
  history entry for everything.
"""

from ..cleanpal_lib_colormap import LIGHT_ROWS
from ..cleanpal_lib_colour import hex_of, oklab
from ..cleanpal_lib_constants import ENTRIES
from ..cleanpal_lib_rampedit import (
    POSITIONS, Ramp, Snapper, build_ramp_fades, clean_re_settings, grey_of,
    missing_colours,
)
from .gui_cmap_tools import CTOOL_COLOUR, _CWin

MARK_BG = "#262626"


# ============================================================ strip widget
class RampStrip:
    """32 cells (ramp positions 0-31) with node triangles under them and
    fade-entry markers above. kind: "colour" (rgb nodes) / "light" (L nodes)
    / "view" (read-only result)."""

    def __init__(self, parent, owner, kind, title):
        from tkinter import ttk
        tk = owner.app.tk
        ui = owner.ui
        self.o, self.kind = owner, kind
        self.cs = max(10, int(round(17 * ui)))
        self.band = int(round(12 * ui)) if kind != "light" else int(round(4 * ui))
        self.nh = int(round(13 * ui)) if kind != "view" else int(round(3 * ui))
        self.ch = int(round(self.cs * 1.3))
        self.frame = ttk.Frame(parent)
        ttk.Label(self.frame, text=title, width=10).pack(side="left", anchor="n",
                                                          pady=(self.band, 0))
        self.c = tk.Canvas(self.frame, width=POSITIONS * self.cs + 2,
                           height=self.band + self.ch + self.nh + 2, bg=MARK_BG,
                           highlightthickness=0)
        self.c.pack(side="left")
        if kind != "view":
            self.c.bind("<ButtonPress-1>", self._press)
            self.c.bind("<B1-Motion>", self._drag)
            self.c.bind("<Double-Button-1>", self._double)
        self._drag_k = None

    def _pos_at(self, x):
        return int(min(max(x // self.cs, 0), POSITIONS - 1))

    def nodes(self):
        return self.o.node_list(self.kind)

    def _press(self, ev):
        p = self._pos_at(ev.x)
        nodes = self.nodes()
        k = min(range(len(nodes)), key=lambda i: abs(nodes[i][0] - p))
        if abs(nodes[k][0] - p) <= 1:
            self.o.select_node(self.kind, k)
            self._drag_k = k if k > 0 else None
        else:
            self._drag_k = None
            self.o.status("Double-click a cell to add a node there.")

    def _drag(self, ev):
        k = self._drag_k
        if k is None:
            return
        p = max(1, self._pos_at(ev.x))
        nodes = self.nodes()
        if p == nodes[k][0] or any(q == p for i, (q, _v) in enumerate(nodes) if i != k):
            return
        self._drag_k = self.o.move_node(self.kind, k, p)

    def _double(self, ev):
        p = self._pos_at(ev.x)
        if p == 0:
            return
        self.o.add_node(self.kind, p)

    def draw(self, colours, entries=(), active=None):
        """colours: 32 rgb; entries: [(position, rgb)] markers; active =
        selected node index or None."""
        c, cs = self.c, self.cs
        c.delete("all")
        y0 = self.band
        for p, rgb in enumerate(colours):
            c.create_rectangle(1 + p * cs, y0, 1 + (p + 1) * cs - 1, y0 + self.ch,
                               fill=hex_of(rgb), outline="")
        for t, rgb in entries:
            x = 1 + t * cs + cs / 2.0
            c.create_line(x, 1, x, y0 - 1, fill="#ffffff", width=3)
            c.create_line(x, 2, x, y0 - 2, fill=hex_of(rgb), width=1)
        if self.kind == "view":
            return
        yt = y0 + self.ch + 1
        for k, (p, _v) in enumerate(self.nodes()):
            x = 1 + p * cs + cs / 2.0
            h = self.nh - 2
            on = k == active
            c.create_polygon(x, yt, x - h * 0.7, yt + h, x + h * 0.7, yt + h,
                             fill=CTOOL_COLOUR if on else ("#ffcc66" if k == 0 else "#dddddd"),
                             outline="#000000" if not on else "#ffffff")


# ============================================================ window
class EditRampsWin(_CWin):
    TITLE = "Edit Ramps - fades from your own ramp"

    def build(self, f):
        from tkinter import ttk
        from .gui_gradslider import GradSlider

        a = self.app
        tk = a.tk
        ui = self.ui
        self.o = clean_re_settings(a.s.get("rampedit"))
        self._after = None
        self.scope = set()
        self.targets = {}
        self.entries = {}
        self.base = a.cm.copy()
        self._sel_base = self._sel_state()
        self._added = []
        self.proposals = []
        self.picks = set()                # Ctrl+clicked suggestions (empty = all)
        self.prev_rgb = {}                # Palettised + new: (row, src) -> rgb
        self.new_cells = set()
        self.uses = {}                    # suggestion -> cells using it
        self.lead = None
        self.lead_rgb = (128, 128, 128)
        self.g_nodes = [[0, (128, 128, 128)], [31, (0, 0, 0)]]
        self.l_nodes = [[0, 0.6], [31, 0.0]]
        self.c_nodes = [[0, (128, 128, 128)]]
        self.active = ("colour", 1)
        self.scope_var = tk.StringVar()
        ttk.Label(f, textvariable=self.scope_var, foreground="#666").grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 6))
        # ramp type
        ttk.Label(f, text="Ramp type").grid(row=1, column=0, sticky="w")
        self.mode_var = tk.StringVar(value="Gradient" if self.o["re_mode"] == "gradient"
                                     else "Lightness + colour")
        mc = ttk.Combobox(f, textvariable=self.mode_var, state="readonly", width=20,
                          values=["Gradient", "Lightness + colour"])
        mc.grid(row=1, column=1, sticky="w", pady=(0, 6))
        mc.bind("<<ComboboxSelected>>", lambda e: self._mode_changed())
        # strips
        self.sf = ttk.Frame(f)
        self.sf.grid(row=2, column=0, columnspan=3, sticky="w", pady=(2, 2))
        self.s_grad = RampStrip(self.sf, self, "colour", "Ramp")
        self.s_light = RampStrip(self.sf, self, "light", "Lightness")
        self.s_col = RampStrip(self.sf, self, "colour2", "Colour")
        self.s_view = RampStrip(self.sf, self, "view", "Result")
        # node row
        nf = ttk.Frame(f)
        nf.grid(row=3, column=0, columnspan=3, sticky="w", pady=(4, 6))
        self.node_var = tk.StringVar()
        ttk.Label(nf, textvariable=self.node_var, width=24).pack(side="left")
        self.swatch = tk.Canvas(nf, width=int(34 * ui), height=int(20 * ui),
                                highlightthickness=1, highlightbackground="#555",
                                cursor="hand2")
        self.swatch.pack(side="left", padx=(0, 6))
        self.swatch.bind("<Button-1>", lambda e: self.picker())
        self.pick_btn = ttk.Button(nf, text="Pick index", command=self.pick_index)
        self.pick_btn.pack(side="left")
        self.picker_btn = ttk.Button(nf, text="Picker...", command=self.picker)
        self.picker_btn.pack(side="left", padx=(4, 0))
        self.del_btn = ttk.Button(nf, text="Delete node", command=self.delete_node)
        self.del_btn.pack(side="left", padx=(4, 0))
        self.lslider_f = ttk.Frame(f)
        ttk.Label(self.lslider_f, text="Lightness", width=10).pack(side="left")
        self.lslider = GradSlider(self.lslider_f, a, 0, 100, 1, 50,
                                  self._light_value, lambda v: grey_of(v / 100.0), ui)
        self.lslider.frame.pack(side="left", fill="x", expand=True)
        # options
        ttk.Label(f, text="Blend").grid(row=5, column=0, sticky="w")
        bf = ttk.Frame(f)
        bf.grid(row=5, column=1, columnspan=2, sticky="w", pady=2)
        self.blend_var = tk.StringVar(value=self.o["re_blend"])
        self._blend_rbs = []
        for txt, val in (("Around the wheel", "wheel"), ("Straight", "straight"),
                         ("RGB", "rgb")):
            rb = ttk.Radiobutton(bf, text=txt, value=val, variable=self.blend_var,
                                 command=lambda: self._set("re_blend", self.blend_var.get()))
            rb.pack(side="left", padx=(0, 10))
            self._blend_rbs.append(rb)
        ttk.Label(f, text="Pace").grid(row=6, column=0, sticky="w")
        pf = ttk.Frame(f)
        pf.grid(row=6, column=1, columnspan=2, sticky="w", pady=2)
        self.pace_var = tk.StringVar(value=self.o["re_pace"])
        for txt, val in (("Same speed (dark colours finish sooner)", "same"),
                         ("Stretch to fit", "stretch")):
            ttk.Radiobutton(pf, text=txt, value=val, variable=self.pace_var,
                            command=lambda: self._set("re_pace", self.pace_var.get())
                            ).pack(side="left", padx=(0, 10))
        ttk.Label(f, text="Blend in (rows)").grid(row=7, column=0, sticky="w")
        self.blendin = GradSlider(f, a, 0, 8, 1, self.o["re_blendin"],
                                  lambda v: self._set("re_blendin", int(v)), None, ui)
        self.blendin.frame.grid(row=7, column=1, columnspan=2, sticky="we", pady=2)
        ttk.Label(f, text="Match").grid(row=8, column=0, sticky="w")
        mf = ttk.Frame(f)
        mf.grid(row=8, column=1, columnspan=2, sticky="w", pady=2)
        self.metric_var = tk.StringVar(value=self.o["re_metric"])
        for txt, val in (("RGB", "rgb"), ("Perceptual", "oklab")):
            ttk.Radiobutton(mf, text=txt, value=val, variable=self.metric_var,
                            command=lambda: self._set("re_metric", self.metric_var.get())
                            ).pack(side="left", padx=(0, 10))
        ttk.Label(f, text="Show").grid(row=9, column=0, sticky="w")
        vf = ttk.Frame(f)
        vf.grid(row=9, column=1, columnspan=2, sticky="w", pady=2)
        self.view_var = tk.StringVar(value="true")
        self._view_rbs = {}
        for txt, val in (("True colour", "true"), ("Palettised", "pal"),
                         ("Palettised + new colours", "new")):
            rb = ttk.Radiobutton(vf, text=txt, value=val, variable=self.view_var,
                                 command=self._view_changed)
            rb.pack(side="left", padx=(0, 10))
            self._view_rbs[val] = rb
        self.mark_var = tk.BooleanVar(value=bool(a.s.get("rampedit_marks", False)))
        self.mark_chk = ttk.Checkbutton(vf, text="Mark new colours", variable=self.mark_var,
                                        command=self._mark_toggled)
        self.mark_chk.pack(side="left", padx=(6, 0))
        # add missing colours
        ttk.Separator(f).grid(row=10, column=0, columnspan=3, sticky="we", pady=(8, 6))
        self.add_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Add missing colours", variable=self.add_var,
                        command=self._add_toggled).grid(row=11, column=0, columnspan=3,
                                                        sticky="w")
        self.add_f = ttk.Frame(f)
        self.add_f.grid(row=12, column=0, columnspan=3, sticky="we")
        ttk.Label(self.add_f, text="Max new colours").grid(row=0, column=0, sticky="w")
        self.addmax = GradSlider(self.add_f, a, 1, 32, 1, self.o["re_add_max"],
                                 lambda v: self._set("re_add_max", int(v)), None, ui)
        self.addmax.frame.grid(row=0, column=1, columnspan=2, sticky="we", pady=2)
        af = ttk.Frame(self.add_f)
        af.grid(row=1, column=0, columnspan=3, sticky="w", pady=2)
        self.place_var = tk.StringVar(value=self.o["re_add_place"])
        self._add_widgets = []
        for txt, val in (("After selection", "insert"), ("Empty slots", "empty")):
            rb = ttk.Radiobutton(af, text=txt, value=val, variable=self.place_var,
                                 command=lambda: self._set("re_add_place",
                                                           self.place_var.get(), False))
            rb.pack(side="left", padx=(0, 10))
            self._add_widgets.append(rb)
        self.tog_var = tk.BooleanVar(value=self.o["re_add_together"])
        cb = ttk.Checkbutton(af, text="Keep together", variable=self.tog_var,
                             command=lambda: self._set("re_add_together",
                                                       bool(self.tog_var.get()), False))
        cb.pack(side="left", padx=(4, 0))
        self._add_widgets.append(cb)
        bx = ttk.Frame(self.add_f)
        bx.grid(row=2, column=0, columnspan=3, sticky="we", pady=(4, 0))
        bh = a.s.get("rampedit_box_h")
        bh = float(bh) if isinstance(bh, (int, float)) and not isinstance(bh, bool) \
            and bh > 0 else 40.0
        self.prop_cv = tk.Canvas(bx, height=int(bh * ui), bg=MARK_BG, highlightthickness=0)
        self.prop_cv.pack(fill="x", expand=True)
        self.prop_cv.bind("<Configure>", lambda e: self._draw_props())
        self.prop_cv.bind("<ButtonPress-1>", self._prop_click)
        self.prop_cv.bind("<Motion>", self._prop_hover)
        self.prop_cv.bind("<Leave>", lambda e: self.prop_hover.set(""))
        grip = tk.Frame(bx, height=max(6, int(7 * ui)), bg="#9a9a9a",
                        cursor="sb_v_double_arrow")
        grip.pack(fill="x")
        grip.bind("<ButtonPress-1>", self._grip_press)
        grip.bind("<B1-Motion>", self._grip_drag)
        grip.bind("<ButtonRelease-1>", self._grip_release)
        self._props_geom = []
        pr = ttk.Frame(self.add_f)
        pr.grid(row=3, column=0, columnspan=3, sticky="w", pady=(4, 0))
        self.add_btn = ttk.Button(pr, text="Add to palette", command=self.add_to_palette)
        self.add_btn.pack(side="left")
        self._add_widgets.append(self.add_btn)
        self.clear_btn = ttk.Button(pr, text="Clear picks", command=self._clear_picks)
        self.clear_btn.pack(side="left", padx=(6, 0))
        self._add_widgets.append(self.clear_btn)
        self.prop_hover = tk.StringVar()
        ttk.Label(pr, textvariable=self.prop_hover, foreground="#666").pack(
            side="left", padx=(10, 0))
        self.add_info = tk.StringVar()
        ttk.Label(self.add_f, textvariable=self.add_info, foreground="#666").grid(
            row=4, column=0, columnspan=3, sticky="w")
        self.add_f.columnconfigure(1, weight=1)
        ttk.Label(f, foreground="#888", wraplength=int(560 * ui), justify="left",
                  text="Select fades (click their numbers, else the palette selection). "
                       "One ramp for all of them: each fade starts where the ramp is as "
                       "dark as its own colour (markers above the strip). Node 0 = the "
                       "brightest selected colour. Double-click a cell to add a node, "
                       "drag a node along, Delete removes it. Pick index = click a palette "
                       "or fade cell for an exact palette colour; Picker = any colour. "
                       "Show: the ramp as drawn, snapped to the palette, or snapped to the "
                       "palette plus the suggested colours (Mark new colours = white dots). Ctrl+click "
                       "suggestions to use / add only those.").grid(row=13, column=0, columnspan=3, sticky="w",
                                      pady=(8, 0))
        f.columnconfigure(1, weight=1)
        self.win.bind("<Delete>", lambda e: self.delete_node())
        self.win.bind("<Escape>", lambda e: (a.close_ctool(), "break")[1])
        self._layout()
        self._add_toggled(redo=False)
        self.schedule(now=True)

    # ---------------------------------------------------------- state helpers
    def _sel_state(self):
        a = self.app
        return (set(a.selection), set(a.fade_sel), set(a.cmap_pool))

    def status(self, txt):
        self.app.status_var.set(txt)

    def _mode(self):
        return "gradient" if self.mode_var.get() == "Gradient" else "lc"

    def _set(self, key, v, redo=True):
        self.o[key] = v
        d = dict(self.app.s.get("rampedit") or {})
        d[key] = v
        self.app.s["rampedit"] = d
        if redo:
            self.schedule()

    def _mode_changed(self):
        m = self._mode()
        self._set("re_mode", m, False)
        self.g_nodes = [[0, self.lead_rgb], [31, (0, 0, 0)]]
        self.l_nodes = [[0, oklab(self.lead_rgb)[0]], [31, 0.0]]
        self.c_nodes = [[0, self.lead_rgb]]
        self.active = ("colour", 1) if m == "gradient" else ("light", 1)
        self._layout()
        self.status("Ramp type: %s - nodes reset." % self.mode_var.get())
        self.schedule()

    def _layout(self):
        for s in (self.s_grad, self.s_light, self.s_col, self.s_view):
            s.frame.pack_forget()
        if self._mode() == "gradient":
            self.s_grad.frame.pack(anchor="w")
            for rb in self._blend_rbs:
                rb.state(["!disabled"])
        else:
            self.s_light.frame.pack(anchor="w")
            self.s_col.frame.pack(anchor="w", pady=(4, 0))
            self.s_view.frame.pack(anchor="w", pady=(4, 0))
            for rb in self._blend_rbs:
                rb.state(["disabled"])
        self._node_ui()

    # ---------------------------------------------------------- nodes
    def node_list(self, kind):
        return {"colour": self.g_nodes, "light": self.l_nodes,
                "colour2": self.c_nodes}[kind]

    def _cur(self):
        kind, k = self.active
        nodes = self.node_list(kind)
        if self._mode() == "gradient" and kind != "colour" or \
                self._mode() == "lc" and kind == "colour":
            kind = "colour" if self._mode() == "gradient" else "light"
            nodes = self.node_list(kind)
            k = len(nodes) - 1
            self.active = (kind, k)
        if k >= len(nodes):
            k = len(nodes) - 1
            self.active = (kind, k)
        return kind, k, nodes

    def select_node(self, kind, k):
        self.active = (kind, k)
        self._node_ui()
        self._draw_strips()
        self._retarget_picker()

    def move_node(self, kind, k, p):
        nodes = self.node_list(kind)
        nodes[k][0] = p
        v = nodes[k]
        nodes.sort(key=lambda n: n[0])
        k = nodes.index(v)
        self.active = (kind, k)
        self._node_ui()
        self.schedule()
        return k

    def add_node(self, kind, p):
        nodes = self.node_list(kind)
        if any(q == p for q, _v in nodes):
            return
        r = self._ramp()
        if kind == "colour":
            v = r.rgb(p)
        elif kind == "light":
            v = r.lab(p)[0]
        else:
            v = Ramp("gradient", "wheel", [tuple(n) for n in self.c_nodes]).rgb(p)
        nodes.append([p, v])
        nodes.sort(key=lambda n: n[0])
        self.select_node(kind, [n[0] for n in nodes].index(p))
        self.status("Node added at row %d." % p)
        self.schedule()

    def delete_node(self):
        kind, k, nodes = self._cur()
        if k == 0:
            self.status("Node 0 is the starting colour - it always stays.")
            return
        del nodes[k]
        self.active = (kind, min(k, len(nodes) - 1))
        self._node_ui()
        self.schedule()

    def _set_value(self, v):
        kind, k, nodes = self._cur()
        if k == 0:
            self.status("Node 0 is the starting colour (the brightest selected one).")
            return
        nodes[k][1] = v
        self._node_ui()
        self.schedule()

    def _light_value(self, v):
        self._set_value(float(v) / 100.0)

    def _node_ui(self):
        kind, k, nodes = self._cur()
        p, v = nodes[k]
        name = {"colour": "Node", "light": "Lightness node", "colour2": "Colour node"}[kind]
        self.node_var.set("%s %d/%d at row %d%s" % (name, k + 1, len(nodes), p,
                                                     " (start)" if k == 0 else ""))
        rgb = grey_of(v) if kind == "light" else tuple(v)
        self.swatch.delete("all")
        self.swatch.create_rectangle(0, 0, 400, 400, fill=hex_of(rgb), outline="")
        st = ["disabled"] if k == 0 else ["!disabled"]
        for b in (self.pick_btn, self.del_btn):
            b.state(st)
        self.picker_btn.state(["disabled"] if k == 0 or kind == "light" else ["!disabled"])
        if kind == "light":
            self.lslider_f.grid(row=4, column=0, columnspan=3, sticky="we", pady=(0, 6))
            self.lslider.set(round(v * 100))
            self.lslider.set_enabled(k != 0)
        else:
            self.lslider_f.grid_forget()

    # ---------------------------------------------------------- picking colours
    def pick_index(self):
        kind, k, _nodes = self._cur()
        if k == 0:
            return

        def done(idx):
            if idx is None:
                return
            rgb = tuple(self.app.rgbs[idx])
            self._set_value(oklab(rgb)[0] if kind == "light" else rgb)
            self.status("Node set to palette colour %d %s." % (idx, hex_of(rgb)))
        self.app.cmap_pick_start(done)

    def picker(self):
        kind, k, nodes = self._cur()
        if k == 0 or kind == "light":
            return
        p = self.app.open_picker()
        p.owner = self.win
        self._retarget_picker(force=True)

    def _retarget_picker(self, force=False):
        p = self.app.picker
        if p is None or (getattr(p, "owner", None) is not self.win and not force):
            return
        kind, k, nodes = self._cur()
        if kind == "light" or k == 0:
            p.set_target(None, (128, 128, 128), None, "")
            return
        p.set_target(lambda rgb, hsl: self._set_value(tuple(int(v) for v in rgb)),
                     tuple(nodes[k][1]), None, "Edit Ramps node %d" % (k + 1))

    # ---------------------------------------------------------- palettised view
    def _view_changed(self):
        v = self.view_var.get()
        self._view_state()
        self.status("Main window: %s." % {
            "true": "the true-colour ramp for the edited fades",
            "pal": "the palettised result (what the COLORMAP is now)",
            "new": "palettised with the suggested colours added (white dots = new "
                   "colours) - nothing is added until Add to palette"}[v])
        self.schedule(now=True)

    def show_true(self):
        return self.view_var.get() == "true"

    def view_rgb(self, r, s):
        if self.view_var.get() != "new":
            return None
        return self.prev_rgb.get((r, s))

    def _view_state(self):
        on = bool(self.add_var.get())
        self._view_rbs["new"].state(["!disabled"] if on else ["disabled"])
        if not on and self.view_var.get() == "new":
            self.view_var.set("pal")
        self.mark_chk.state(["!disabled"] if self.view_var.get() == "new" else ["disabled"])

    def _mark_toggled(self):
        self.app.s["rampedit_marks"] = bool(self.mark_var.get())
        self.app.draw_fades()

    def marked_cells(self):
        """White-dot cells for the main window (only when Mark new colours is on)."""
        if self.view_var.get() != "new" or not self.mark_var.get():
            return set()
        return self.new_cells

    # ---------------------------------------------------------- add colours
    def _add_toggled(self, redo=True):
        on = bool(self.add_var.get())
        for w in self._add_widgets:
            w.state(["!disabled"] if on else ["disabled"])
        self.addmax.set_enabled(on)
        if on and redo:
            self.view_var.set("new")
        if not on:
            self.proposals = []
            self.picks = set()
            self.prev_rgb, self.new_cells, self.uses = {}, set(), {}
            self.add_info.set("")
            self._draw_props()
        self._view_state()
        if redo:
            self.schedule()
            self._view_changed()

    def chosen(self):
        """Suggestions in use: the Ctrl+clicked ones, else all of them."""
        if self.picks:
            return [c for c in self.proposals if c in self.picks]
        return list(self.proposals)

    def _draw_props(self):
        cv = self.prop_cv
        cv.delete("all")
        self._props_geom = []
        n = len(self.proposals)
        if not n:
            return
        W, H = max(cv.winfo_width(), 40), max(cv.winfo_height(), 10)
        gap = max(2, int(3 * self.ui))
        size = 4
        for sz in range(int(min(H, W, 64 * self.ui)), 3, -1):   # biggest that fits
            cols = max(1, (W - gap) // (sz + gap))
            rows = -(-n // cols)
            if rows * (sz + gap) + gap <= H:
                size = sz
                break
        cols = max(1, (W - gap) // (size + gap))
        chosen = set(self.chosen())
        for k, rgb in enumerate(self.proposals):
            x = gap + (k % cols) * (size + gap)
            y = gap + (k // cols) * (size + gap)
            if self.picks and rgb not in chosen:           # not picked: small
                i = size * 0.3
                cv.create_rectangle(x + i, y + i, x + size - i, y + size - i,
                                    fill=hex_of(rgb), outline="#555555")
            else:
                cv.create_rectangle(x, y, x + size, y + size, fill=hex_of(rgb), outline="")
            if self.picks and rgb in chosen:
                w = max(2, int(2 * self.ui))
                cv.create_rectangle(x + w / 2, y + w / 2, x + size - w / 2, y + size - w / 2,
                                    outline="#ffffff", width=w)
            self._props_geom.append((x, y, size, rgb))

    def _prop_at(self, ev):
        for x, y, sz, rgb in self._props_geom:
            if x <= ev.x <= x + sz and y <= ev.y <= y + sz:
                return rgb
        return None

    def _prop_click(self, ev):
        rgb = self._prop_at(ev)
        if rgb is None:
            return
        if not ev.state & 0x0004:
            self.status("Ctrl+click suggestions to use / add only those (Clear picks = all).")
            return
        self.picks ^= {rgb}
        self.schedule(now=True)

    def _clear_picks(self):
        self.picks = set()
        self.schedule(now=True)

    def _prop_hover(self, ev):
        self.prop_hover.set("")
        rgb = self._prop_at(ev)
        if rgb is None:
            self.prop_hover.set("")
            return
        if self.picks and rgb not in self.picks:
            self.prop_hover.set("%s - not picked" % hex_of(rgb))
        else:
            n = self.uses.get(rgb, 0)
            self.prop_hover.set("%s - used in %d cell%s" % (hex_of(rgb), n,
                                                           "" if n == 1 else "s"))

    def _grip_press(self, ev):
        self._grip0 = (ev.y_root, self.prop_cv.winfo_height())

    def _grip_drag(self, ev):
        y0, h0 = getattr(self, "_grip0", (ev.y_root, self.prop_cv.winfo_height()))
        h = int(min(max(h0 + ev.y_root - y0, 12 * self.ui), 600 * self.ui))
        self.prop_cv.configure(height=h)

    def _grip_release(self, ev):
        self.app.s["rampedit_box_h"] = round(int(self.prop_cv.cget("height")) / self.ui, 1)
        self._draw_props()

    def add_to_palette(self):
        self._add_now()

    def before_apply(self):
        """Apply with Add missing colours ticked: add the chosen suggestions
        (picked ones, else all) with this section's placement, rebuild the
        fades on them, then let Apply record it all. False = don't apply."""
        if self._after is not None:              # settle any pending rebuild first
            self.app.root.after_cancel(self._after)
            self._after = None
            self.rebuild()
        if not self.add_var.get() or not self.scope or not self.chosen():
            return True
        if not self._add_now(rebuild=False):
            self.status("Not applied - the new colours couldn't be placed: %s "
                        "Change the placement in Add missing colours and Apply again."
                        % self.app.status_var.get())
            return False
        self.add_var.set(False)                  # done: don't suggest on top of them
        self._add_toggled(redo=False)
        self.rebuild()
        return True

    def _add_now(self, rebuild=True):
        a = self.app
        cols = self.chosen()
        if not cols:
            self.status("Nothing to add - every step already has a close palette colour.")
            return False
        p = max(set(a.selection) | set(a.fade_sel) | self.scope | {-1}) + 1
        a.cm = self.base.copy()                  # palette moves with the base edits
        slots, newpos, msg = a.place_colours(cols, self.o["re_add_place"],
                                             self.o["re_add_together"], min(p, ENTRIES))
        if not slots:
            a.cm_changed()
            self.status(msg)
            self.schedule()
            return False
        if newpos is not None:
            a.fade_sel = {newpos[i] for i in a.fade_sel if newpos[i] < ENTRIES}
            a._fade_anchor = None
        self.base = a.cm.copy()
        self._added += [tuple(c) for c in cols[:len(slots)]]
        self.picks = set()
        self.view_var.set("pal")
        a.cm_changed()
        a.recompute()
        self.status("Added %d colour%s to the palette (slots %s). %s" % (
            len(slots), "" if len(slots) == 1 else "s",
            ", ".join(str(s) for s in slots[:8]) + ("..." if len(slots) > 8 else ""),
            msg))
        if rebuild:
            self.schedule(now=True)
        return True

    # ---------------------------------------------------------- live build
    def schedule(self, now=False):
        a = self.app
        if self._after is not None:
            a.root.after_cancel(self._after)
        self._after = a.root.after(1 if now else 120, self.rebuild)

    def _ramp(self):
        if self._mode() == "gradient":
            return Ramp("gradient", self.o["re_blend"], [tuple(n) for n in self.g_nodes])
        return Ramp("lc", "wheel", light=[tuple(n) for n in self.l_nodes],
                    colour=[tuple(n) for n in self.c_nodes])

    def rebuild(self):
        a = self.app
        self._after = None
        if a.ctool_win is not self or a.rgbs is None:
            return
        if a._cmap_compare:
            self.schedule()
            return
        scope, label, nlock = a.cmap_targets()
        scope = [s for s in scope if s < ENTRIES and a.rgbs[s] is not None]
        cm = self.base.copy()
        if label.startswith("Whole palette") or not scope:
            self.scope_var.set("Select the fades to edit first (click fade numbers, or "
                               "select colours in the palette) - nothing is changed.")
            scope = []
        ss = set(scope)
        if scope:
            lead = max(scope, key=lambda s: (oklab(a.rgbs[s])[0], -s))
            self.lead, self.lead_rgb = lead, tuple(a.rgbs[lead])
            self.g_nodes[0][1] = self.lead_rgb
            self.c_nodes[0][1] = self.lead_rgb
            self.l_nodes[0][1] = oklab(self.lead_rgb)[0]
            self.scope_var.set("%s%s - ramp starts from colour %d %s" % (
                label, "  (%d locked skipped)" % nlock if nlock else "", lead,
                hex_of(self.lead_rgb)))
            ramp = self._ramp()
            over, self.targets, self.entries = build_ramp_fades(a.pal, a.deleted, scope,
                                                                ramp, self.o)
            cm.overrides = {k: t for k, t in cm.overrides.items()
                            if not (k[1] in ss and 1 <= k[0] < LIGHT_ROWS)}
            cm.fullbright = set(cm.fullbright) - ss
            cm.overrides.update(over)
        else:
            self.targets, self.entries = {}, {}
        self.scope = ss
        self.prev_rgb, self.new_cells, self.uses = {}, set(), {}
        if self.add_var.get() and scope:
            self.proposals = missing_colours(a.pal, a.deleted, self.targets,
                                             self.o["re_add_max"])
            self.picks &= set(self.proposals)
            chosen = self.chosen()
            if chosen:
                virt = [a.pal[i] if i < len(a.pal) else None for i in range(ENTRIES)] \
                    + [tuple(c) for c in chosen]
                snap = Snapper(virt, a.deleted, self.o["re_metric"], limit=len(virt))
                for (r, s), rgb in self.targets.items():
                    k = snap.nearest(oklab(rgb), rgb)
                    if k is None:
                        continue
                    self.prev_rgb[(r, s)] = tuple(virt[k])
                    if k >= ENTRIES:
                        self.new_cells.add((r, s))
                        c = tuple(virt[k])
                        self.uses[c] = self.uses.get(c, 0) + 1
            n = len(self.proposals)
            if not n:
                self.add_info.set("Every step already has a close palette colour.")
            else:
                used = sum(1 for c in chosen if self.uses.get(tuple(c)))
                self.add_info.set("%s%d suggested (limit %d) - %d used in %d cell%s - "
                                  "not added yet" % (
                                      ("%d picked of " % len(chosen)) if self.picks else "",
                                      n, self.o["re_add_max"], used, len(self.new_cells),
                                      "" if len(self.new_cells) == 1 else "s"))
            self._draw_props()
        if self.view_var.get() != "new":
            self.new_cells = set()
        if cm != a.cm:
            a.cm = cm
            a.cm_changed()
            a.recompute()
        else:
            a.draw_fades()
        self._node_ui()
        self._draw_strips()
        self.refresh()

    def _draw_strips(self):
        r = self._ramp()
        kind, k, _n = self._cur()
        ents = sorted((t, tuple(self.app.rgbs[s])) for s, t in self.entries.items()
                      if self.app.rgbs[s] is not None)
        strip = r.strip()
        if self._mode() == "gradient":
            self.s_grad.draw(strip, ents, k)
        else:
            self.s_light.draw([grey_of(v) for v in
                               (Ramp("lc", light=[tuple(n) for n in self.l_nodes],
                                     colour=[(0, (128, 128, 128))]).lab(p)[0]
                                for p in range(POSITIONS))],
                              (), k if kind == "light" else None)
            cr = Ramp("gradient", "wheel", [tuple(n) for n in self.c_nodes])
            self.s_col.draw(cr.strip(), (), k if kind == "colour2" else None)
            self.s_view.draw(strip, ents)

    def log_text(self):
        n = len(self.scope)
        txt = "%d fade%s from a %s ramp (%s, %s)" % (
            n, "" if n == 1 else "s",
            "gradient" if self._mode() == "gradient" else "lightness + colour",
            "same speed" if self.o["re_pace"] == "same" else "stretch to fit",
            "RGB match" if self.o["re_metric"] == "rgb" else "perceptual match")
        if self._added:
            txt += ", %d colour%s added" % (len(self._added),
                                            "" if len(self._added) == 1 else "s")
        return txt

    # ---------------------------------------------------------- session hooks
    def sel_changed(self):
        self.schedule()

    def external_edit(self):
        self.base = self.app.cm.copy()
        self.schedule()

    def note_applied(self):
        self.base = self.app.cm.copy()
        self._sel_base = self._sel_state()
        self._added = []

    def note_reverted(self):
        a = self.app
        if self._added:
            a.selection, a.fade_sel, a.cmap_pool = (set(x) for x in self._sel_base)
            a._fade_anchor = None
            self._added = []
            a.recompute()
        self.base = a.cm.copy()
        self.schedule()

    def teardown(self):
        a = self.app
        a.cmap_compare(False)
        if a._cmap_pick is not None:
            a.cmap_pick_cancel()
        p = a.picker
        if p is not None and getattr(p, "owner", None) is self.win:
            p.owner = None
            try:
                p.set_target(None, (128, 128, 128), None, "")
            except a.tk.TclError:
                pass
        if self._after is not None:
            a.root.after_cancel(self._after)
            self._after = None
        _CWin.teardown(self)
