"""Lost colours (preview companion window): which colours of the art the
working palette fails - too far from any cell (lost) or a colourful pixel
landing on a grey (greyed) - for this image, this page, the filtered list or
the whole WAD / folder. Grouped, biggest first, with the images that use
them most. Copy / To scratch / To ramp nodes; Save / Load scan."""

import os
import time

from ..cleanpal_lib_colour import hex_of
from ..cleanpal_lib_constants import DEFAULT_TOL, ENTRIES, METRIC_HOVER
from ..cleanpal_lib_scan import (
    SCAN_EXT, classify, group_lost, item_hist, load_scan, save_scan, store,
)

SCOPES = [("This image", "image"), ("This page", "page"), ("Filtered", "filtered"),
          ("Whole", "whole")]
LOST_COL = "#ff00ff"
GREY_COL = "#00ffff"
BIN_OVER = 20000              # more unique colours than this: 5-bit bins


def _fg(c):
    return "#000000" if 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2] > 140 else "#ffffff"


def lost_settings(app):
    """(metric, closeness, greyed) shared by the window and the preview overlay."""
    m = app.metric_var.get()
    v = app.s.get("lost_close_%s" % m)
    if not isinstance(v, (int, float)):
        v = app.tol.get(m, DEFAULT_TOL[m])
    return m, float(v), bool(app.s.get("lost_greyed", True))


def palette_cells(app, applied):
    if applied and app.history:
        pal = app.history[app.hist_pos]["palette"]
    else:
        pal = app.rgbs or []
    pal = list(pal[:ENTRIES]) + [None] * max(0, ENTRIES - len(pal))
    return [tuple(c) if c is not None else None for c in pal]


def _bin(hist):
    out = {}
    for (r, g, b), n in hist.items():
        k = ((r & 0xF8) | 4, (g & 0xF8) | 4, (b & 0xF8) | 4)
        out[k] = out.get(k, 0) + n
    return out


class LostWindow:
    def __init__(self, preview):
        from tkinter import ttk
        app = preview.app
        tk = app.tk
        self.pv = preview
        self.app = app
        self.ui = ui = getattr(app, "ui", 1.0)
        s = app.s
        self.win = tk.Toplevel(preview.win)
        self.win.title("Lost colours")
        self.win.transient(preview.win)
        self.win.minsize(int(420 * ui), int(320 * ui))
        try:
            self.win.geometry(s.get("lost_geometry") or "%dx%d" % (int(620 * ui), int(560 * ui)))
        except tk.TclError:
            pass
        if preview.pin_var.get():
            try:
                self.win.attributes("-topmost", True)
            except tk.TclError:
                pass
        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.columnconfigure(0, weight=1)
        self.win.rowconfigure(2, weight=1)

        sc = s.get("lost_scope")
        self.scope_var = tk.StringVar(value=sc if sc in [v for _t, v in SCOPES] else "filtered")
        self.greyed_var = tk.BooleanVar(value=bool(s.get("lost_greyed", True)))
        vw = s.get("lost_view")
        self.view_var = tk.StringVar(value=vw if vw in ("Swatches", "List") else "Swatches")
        m, close, _g = lost_settings(app)
        self.close_var = tk.StringVar(value="%g" % close)
        self.status_var = tk.StringVar()
        self.info_var = tk.StringVar()

        r1 = ttk.Frame(self.win, padding=(8, 8, 8, 2))
        r1.grid(row=0, column=0, sticky="ew")
        ttk.Label(r1, text="Scope").pack(side="left")
        for t, v in SCOPES:
            ttk.Radiobutton(r1, text=t, value=v, variable=self.scope_var,
                            command=self._opt).pack(side="left", padx=(6, 0))
        r2 = ttk.Frame(self.win, padding=(8, 2, 8, 4))
        r2.grid(row=1, column=0, sticky="ew")
        ttk.Label(r2, text="Closeness").pack(side="left")
        sp = ttk.Spinbox(r2, textvariable=self.close_var, from_=0, to=100, increment=0.25,
                         width=6, command=self._opt)
        sp.pack(side="left", padx=(4, 2))
        sp.bind("<Return>", lambda e: self._opt())
        sp.bind("<FocusOut>", lambda e: self._opt())
        self.unit_var = tk.StringVar(value=METRIC_HOVER.get(m, ""))
        ttk.Label(r2, textvariable=self.unit_var, foreground="#888").pack(side="left",
                                                                          padx=(0, 10))
        ttk.Checkbutton(r2, text="Greyed", variable=self.greyed_var,
                        command=self._opt).pack(side="left")
        cb = ttk.Combobox(r2, textvariable=self.view_var, values=("Swatches", "List"),
                          state="readonly", width=9)
        cb.pack(side="right")
        cb.bind("<<ComboboxSelected>>", lambda e: self._view_changed())

        self.body = ttk.Frame(self.win, padding=(8, 0, 8, 0))
        self.body.grid(row=2, column=0, sticky="nsew")
        self.body.rowconfigure(0, weight=1)
        self.body.columnconfigure(0, weight=1)
        c = tk.Canvas(self.body, bg="#262626", highlightthickness=0)
        c.bind("<Configure>", lambda e: self._draw_swatches())
        c.bind("<Motion>", self._hover)
        c.bind("<Leave>", lambda e: self.info_var.set(""))
        c.bind("<Button-1>", self._click)
        c.bind("<Double-Button-1>", self._dclick)
        c.bind("<MouseWheel>", lambda e: c.yview_scroll(-1 if e.delta > 0 else 1, "units"))
        self.cv = c
        self.cv_sb = ttk.Scrollbar(self.body, orient="vertical", command=c.yview)
        c.configure(yscrollcommand=self.cv_sb.set)
        from .gui_filters_window import _tree_style
        tv = ttk.Treeview(self.body, columns=("px", "kind", "lands", "used"),
                          show="tree headings", selectmode="extended",
                          style=_tree_style(app, "Lost.Treeview"))
        for col, t, w in (("#0", "Colour", 100), ("px", "Pixels", 80), ("kind", "", 60),
                          ("lands", "Lands on", 130), ("used", "Used most in", 200)):
            tv.heading(col, text=t)
            tv.column(col, width=int(w * ui), stretch=col == "used")
        tv.bind("<Double-Button-1>", lambda e: self._jump_sel())
        tv.bind("<<TreeviewSelect>>", lambda e: self._tv_sel())
        self.tv = tv
        self.tv_sb = ttk.Scrollbar(self.body, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=self.tv_sb.set)

        ttk.Label(self.win, textvariable=self.info_var, font=("Consolas", 10),
                  padding=(8, 2, 8, 0)).grid(row=3, column=0, sticky="w")
        ttk.Label(self.win, textvariable=self.status_var, foreground="#666",
                  padding=(8, 0, 8, 0)).grid(row=4, column=0, sticky="w")
        ins = ttk.Frame(self.win, padding=(8, 6, 8, 0))
        ins.grid(row=5, column=0, sticky="ew")
        ttk.Button(ins, text="Insert", command=self.insert).pack(side="left")
        pl = s.get("lost_ins_place")
        self.place_var = tk.StringVar(value=pl if pl in ("insert", "empty") else "insert")
        for t, v in (("After selection", "insert"), ("Empty slots", "empty")):
            ttk.Radiobutton(ins, text=t, value=v, variable=self.place_var,
                            command=self._ins_opt).pack(side="left", padx=(8, 0))
        self.tog_var = tk.BooleanVar(value=bool(s.get("lost_ins_together", True)))
        ttk.Checkbutton(ins, text="Keep together", variable=self.tog_var,
                        command=self._ins_opt).pack(side="left", padx=(10, 0))
        # ---- unused: palette cells no image in the scope lands on
        uf = ttk.LabelFrame(self.win, text="Unused palette colours (no pixel in the scope "
                            "lands on them)", padding=6)
        uf.grid(row=6, column=0, sticky="ew", padx=8, pady=(8, 0))
        uf.columnconfigure(0, weight=1)
        self.unused = []
        self._un_scope, self._un_hits, self._un_locked = [], [], 0
        self.un_info = tk.StringVar()
        ttk.Label(uf, textvariable=self.un_info, foreground="#666").grid(
            row=0, column=0, sticky="w")
        self.un_cv = tk.Canvas(uf, height=int(24 * ui), bg="#262626", highlightthickness=0)
        self.un_cv.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.un_cv.bind("<Configure>", lambda e: self._draw_unused())
        self.un_cv.bind("<Motion>", self._un_hover)
        self.un_cv.bind("<Leave>", lambda e: self.info_var.set(""))
        ur = ttk.Frame(uf)
        ur.grid(row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Button(ur, text="Remove unused", command=self.remove_unused).pack(side="left")
        ttk.Button(ur, text="Select in palette", command=self.select_unused).pack(
            side="left", padx=(6, 0))
        ur = ttk.Frame(uf)
        ur.grid(row=3, column=0, sticky="w", pady=(2, 0))
        self.un_below_var = tk.BooleanVar(value=bool(s.get("lost_un_below", False)))
        self.un_pack_var = tk.BooleanVar(value=bool(s.get("lost_un_pack", False)))
        self.un_show_var = tk.BooleanVar(value=bool(s.get("lost_un_show", False)))
        for t, v, k in (("Move under the line", self.un_below_var, "lost_un_below"),
                        ("Close the gaps", self.un_pack_var, "lost_un_pack"),
                        ("Show on palette", self.un_show_var, "lost_un_show")):
            ttk.Checkbutton(ur, text=t, variable=v, command=lambda v=v, k=k: (
                s.__setitem__(k, bool(v.get())), self._un_marks())).pack(
                side="left", padx=(0, 12))
        b = ttk.Frame(self.win, padding=(8, 6, 8, 8))
        b.grid(row=7, column=0, sticky="ew")
        ttk.Button(b, text="Copy", command=self.copy).pack(side="left")
        ttk.Button(b, text="To scratch", command=self.to_scratch).pack(side="left",
                                                                        padx=(6, 0))
        ttk.Button(b, text="To ramp nodes", command=self.to_ramp).pack(side="left",
                                                                       padx=(6, 0))
        ttk.Button(b, text="Close", command=self.close).pack(side="right")
        ttk.Button(b, text="Load scan...", command=self.load).pack(side="right",
                                                                   padx=(0, 6))
        ttk.Button(b, text="Save scan...", command=self.save).pack(side="right",
                                                                   padx=(0, 6))

        self.groups = []
        self.sel = set()               # chosen group indexes
        self.hits = []
        self.hists = {}                # item key -> {rgb: px} (this source)
        self._src = None
        self._todo = []
        self._scanning = False
        self._sig = None
        self.loaded = None             # a loaded .cpscan when the preview has no source
        self._view_changed(redraw=False)
        self._poll()

    # ---------------------------------------------------------- options
    def _opt(self):
        s = self.app.s
        s["lost_scope"] = self.scope_var.get()
        s["lost_greyed"] = bool(self.greyed_var.get())
        try:
            s["lost_close_%s" % self.app.metric_var.get()] = max(0.0, float(self.close_var.get()))
        except ValueError:
            pass
        self._sig = None
        self.pv.schedule()                      # the overlay follows these settings

    def _view_changed(self, redraw=True):
        self.app.s["lost_view"] = self.view_var.get()
        if self.view_var.get() == "List":
            self.cv.grid_remove()
            self.cv_sb.grid_remove()
            self.tv.grid(row=0, column=0, sticky="nsew")
            self.tv_sb.grid(row=0, column=1, sticky="ns")
            self._fill_list()
        else:
            self.tv.grid_remove()
            self.tv_sb.grid_remove()
            self.cv.grid(row=0, column=0, sticky="nsew")
            self.cv_sb.grid(row=0, column=1, sticky="ns")
            if redraw:
                self._draw_swatches()

    # ---------------------------------------------------------- scope items
    def _source(self):
        pv = self.pv
        if pv.mode == "wad" and pv.wad is not None:
            return ("wad", pv.wad.path)
        if pv.mode == "folder" and pv.folder:
            return ("folder", pv.folder)
        return None

    def scope_items(self):
        pv = self.pv
        if not pv.items:
            return []
        sc = self.scope_var.get()
        if sc == "whole":
            return [it for it in pv.items if it["kind"] not in ("texture1", "texture2")
                    and it.get("tex_src", "WAD") == "WAD"]
        if not pv.view:
            return []
        if sc == "filtered":
            return list(pv.view)
        if sc == "page" and pv._grid():
            a, b = pv._page_range()
            return pv.view[a:b]
        return [pv.view[pv.idx]]

    def _hist(self, it):
        h = self.hists.get(it["key"])
        if h is None:
            h = item_hist(it, self.pv.wad if self.pv.mode == "wad" else None,
                          image=self.pv._orig)
            self.hists[it["key"]] = h
        return h

    # ---------------------------------------------------------- polling / scanning
    def _signature(self):
        pv = self.pv
        m, close, g = lost_settings(self.app)
        cells = palette_cells(self.app, pv._applied())
        items = self.scope_items()
        live = tuple(palette_cells(self.app, False))
        sel = tuple(sorted(i for i in self.app.selection if i < ENTRIES))
        return (self._source(), self.scope_var.get(), tuple(it["key"] for it in items[:2000]),
                len(items), tuple(cells), m, close, g, self.loaded is not None, live, sel,
                frozenset(self.app.locked))

    def _poll(self):
        self._after = None
        try:
            src = self._source()
            if src != self._src:                # a new WAD / folder: new histograms
                self._src = src
                self.hists = {}
                self._sig = None
            self.unit_var.set(METRIC_HOVER.get(self.app.metric_var.get(), ""))
            if not self._scanning:
                sig = self._signature()
                if sig != self._sig:
                    self._sig = sig
                    self._start()
        except self.app.tk.TclError:
            return
        except Exception as e:  # noqa: BLE001 - keep polling
            self.status_var.set("Lost colours: %s" % e)
        try:
            self._after = self.win.after(300, self._poll)
        except self.app.tk.TclError:
            pass

    def _start(self):
        items = self.scope_items()
        self._todo = [it for it in items if it["key"] not in self.hists]
        self._items = items
        if self._todo:
            self._scanning = True
            self._t0 = time.time()
            self._tick()
        else:
            self._compute()

    def _tick(self):
        """Histograms a slice at a time (cached lumps are instant)."""
        t = time.time()
        while self._todo and time.time() - t < 0.06:
            it = self._todo.pop()
            try:
                self._hist(it)
            except Exception:  # noqa: BLE001 - unreadable image: empty
                self.hists[it["key"]] = {}
        if self._todo:
            done = len(self._items) - len(self._todo)
            self.status_var.set("Counting colours... %d / %d images" % (done, len(self._items)))
            self.win.after(1, self._tick)
            return
        self._scanning = False
        store().save()
        self._compute()

    # ---------------------------------------------------------- results
    def _compute(self):
        app = self.app
        m, close, greyed = lost_settings(app)
        cells = palette_cells(app, self.pv._applied())
        if self.loaded is not None and not self.pv.items:
            per_item = self.loaded
        else:
            per_item = {it["name"]: self.hists.get(it["key"], {}) for it in self._items}
        total = {}
        for h in per_item.values():
            for c, n in h.items():
                total[c] = total.get(c, 0) + n
        self._compute_unused(total, m)
        binned = len(total) > BIN_OVER
        if binned:
            total = _bin(total)
        cls = classify(total, cells, m, close, greyed) if total else {}
        self.groups = group_lost(total, cls, m, close)
        # images using each group most
        where = {}
        for gi, g in enumerate(self.groups):
            for c in g["members"]:
                where[c] = gi
        used = [{} for _g in self.groups]
        for name, h in per_item.items():
            src = _bin(h) if binned else h
            for c, n in src.items():
                gi = where.get(c)
                if gi is not None:
                    used[gi][name] = used[gi].get(name, 0) + n
        for g, u in zip(self.groups, used):
            g["used"] = sorted(u.items(), key=lambda t: -t[1])[:5]
        self.sel = {k for k in self.sel if k < len(self.groups)}
        tot_px = sum(total.values())
        bad = sum(g["px"] for g in self.groups)
        nl = sum(1 for g in self.groups if g["kind"] == "lost")
        note, self._note = getattr(self, "_note", ""), ""
        self.status_var.set(note + 
            "%d image%s, %d px: %d lost group%s, %d greyed - %.2f%% of pixels%s" % (
                len(per_item), "" if len(per_item) == 1 else "s", tot_px, nl,
                "" if nl == 1 else "s", len(self.groups) - nl,
                100.0 * bad / tot_px if tot_px else 0,
                " (colours binned to 5 bits)" if binned else ""))
        self._draw_swatches()
        self._fill_list()

    # ---------------------------------------------------------- unused cells
    def _compute_unused(self, total, metric):
        """Palette cells (the selection, else the whole palette) that no
        colour in the scope lands on - every colour, no binning, against the
        working palette (the one Remove changes)."""
        app = self.app
        live = palette_cells(app, False)
        check = sorted(i for i in (app.selection or range(ENTRIES)) if i < ENTRIES)
        cand = [i for i in check if live[i] is not None]
        if not total or not cand:
            self.unused, self._un_locked = [], 0
        else:
            cls = classify(total, live, metric, 0.0, False)
            used = {v[1] for v in cls.values()}
            un = [i for i in cand if i not in used]
            self._un_locked = sum(1 for i in un if i in app.locked)
            self.unused = [i for i in un if i not in app.locked]
        self._un_scope = [i for i in check if i < ENTRIES] if app.selection else []
        self._draw_unused()
        self._un_marks()

    def _un_text(self):
        n, nl = len(self.unused), getattr(self, "_un_locked", 0)
        where = ("%d selected cell%s" % (len(self._un_scope), "" if len(self._un_scope) == 1
                                         else "s")) if self._un_scope else "the palette"
        if not self.pv.items and self.loaded is None:
            return "Open a WAD or folder in the preview."
        return "%d unused colour%s in %s%s" % (
            n, "" if n == 1 else "s", where,
            (" (+%d locked - never removed)" % nl) if nl else "")

    def _draw_unused(self):
        c = self.un_cv
        c.delete("all")
        self._un_hits = []
        self.un_info.set(self._un_text())
        cells = palette_cells(self.app, False)
        u = self.ui
        s = max(int(20 * u), 10)
        W = max(c.winfo_width(), 60)
        per = max(1, int((W - 4) // (s + 3)))
        rows = max(1, (len(self.unused) + per - 1) // per)
        h = min(rows, 4) * (s + 3) + 3
        if int(c.cget("height")) != h:
            c.configure(height=h)
        for k, i in enumerate(self.unused[:per * 4]):
            x = 2 + (k % per) * (s + 3)
            y = 2 + (k // per) * (s + 3)
            col = cells[i]
            c.create_rectangle(x, y, x + s, y + s, fill=hex_of(col), outline="#6a6a6a")
            self._un_hits.append((x, y, x + s, y + s, i))
        if len(self.unused) > per * 4:
            self.un_info.set(self._un_text() + " - showing the first %d" % (per * 4))

    def _un_hover(self, ev):
        cells = palette_cells(self.app, False)
        for x0, y0, x1, y1, i in self._un_hits:
            if x0 <= ev.x < x1 and y0 <= ev.y < y1:
                col = cells[i]
                self.info_var.set("cell %d  %s  %d,%d,%d - unused" % ((i, hex_of(col).upper())
                                                                     + tuple(col)))
                return
        self.info_var.set("")

    def _un_marks(self):
        app = self.app
        app._unused_marks = set(self.unused) if self.un_show_var.get() else None
        try:
            app._draw_pv_marks()
        except Exception:  # noqa: BLE001
            pass

    def select_unused(self):
        if not self.unused:
            self.status_var.set("No unused colours to select.")
            return
        self.app._apply_selection(list(self.unused), "replace")

    def remove_unused(self):
        if not self.unused:
            self.status_var.set("No unused colours to remove.")
            return
        msg = self.app.remove_unused(list(self.unused), bool(self.un_below_var.get()),
                                     bool(self.un_pack_var.get()), list(self._un_scope))
        self._note = msg + "  "
        self._sig = None

    def _text(self, g):
        unit = METRIC_HOVER.get(self.app.metric_var.get(), "")
        used = ", ".join("%s (%d)" % (n, p) for n, p in g["used"][:3])
        return "%s  %d px  %s: lands on cell %d (%.2f %s)%s" % (
            hex_of(g["rep"]), g["px"], "LOST" if g["kind"] == "lost" else "GREYED",
            g["cell"], g["dist"], unit, ("  -  " + used) if used else "")

    def _draw_swatches(self):
        if self.view_var.get() != "Swatches":
            return
        c = self.cv
        c.delete("all")
        self.hits = []
        if not self.groups:
            msg = ("Open a WAD or folder in the preview." if not self.pv.items
                   and self.loaded is None else "Nothing lost - every colour has a close "
                   "match in your palette." if not self._scanning else "Counting...")
            c.create_text(14, 14, anchor="nw", text=msg, fill="#bbbbbb")
            return
        W = max(c.winfo_width(), 60)
        u = self.ui
        s = max(int(30 * u), 14)
        cols = max(1, int((W - 8) // (s + 4)))
        for k, g in enumerate(self.groups):
            x = 4 + (k % cols) * (s + 4)
            y = 4 + (k // cols) * (s + 4)
            col = g["rep"]
            c.create_rectangle(x, y, x + s, y + s, fill=hex_of(col),
                               outline="#ffffff" if k in self.sel else "",
                               width=max(2, int(2 * u)))
            q = s / 3.2
            c.create_polygon(x + s, y + s, x + s - q, y + s, x + s, y + s - q,
                             fill=LOST_COL if g["kind"] == "lost" else GREY_COL,
                             outline="#000000")
            self.hits.append((x, y, x + s, y + s, k))
        c.configure(scrollregion=(0, 0, W, 8 + ((len(self.groups) + cols - 1) // cols)
                                  * (s + 4)))

    def _at(self, ev):
        ex, ey = self.cv.canvasx(ev.x), self.cv.canvasy(ev.y)
        for x0, y0, x1, y1, k in self.hits:
            if x0 <= ex < x1 and y0 <= ey < y1:
                return k
        return None

    def _hover(self, ev):
        k = self._at(ev)
        self.info_var.set("" if k is None else self._text(self.groups[k]))

    def _click(self, ev):
        k = self._at(ev)
        if k is None:
            return
        if ev.state & 0x0005:                  # Shift / Ctrl: add / toggle
            self.sel ^= {k}
        else:
            self.sel = set() if self.sel == {k} else {k}
        self._draw_swatches()

    def _dclick(self, ev):
        k = self._at(ev)
        if k is not None:
            self.jump(k)

    def _fill_list(self):
        tv = self.tv
        if self.view_var.get() != "List":
            return
        tv.delete(*tv.get_children())
        self._icons = getattr(self, "_icons", {})
        unit = METRIC_HOVER.get(self.app.metric_var.get(), "")
        for k, g in enumerate(self.groups):
            col = g["rep"]
            img = self._icons.get(col)
            if img is None:
                sz = max(10, int(14 * self.ui))
                img = self.app.tk.PhotoImage(width=sz, height=sz)
                img.put(hex_of(col), to=(0, 0, sz, sz))
                self._icons[col] = img
            tv.insert("", "end", iid=str(k), image=img, text=" " + hex_of(col),
                      values=(g["px"], g["kind"], "cell %d (%.2f %s)" % (g["cell"], g["dist"],
                                                                         unit),
                              ", ".join(n for n, _p in g["used"][:3])))
        for k in self.sel:
            if tv.exists(str(k)):
                tv.selection_add(str(k))

    def _tv_sel(self):
        self.sel = {int(i) for i in self.tv.selection()}
        sel = self.tv.selection()
        if sel:
            self.info_var.set(self._text(self.groups[int(sel[-1])]))

    def _jump_sel(self):
        sel = self.tv.selection()
        if sel:
            self.jump(int(sel[-1]))

    def jump(self, k):
        """Show the image that uses this group most in the preview."""
        g = self.groups[k]
        if not g["used"]:
            return
        name = g["used"][0][0]
        pv = self.pv
        names = [it["name"] for it in pv.view]
        if name not in names:
            self.status_var.set("%s isn't in the preview's current list (Type / Name / "
                                "Filters)." % name)
            return
        pv.idx = names.index(name)
        if pv.layout_var.get() != "single":
            pv.layout_var.set("single")
        pv._on_layout()
        self.status_var.set("Showing %s - it uses %d px of %s." % (name, g["used"][0][1],
                                                                  hex_of(g["rep"])))

    # ---------------------------------------------------------- actions
    def _chosen(self):
        ks = sorted(self.sel) or range(len(self.groups))
        return [self.groups[k]["rep"] for k in ks]

    def _ins_opt(self):
        self.app.s["lost_ins_place"] = self.place_var.get()
        self.app.s["lost_ins_together"] = bool(self.tog_var.get())

    def insert(self):
        """Selected (or all) lost colours into the palette - after the palette
        selection or into empty slots - as one history entry."""
        cols = self._chosen()
        if not cols:
            self.status_var.set("No lost colours to insert.")
            return
        msg = self.app.insert_colours(cols, self.place_var.get(), bool(self.tog_var.get()),
                                      "lost colour%s" % ("" if len(cols) == 1 else "s"))
        self.status_var.set(msg)
        self._note = (msg.split(" - recorded")[0].rstrip(".") + ".  |  ") \
            if msg.startswith("Inserted") else ""
        self.sel = set()

    def copy(self):
        cols = self._chosen()
        if not cols:
            return
        self.app.clip_set(cols, "Lost colours")
        self.status_var.set("Copied %d colour(s) - Ctrl+V in Paint inserts them." % len(cols))

    def to_scratch(self):
        cols = self._chosen()
        if cols:
            self.app.open_scratch().add_colours(cols)
            self.status_var.set("Sent %d colour(s) to the Scratch palette." % len(cols))

    def to_ramp(self):
        a = self.app
        r = a.ramp
        if a.tool != "paint" or r is None or getattr(r, "FADE", False):
            self.status_var.set("Open the Paint tool first (its ramp bar takes the colours).")
            return
        from ..cleanpal_lib_colour import oklab
        cols = sorted(self._chosen()[:32], key=lambda c: oklab(c)[0])
        if len(cols) < 2:
            self.status_var.set("Pick 2+ colours for ramp nodes.")
            return
        nodes = r.nodes()
        m = len(cols)
        nodes[:] = [{"pos": r._to_pos(k / float(m - 1)), "rgb": list(c), "hsl": None}
                    for k, c in enumerate(cols)]
        nodes[0]["pos"], nodes[-1]["pos"] = 0.0, 1.0
        r.set_active(nodes[0])
        r.changed()
        self.status_var.set("Set %d ramp nodes (dark -> light)." % m)

    def _scan_dir(self):
        p = self.app.project_path
        return os.path.dirname(p) if p else (self.app.s.get("scan_dir")
                                             or self.app.s.get("last_dir") or None)

    def save(self):
        from tkinter import filedialog, messagebox
        pv = self.pv
        src = self._source()
        if src is None:
            self.status_var.set("Open a WAD or folder in the preview first.")
            return
        items = [it for it in pv.items if it["kind"] not in ("texture1", "texture2")]
        missing = [it for it in items if it["key"] not in self.hists]
        if missing:
            self.status_var.set("Scanning %d images before saving..." % len(missing))
            self.win.update_idletasks()
            for it in missing:
                try:
                    self._hist(it)
                except Exception:  # noqa: BLE001
                    self.hists[it["key"]] = {}
            store().save()
        stem = os.path.splitext(os.path.basename(src[1].rstrip("/\\")))[0] or "scan"
        p = filedialog.asksaveasfilename(parent=self.win, title="Save scan",
                                         initialdir=self._scan_dir(),
                                         initialfile=stem + SCAN_EXT, defaultextension=SCAN_EXT,
                                         filetypes=[("cleanpal scan", "*" + SCAN_EXT)])
        if not p:
            return
        rgb = {}
        wad = pv.wad if src[0] == "wad" else None
        for it in items:
            if wad is not None and it.get("fmt") in ("doom", "flat"):
                continue                       # stored as index counts + crc
            key = it["name"]
            ck = ""
            if it.get("fmt") == "file":
                try:
                    st = os.stat(it["path"])
                    ck = "%s|%d|%d" % (os.path.abspath(it["path"]), st.st_size,
                                       int(st.st_mtime))
                except OSError:
                    pass
            rgb[key] = (ck, self.hists.get(it["key"], {}))
        try:
            save_scan(p, os.path.basename(src[1].rstrip("/\\")), rgb, wad)
        except OSError as e:
            messagebox.showerror("cleanpal", "Could not save the scan:\n%s" % e,
                                 parent=self.win)
            return
        self.app.s["scan_dir"] = os.path.dirname(p)
        self.status_var.set("Saved scan of %s (%d images) to %s" % (
            os.path.basename(src[1].rstrip("/\\")), len(items), p))

    def load(self):
        from tkinter import filedialog, messagebox
        p = filedialog.askopenfilename(parent=self.win, title="Load scan",
                                       initialdir=self._scan_dir(),
                                       filetypes=[("cleanpal scan", "*" + SCAN_EXT),
                                                  ("All files", "*.*")])
        if not p:
            return
        try:
            data, src, n = load_scan(p)
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not load the scan:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        store().save()
        self.app.s["scan_dir"] = os.path.dirname(p)
        # with no WAD / folder open, the loaded scan itself is what's analysed
        pal = [tuple(c) for c in (data.get("playpal") or [])]
        per = {}
        for name, v in (data.get("lumps") or {}).items():
            c = v.get("c", v) if isinstance(v, dict) else {}
            if pal:
                h = {}
                for i, cnt in c.items():
                    col = pal[int(i)]
                    h[col] = h.get(col, 0) + int(cnt)
                per[name] = h
        for name, v in (data.get("rgb") or {}).items():
            per[name] = {(int(k[0:2], 16), int(k[2:4], 16), int(k[4:6], 16)): n
                         for k, n in (v.get("h") or {}).items()}
        self.loaded = per
        self._sig = None
        self._note = "Loaded scan of %s (%d new entries)%s.  |  " % (
            src, n, "" if self.pv.items else " - showing the scan itself")
        self.status_var.set(self._note)

    # ---------------------------------------------------------- window
    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def close(self):
        self.app._unused_marks = None
        try:
            self.app._draw_pv_marks()
        except Exception:  # noqa: BLE001
            pass
        self._close_win()

    def _close_win(self):
        try:
            self.app.s["lost_geometry"] = self.win.geometry()
        except self.app.tk.TclError:
            pass
        if getattr(self, "_after", None) is not None:
            try:
                self.win.after_cancel(self._after)
            except self.app.tk.TclError:
                pass
        store().save()
        self.pv.lost_win = None
        try:
            self.win.destroy()
        except self.app.tk.TclError:
            pass
