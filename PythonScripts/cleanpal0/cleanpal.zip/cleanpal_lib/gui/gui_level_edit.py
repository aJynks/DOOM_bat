"""Edit Levels (COLORMAP tool): edit the light levels of ONE index, row by
row, with the colour picker.

Press the tool button -> click a light-level cell (Matrix / Fades pane) or
a palette cell -> the window shows that index's rows 0-31 twice: TRUE
COLOUR (what you picked) on top, PALETTISED (what is written) under it.
Row 0 is the colour itself (not editable); rows 32 / 33 are ignored.

Click a row = it's the picker's target. Right-click = choose a pal0 colour.
Alt+right-click a true-colour swatch = add that colour as a NEW colour:
every edited row then re-palettises against pal0 + the new colours. New
colours go into pal0 at Apply, together in one run: after the palette
selection (pushing along), else the first empty gap big enough, else below
the red line (with a warning - rows then use their nearest pal0 colour).
Apply = one history entry; Revert drops everything; Ctrl+Z / Ctrl+Y."""

import time

from ..cleanpal_lib_colormap import LIGHT_ROWS
from ..cleanpal_lib_colour import hex_of, oklab
from ..cleanpal_lib_constants import ENTRIES
from ..cleanpal_lib_rampedit import Snapper
from .gui_cmap_tools import _CWin

ROWS = LIGHT_ROWS            # 0-31 (32 / 33 never shown or touched)
UNDO_GAP = 0.6
BG = "#2a2a2a"


def _np(newpos):
    """newpos (list or dict: old index -> new index) as a function."""
    if isinstance(newpos, dict):
        return lambda i: newpos.get(i, i)
    return lambda i: newpos[i] if 0 <= i < len(newpos) else i


class EditLevelsWin(_CWin):
    TITLE = "Edit Levels - one index, row by row"

    def build(self, f):
        from tkinter import ttk
        a = self.app
        tk = a.tk
        ui = self.ui
        self.src = None              # the index being edited
        self.row = 1                 # the active row
        self.true = {}               # src -> {row: rgb} (edited rows only)
        self.newc = []               # added colours (rgb), not in pal0 until Apply
        self.scope = set()           # (fade view: no true-colour override)
        self.targets = {}
        self._undo, self._redo = [], []
        self._last_t, self._last_key = 0.0, None
        self._chooser = None
        self.base = a.cm.copy()
        self.metric = a.s.get("el_metric", "rgb")
        if self.metric not in ("rgb", "oklab"):
            self.metric = "rgb"
        self._snap_key, self._snap = None, None
        # top line
        top = ttk.Frame(f)
        top.grid(row=0, column=0, sticky="ew")
        self.title_var = tk.StringVar(value="Click a light level (Matrix / Fades) or a "
                                            "palette cell")
        ttk.Label(top, textvariable=self.title_var, font=("Segoe UI", 10, "bold")).pack(
            side="left")
        ttk.Label(top, text="Match").pack(side="left", padx=(16, 4))
        self.metric_var = tk.StringVar(value=self.metric)
        for t, v in (("RGB", "rgb"), ("Perceptual", "oklab")):
            ttk.Radiobutton(top, text=t, value=v, variable=self.metric_var,
                            command=self._metric_changed).pack(side="left", padx=(0, 6))
        # strips
        hf = ttk.Frame(f)
        ttk.Label(hf, text="Light levels 0-31 - top: true colour · bottom: palettised"
                  ).pack(side="left")
        sf = ttk.LabelFrame(f, labelwidget=hf, padding=6)
        sf.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        sf.columnconfigure(0, weight=1)
        self.sz = max(10, int(round(float(a.s.get("el_sz", 24)) * ui)))
        self.cv = tk.Canvas(sf, height=int(60 * ui), bg=BG, highlightthickness=0,
                            cursor="hand2")
        self.cv.grid(row=0, column=0, sticky="ew")
        self.cv.bind("<Configure>", lambda e: self.draw())
        self.cv.bind("<Button-1>", self._click)
        self.cv.bind("<Button-3>", self._right)
        self.cv.bind("<Motion>", self._hover)
        g = tk.Canvas(sf, height=max(6, int(7 * ui)), highlightthickness=0, bg="#3c3c3c",
                      cursor="sb_v_double_arrow")
        g.grid(row=1, column=0, sticky="ew")
        g.bind("<Configure>", lambda e: self._grip_dots(g))
        g.bind("<ButtonPress-1>", lambda e: setattr(self, "_grip", (e.y_root, self.sz)))
        g.bind("<B1-Motion>", self._grip_move)
        g.bind("<ButtonRelease-1>", lambda e: (setattr(self, "_grip", None),
                                               a.s.__setitem__("el_sz",
                                                               round(self.sz / ui, 1))))
        self._grip = None
        self.info_var = tk.StringVar()
        ttk.Label(sf, textvariable=self.info_var, font=("Consolas", 9)).grid(
            row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Label(sf, foreground="#888", wraplength=int(760 * ui), justify="left",
                  text="click a row = edit it with the picker · right-click = choose a pal0 "
                       "colour · Alt+right-click a true-colour swatch = add it as a new "
                       "colour · under the rows: ••• = edited, ◆ = uses a new colour, line "
                       "= the row being edited · row 0 is the colour itself").grid(
            row=3, column=0, sticky="w")
        self.new_var = tk.StringVar()
        ttk.Label(sf, textvariable=self.new_var, foreground="#b05000").grid(
            row=4, column=0, sticky="w", pady=(2, 0))
        # picker
        pf = ttk.Frame(f)
        pf.grid(row=2, column=0, sticky="nsew", pady=(8, 0))
        pf.columnconfigure(0, weight=1)
        pf.rowconfigure(0, weight=1)
        from .gui_picker import ColourPicker
        self.picker = ColourPicker(a, parent=pf)
        self.picker.win.grid(row=0, column=0, sticky="nsew")
        f.columnconfigure(0, weight=1)
        f.rowconfigure(2, weight=1)
        self.win.resizable(True, True)
        self._set_cursor(True)
        a.status_var.set("Edit Levels: click a light level in the Matrix / Fades view, or a "
                         "palette cell. Esc or the button again stops.")
        self.win.withdraw()          # shows on the first pick
        self._shown = False

    # ---------------------------------------------------------- picking
    def _set_cursor(self, on):
        a = self.app
        for w in [a.canvas] + [p.cv for p in a._panes.values()]:
            try:
                w.configure(cursor="crosshair" if on else "")
            except a.tk.TclError:
                pass

    def pick(self, src, row=1):
        """Main window: a level cell (src, row) or a palette cell (row 1)."""
        a = self.app
        if src is None or src >= ENTRIES or a.rgbs[src] is None:
            return
        if src in a.cmap_locks:
            a.status_var.set("Fade %d is locked - unlock it to edit its levels." % src)
            return
        if not self._shown:
            self.win.deiconify()
            self.win.lift()
            self._shown = True
        self.src = src
        self.row = row if 1 <= row < ROWS else 1
        self._last_key = None
        self._target()
        self.draw()
        a.status_var.set("Edit Levels: index %d, row %d - the picker edits it." % (
            src, self.row))

    def _target(self):
        if self.src is None:
            return
        self.picker.set_target(self._picked, self.true_rgb(self.row), None,
                               "Index %d row %d" % (self.src, self.row))

    # ---------------------------------------------------------- colours
    def _virt(self):
        """pal0 (first 256) + the added colours (virtual indices 256+)."""
        pal = list(self.app.pal[:ENTRIES])
        pal += [None] * (ENTRIES - len(pal))
        return pal + [tuple(c) for c in self.newc]

    def _snapper(self, with_new=True):
        a = self.app
        key = (tuple(a.pal), frozenset(a.deleted), self.metric,
               tuple(self.newc) if with_new else ())
        if key != self._snap_key:
            v = self._virt() if with_new else self._virt()[:ENTRIES]
            self._snap = Snapper(v, a.deleted, self.metric, limit=len(v))
            self._snap_key = key
        return self._snap

    def snap(self, rgb, with_new=True):
        return self._snapper(with_new).nearest(oklab(rgb), tuple(rgb))

    def cur_index(self, r, s=None):
        """The palette index row r of the fade shows now (cm result)."""
        s = self.src if s is None else s
        res, _f = self.app.cmap_result()
        return res.rows[r][s]

    def true_rgb(self, r, s=None):
        s = self.src if s is None else s
        t = self.true.get(s, {}).get(r)
        if t is not None:
            return tuple(t)
        c = self.app.rgbs[self.cur_index(r, s)]
        return tuple(c) if c is not None else (0, 0, 0)

    def pal_index(self, r, s=None):
        """Palettised result incl. new colours (virtual index >= 256)."""
        s = self.src if s is None else s
        t = self.true.get(s, {}).get(r)
        if t is None:
            return self.cur_index(r, s)
        return self.snap(t)

    def pal_rgb(self, r, s=None):
        i = self.pal_index(r, s)
        v = self._virt()
        c = v[i] if i is not None and 0 <= i < len(v) else None
        return tuple(c) if c is not None else (0, 0, 0)

    # ---------------------------------------------------------- edits
    def _push(self, key=None):
        now = time.time()
        if key is not None and key == self._last_key and now - self._last_t < UNDO_GAP:
            self._last_t = now
            return
        self._undo.append(self._state())
        del self._undo[:-200]
        self._redo = []
        self._last_t, self._last_key = now, key

    def _state(self):
        return ({s: dict(d) for s, d in self.true.items()}, list(self.newc), self.src,
                self.row)

    def _load(self, st):
        self.true = {s: dict(d) for s, d in st[0].items()}
        self.newc = list(st[1])
        if st[2] is not None:
            self.src, self.row = st[2], st[3]
        self._write()
        self._target()

    def undo(self, redo=False):
        a, b = (self._redo, self._undo) if redo else (self._undo, self._redo)
        if not a:
            return False
        b.append(self._state())
        self._load(a.pop())
        self._last_key = None
        return True

    def _picked(self, rgb, _hsl=None):
        if self.src is None or self.row < 1:
            return
        rgb = tuple(max(0, min(255, int(round(v)))) for v in rgb)
        if self.true.get(self.src, {}).get(self.row) == rgb:
            return
        self._push(("pick", self.src, self.row))
        self.true.setdefault(self.src, {})[self.row] = rgb
        self._write()

    def set_row_index(self, r, i):
        """Right-click palette choice: the row becomes exactly pal0 colour i."""
        a = self.app
        if self.src is None or not 1 <= r < ROWS or a.rgbs[i] is None:
            return
        self._push()
        self.true.setdefault(self.src, {})[r] = tuple(a.rgbs[i])
        self.row = r
        self._write()
        self._target()

    def add_new(self, r):
        """Alt+right-click a true-colour swatch: its colour becomes a new colour."""
        a = self.app
        if self.src is None or not 1 <= r < ROWS:
            return
        rgb = self.true_rgb(r)
        if rgb in [tuple(c) for c in a.pal if c is not None]:
            a.status_var.set("%s is already in pal0." % hex_of(rgb).upper())
            return
        if rgb in [tuple(c) for c in self.newc]:
            a.status_var.set("%s is already a new colour." % hex_of(rgb).upper())
            return
        self._push()
        self.true.setdefault(self.src, {})[r] = rgb
        self.newc.append(rgb)
        self._write()
        a.status_var.set("New colour %s added - every edited row re-palettised (goes into "
                         "pal0 at Apply)." % hex_of(rgb).upper())

    def revert_row(self, r):
        d = self.true.get(self.src, {})
        if r in d:
            self._push()
            del d[r]
            self._write()

    def _write(self):
        """Edited rows -> cm hand edits on top of the base (new colours not in
        pal0 yet: their nearest pal0 colour); live."""
        a = self.app
        cm = self.base.copy()
        for s, d in self.true.items():
            if not d:
                continue
            if s in cm.fullbright:           # freeze the full-bright line first
                cm.fullbright = set(cm.fullbright) - {s}
                for r in range(1, ROWS):
                    cm.overrides.setdefault((r, s), s)
            for r, rgb in d.items():
                i = self.snap(rgb)
                if i is None:
                    continue
                if i >= ENTRIES:
                    i = self.snap(rgb, with_new=False)
                cm.overrides[(r, s)] = i
        if cm != a.cm:
            a.cm = cm
            a.cm_changed()
        a.recompute()
        self.draw()
        self.refresh()

    # ---------------------------------------------------------- main view hooks
    def show_true(self):
        return False

    def view_rgb(self, r, s):
        if s in self.true and r in self.true[s]:
            return self.pal_rgb(r, s)
        return None

    def marked_cells(self):
        out = set()
        for s, d in self.true.items():
            for r in d:
                i = self.pal_index(r, s)
                if i is not None and i >= ENTRIES:
                    out.add((r, s))
        return out

    # ---------------------------------------------------------- drawing
    def _geo(self):
        u = self.ui
        gap = max(1, int(round(1 * u)))
        W0 = max(self.cv.winfo_width(), 100)
        s = max(8, min(self.sz, (W0 - 4) // ROWS - gap))   # all 32 rows on one line
        num_h = int(12 * u)
        dot = max(2.0, 1.6 * u)
        lw = max(2, int(round(2 * u)))
        mark_h = int(round(dot * 2 + 3 * u + dot * 2 + 3 * u + lw + 3 * u))
        W = max(self.cv.winfo_width(), 100)
        per = max(1, min(ROWS, (W - 4 + gap) // (s + gap)))
        return s, gap, num_h, dot, lw, mark_h, per

    def draw(self):
        c = self.cv
        c.delete("all")
        self._hits = []
        if self.src is None:
            return
        a = self.app
        s, gap, num_h, dot, lw, mark_h, per = self._geo()
        u = self.ui
        lines = (ROWS + per - 1) // per
        band = num_h + 2 * s + 2 * u + mark_h + int(6 * u)
        h = lines * band + 2
        if int(c.cget("height")) != h:
            c.configure(height=h)
        fsz = max(7, int(round(7 * max(1.0, s / (24.0 * u)))))
        d = self.true.get(self.src, {})
        for r in range(ROWS):
            k = r % per
            x = 2 + k * (s + gap)
            y0 = 2 + (r // per) * band
            c.create_text(x + s / 2.0, y0 + num_h / 2.0, text=str(r), fill="#bbbbbb",
                          font=("Consolas", fsz))
            yt = y0 + num_h
            yp = yt + s + 2 * u
            tc, pc = self.true_rgb(r), self.pal_rgb(r)
            out = "#555" if r == 0 else "#6a6a6a"
            c.create_rectangle(x, yt, x + s, yt + s, fill=hex_of(tc), outline=out)
            c.create_rectangle(x, yp, x + s, yp + s, fill=hex_of(pc), outline=out)
            if r == 0:                                   # not editable
                c.create_line(x + 2, yt + s - 2, x + s - 2, yt + 2, fill="#777")
            my = yp + s + 2 * u + dot
            if r in d:                                   # ••• edited
                for q in (-1, 0, 1):
                    cx = x + s / 2.0 + q * dot * 3
                    c.create_oval(cx - dot, my - dot, cx + dot, my + dot, fill="#ffffff",
                                  outline="")
            my2 = my + dot + 3 * u + dot
            i = self.pal_index(r)
            if r in d and i is not None and i >= ENTRIES:   # ◆ uses a new colour
                cx = x + s / 2.0
                q = dot * 1.6
                c.create_polygon(cx, my2 - q, cx + q, my2, cx, my2 + q, cx - q, my2,
                                 fill="#00e5ff", outline="")
            if r == self.row:                             # line = active row
                ly = my2 + dot + 3 * u + lw / 2.0
                c.create_line(x, ly, x + s, ly, fill="#ffffff", width=lw)
            self._hits.append((x, yt, x + s, yp + s, r, yt + s))
        n = len(self.newc)
        used = len(self.marked_cells())
        self.new_var.set(("%d new colour%s (%s) - %d row%s - into pal0 at Apply"
                          % (n, "" if n == 1 else "s",
                             " ".join(hex_of(c).upper() for c in self.newc[:6]) +
                             (" ..." if n > 6 else ""), used,
                             " uses it" if used == 1 else "s use them"))
                         if n else "")
        lk = "  LOCKED" if self.src in a.cmap_locks else ""
        self.title_var.set("Index %d  %s%s" % (self.src, hex_of(a.rgbs[self.src]).upper(),
                                               lk))

    def _hit(self, ev):
        for x0, y0, x1, y1, r, ymid in getattr(self, "_hits", []):
            if x0 <= ev.x <= x1 and y0 <= ev.y <= y1:
                return r, ev.y <= ymid
        return None, None

    def _click(self, ev):
        r, _top = self._hit(ev)
        if r is None:
            return
        if r == 0:
            self.app.status_var.set("Row 0 is the colour itself - it can't be edited.")
            return
        self.row = r
        self._last_key = None
        self._target()
        self.draw()

    def _right(self, ev):
        r, top = self._hit(ev)
        if r is None:
            return
        if r == 0:
            self.app.status_var.set("Row 0 is the colour itself - it can't be edited.")
            return
        if self.app._alt_down(ev):
            if top:
                self.add_new(r)
            else:
                self.app.status_var.set("Alt+right-click the TRUE-COLOUR (top) swatch to "
                                        "add its colour.")
            return
        from .gui_fade_edit import PaletteChooser
        if self._chooser is not None:
            self._chooser.close()
        self._chooser = PaletteChooser(self.app, self.win,
                                       lambda i, r=r: self.set_row_index(r, i),
                                       "Index %d row %d - choose a pal0 colour" % (self.src,
                                                                                  r))

    def _hover(self, ev):
        r, top = self._hit(ev)
        if r is None:
            self.info_var.set("")
            return
        tc = self.true_rgb(r)
        i = self.pal_index(r)
        pc = self.pal_rgb(r)
        where = ("new colour" if i is not None and i >= ENTRIES else "pal0 %s" % i)
        t = "row %d   true %s   -> %s %s" % (r, hex_of(tc).upper(), where,
                                             hex_of(pc).upper())
        if r == 0:
            t += "   (the colour itself)"
        elif r in self.true.get(self.src, {}):
            t += "   edited"
        self.info_var.set(t)

    def _grip_dots(self, g):
        g.delete("all")
        W, H = g.winfo_width(), g.winfo_height()
        u = max(1.0, self.ui)
        for k in (-1, 0, 1):
            x = W / 2.0 + k * 6 * u
            g.create_oval(x - u, H / 2.0 - u, x + u, H / 2.0 + u, fill="#aaaaaa", outline="")

    def _grip_move(self, ev):
        if not self._grip:
            return
        y0, sz0 = self._grip
        sz = int(min(max(sz0 + (ev.y_root - y0) / 2.0, 10 * self.ui), 80 * self.ui))
        if sz != self.sz:
            self.sz = sz
            self.draw()

    def _metric_changed(self):
        self.metric = self.metric_var.get()
        self.app.s["el_metric"] = self.metric
        self._write()

    # ---------------------------------------------------------- apply / revert
    def before_apply(self):
        """New colours go into pal0 first (together); rows re-snap to them."""
        a = self.app
        self._apply_msg = ""
        if not self.newc:
            return True
        used = set()
        for s, d in self.true.items():
            for r, rgb in d.items():
                i = self.snap(rgb)
                if i is not None and i >= ENTRIES:
                    used.add(i - ENTRIES)
        cols = [tuple(c) for k, c in enumerate(self.newc) if k in used]
        if not cols:
            self.newc = []
            return True
        n = len(cols)
        sel = sorted(i for i in a.selection if i < ENTRIES)
        newpos = None
        if sel:
            slots, newpos, msg = a.place_colours(cols, "insert", True, max(sel) + 1)
            self._apply_msg = msg
        else:
            slots, newpos, msg = a.place_colours(cols, "empty", True, 0)
            if not slots:                    # no gap: below the red line + warning
                r_ = a.rgbs
                start = max([i for i in range(len(r_)) if r_[i] is not None] +
                            [ENTRIES - 1]) + 1
                a._ensure_len(start + n)
                slots = list(range(start, start + n))
                a._write_cells(slots, cols)
                self._apply_msg = ("%d new colour%s didn't fit in pal0 - put below the red "
                                   "line (%d-%d): move them into pal0 yourself; the rows "
                                   "use their nearest pal0 colour until then." % (
                                       n, "" if n == 1 else "s", slots[0], slots[-1]))
                try:
                    from tkinter import messagebox
                    messagebox.showwarning("Edit Levels", self._apply_msg, parent=self.win)
                except Exception:  # noqa: BLE001
                    pass
        if newpos:                           # indices moved: follow them
            np_ = _np(newpos)
            self.true = {np_(s): d for s, d in self.true.items()}
            if self.src is not None:
                self.src = np_(self.src)
        self._placed = list(zip(cols, slots))
        self.newc = []
        self._snap_key = None
        self.base = self._base_after_place(newpos)
        self._write()
        return True

    def _base_after_place(self, newpos):
        """The session base, with its indices following a push."""
        a = self.app
        st = a._ctool_start
        if not newpos or st is None:
            return self.base
        np_ = _np(newpos)
        cm = st[0].copy()
        cm.overrides = {(r, np_(s)): np_(t) for (r, s), t in cm.overrides.items()}
        cm.fullbright = {np_(i) for i in cm.fullbright}
        return cm

    def log_text(self):
        rows = sum(len(d) for d in self.true.values())
        fades = sum(1 for d in self.true.values() if d)
        t = "%d level%s in %d fade%s" % (rows, "" if rows == 1 else "s", fades,
                                         "" if fades == 1 else "s")
        placed = getattr(self, "_placed", [])
        if placed:
            t += ", %d new colour%s at %s" % (len(placed), "" if len(placed) == 1 else "s",
                                              ", ".join(str(s) for _c, s in placed))
        if getattr(self, "_apply_msg", ""):
            t += " (%s)" % self._apply_msg
        return t

    def note_applied(self):
        self.true, self.newc = {}, []
        self._undo, self._redo = [], []
        self._placed, self._apply_msg = [], ""
        self.base = self.app.cm.copy()
        self._snap_key = None
        self.draw()
        if self.src is not None:
            self._target()

    def note_reverted(self):
        self.true, self.newc = {}, []
        self._undo, self._redo = [], []
        self._placed = []
        self.base = self.app.cm.copy()
        self._snap_key = None
        self.draw()
        if self.src is not None:
            self._target()

    def external_edit(self):
        self.base = self.app.cm.copy()

    def teardown(self):
        self._set_cursor(False)
        if self._chooser is not None:
            self._chooser.close()
        try:
            self.picker.close()
        except Exception:  # noqa: BLE001
            pass
        _CWin.teardown(self)
