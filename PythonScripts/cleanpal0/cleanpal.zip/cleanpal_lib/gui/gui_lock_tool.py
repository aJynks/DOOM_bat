"""Colour lock (App mixin + tool window).

Locked cells (palette indices 0-255) are left alone by every tool, even when
selected: Paint, Cull, Move, Reorder, clipboard pastes / inserts and the
COLORMAP tools that add colours. Locking an empty cell reserves the slot.
Locks are a property of the cells, not of a palette state: they don't add
history entries and are saved in projects. Reserved groups (tick boxes) just
lock their slots; Restore originals / Palette Browser Restore put original colours
back (one history entry).
"""

from ..cleanpal_lib_constants import ENTRIES
from .gui_tool_windows import _ToolWin, focus_on_click

# Doom's PLAYPAL (identical to Freedoom's) - the "original" colours when no
# IWAD is set
_DOOM_HEX = (
    "0000001f170b170f074b4b4bffffff1b1b1b1313130b0b0b0707072f371f232b0f171f07"
    "0f17004f3b2b4733233f2b1bffb7b7f7ababf3a3a3eb9797e78f8fdf8787db7b7bd37373"
    "cb6b6bc76363bf5b5bbb5757b34f4faf4747a73f3fa33b3b9b3333972f2f8f2b2b8b2323"
    "831f1f7f1b1b7717177313136b0f0f670b0b5f07075b07075307074f0000470000430000"
    "ffebdfffe3d3ffdbc7ffd3bbffcfb3ffc7a7ffbf9bffbb93ffb383f7ab7befa373e79b6b"
    "df9363d78b5bcf8353cb7f4fbf7b4bb37347ab6f43a36b3f9b633b8f5f378757337f532f"
    "774f2b6b47275f4323533f1f4b371b3f2f17332b132b230fefefefe7e7e7dfdfdfdbdbdb"
    "d3d3d3cbcbcbc7c7c7bfbfbfb7b7b7b3b3b3abababa7a7a79f9f9f9797979393938b8b8b"
    "8383837f7f7f7777776f6f6f6b6b6b6363635b5b5b5757574f4f4f4747474343433b3b3b"
    "3737372f2f2f27272723232377ff6f6fef6767df5f5fcf575bbf4f53af474b9f3f439337"
    "3f832f37732b2f632327531b1f431717330f13230b0b1707bfa78fb79f87af977fa78f77"
    "9f876f9b7f6b937b638b735b836b577b634f775f4b6f574367533f5f4b37574333533f2f"
    "9f83638f7753836b4b775f3f6753335b472b4f3b2343331b7b7f636f7357676b4f5b6347"
    "53573b474f333f472b373f27ffff73ebdb57d7bb43c39b2faf7b1f9b5b13874307732b00"
    "ffffffffdbdbffbbbbff9b9bff7b7bff5f5fff3f3fff1f1fff0000ef0000e30000d70000"
    "cb0000bf0000b30000a700009b00008b00007f00007300006700005b00004f0000430000"
    "e7e7ffc7c7ffababff8f8fff7373ff5353ff3737ff1b1bff0000ff0000e30000cb0000b3"
    "00009b00008300006b000053ffffffffebdbffd7bbffc79bffb37bffa35bff8f3bff7f1b"
    "f37317eb6f0fdf670fd75f0bcb5707c34f00b74700af4300ffffffffffd7ffffb3ffff8f"
    "ffff6bffff47ffff23ffff00a73f009f3700932f008723004f3b27432f1b3723132f1b0b"
    "00005300004700003b00002f00002300001700000b000000ff9f43ffe74bff7bffff00ff"
    "cf00cf9f009b6f006ba76b6b"
)


def doom_palette():
    b = bytes.fromhex("".join(_DOOM_HEX))
    return [tuple(b[i * 3:i * 3 + 3]) for i in range(ENTRIES)]


# key, label, first index, count, why
RESERVED = (
    ("black0", "Black - index 0", 0, 1,
     "vanilla clears / automap, COLORMAP fades toward it; Nyan text shadow "
     "(always index 0 - Nyan start-up bug)"),
    ("black247", "Black - index 247", 247, 1,
     "Doom's second black: DeuTex transparent, Boom/dsda automap background"),
    ("red176", "Red - index 176 (dsda HUD bright)", 176, 1,
     "dsda / Nyan font colour ranges force it to the range's end colour; "
     "vanilla automap wall red"),
    ("green", "Green ramp - 112-127 (Player 1)", 112, 16,
     "player 1 sprite range (recoloured for the other players)"),
    ("grey", "Grey ramp - 96-111 (Player 2)", 96, 16, "player 2 colour (green is remapped here)"),
    ("brown", "Brown ramp - 64-79 (Player 3)", 64, 16, "player 3 colour"),
    ("red", "Red ramp - 32-47 (Player 4)", 32, 16, "player 4 colour"),
    ("redfont", "Red ramp - 176-191 (fonts / HUD)", 176, 16,
     "STCFN message font + STTNUM status bar numbers are stored here; "
     "Default text uses these colours"),
    ("fontdark", "Dark red - 40-47 (font shading)", 40, 8,
     "the darker pixels of the STCFN message font"),
)

LOCK_COLOUR = "#b48cff"


def pin_perm(perm, locked):
    """perm[new] = old with every locked cell kept in place: the other cells
    keep their order from perm and flow around the locked ones."""
    if not locked:
        return list(perm)
    n = len(perm)
    seq = [o for o in perm if o not in locked]
    out = []
    k = 0
    for i in range(n):
        if i in locked:
            out.append(i)
        else:
            out.append(seq[k])
            k += 1
    return out


class LockMixin:
    """Lock state + the helpers every tool uses to skip locked cells."""

    def _lock_init(self):
        self.locked = set()
        self.reserved = set()        # ticked reserved groups (keys of RESERVED)

    def is_locked(self, i):
        return i in self.locked

    def editable(self, idx):
        """The cells of idx that tools may change (locked ones dropped)."""
        lk = self.locked
        return [i for i in idx if i not in lk]

    def free_cells(self):
        """Empty, unlocked palette cells - where new colours may go."""
        lk = self.locked
        r = self.rgbs or []
        return [i for i in range(min(ENTRIES, len(r))) if r[i] is None and i not in lk]

    def _lock_note(self, wanted, used):
        n = len(set(wanted)) - len(set(used))
        return ("  (%d locked cell%s left alone)" % (n, "" if n == 1 else "s")) if n > 0 else ""

    # ---- lock / unlock
    def lock_cells(self, idx, on=True):
        idx = {i for i in idx if 0 <= i < ENTRIES}
        if not idx:
            self.status_var.set("Select cells to %s first." % ("lock" if on else "unlock"))
            return
        before = len(self.locked)
        if on:
            self.locked |= idx
        else:
            self.locked -= idx
        n = abs(len(self.locked) - before)
        self.status_var.set("%s %d cell(s) - %d locked in all." % (
            "Locked" if on else "Unlocked", n, len(self.locked)))
        self._lock_changed()

    def lock_toggle(self, i):
        if not 0 <= i < ENTRIES:
            self.status_var.set("Only palette cells (above the red line) can be locked.")
            return
        self.lock_cells([i], on=i not in self.locked)

    def unlock_all(self):
        n = len(self.locked)
        self.locked = set()
        self.reserved = set()
        self.status_var.set("Unlocked all %d cell(s)." % n)
        self._lock_changed()

    def _lock_changed(self):
        if getattr(self, "locks_win", None) is not None:
            self.locks_win.refresh()
        self.recompute()

    def open_locks(self):
        """The Lock tool (side panel)."""
        self.open_tool("lock")

    # ---- reserved groups (tick boxes: lock the slots, never change colours)
    @staticmethod
    def reserved_cells(key):
        _k, _l, start, n, _w = next(r for r in RESERVED if r[0] == key)
        return list(range(start, start + n))

    def set_reserved(self, keys):
        """Tick state -> locks: newly ticked groups lock their slots, unticked
        ones unlock theirs. Colours are never touched."""
        keys = {k for k in keys if any(r[0] == k for r in RESERVED)}
        on, off = keys - self.reserved, self.reserved - keys
        keep = {i for k in keys for i in self.reserved_cells(k)}   # groups overlap
        for k in off:
            self.locked -= set(self.reserved_cells(k)) - keep
        for k in on:
            self.locked |= set(self.reserved_cells(k))
        self.reserved = keys
        self.status_var.set("Reserved groups: %s - %d cell(s) locked in all." % (
            ", ".join(next(r[1] for r in RESERVED if r[0] == k)
                      for k in [r[0] for r in RESERVED] if k in keys) or "none",
            len(self.locked)))
        self._lock_changed()

    def original_palette(self):
        """(name, 256 colours): the IWAD's PLAYPAL, else Doom's built in."""
        arch = self.iwad_archive()
        pal = arch.playpal() if arch is not None else None
        if pal and len(pal) >= ENTRIES:
            import os
            return "IWAD %s" % os.path.basename(arch.path), [
                tuple(c) if c is not None else None for c in pal[:ENTRIES]]
        return "Doom's palette (built in)", doom_palette()

    # ---- restore engine
    def _push_from(self, t, pinned):
        """Free cell t by pushing its colour (and the ones after it) along to
        the nearest empty cell; past index 255 the last one goes below the red
        line. Pinned cells stay put. Returns True if a colour went below."""
        r = self.rgbs
        chain = [p for p in range(t, ENTRIES) if p not in pinned]
        k = next((j for j, p in enumerate(chain) if r[p] is None), None)
        overflow = False
        if k is None:
            spots = [i for i in range(ENTRIES, len(r)) if r[i] is None]
            if not spots:
                self._ensure_len(len(r) + 1)
                spots = [len(self.rgbs) - 1]
            chain.append(spots[0])
            k = len(chain) - 1
            overflow = True
        perm = list(range(len(self.rgbs)))
        for j in range(1, k + 1):
            perm[chain[j]] = chain[j - 1]
        perm[chain[0]] = chain[k]
        self.locked = set(pinned)
        self._permute(perm)
        self.locked = set()
        return overflow

    def _restore_apply(self, targets):
        """targets: [(index, colour)]. Each cell gets its colour: already
        right = left alone; the colour elsewhere in the strip = moved in (even
        from a locked cell); otherwise added. A colour in the way is pushed
        along, never overwritten. Locked cells (other than the targets) and
        cells already done stay put."""
        lock0 = set(self.locked)
        st = {"added": 0, "moved": 0, "pushed": 0, "below": 0, "ok": 0}
        done = set()
        try:
            for t, c in sorted(targets):
                c = tuple(c)
                r = self.rgbs
                if r[t] is not None and tuple(r[t]) == c:
                    done.add(t)
                    st["ok"] += 1
                    continue
                self.locked = set()
                m = next((i for i, x in enumerate(r) if x is not None and tuple(x) == c
                          and i != t and i not in done), None)
                if m is not None:
                    self._write_cells([m], [None])
                    st["moved"] += 1
                else:
                    st["added"] += 1
                if self.rgbs[t] is not None:
                    st["pushed"] += 1
                    if self._push_from(t, (lock0 - {t}) | done):
                        st["below"] += 1
                self.locked = set()
                self._write_cells([t], [c])
                done.add(t)
        finally:
            self.locked = lock0
        return st, sorted(done)

    @staticmethod
    def _restore_text(st):
        parts = []
        for k, word in (("written", "overwritten"), ("added", "added"),
                        ("moved", "moved in"),
                        ("pushed", "pushed along"), ("ok", "already right")):
            if st.get(k):
                parts.append("%d %s" % (st[k], word))
        if st.get("below"):
            parts.append("%d went below the red line" % st["below"])
        return ", ".join(parts) or "nothing to do"

    def _restore_groups(self, keys, mode):
        """Write the original colours into the cells of reserved groups `keys`
        (locks ignored for those cells). mode "slide" = colours in the way are
        pushed along / a copy elsewhere is moved in; "overwrite" = written
        straight in, nothing else moves. -> (stats, cells, source name)."""
        cells = sorted({i for k in keys for i in self.reserved_cells(k)})
        name, orig = self.original_palette()
        if mode == "overwrite":
            todo = [i for i in cells if orig[i] is not None and (
                self.rgbs[i] is None or tuple(self.rgbs[i]) != tuple(orig[i]))]
            if todo:
                lock0 = set(self.locked)
                self.locked = set()
                try:
                    self._write_cells(todo, [tuple(orig[i]) for i in todo])
                finally:
                    self.locked = lock0
            return {"written": len(todo), "ok": len(cells) - len(todo)}, cells, name
        st, done = self._restore_apply([(i, orig[i]) for i in cells])
        return st, done, name

    def restore_colours(self, mode=None, keys=None):
        """Restore originals without the dialog (keys default = the ticked
        reserved groups). One history entry."""
        mode = mode or self.s.get("lock_restore_mode", "slide")
        keys = list(keys if keys is not None else self.reserved)
        if not keys:
            self.status_var.set("Restore originals: no groups chosen.")
            return
        if not self._external_edit_ok():
            return
        st, cells, name = self._restore_groups(keys, mode)
        if not (st.get("written") or st.get("added") or st.get("moved")):
            self.status_var.set("Restore originals: already right - nothing changed.")
            return
        self._external_commit(cells, "Restore originals%s" % (
            " (overwrite)" if mode == "overwrite" else ""),
            "Restore originals from %s: %s" % (name, self._restore_text(st)))

    def _state_save(self):
        return (self.rgbs, self.labs, self.pairs, set(self.deleted), self.cm.copy(),
                set(self.locked), set(self.selection))

    def _state_load(self, b):
        self.rgbs, self.labs, self.pairs = b[0], b[1], b[2]
        self.deleted, self.cm = set(b[3]), b[4].copy()
        self.locked, self.selection = set(b[5]), set(b[6])
        self.cm_changed()

    def restore_dialog(self):
        """Restore originals box: the reserved groups as tick boxes (none
        ticked at the start, independent of the locks and the selection).
        Ticking previews the original colours on the palette; OK writes one
        history entry, Cancel puts everything back."""
        from tkinter import ttk

        if not self._external_edit_ok():
            return
        tk = self.tk
        base = self._state_save()
        win = tk.Toplevel(self.root)
        win.title("Restore originals")
        win.transient(self.root)
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except tk.TclError:
            pass
        f = ttk.Frame(win, padding=14)
        f.pack(fill="both", expand=True)
        name, _o = self.original_palette()
        ttk.Label(f, text="Tick the groups to put back to their original colours (%s).\n"
                          "The palette shows it as you tick - Apply writes it (one history\n"
                          "entry) and the box stays open; Close drops anything not applied.\n"
                          "Locks and the selection don't matter here." % name,
                  foreground="#666", justify="left").pack(anchor="w")
        vs = {}
        mode = tk.StringVar(value="overwrite" if self.s.get("lock_restore_mode") ==
                            "overwrite" else "slide")
        info = tk.StringVar()
        res = {"st": None, "cells": [], "keys": []}
        state = {"base": base, "applied": 0}

        def live():
            self._state_load(state["base"])           # the palette at the last Apply
            keys = [k for k, *_r in RESERVED if vs[k].get()]
            res["keys"] = keys
            if keys:
                st, cells, _n = self._restore_groups(keys, mode.get())
                res["st"], res["cells"] = st, cells
                info.set(self._restore_text(st))
            else:
                res["st"], res["cells"] = None, []
                info.set("nothing ticked")
            self.recompute()

        for k, lbl, _s, _n, why in RESERVED:
            row = ttk.Frame(f)
            row.pack(fill="x", pady=(4, 0))
            vs[k] = tk.BooleanVar(value=False)
            ttk.Checkbutton(row, text=lbl, variable=vs[k], width=34,
                            command=live).pack(side="left")
            ttk.Label(row, text=why, foreground="#666").pack(side="left")
        mf = ttk.Frame(f)
        mf.pack(fill="x", pady=(12, 0))
        ttk.Label(mf, text="Mode:").pack(side="left")
        for val, txt in (("overwrite", "Overwrite (written straight in, nothing else moves)"),
                         ("slide", "Slide along (colours in the way pushed along)")):
            ttk.Radiobutton(mf, text=txt, value=val, variable=mode,
                            command=lambda: (self.s.__setitem__("lock_restore_mode",
                                                                mode.get()), live())).pack(
                side="left", padx=(8, 0))
        ttk.Label(f, textvariable=info, foreground="#444").pack(anchor="w", pady=(8, 0))
        def apply():
            st = res["st"]
            if st is None or not (st.get("written") or st.get("added") or st.get("moved")):
                self.status_var.set("Restore originals: nothing to apply.")
                return
            b0 = state["base"]
            self.locked, self.selection = set(b0[5]), set(b0[6])
            groups = ", ".join(next(r[1] for r in RESERVED if r[0] == k) for k in res["keys"])
            self._external_commit(res["cells"], "Restore originals%s" % (
                " (overwrite)" if mode.get() == "overwrite" else ""),
                "Restore originals from %s (%s): %s" % (name, groups, self._restore_text(st)))
            state["base"] = self._state_save()
            state["applied"] += 1
            for v in vs.values():
                v.set(False)
            res["st"], res["cells"], res["keys"] = None, [], []
            info.set("applied - tick more groups or Close")

        def close():
            try:
                win.grab_release()
            except tk.TclError:
                pass
            win.destroy()

        bf = ttk.Frame(f)
        bf.pack(fill="x", pady=(14, 0))
        ttk.Button(bf, text="Close", command=close).pack(side="right")
        ttk.Button(bf, text="Apply", command=apply).pack(side="right", padx=(0, 6))
        win.bind("<Escape>", lambda e: close())
        win.protocol("WM_DELETE_WINDOW", close)
        info.set("nothing ticked")
        win.update_idletasks()
        r = self.root
        win.geometry("+%d+%d" % (max(0, r.winfo_rootx() + (r.winfo_width()
                                                           - win.winfo_reqwidth()) // 2),
                                 max(0, r.winfo_rooty() + 120)))
        try:
            win.grab_set()
        except tk.TclError:
            pass
        self._restore_win = win
        self.root.wait_window(win)
        self._restore_win = None
        dropped = res["st"] is not None
        self._state_load(state["base"])           # anything not applied goes
        if dropped or not state["applied"]:
            self.status_var.set("Restore originals: %d applied%s." % (
                state["applied"], ", unapplied ticks dropped" if dropped else ""))
        self.recompute()

    def restore_at_index(self, items, src):
        """Palette Browser Restore: items [(index, colour)] into the same indices,
        ignoring locks and tick boxes (other locked cells still stay put)."""
        if self._ramp_copy_busy():
            return
        if not self._external_edit_ok():
            return
        items = [(i, c) for i, c in items if c is not None and 0 <= i < ENTRIES]
        if not items:
            self.status_var.set("Select colours in the Palette Browser window first.")
            return
        st, cells = self._restore_apply(items)
        if not st["added"] and not st["moved"]:
            self.status_var.set("Restore: those colours are already in place.")
            return
        self._external_commit(cells, "Restored %d cells from %s" % (len(items), src),
                              "Restored from %s: %s" % (src, self._restore_text(st)))

    def restore_free_space(self, cols, src):
        """Palette Browser Restore with 'Place in first free space': the colours, in
        order, into the first run of empty unlocked cells long enough to hold
        them (colours already elsewhere are moved in, not copied). No such run:
        after the last filled cell below the red line (colours already in the
        strip are then left where they are, not duplicated)."""
        if self._ramp_copy_busy():
            return
        if not self._external_edit_ok():
            return
        cols = [tuple(c) for c in cols if c is not None]
        if not cols:
            self.status_var.set("Select colours in the Palette Browser window first.")
            return
        n = len(cols)
        r = self.rgbs
        lk = self.locked
        start = next((s for s in range(0, ENTRIES - n + 1)
                      if all(r[i] is None and i not in lk for i in range(s, s + n))), None)
        lock0 = set(self.locked)
        self.locked = set()
        try:
            moved = 0
            if start is not None:
                run = set(range(start, start + n))
                for c in cols:
                    r = self.rgbs
                    m = next((i for i, x in enumerate(r) if x is not None and tuple(x) == c
                              and i not in run), None)
                    if m is not None:
                        self._write_cells([m], [None])
                        moved += 1
                cells = list(range(start, start + n))
                self._write_cells(cells, cols)
                detail = "Restored %d colour(s) from %s into %d-%d (%d moved in)" % (
                    n, src, start, start + n - 1, moved)
            else:
                have = {tuple(x) for x in self.rgbs if x is not None}
                new = [c for c in cols if c not in have]
                if not new:
                    self.status_var.set("Restore: those colours are all in the palette "
                                        "already - nothing added.")
                    return
                last = max((i for i in range(ENTRIES, len(self.rgbs))
                            if self.rgbs[i] is not None), default=ENTRIES - 1)
                cells = list(range(last + 1, last + 1 + len(new)))
                self._write_cells(cells, new)
                detail = ("No run of %d free cells - %d colour(s) from %s added below "
                          "the red line%s" % (n, len(new), src,
                                              (" (%d already in the strip)" % (n - len(new)))
                                              if n > len(new) else ""))
        finally:
            self.locked = lock0
        self._external_commit(cells, "Restored %d cells from %s" % (n, src), detail)

    def reserved_dialog(self):
        from tkinter import ttk

        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("Lock reserved")
        win.transient(self.root)
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except tk.TclError:
            pass
        f = ttk.Frame(win, padding=14)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="Ticked groups have their slots locked - whatever colours are in\n"
                          "them (or none). Nothing is written or moved. Restore\n"
                          "originals puts the original colours back into ticked groups.",
                  foreground="#666", justify="left").pack(anchor="w")
        vs = {}
        lock0, res0 = set(self.locked), set(self.reserved)

        def live():                    # show the locks on the palette as you tick
            self.set_reserved([k for k, *_r in RESERVED if vs[k].get()])

        for k, lbl, _s, _n, why in RESERVED:
            row = ttk.Frame(f)
            row.pack(fill="x", pady=(4, 0))
            vs[k] = tk.BooleanVar(value=k in self.reserved)
            ttk.Checkbutton(row, text=lbl, variable=vs[k], width=34,
                            command=live).pack(side="left")
            ttk.Label(row, text=why, foreground="#666").pack(side="left")
        res = {"ok": False}

        def done(ok):
            res["ok"] = ok
            try:
                win.grab_release()
            except tk.TclError:
                pass
            win.destroy()

        bf = ttk.Frame(f)
        bf.pack(fill="x", pady=(14, 0))
        ttk.Button(bf, text="Cancel", command=lambda: done(False)).pack(side="right")
        ttk.Button(bf, text="OK", command=lambda: done(True)).pack(side="right",
                                                                  padx=(0, 6))
        win.bind("<Return>", lambda e: done(True))
        win.bind("<Escape>", lambda e: done(False))
        win.protocol("WM_DELETE_WINDOW", lambda: done(False))
        win.update_idletasks()
        r = self.root
        win.geometry("+%d+%d" % (max(0, r.winfo_rootx() + (r.winfo_width()
                                                           - win.winfo_reqwidth()) // 2),
                                 max(0, r.winfo_rooty() + 120)))
        try:
            win.grab_set()
        except tk.TclError:
            pass
        self.root.wait_window(win)
        if res["ok"]:
            self.set_reserved([k for k, *_r in RESERVED if vs[k].get()])
        else:                          # Cancel: every lock back as it was
            self.locked, self.reserved = lock0, res0
            self.status_var.set("Lock reserved cancelled - locks unchanged.")
            self._lock_changed()

    # ---- grid mark
    def _draw_lock_mark(self, cv, x, y, C):
        if C < 10:
            cv.create_rectangle(x, y, x + C, y + C, outline=LOCK_COLOUR)
            return
        s = C * 0.34
        bx0, by0 = x + C - s - C * 0.06, y + C * 0.06 + s * 0.35
        bx1, by1 = bx0 + s, by0 + s * 0.7
        w = max(1, round(C / 22))
        sh = s * 0.28                                     # shackle
        cv.create_arc(bx0 + sh * 0.6, by0 - sh * 1.6, bx1 - sh * 0.6, by0 + sh * 0.6,
                      start=0, extent=180, style="arc", outline="#000000", width=w + 2)
        cv.create_arc(bx0 + sh * 0.6, by0 - sh * 1.6, bx1 - sh * 0.6, by0 + sh * 0.6,
                      start=0, extent=180, style="arc", outline=LOCK_COLOUR, width=w)
        cv.create_rectangle(bx0, by0, bx1, by1, fill=LOCK_COLOUR, outline="#000000",
                            width=1)


class LockTool(_ToolWin):
    """Lock tool (side panel, one tool at a time like the others): lock /
    unlock cells, reserved groups, Restore originals (overwrite or slide
    along). While it is open a double-click on a grid cell toggles its lock."""
    POS_KEY = "lock_pos"

    def __init__(self, app):
        tk = app.tk
        from tkinter import ttk

        win = self._make_win(app, "Lock tools")
        win.bind("<Escape>", lambda e: app.close_tool())
        f = ttk.Frame(win, padding=10)
        f.pack(fill="both", expand=True)
        ttk.Label(f, text="Locked cells are left alone by every tool, even when\n"
                          "selected. Lock an empty cell to reserve the slot.\n"
                          "Double-click a cell = lock / unlock.",
                  foreground="#666", justify="left").pack(anchor="w")
        bf = ttk.Frame(f)
        bf.pack(fill="x", pady=(8, 0))
        ttk.Button(bf, text="Lock selected",
                   command=lambda: app.lock_cells(app.selection, True)).pack(side="left")
        ttk.Button(bf, text="Unlock selected",
                   command=lambda: app.lock_cells(app.selection, False)).pack(
            side="left", padx=(6, 0))
        ttk.Button(bf, text="Unlock all", command=app.unlock_all).pack(side="left",
                                                                      padx=(6, 0))
        rf = ttk.Frame(f)
        rf.pack(fill="x", pady=(8, 0))
        ttk.Button(rf, text="Lock reserved...", command=app.reserved_dialog).pack(side="left")
        ttk.Button(rf, text="Select locked", command=self.select_locked).pack(
            side="left", padx=(6, 0))

        sf = ttk.LabelFrame(f, text="Restore originals", padding=6)
        sf.pack(fill="x", pady=(10, 0))
        ttk.Button(sf, text="Restore originals...", command=app.restore_dialog).pack(
            anchor="w")
        ttk.Label(sf, text="Tick groups (Black 0, Red 176, player ramps ...) to put back the\n"
                           "original colours (IWAD PLAYPAL, else Doom's) - shown live,\n"
                           "written on OK as one history entry. Overwrite or Slide along\n"
                           "is chosen in the box. Independent of the locks.",
                  foreground="#666", justify="left").pack(anchor="w", pady=(6, 0))
        self.count_var = tk.StringVar()
        ttk.Label(f, textvariable=self.count_var).pack(anchor="w", pady=(8, 0))
        focus_on_click(win)
        ttk.Separator(f).pack(fill="x", pady=(10, 0))
        cf = ttk.Frame(f)
        cf.pack(fill="x", pady=(8, 0))
        ttk.Button(cf, text="Close", command=app.close_tool).pack(side="right")
        self.refresh()
        self._place()

    def select_locked(self):
        a = self.app
        a.selection = set(a.locked)
        a.recompute()

    def refresh(self):
        a = self.app
        n = len(a.locked)
        empty = sum(1 for i in a.locked if a.rgbs is not None and a.rgbs[i] is None)
        groups = []
        for r in RESERVED:
            if r[0] in a.reserved:
                lbl = r[1].split(" - ")[0]
                groups.append(lbl + (" %d" % r[2] if r[3] == 1 else ""))
        self.count_var.set("Locked: %d cell(s)%s\nReserved: %s" % (
            n, (" - %d empty" % empty) if empty else "", ", ".join(groups) or "none"))

    def teardown(self):
        self.app.locks_win = None
        super().teardown()
