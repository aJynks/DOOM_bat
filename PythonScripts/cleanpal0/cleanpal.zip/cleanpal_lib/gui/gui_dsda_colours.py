"""DSDA Colours: the 14 DSDACR font colour ranges for dsda-doom / Nyan Doom.

A free window (like the Analyser): it never changes the palette. Each range
is a two-node true-colour gradient (start = the font's darkest pixels, end =
its brightest). The preview draws real font lumps through an exact copy of
the port's table building (cleanpal_lib_dsdacr) against the live WIP pal0.
The ranges live on the app (`app.dsdacr`), are saved in projects and have
their own undo here. Export DSDACR... writes all 14 rows.
"""

import os
import time

from ..cleanpal_lib_colour import hex_of, parse_colour
from ..cleanpal_lib_dsdacr import (
    BRIGHT_INDEX, CRBuilder, FONT_LABEL, FONTS, MESSAGES, NAMES, PORT_LABEL, REF_LUMP,
    SPACE_WIDTH, VARIANT_LABEL, decode_glyph, default_ranges, dsdacr_text, glyph_names,
    lightness, parse_dsdacr, picture_posts, png_translation,
)
from .gui_tool_windows import focus_on_click

TOGGLE_ON = "#c9a0ff"
MARK_COLOUR = "#00e5ff"
BACKGROUNDS = (("Dark", (40, 40, 40)), ("Black", (0, 0, 0)), ("Mid grey", (96, 96, 96)),
               ("Light", (200, 200, 200)))
BG = dict(BACKGROUNDS)


class DsdaColoursWin:
    POS_KEY = "dsda_pos"

    def __init__(self, app):
        tk = app.tk
        from tkinter import ttk

        self.app = app
        self.ui = ui = getattr(app, "ui", 1.0)
        s = app.s
        self.sel = s.get("dsda_sel") if isinstance(s.get("dsda_sel"), int) \
            and 0 <= s.get("dsda_sel") < 14 else 5
        self.node = 0                          # 0 = start, 1 = end
        self._undo, self._redo = [], []
        self._last_push = 0.0
        self._builder = None
        self._bkey = None
        self._maps = {}
        self._glyphs = {}
        self._arch = {}
        self._imgs = []
        self._pal_key = None
        self._marks = set()
        self._after = None

        win = self.win = tk.Toplevel(app.root)
        win.title("DSDA Colours - DSDACR font colour ranges")
        win.transient(app.root)
        win.protocol("WM_DELETE_WINDOW", self.close)
        win.bind("<Escape>", lambda e: self.close())
        for k in ("<Control-z>", "<Control-Z>"):
            win.bind(k, lambda e: self.undo())
        for k in ("<Control-y>", "<Control-Y>"):
            win.bind(k, lambda e: self.undo(redo=True))
        win.columnconfigure(0, weight=1)
        win.columnconfigure(1, weight=1)
        win.rowconfigure(1, weight=1)

        # ---------------- ranges list
        lf = ttk.LabelFrame(win, text="Colour ranges (click one to edit)", padding=6)
        lf.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 0))
        lf.columnconfigure(0, weight=1)
        self.row_h = int(18 * ui)
        self.list_cv = tk.Canvas(lf, height=self.row_h * 14 + 4, highlightthickness=0,
                                 bg="#2a2a2a", width=int(470 * ui))
        self.list_cv.grid(row=0, column=0, sticky="ew")
        self.list_cv.bind("<Configure>", lambda e: self.draw_list())
        self.list_cv.bind("<ButtonPress-1>", self._list_click)

        # ---------------- editor
        ef = self.edit_frame = ttk.LabelFrame(win, text="", padding=6)
        ef.grid(row=1, column=0, sticky="new", padx=8, pady=(8, 0))
        ef.columnconfigure(0, weight=1)
        tf = ttk.Frame(ef)
        tf.grid(row=0, column=0, sticky="ew")
        tf2 = ttk.Frame(ef)
        self.pal_on = bool(s.get("dsda_palettised", False))
        self.pal_btn = tk.Button(tf, text="Palettised", relief="raised",
                                 command=self.toggle_palettised)
        self.pal_btn.pack(side="left")
        self._btn_bg = self.pal_btn.cget("background")
        ttk.Button(tf, text="From selection", command=self.from_selection).pack(
            side="left", padx=(10, 0))
        ttk.Button(tf, text="Swap", command=self.swap).pack(side="left", padx=(6, 0))
        ttk.Button(tf, text="Reset", command=self.reset).pack(side="left", padx=(6, 0))
        tf2.grid(row=4, column=0, sticky="w", pady=(4, 0))
        ttk.Label(tf2, text="From selection: the darkest selected cell = start, the "
                            "lightest = end.\nClick near a node to edit it, double-click = "
                            "picker.", foreground="#888", justify="left").pack(side="left")
        self.bar = tk.Canvas(ef, height=int(46 * ui), highlightthickness=0, bg="#2a2a2a",
                             cursor="hand2")
        self.bar.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        self.bar.bind("<Configure>", lambda e: self.draw_bar())
        self.bar.bind("<ButtonPress-1>", self._bar_click)
        self.bar.bind("<Double-Button-1>", lambda e: (self._bar_click(e), self.picker()))
        self.bar.bind("<Motion>", self._bar_hover)
        self.bar.bind("<Leave>", lambda e: self.bar_info.set(""))
        nf = ttk.Frame(ef)
        nf.grid(row=2, column=0, sticky="ew", pady=(6, 0))
        self.node_var = tk.StringVar()
        ttk.Label(nf, textvariable=self.node_var, width=18).pack(side="left")
        self.node_sw = tk.Canvas(nf, width=int(44 * ui), height=int(22 * ui),
                                 highlightthickness=1, highlightbackground="#888",
                                 cursor="hand2")
        self.node_sw.pack(side="left")
        self.node_sw.bind("<Button-1>", lambda e: self.picker())
        self.hex_var = tk.StringVar()
        he = ttk.Entry(nf, textvariable=self.hex_var, width=9)
        he.pack(side="left", padx=(6, 0))
        he.bind("<Return>", lambda e: self._on_hex())
        he.bind("<FocusOut>", lambda e: self._on_hex())
        ttk.Button(nf, text="Picker...", command=self.picker).pack(side="left", padx=(6, 0))
        ttk.Button(nf, text="Eyedropper", command=self.eyedropper).pack(side="left",
                                                                         padx=(6, 0))
        self.bar_info = tk.StringVar()
        ttk.Label(ef, textvariable=self.bar_info, font=("Consolas", 9)).grid(
            row=3, column=0, sticky="w", pady=(4, 0))

        # ---------------- preview
        pf = ttk.LabelFrame(win, text="Preview", padding=6)
        pf.grid(row=0, column=1, rowspan=2, sticky="nsew", padx=(0, 8), pady=(8, 0))
        pf.columnconfigure(0, weight=1)
        pf.rowconfigure(5, weight=1)
        r1 = ttk.Frame(pf)
        r1.grid(row=0, column=0, sticky="ew")
        self.port_var = tk.StringVar(value=s.get("dsda_port") if s.get("dsda_port") in
                                     PORT_LABEL else "nyan")
        ttk.Label(r1, text="Port:").pack(side="left")
        for k in ("nyan", "dsda"):
            ttk.Radiobutton(r1, text=PORT_LABEL[k], value=k, variable=self.port_var,
                            command=self._opts).pack(side="left", padx=(4, 0))
        self.var_var = tk.StringVar(value=s.get("dsda_variant") if s.get("dsda_variant") in
                                    VARIANT_LABEL else "normal")
        ttk.Label(r1, text="   Text:").pack(side="left")
        for k in ("normal", "dark", "light"):
            ttk.Radiobutton(r1, text=VARIANT_LABEL[k], value=k, variable=self.var_var,
                            command=self._opts).pack(side="left", padx=(4, 0))
        r2 = ttk.Frame(pf)
        r2.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.view_var = tk.StringVar(value="one" if s.get("dsda_view") == "one" else "all")
        ttk.Label(r2, text="Show:").pack(side="left")
        for k, t in (("all", "All ranges"), ("one", "This range")):
            ttk.Radiobutton(r2, text=t, value=k, variable=self.view_var,
                            command=self._opts).pack(side="left", padx=(4, 0))
        ttk.Label(r2, text="   Font:").pack(side="left")
        fk = s.get("dsda_font") if s.get("dsda_font") in FONT_LABEL else "stcfn"
        self.font_var = tk.StringVar(value=FONT_LABEL[fk])
        cb = ttk.Combobox(r2, textvariable=self.font_var, state="readonly", width=30,
                          values=[lbl for _k, lbl, _x in FONTS])
        cb.pack(side="left", padx=(4, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self._opts())
        r3 = ttk.Frame(pf)
        r3.grid(row=2, column=0, sticky="ew", pady=(4, 0))
        self.shadow_var = tk.BooleanVar(value=bool(s.get("dsda_shadow", True)))
        self.shadow_chk = ttk.Checkbutton(r3, text="Nyan text shadow", variable=self.shadow_var,
                                          command=self._opts)
        self.shadow_chk.pack(side="left")
        ttk.Label(r3, text="   Background:").pack(side="left")
        self.bg_var = tk.StringVar(value=s.get("dsda_bg") if s.get("dsda_bg") in BG
                                   else "Dark")
        bcb = ttk.Combobox(r3, textvariable=self.bg_var, state="readonly", width=10,
                           values=[k for k, _c in BACKGROUNDS])
        bcb.pack(side="left", padx=(4, 0))
        bcb.bind("<<ComboboxSelected>>", lambda e: self._opts())
        ttk.Label(r3, text="   Zoom:").pack(side="left")
        z = s.get("dsda_zoom")
        self.zoom_var = tk.StringVar(value=str(z if isinstance(z, int) and 1 <= z <= 8 else 2))
        zs = ttk.Spinbox(r3, from_=1, to=8, width=3, textvariable=self.zoom_var,
                         command=self._opts, state="readonly")
        zs.pack(side="left", padx=(4, 0))
        self.marks_var = tk.BooleanVar(value=bool(s.get("dsda_marks", True)))
        ttk.Checkbutton(r3, text="Mark used cells", variable=self.marks_var,
                        command=self._opts).pack(side="left", padx=(12, 0))
        r4 = ttk.Frame(pf)
        r4.grid(row=3, column=0, sticky="ew", pady=(4, 0))
        ttk.Button(r4, text="▲", width=3, command=lambda: self.step_msg(-1)).pack(side="left")
        ttk.Button(r4, text="▼", width=3, command=lambda: self.step_msg(1)).pack(
            side="left", padx=(2, 0))
        mi = s.get("dsda_msg")
        self.msg_i = mi if isinstance(mi, int) and 0 <= mi < len(MESSAGES) else 0
        txt = s.get("dsda_text")
        self.text_var = tk.StringVar(value=txt if isinstance(txt, str) and txt
                                     else MESSAGES[self.msg_i])
        te = ttk.Entry(r4, textvariable=self.text_var)
        te.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.text_var.trace_add("write", lambda *a: self._soon())
        r5 = ttk.Frame(pf)
        r5.grid(row=4, column=0, sticky="ew", pady=(4, 0))
        self.src_var = tk.StringVar()
        ttk.Label(r5, textvariable=self.src_var, foreground="#666").pack(side="left")
        ttk.Button(r5, text="Port WAD...", command=lambda: self.load_wad("dsda_portwad")).pack(
            side="right")
        ttk.Button(r5, text="PWAD...", command=lambda: self.load_wad("dsda_pwad")).pack(
            side="right", padx=(0, 6))
        ttk.Button(r5, text="Clear WADs", command=self.clear_wads).pack(side="right",
                                                                         padx=(0, 6))
        cv_f = ttk.Frame(pf)
        cv_f.grid(row=5, column=0, sticky="nsew", pady=(6, 0))
        cv_f.columnconfigure(0, weight=1)
        cv_f.rowconfigure(0, weight=1)
        self.pv = tk.Canvas(cv_f, height=int(200 * ui), width=int(520 * ui),
                            highlightthickness=0, bg="#1e1e1e")
        self.pv.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(cv_f, orient="vertical", command=self.pv.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.pv.configure(yscrollcommand=sb.set)
        self.pv.bind("<MouseWheel>", lambda e: self.pv.yview_scroll(
            -1 if e.delta > 0 else 1, "units"))
        self.pv.bind("<Configure>", lambda e: self._soon())
        self.note_var = tk.StringVar()
        self.note_lbl = ttk.Label(pf, textvariable=self.note_var, foreground="#666",
                                  justify="left", wraplength=int(520 * ui))
        self.note_lbl.grid(row=6, column=0, sticky="w", pady=(4, 0))
        pf.bind("<Configure>", lambda e: self.note_lbl.configure(
            wraplength=max(100, e.width - int(16 * ui))))

        # ---------------- bottom
        bf = ttk.Frame(win, padding=8)
        bf.grid(row=2, column=0, columnspan=2, sticky="ew")
        ttk.Button(bf, text="Load DSDACR...", command=self.load_dsdacr).pack(side="left")
        ttk.Button(bf, text="Export DSDACR...", command=self.export).pack(side="left",
                                                                         padx=(6, 0))
        self.undo_btn = ttk.Button(bf, text="Undo", command=self.undo)
        self.undo_btn.pack(side="left", padx=(12, 0))
        self.redo_btn = ttk.Button(bf, text="Redo", command=lambda: self.undo(redo=True))
        self.redo_btn.pack(side="left", padx=(6, 0))
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")
        focus_on_click(win)
        self._pal_ui()
        self._place()
        self.refresh(force=True)

    # ---------------------------------------------------------- window bits
    def _place(self):
        a = self.app
        self.win.update_idletasks()
        pos = a.s.get(self.POS_KEY)
        if isinstance(pos, str) and pos.startswith("+"):
            try:
                self.win.geometry(pos)
                return
            except a.tk.TclError:
                pass
        r = a.root
        self.win.geometry("+%d+%d" % (r.winfo_rootx() + 60, r.winfo_rooty() + 40))

    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def close(self):
        a = self.app
        try:
            a.s[self.POS_KEY] = "+%d+%d" % (self.win.winfo_x(), self.win.winfo_y())
        except a.tk.TclError:
            pass
        p = a.picker
        if p is not None and getattr(p, "owner", None) is self:
            p.set_target(None, p.rgb(), None, "")
            p.owner = None
        if self._after is not None:
            try:
                self.win.after_cancel(self._after)
            except a.tk.TclError:
                pass
        a.dsda_win = None
        try:
            self.win.destroy()
        except a.tk.TclError:
            pass
        a.redraw()
        if hasattr(a, "_refresh_win_btns"):
            a._refresh_win_btns()

    # ---------------------------------------------------------- state
    @property
    def ranges(self):
        return self.app.dsdacr

    def rng(self, k=None):
        return self.app.dsdacr[self.sel if k is None else k]

    def _push(self, coalesce=False):
        now = time.time()
        if coalesce and self._undo and now - self._last_push < 0.6:
            self._last_push = now
            return
        self._undo.append([tuple(r) for r in self.app.dsdacr])
        del self._undo[:-200]
        self._redo = []
        self._last_push = now if coalesce else 0.0

    def _set(self, k, rng, coalesce=False, push=True):
        rng = (tuple(rng[0]), tuple(rng[1]))
        if self.app.dsdacr[k] == rng:
            return
        if push:
            self._push(coalesce)
        new = list(self.app.dsdacr)
        new[k] = rng
        self.app.dsdacr = new
        self.changed()

    def undo(self, redo=False):
        src, dst = (self._redo, self._undo) if redo else (self._undo, self._redo)
        if not src:
            self.app.status_var.set("DSDA Colours: nothing to %s." % ("redo" if redo else "undo"))
            return "break"
        dst.append([tuple(r) for r in self.app.dsdacr])
        self.app.dsdacr = src.pop()
        self._last_push = 0.0
        self.changed()
        return "break"

    def changed(self):
        self._sync_picker()
        self.refresh()

    def _opts(self):
        s = self.app.s
        s["dsda_port"] = self.port_var.get()
        s["dsda_variant"] = self.var_var.get()
        s["dsda_view"] = self.view_var.get()
        s["dsda_font"] = self._font_key()
        s["dsda_shadow"] = bool(self.shadow_var.get())
        s["dsda_bg"] = self.bg_var.get()
        try:
            s["dsda_zoom"] = max(1, min(8, int(self.zoom_var.get())))
        except ValueError:
            pass
        s["dsda_marks"] = bool(self.marks_var.get())
        self.refresh()

    def _font_key(self):
        lbl = self.font_var.get()
        return next((k for k, l2, _x in FONTS if l2 == lbl), "stcfn")

    # ---------------------------------------------------------- sources / fonts
    def _sources(self):
        """[(label, WadArchive)] in lookup order: PWAD, port WAD, IWAD."""
        from ..cleanpal_lib_wadgfx import WadArchive

        out = []
        for key, lbl in (("dsda_pwad", "PWAD"), ("dsda_portwad", "Port WAD")):
            p = self.app.s.get(key)
            if not (isinstance(p, str) and os.path.isfile(p)):
                continue
            try:
                k = (p, os.path.getmtime(p))
            except OSError:
                continue
            arch = self._arch.get(key)
            if arch is None or arch[0] != k:
                try:
                    arch = (k, WadArchive(p))
                except (OSError, ValueError):
                    arch = (k, None)
                self._arch[key] = arch
            if arch[1] is not None:
                out.append((lbl, arch[1]))
        iw = self.app.iwad_archive()
        if iw is not None:
            out.append(("IWAD", iw))
        return out

    def _src_key(self):
        return tuple((lbl, a.path) for lbl, a in self._sources())

    def _lump(self, name):
        for _lbl, arch in self._sources():
            d = arch.lump(name)
            if d is not None:
                return d
        return None

    def glyph(self, name):
        key = (self._src_key(), name)
        if key not in self._glyphs:
            self._glyphs[key] = decode_glyph(self._lump(name))
        return self._glyphs[key]

    def load_wad(self, key):
        from tkinter import filedialog

        cur = self.app.s.get(key)
        p = filedialog.askopenfilename(
            parent=self.win, title="Choose the %s" % (
                "port WAD (dsda-doom.wad / nyan-doom.wad - DIG font)" if key == "dsda_portwad"
                else "PWAD (its fonts / DSDACR override the others)"),
            initialdir=os.path.dirname(cur) if isinstance(cur, str) and cur else None,
            filetypes=[("WAD", "*.wad *.pk3"), ("All files", "*.*")])
        if not p:
            return
        self.app.s[key] = os.path.abspath(p)
        self._glyphs = {}
        self._bkey = None
        self.refresh()

    def clear_wads(self):
        self.app.s.pop("dsda_pwad", None)
        self.app.s.pop("dsda_portwad", None)
        self._glyphs = {}
        self._bkey = None
        self.refresh()

    def _png_map(self, g):
        """Nyan loads paletted PNG lumps by colour: entries that differ from
        the loaded PLAYPAL are re-matched (r_png.c). dsda-doom has no PNG
        loader, so its preview keeps the stored indices."""
        if g is None or g[5] is None or self.port_var.get() != "nyan":
            return None
        pal = self._pal()
        key = (id(g), hash(tuple(pal)))
        cache = self.__dict__.setdefault("_pngmaps", {})
        if key not in cache:
            if len(cache) > 400:
                cache.clear()
            cache[key] = png_translation(g[5], pal)
        return cache[key]

    def _ref_indices(self):
        d = self._lump(REF_LUMP)
        if d is None:
            return None
        idx = picture_posts(d) if d[:4] != b"\x89PNG" else None
        if idx is None:
            g = self.glyph(REF_LUMP)
            if g is None:
                return None
            tm = self._png_map(g) or {}
            idx = [tm.get(p[2], p[2]) for p in g[4]]
        return idx

    # ---------------------------------------------------------- tables
    def _pal(self):
        pal = self.app.pal or []
        return [tuple(c) if c is not None else (0, 0, 0) for c in pal[:256]] + \
            [(0, 0, 0)] * max(0, 256 - len(pal))

    def _png_any(self):
        """Port + whether the reference letter is a PNG (its re-match
        depends on the palette, already in the builder key)."""
        return self.port_var.get()

    def builder(self):
        pal = self._pal()
        port = self.port_var.get()
        key = (hash(tuple(pal)), self._src_key(), port, self._png_any())
        if key != self._bkey or self._builder is None:
            self._builder = CRBuilder(pal, self._ref_indices(), port)
            self._bkey = key
            self._maps = {}
        return self._builder

    def _row15(self):
        try:
            res, _f = self.app.cmap_result()
            return list(res.rows[15]) if res is not None else None
        except Exception:
            return None

    def mapping(self, k, variant):
        """Index -> index function for range k (0 = Default, 1-14)."""
        b = self.builder()
        key = (k, variant, self.app.dsdacr[k - 1] if k else None)
        m = self._maps.get(key)
        if m is None:
            m = self._maps[key] = {}
        if k == 0:
            row15 = self._row15() if variant == "dark" else None

            def f(i):
                v = m.get(i)
                if v is None:
                    v = m[i] = b.default_entry(i, variant, row15)
                return v
            return f
        rng = self.app.dsdacr[k - 1]

        def g(i):
            v = m.get(i)
            if v is None:
                v = m[i] = b.entry(rng, i, variant)
            return v
        return g

    # ---------------------------------------------------------- refresh
    def palette_changed(self):
        key = hash(tuple(self._pal()))
        if key != self._pal_key:
            self._pal_key = key
            self.refresh()

    def _soon(self):
        if self._after is not None:
            try:
                self.win.after_cancel(self._after)
            except self.app.tk.TclError:
                pass
        self._after = self.win.after(60, self._later)

    def _later(self):
        self._after = None
        self.app.s["dsda_text"] = self.text_var.get()
        self.draw_preview()
        self.app.redraw()

    def refresh(self, force=False):
        self._pal_key = hash(tuple(self._pal()))
        self.app.s["dsda_sel"] = self.sel
        k = self.sel
        self.edit_frame.configure(text="Editing %d  %s" % (k + 1, NAMES[k]))
        nn = ("Start (dark end)", "End (bright end)")[self.node]
        self.node_var.set(nn)
        c = self.rng()[self.node]
        self.node_sw.configure(background=hex_of(c))
        self.hex_var.set(hex_of(c).lstrip("#"))
        try:
            self.shadow_chk.state(["!disabled"] if self.port_var.get() == "nyan"
                                  else ["disabled"])
            self.undo_btn.state(["!disabled"] if self._undo else ["disabled"])
            self.redo_btn.state(["!disabled"] if self._redo else ["disabled"])
        except self.app.tk.TclError:
            pass
        self._sources_text()
        self.draw_list()
        self.draw_bar()
        self.draw_preview()
        self.app.redraw()

    def _sources_text(self):
        parts = []
        for lbl, arch in self._sources():
            parts.append("%s: %s" % (lbl, os.path.basename(arch.path)))
        self.src_var.set("Fonts from  " + ("  >  ".join(parts) if parts else
                                           "no WADs (set the IWAD in the top bar)"))

    # ---------------------------------------------------------- list
    def draw_list(self):
        cv = self.list_cv
        cv.delete("all")
        w = max(cv.winfo_width(), int(400 * self.ui))
        rh = self.row_h
        ui = self.ui
        name_w = int(130 * ui)
        sw = int(26 * ui)
        x_strip = name_w + 2 * sw + int(16 * ui)
        n = 32
        b = self.builder() if self.pal_on else None
        for k in range(14):
            y = 2 + k * rh
            a, e = self.app.dsdacr[k]
            if k == self.sel:
                cv.create_rectangle(0, y, w, y + rh - 1, fill="#3d3550", outline="")
            cv.create_text(int(6 * ui), y + rh / 2, anchor="w", fill="#e0e0e0",
                           text="%2d  %s" % (k + 1, NAMES[k]), font=("Consolas", 9))
            for j, c in enumerate((a, e)):
                x0 = name_w + j * (sw + int(4 * ui))
                cv.create_rectangle(x0, y + 2, x0 + sw, y + rh - 3, fill=hex_of(c),
                                    outline="#888")
            sx1 = w - int(6 * ui)
            step = (sx1 - x_strip) / float(n)
            if b is not None:
                pal = self._pal()
                cols = [pal[i] for _t, i in b.strip((a, e), n)]
            else:
                cols = [CRBuilder.target((a, e), t / float(n - 1)) for t in range(n)]
            for t, c in enumerate(cols):
                x0 = x_strip + t * step
                cv.create_rectangle(x0, y + 3, x0 + step + 1, y + rh - 4, fill=hex_of(c),
                                    outline="")

    def _list_click(self, e):
        k = int((e.y - 2) // self.row_h)
        if 0 <= k < 14 and k != self.sel:
            self.sel = k
            self._sync_picker()
            self.refresh()

    # ---------------------------------------------------------- bar
    def _bar_geo(self):
        w = max(self.bar.winfo_width(), int(300 * self.ui))
        pad = int(14 * self.ui)
        h = max(self.bar.winfo_height(), int(46 * self.ui))
        return pad, w - pad, int(4 * self.ui), int(h * 0.55), h

    def draw_bar(self):
        from PIL import Image, ImageTk

        cv = self.bar
        cv.delete("all")
        x0, x1, y0, y1, h = self._bar_geo()
        bw = max(2, int(x1 - x0))
        rng = self.rng()
        if self.pal_on:
            b = self.builder()
            n = min(bw, 96)
            cols = [self._pal()[i] for _t, i in b.strip(rng, n)]
        else:
            n = min(bw, 256)
            cols = [CRBuilder.target(rng, t / float(n - 1)) for t in range(n)]
        im = Image.new("RGB", (n, 1))
        im.putdata([tuple(c) for c in cols])
        im = im.resize((bw, max(2, y1 - y0)), Image.NEAREST)
        self._bar_img = ImageTk.PhotoImage(im)
        cv.create_image(x0, y0, anchor="nw", image=self._bar_img)
        cv.create_rectangle(x0 - 1, y0 - 1, x0 + bw, y1, outline="#888")
        from .gui_gradslider import draw_node
        s = int(9 * self.ui)
        for j, x in enumerate((x0, x0 + bw - 1)):
            pts = (x, y1 + 2, x - s, y1 + 2 + s * 1.6, x + s, y1 + 2 + s * 1.6)
            draw_node(cv, pts, hex_of(rng[j]), j == self.node, self.ui)

    def _bar_click(self, e):
        x0, x1, _y0, _y1, _h = self._bar_geo()
        j = 0 if e.x < (x0 + x1) / 2.0 else 1
        if j != self.node:
            self.node = j
            self._sync_picker()
            self.refresh()

    def _bar_hover(self, e):
        x0, x1, _y0, _y1, _h = self._bar_geo()
        t = max(0.0, min(1.0, (e.x - x0) / float(max(1, x1 - x0))))
        rng = self.rng()
        tc = CRBuilder.target(rng, t)
        b = self.builder()
        i = b.match(tc)
        c = self._pal()[i]
        self.bar_info.set("%3d%%  target %s  ->  pal0 %d %s" % (
            round(t * 100), hex_of(tc), i, hex_of(c)))

    def toggle_palettised(self):
        self.pal_on = not self.pal_on
        self.app.s["dsda_palettised"] = self.pal_on
        self._pal_ui()
        self.draw_list()
        self.draw_bar()

    def _pal_ui(self):
        on = self.pal_on
        self.pal_btn.configure(relief="sunken" if on else "raised",
                               background=TOGGLE_ON if on else self._btn_bg,
                               activebackground=TOGGLE_ON if on else self._btn_bg)

    # ---------------------------------------------------------- node colour
    def set_node_colour(self, rgb, coalesce=False):
        rgb = tuple(int(v) for v in rgb)
        r = list(self.rng())
        r[self.node] = rgb
        self._set(self.sel, r, coalesce=coalesce)

    def _on_hex(self):
        c = parse_colour(self.hex_var.get())
        if c is None:
            self.hex_var.set(hex_of(self.rng()[self.node]).lstrip("#"))
            return
        if tuple(c) != tuple(self.rng()[self.node]):
            self.set_node_colour(c)

    def picker(self):
        p = self.app.open_picker()
        p.owner = self
        self._picker_target = (self.sel, self.node)
        k, j = self._picker_target

        def cb(rgb, hsl, k=k, j=j):
            if self.app.dsda_win is not self:
                return
            r = list(self.app.dsdacr[k])
            r[j] = tuple(rgb)
            self._set(k, r, coalesce=True)
        p.set_target(cb, tuple(self.rng()[self.node]), None,
                     "DSDACR %d %s %s" % (self.sel + 1, NAMES[self.sel],
                                          ("start", "end")[self.node]))

    def _sync_picker(self):
        """An open picker owned by this window follows the selected node."""
        p = self.app.picker
        if p is not None and getattr(p, "owner", None) is self and \
                getattr(self, "_picker_target", None) != (self.sel, self.node):
            self.picker()

    def eyedropper(self):
        from .gui_picker import EyeDropper
        EyeDropper(self.app, lambda rgb: self.set_node_colour(rgb))

    def from_selection(self):
        a = self.app
        cols = [tuple(a.rgbs[i]) for i in sorted(a.selection)
                if a.rgbs and i < len(a.rgbs) and a.rgbs[i] is not None]
        if not cols:
            a.status_var.set("DSDA Colours: select palette cells first (any cells, joined "
                             "up or not).")
            return
        dark = min(cols, key=lightness)
        light = max(cols, key=lightness)
        self._set(self.sel, (dark, light))
        a.status_var.set("DSDA Colours: %s = %s -> %s (darkest / lightest of %d selected)."
                         % (NAMES[self.sel], hex_of(dark), hex_of(light), len(cols)))

    def swap(self):
        a, e = self.rng()
        self._set(self.sel, (e, a))

    def reset(self):
        self._set(self.sel, default_ranges()[self.sel])

    # ---------------------------------------------------------- load / export
    def load_dsdacr(self):
        from tkinter import filedialog, messagebox

        from ..cleanpal_lib_wadgfx import WadArchive

        p = filedialog.askopenfilename(
            parent=self.win, title="Load DSDACR (text file, or a WAD with a DSDACR lump)",
            initialdir=self.app.s.get("dsda_dir") or None,
            filetypes=[("DSDACR / WAD", "*.txt *.lmp *.wad"), ("All files", "*.*")])
        if not p:
            return
        self.app.s["dsda_dir"] = os.path.dirname(p)
        try:
            with open(p, "rb") as fh:
                raw = fh.read()
            if raw[:4] in (b"IWAD", b"PWAD"):
                raw = WadArchive(p).lump("DSDACR")
                if raw is None:
                    raise ValueError("That WAD has no DSDACR lump.")
            ranges, header, seen = parse_dsdacr(raw.decode("latin-1"))
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not load DSDACR:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        self._push()
        self.app.dsdacr = ranges
        self.changed()
        miss = 14 - len(set(seen))
        self.app.status_var.set("DSDA Colours: loaded %s (%d range line(s)%s)." % (
            os.path.basename(p), len(seen),
            ("; %d not in the file kept dsda's defaults" % miss) if miss else ""))

    def export(self):
        from tkinter import filedialog, messagebox

        p = filedialog.asksaveasfilename(
            parent=self.win, title="Export DSDACR", initialfile="dsdacr.txt",
            initialdir=self.app.s.get("dsda_dir") or self.app.s.get("last_dir") or None,
            defaultextension=".txt",
            filetypes=[("Text", "*.txt"), ("Lump", "*.lmp"), ("All files", "*.*")])
        if not p:
            return
        try:
            with open(p, "w", encoding="ascii", newline="\n") as fh:
                fh.write(dsdacr_text(self.app.dsdacr))
        except OSError as e:
            messagebox.showerror("cleanpal", "Could not write:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        self.app.s["dsda_dir"] = os.path.dirname(p)
        self.app.status_var.set("DSDA Colours: wrote all 14 ranges to %s (import it as the "
                                "DSDACR lump)." % p)

    # ---------------------------------------------------------- preview
    def step_msg(self, d):
        self.msg_i = (self.msg_i + d) % len(MESSAGES)
        self.app.s["dsda_msg"] = self.msg_i
        self.text_var.set(MESSAGES[self.msg_i])

    def _layout(self, text, font):
        """[(x, y, index)] pixels of the text (offsets applied), width, height
        or None when the font has no lumps at all."""
        x = 0
        pts = []
        found = False
        sp = SPACE_WIDTH.get(font, 4)
        for ch in text:
            if ch == " ":
                x += sp
                continue
            g = None
            for nm in glyph_names(font, ch):
                g = self.glyph(nm)
                if g is not None:
                    break
            if g is None:
                x += sp
                continue
            found = True
            w, _h, lo, to, gp, _pp = g
            tm = self._png_map(g)
            if tm:
                self._png_hit = True
            for gx, gy, i in gp:
                pts.append((x + gx - lo, gy - to, tm.get(i, i) if tm else i))
            x += w
        if not found:
            return None
        if not pts:
            return [], x, 1
        miny = min(p[1] for p in pts)
        minx = min(0, min(p[0] for p in pts))
        pts = [(px - minx, py - miny, i) for px, py, i in pts]
        return pts, max(x - minx, max(p[0] for p in pts) + 1), max(p[1] for p in pts) + 1

    def render(self, lay, fn, shadow):
        from PIL import Image

        pts, w, h = lay
        bg = BG.get(self.bg_var.get(), (40, 40, 40))
        im = Image.new("RGB", (w + 3, h + 3), bg)
        px = im.load()
        pal = self._pal()
        if shadow is not None:
            for x, y, _i in pts:
                c = px[x + 2, y + 2]
                px[x + 2, y + 2] = tuple((c[n] + shadow[n]) // 2 for n in range(3))
        for x, y, i in pts:
            px[x + 1, y + 1] = pal[fn(i)]
        return im

    def draw_preview(self):
        from PIL import Image, ImageTk

        cv = self.pv
        cv.delete("all")
        self._imgs = []
        ui = self.ui
        font = self._font_key()
        text = self.text_var.get() or " "
        self._png_hit = False
        lay = self._layout(text, font)
        variant = self.var_var.get()
        port = self.port_var.get()
        pal = self._pal()
        notes = []
        if lay is None:
            need = {"dig": "Load the port WAD (dsda-doom.wad / nyan-doom.wad) - the DIG font "
                           "lives there."}.get(font, "None of these font lumps were found - "
                                                     "set the IWAD in the top bar.")
            cv.create_text(int(10 * ui), int(10 * ui), anchor="nw", fill="#ff8080",
                           text=need, font=("Segoe UI", 9))
            self._marks = set()
            self.note_var.set("")
            return
        b = self.builder()
        shadow = None
        if port == "nyan" and self.shadow_var.get():
            shadow = pal[0]
        try:
            z = max(1, min(8, int(self.zoom_var.get())))
        except ValueError:
            z = 2
        z = max(1, int(round(z * ui)))          # zoom is per 100% display scale
        rows = list(range(1, 15)) if self.view_var.get() == "all" else [self.sel + 1]
        if self.view_var.get() == "all":
            rows = [0] + rows
        y = int(6 * ui)
        lab_w = int(130 * ui)
        used = set(i for _x, _y, i in lay[0])
        marks = set()
        for k in rows:
            fn = self.mapping(k, variant)
            im = self.render(lay, fn, shadow)
            im = im.resize((im.width * z, im.height * z), Image.NEAREST)
            ph = ImageTk.PhotoImage(im)
            self._imgs.append(ph)
            name = "Default" if k == 0 else NAMES[k - 1]
            col = "#ffe08a" if k == self.sel + 1 else "#d0d0d0"
            cv.create_text(int(6 * ui), y + im.height / 2, anchor="w", fill=col,
                           text="%2d  %s" % (k, name), font=("Consolas", 9))
            cv.create_image(lab_w, y, anchor="nw", image=ph)
            if k == self.sel + 1:
                marks = {fn(i) for i in used}
            y += im.height + int(6 * ui)
        cv.configure(scrollregion=(0, 0, max(cv.winfo_width(), lab_w + 10), y))
        self._marks = marks if self.marks_var.get() else set()
        # notes
        if b.flat:
            notes.append("Reference letter %s is one colour - Nyan uses the full 0..1 range "
                         "(dsda would divide by zero)." % REF_LUMP)
        if self._ref_indices() is None:
            notes.append("No %s found - brightness uses the full 0..1 range." % REF_LUMP)
        if port == "nyan":
            c0 = pal[0]
            dk = min(range(256), key=lambda i: (lightness(pal[i]), i))
            warn = "" if lightness(c0) < 6 else "  <- not near black: shadows show in this colour!"
            notes.append("Nyan text shadow = index 0 %s%s  (Nyan means the darkest cell, "
                         "index %d %s, but a start-up bug always uses 0)" % (
                             hex_of(c0), warn, dk, hex_of(pal[dk])))
        if BRIGHT_INDEX in used:
            notes.append("This text uses index 176: always drawn with the range's end colour.")
        if pal[BRIGHT_INDEX] != (255, 0, 0):
            notes.append("Index 176 is %s, not #FF0000: Nyan loads its PNG HUD font (DIG) by "
                         "colour, so the letters' red goes to another index, loses the "
                         "176 rule and comes out dark. Put #FF0000 back in 176 (Lock -> "
                         "Restore originals -> Red 176)." % hex_of(pal[BRIGHT_INDEX]))
        if getattr(self, "_png_hit", False):
            notes.append("Some of these font lumps are PNGs - re-matched by colour into "
                         "your palette, as Nyan does.")
        if variant != "normal" and port == "dsda":
            notes.append({"dark": "dsda Disabled: range targets halved; Default = COLORMAP "
                                  "row 15.",
                          "light": "dsda Highlighted: the normal result brightened x1.4 "
                                   "(Default = its own colour)."}[variant])
        elif variant != "normal":
            notes.append({"dark": "Nyan Disabled: range targets x0.5; Default = COLORMAP "
                                  "row 15.",
                          "light": "Nyan Highlighted: range targets x1.4 (Default = its own "
                                   "colour x1.4)."}[variant])
        self.note_var.set("\n".join(notes))

    def marked_cells(self):
        """Palette indices the selected range uses for the current text."""
        return self._marks
