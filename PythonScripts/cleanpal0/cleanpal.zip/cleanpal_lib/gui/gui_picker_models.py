"""Colour models for the picker: channel values <-> RGB, and the square /
strip images used by the HSL Box, Photoshop and slider modes.

Every model is a list of channels (name, low, high, step). Values are kept
in the units shown to the user (H 0-360, S 0-100, Lab a/b -128..127 ...).
from_vals() returns (rgb floats 0..255 clipped, in_gamut)."""

import math

from ..cleanpal_lib_colour import hsl_to_rgb, oklab, rgb_to_hsl, srgb_to_lab

# space -> ((name, low, high), ...)
SPACES = {
    "hsl": (("H", 0.0, 360.0), ("S", 0.0, 100.0), ("L", 0.0, 100.0)),
    "hsb": (("H", 0.0, 360.0), ("S", 0.0, 100.0), ("B", 0.0, 100.0)),
    "rgb": (("R", 0.0, 255.0), ("G", 0.0, 255.0), ("B", 0.0, 255.0)),
    "lab": (("L", 0.0, 100.0), ("a", -128.0, 127.0), ("b", -128.0, 127.0)),
    "oklch": (("L", 0.0, 100.0), ("C", 0.0, 37.0), ("H", 0.0, 360.0)),
    "grey": (("V", 0.0, 255.0),),
}
HUE_CH = {"hsl": 0, "hsb": 0, "oklch": 2}      # wrapping hue channel per space


def channels(space):
    return SPACES[space]


def clamp_val(space, i, v):
    _n, lo, hi = SPACES[space][i]
    if HUE_CH.get(space) == i:
        return v % 360.0 if v != 360.0 else 360.0
    return min(max(v, lo), hi)


# ------------------------------------------------------------ conversions
def _hsv_to_rgb(h, s, v):
    s, v = s / 100.0, v / 100.0
    h = (h % 360.0) / 60.0
    i = int(h) % 6
    f = h - int(h)
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    r, g, b = ((v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q))[i]
    return r * 255.0, g * 255.0, b * 255.0


def _rgb_to_hsv(r, g, b):
    r, g, b = r / 255.0, g / 255.0, b / 255.0
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    if d <= 1e-12:
        h = 0.0
    elif mx == r:
        h = ((g - b) / d) % 6
    elif mx == g:
        h = (b - r) / d + 2
    else:
        h = (r - g) / d + 4
    return h * 60.0, (d / mx * 100.0 if mx > 1e-12 else 0.0), mx * 100.0


def _enc(c):
    c = c * 12.92 if c <= 0.0031308 else 1.055 * (max(c, 0.0) ** (1.0 / 2.4)) - 0.055
    return c * 255.0


def _lab_to_rgb(L, a, b):
    fy = (L + 16.0) / 116.0
    fx = fy + a / 500.0
    fz = fy - b / 200.0

    def finv(t):
        return t ** 3 if t > 0.206893 else (t - 16.0 / 116.0) / 7.787

    x, y, z = 0.95047 * finv(fx), finv(fy), 1.08883 * finv(fz)
    rl = 3.2404542 * x - 1.5371385 * y - 0.4985314 * z
    gl = -0.9692660 * x + 1.8760108 * y + 0.0415560 * z
    bl = 0.0556434 * x - 0.2040259 * y + 1.0572252 * z
    return _enc(rl), _enc(gl), _enc(bl)


def _oklch_raw(L, C, H):
    """OKLCH (display units) -> unclipped sRGB floats."""
    L, C, h = L / 100.0, C / 100.0, math.radians(H)
    a, b = C * math.cos(h), C * math.sin(h)
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    return _enc(r), _enc(g), _enc(bb)


def _ok(rgb, eps=0.6):
    return all(-eps <= v <= 255.0 + eps for v in rgb)


def _clip(rgb):
    return tuple(min(max(v, 0.0), 255.0) for v in rgb)


def from_vals(space, v):
    """Channel values -> (rgb floats clipped, in_gamut)."""
    if space == "hsl":
        return hsl_to_rgb(v[0], v[1], v[2]), True
    if space == "hsb":
        return _hsv_to_rgb(v[0], v[1], v[2]), True
    if space == "rgb":
        return _clip(v), True
    if space == "grey":
        return (v[0], v[0], v[0]), True
    if space == "lab":
        raw = _lab_to_rgb(*v)
        return _clip(raw), _ok(raw)
    raw = _oklch_raw(*v)
    if _ok(raw):
        return _clip(raw), True
    lo, hi = 0.0, 1.0                     # out of gamut: reduce chroma
    for _ in range(16):
        mid = (lo + hi) / 2.0
        if _ok(_oklch_raw(v[0], v[1] * mid, v[2])):
            lo = mid
        else:
            hi = mid
    return _clip(_oklch_raw(v[0], v[1] * lo, v[2])), False


def to_vals(space, rgbf, hue=0.0):
    """RGB floats -> channel values. hue = fallback for colours with none."""
    r, g, b = rgbf
    if space == "hsl":
        h, s, l = rgb_to_hsl(r, g, b)
        return [hue if max(rgbf) - min(rgbf) < 1e-9 else h, s, l]
    if space == "hsb":
        h, s, v = _rgb_to_hsv(r, g, b)
        return [hue if max(rgbf) - min(rgbf) < 1e-9 else h, s, v]
    if space == "rgb":
        return [r, g, b]
    if space == "grey":
        return [0.299 * r + 0.587 * g + 0.114 * b]
    if space == "lab":
        return list(srgb_to_lab(r, g, b))
    L, a, bb = oklab((r, g, b))
    C = math.hypot(a, bb)
    H = math.degrees(math.atan2(bb, a)) % 360.0 if C > 1e-4 else hue
    return [L * 100.0, C * 100.0, H]


def grey_luma(rgb):
    return 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]


# ------------------------------------------------------------ images
_CACHE = {}
_HATCH = {}


def _norm(space, i, t):
    _n, lo, hi = SPACES[space][i]
    return lo + t * (hi - lo)


def strip_image(space, i, vals, n=160):
    """1-pixel-high strip along channel i (others fixed). (RGB image, mask L)."""
    from PIL import Image

    key = ("strip", space, i, tuple(round(v, 2) for v in vals), n)
    if key in _CACHE:
        return _CACHE[key]
    if space == "hsl" and i == 0 or space == "hsb" and i == 0:
        f = (lambda t: from_vals(space, (t * 360.0, 100.0, 50.0 if space == "hsl" else 100.0)))
    else:
        def f(t):
            v = list(vals)
            v[i] = _norm(space, i, t)
            return from_vals(space, v)
    im = Image.new("RGB", (n, 1))
    mk = Image.new("L", (n, 1))
    px, pm = [], []
    for k in range(n):
        c, ok = f(k / (n - 1.0))
        px.append(tuple(int(round(x)) for x in c))
        pm.append(0 if ok else 255)
    im.putdata(px)
    mk.putdata(pm)
    out = (im, mk if any(pm) else None)
    if len(_CACHE) > 400:
        _CACHE.clear()
    _CACHE[key] = out
    return out


def plane_image(space, xi, yi, vals, res=80):
    """Square: channel xi left->right, channel yi bottom->top, the third
    channel fixed at vals. Returns (RGB image res x res, out-of-gamut mask)."""
    from PIL import Image

    fixed = [k for k in range(3) if k not in (xi, yi)][0]
    key = ("plane", space, xi, yi, round(vals[fixed], 2), res)
    if key in _CACHE:
        return _CACHE[key]
    im = Image.new("RGB", (res, res))
    mk = Image.new("L", (res, res))
    px, pm = [], []
    v = list(vals)
    for y in range(res):
        v[yi] = _norm(space, yi, 1.0 - y / (res - 1.0))
        for x in range(res):
            v[xi] = _norm(space, xi, x / (res - 1.0))
            c, ok = from_vals(space, v)
            px.append((int(c[0] + 0.5), int(c[1] + 0.5), int(c[2] + 0.5)))
            pm.append(0 if ok else 255)
    im.putdata(px)
    mk.putdata(pm)
    out = (im, mk if any(pm) else None)
    if len(_CACHE) > 400:
        _CACHE.clear()
    _CACHE[key] = out
    return out


def finish(img, mask, size, smooth=True):
    """Scale a strip / plane image to size and hatch any out-of-gamut parts."""
    from PIL import Image, ImageChops

    W, H = max(int(size[0]), 1), max(int(size[1]), 1)
    out = img.resize((W, H), Image.BILINEAR if smooth else Image.NEAREST)
    if mask is None:
        return out
    m = mask.resize((W, H), Image.BILINEAR).point(lambda p: 255 if p >= 128 else 0)
    hk = (W, H)
    if hk not in _HATCH:
        st = Image.new("L", (W, H))
        st.putdata([255 if ((x + y) // 3) % 3 == 0 else 0
                    for y in range(H) for x in range(W)])
        if len(_HATCH) > 16:
            _HATCH.clear()
        _HATCH[hk] = st
    dark = ImageChops.multiply(out, Image.new("RGB", (W, H), (110, 110, 110)))
    hatched = Image.composite(dark, out, _HATCH[hk])
    return Image.composite(hatched, out, m)
