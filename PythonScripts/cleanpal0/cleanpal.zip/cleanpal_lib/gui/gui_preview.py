"""Palettised preview window."""

import math
import os

from ..cleanpal_lib_lighting import SURFACES, WALL_ORIENTATIONS, flat_row, surface_row, wall_row
from ..cleanpal_lib_palette_io import _pil_const, palettise, palettise_p, relight
from ..cleanpal_lib_gfxfilters import (
    PLAYER_GREEN, PLAYER_RANGE, FilterEngine, item_name, player_mode,
)
from ..cleanpal_lib_wadgfx import KIND_LABEL, WadSource, index_from_png

SHOWPAL_TEXT = "Show on palette"
NONPAL_TEXT = "Non-paletted image"
NONPAL_BG = "#e07070"
TITLE = "cleanpal - Palettised preview"


# ============================================================ preview window
def _geometry_on_screen(geo):
    """True if a saved 'WxH+X+Y' geometry's title bar lands on a monitor
    that exists now (False when its monitor was unplugged)."""
    import re

    m = re.match(r"^\d+x\d+([+-]-?\d+)([+-]-?\d+)$", geo or "")
    if not m:
        return True                       # size only: the WM places it
    x = int(m.group(1).replace("+-", "-").lstrip("+"))
    y = int(m.group(2).replace("+-", "-").lstrip("+"))
    px, py = x + 60, y + 12               # a point on the title bar
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            fn = ctypes.windll.user32.MonitorFromPoint
            fn.restype = ctypes.c_void_p
            fn.argtypes = [wintypes.POINT, ctypes.c_uint]
            return bool(fn(wintypes.POINT(px, py), 0))      # 0 = DEFAULTTONULL
        except Exception:      # noqa: BLE001 - fall back to "fine"
            return True
    return px >= 0 and py >= 0


class PreviewWindow:
    PAD = 10
    ZOOM_STEP = 1.2
    GAP = 8                 # page pixels between grid cells
    MAX_CACHE = 400
    TYPES = ["All", "Patches", "Sprites", "Flats", "Graphics"]   # + TEXTURE1 / TEXTURE2
    FOLDER_TYPES = ["Loose"]

    def __init__(self, app):
        from tkinter import ttk

        tk = app.tk
        self.app = app
        self.win = tk.Toplevel(app.root)
        self.win.title(TITLE)
        ui0 = getattr(app, "ui", 1.0)
        self.win.minsize(int(480 * ui0), int(340 * ui0))
        geo = app.s.get("preview_geometry") or "%dx%d" % (int(900 * ui0), int(760 * ui0))
        if not _geometry_on_screen(geo):          # saved monitor gone: size only
            geo = geo.split("+")[0].split("-")[0]
        try:
            self.win.geometry(geo)
        except tk.TclError:
            pass
        self.pin_var = tk.BooleanVar(value=bool(app.s.get("preview_pin", True)))
        self.live_var = tk.StringVar(value="live" if app.s.get("preview_live", True)
                                     else "applied")
        self._apply_pin()
        self._render_ms = 0.0
        self._poll_after = None
        self.win.columnconfigure(0, weight=1)
        self.win.rowconfigure(2, weight=1)

        self.mode = None          # "folder" / "wad"
        self._switching = False   # True while a source switch sets the Name filter
        self.folder = None
        self.wad = None
        self.items = []
        self.view = []
        self.idx = 0
        self.orig_cache = {}
        self.idx_cache = {}       # item key -> index image (R = index) or None (true colour)
        self.pal_sel = None       # None = WIP, else (name, path) of a Palette Browser palette
        self._pal_list = []       # [(label, key)] last shown in the palette dropdown
        self._nonpal = False      # Show on palette button is in its red "no indices" state
        self.conv_cache = {}
        self.conv_cache_key = None
        self.errors = {}
        self.content = None
        self.content_key = None
        self.pick_boxes = []          # colour-pick boxes, in content pixels
        self.pick_item = None         # grid view: the view index the boxes belong to
        self._pick_drag = None
        self._pick_key = None
        self.cells = []           # grid: (view index, x, y, w, h) in page pixels
        self._used = 0
        self._native_checkers = {}
        self.view_scale = 1.0
        self.off_x = self.off_y = 0.0
        self.auto_fit = True
        self._pan = None
        self._after = None
        self._tkimg = None
        self._checker = (None, None)

        s = app.s
        self.view_var = tk.StringVar(value="pal")
        self.dither_var = tk.BooleanVar(value=bool(s.get("preview_dither", False)))
        self.type_var = tk.StringVar(value=s.get("preview_type", "All"))
        if self.type_var.get() not in self.TYPES + ["TEXTURE1", "TEXTURE2"]:
            self.type_var.set("All")
        self.filter_var = tk.StringVar(value=s.get("preview_filter", ""))
        self.layout_var = tk.StringVar(value=s.get("preview_layout", "single"))
        if self.layout_var.get() not in ("single", "grid"):
            self.layout_var.set("single")
        self.cols = self._clamp(s.get("preview_cols", 4))
        self.rows = self._clamp(s.get("preview_rows", 4))
        self.names_var = tk.BooleanVar(value=bool(s.get("preview_names", True)))
        self.cols_var = tk.StringVar(value=str(self.cols))
        self.rows_var = tk.StringVar(value=str(self.rows))
        self.name_var = tk.StringVar(value="Open a folder of PNGs or a WAD")
        self.light_on = tk.BooleanVar(value=bool(s.get("preview_light_on", False)))
        self.light_val = tk.IntVar(value=int(s.get("preview_light", 160)))
        self.dist_pos = tk.DoubleVar(value=float(s.get("preview_dist", 40.0)))
        self.surface_var = tk.StringVar(value=s.get("preview_surface", SURFACES[0]))
        if self.surface_var.get() not in SURFACES:
            self.surface_var.set(SURFACES[0])
        self.orient_var = tk.StringVar(value=s.get("preview_orient", WALL_ORIENTATIONS[0]))
        if self.orient_var.get() not in WALL_ORIENTATIONS:
            self.orient_var.set(WALL_ORIENTATIONS[0])
        self.corridor_var = tk.BooleanVar(value=bool(s.get("preview_corridor", False)))
        self.invul_var = tk.BooleanVar(value=False)
        self.compare_var = tk.BooleanVar(value=False)
        self._flip_cmp = False
        self.p_cache = {}
        self.p_cache_key = None
        self.lit_text = ""
        self.info_var = tk.StringVar(value="")
        self.hover_var = tk.StringVar(value="")

        # row 1: sources (line a) + navigation (line b)
        topw = ttk.Frame(self.win, padding=(8, 8, 8, 2))
        topw.grid(row=0, column=0, sticky="ew")
        top = ttk.Frame(topw)
        top.pack(fill="x")
        nav = ttk.Frame(topw)
        nav.pack(fill="x", pady=(4, 0))
        ttk.Button(top, text="Open folder...", command=self.open_folder_dialog).pack(side="left")
        ttk.Button(top, text="Open WAD...", command=self.open_wad_dialog).pack(
            side="left", padx=(6, 0))
        ttk.Button(top, text="\u25c0", width=3, command=lambda: self.step_source(-1)).pack(
            side="left", padx=(10, 0))
        self.src_var = tk.StringVar()
        self.src_cb = ttk.Combobox(top, textvariable=self.src_var, state="readonly", width=22)
        self.src_cb.pack(side="left", padx=(2, 0))
        self.src_cb.bind("<<ComboboxSelected>>",
                         lambda e: self.switch_source(self.src_cb.current()))
        ttk.Button(top, text="\u25b6", width=3, command=lambda: self.step_source(1)).pack(
            side="left", padx=(2, 0))
        ttk.Button(top, text="Close", command=self.close_source).pack(side="left",
                                                                      padx=(6, 0))
        ttk.Button(top, text="Close all", command=self.close_all_sources).pack(
            side="left", padx=(4, 0))
        self.showpal_var = tk.BooleanVar(value=bool(app.s.get("preview_show_pal", False)))
        ttk.Checkbutton(top, text="On top", variable=self.pin_var,
                        command=self._apply_pin).pack(side="right")
        ttk.Button(nav, text="Fit to window", command=self.fit).pack(side="left")
        ttk.Button(nav, text="\u25b2", width=3, command=lambda: self.step(-1)).pack(
            side="left", padx=(6, 0))
        ttk.Button(nav, text="\u25bc", width=3, command=lambda: self.step(1)).pack(
            side="left", padx=(2, 0))
        self.showpal_btn = tk.Checkbutton(
            nav, text=SHOWPAL_TEXT, indicatoron=False, variable=self.showpal_var,
            command=self._showpal_toggled, width=len(NONPAL_TEXT), padx=4)
        self.showpal_btn.pack(side="left", padx=(12, 0))
        self._showpal_bg = self.showpal_btn.cget("background")
        self._showpal_sel = self.showpal_btn.cget("selectcolor")
        ttk.Button(nav, text="Picked colours...", command=self.open_picked_btn).pack(
            side="left", padx=(4, 0))
        self.live_rbs = []
        for txt, val, px in (("Applied", "applied", 0), ("Live", "live", 4)):
            rb = ttk.Radiobutton(nav, text=txt, value=val, variable=self.live_var,
                                 command=self._live_changed)
            rb.pack(side="right", padx=(0, px))
            self.live_rbs.append(rb)
        ttk.Label(nav, textvariable=self.name_var).pack(side="left", padx=8)
        # palette to palettise with: WIP or any Palette Browser palette
        ttk.Button(nav, text="\u25c0", width=3, command=lambda: self.step_pal(-1)).pack(
            side="left", padx=(4, 0))
        self.palsel_var = tk.StringVar(value="WIP")
        self.palsel_cb = ttk.Combobox(nav, textvariable=self.palsel_var, state="readonly",
                                      width=15, postcommand=self._fill_pal_list)
        self.palsel_cb.pack(side="left", padx=(2, 0))
        self.palsel_cb.bind("<<ComboboxSelected>>",
                            lambda e: self.choose_pal(self.palsel_cb.current()))
        ttk.Button(nav, text="\u25b6", width=3, command=lambda: self.step_pal(1)).pack(
            side="left", padx=(2, 0))

        # row 2: filters, layout, view
        row2 = ttk.Frame(self.win, padding=(8, 2, 8, 4))
        row2.grid(row=1, column=0, sticky="ew")
        ttk.Label(row2, text="Type").pack(side="left")
        self.type_cb = ttk.Combobox(row2, textvariable=self.type_var, values=self.TYPES,
                                    state="readonly", width=10)
        self.type_cb.pack(side="left", padx=(4, 8))
        self.type_cb.bind("<<ComboboxSelected>>", lambda e: self.apply_filter())
        ttk.Label(row2, text="Name").pack(side="left")
        self.filter_entry = ttk.Entry(row2, textvariable=self.filter_var, width=11)
        self.filter_entry.pack(side="left", padx=(4, 6))
        self.filter_var.trace_add("write", lambda *a: self.apply_filter())
        self.filt_btn = ttk.Button(row2, text="Filters...", command=self.open_filters)
        self.filt_btn.pack(side="left", padx=(0, 4))
        ttk.Button(row2, text="Scene...", command=self.open_scene).pack(side="right",
                                                                       padx=(4, 0))
        ttk.Button(row2, text="Lost colours...", command=self.open_lost).pack(
            side="left", padx=(0, 10))
        self.lost_win = None
        self.lost_var = tk.BooleanVar(value=bool(app.s.get("preview_show_lost", False)))
        self.filt_win = None
        self.filt_engine = None
        self._filt_key = None

        ttk.Radiobutton(row2, text="Single", value="single", variable=self.layout_var,
                        command=self._on_layout).pack(side="left")
        ttk.Radiobutton(row2, text="Grid", value="grid", variable=self.layout_var,
                        command=self._on_layout).pack(side="left", padx=(4, 4))
        self.cols_sb = ttk.Spinbox(row2, from_=1, to=16, width=3, textvariable=self.cols_var)
        self.cols_sb.pack(side="left")
        ttk.Label(row2, text="x").pack(side="left", padx=2)
        self.rows_sb = ttk.Spinbox(row2, from_=1, to=16, width=3, textvariable=self.rows_var)
        self.rows_sb.pack(side="left")
        ttk.Checkbutton(row2, text="Names", variable=self.names_var,
                        command=self.redraw).pack(side="left", padx=(8, 0))
        for sb, var in ((self.cols_sb, self.cols_var), (self.rows_sb, self.rows_var)):
            sb.bind("<Up>", lambda e, v=var: self._spin(v, 1))
            sb.bind("<Down>", lambda e, v=var: self._spin(v, -1))
            sb.bind("<MouseWheel>", lambda e, v=var: self._spin(v, 1 if e.delta > 0 else -1))
            var.trace_add("write", lambda *a: self._on_grid_size())

        ttk.Checkbutton(row2, text="Dither", variable=self.dither_var,
                        command=self.schedule).pack(side="right")
        ttk.Checkbutton(row2, text="Show lost", variable=self.lost_var,
                        command=self._lost_toggled).pack(side="right", padx=(0, 8))
        ttk.Radiobutton(row2, text="Original", value="orig", variable=self.view_var,
                        command=self._view_changed).pack(side="right", padx=(0, 8))
        ttk.Radiobutton(row2, text="Palettised", value="pal", variable=self.view_var,
                        command=self._view_changed).pack(side="right", padx=(0, 4))

        self.canvas = tk.Canvas(self.win, bg="#262626", highlightthickness=0)
        self.canvas.grid(row=2, column=0, sticky="nsew", padx=8)
        cv = self.canvas
        cv.bind("<Configure>", lambda e: self.redraw())
        cv.bind("<MouseWheel>", self._on_wheel)
        cv.bind("<Button-4>", lambda e: self._zoom_at(e.x, e.y, self.ZOOM_STEP))
        cv.bind("<Button-5>", lambda e: self._zoom_at(e.x, e.y, 1 / self.ZOOM_STEP))
        cv.bind("<ButtonPress-2>", self._pan_start)
        cv.bind("<B2-Motion>", self._pan_move)
        cv.bind("<ButtonRelease-2>", self._pan_end)
        cv.bind("<Double-Button-2>", lambda e: self.fit())
        cv.bind("<ButtonPress-1>", self._pick_press)
        cv.bind("<B1-Motion>", self._pick_motion)
        cv.bind("<ButtonRelease-1>", self._pick_release)
        cv.bind("<Double-Button-1>", self._on_double_click)
        cv.bind("<Motion>", self._on_motion)
        cv.bind("<Leave>", self._on_leave)

        self._build_light_row()
        bottom = ttk.Frame(self.win, padding=(8, 4, 8, 8))
        bottom.grid(row=4, column=0, sticky="ew")
        ttk.Label(bottom, textvariable=self.info_var, font=("Consolas", 10)).pack(anchor="w")
        ttk.Label(bottom, textvariable=self.hover_var, font=("Consolas", 10)).pack(anchor="w")

        w = self.win
        w.bind("<Up>", lambda e: self.step(-1))
        w.bind("<Down>", lambda e: self.step(1))
        w.bind("<Prior>", lambda e: self.step(-1))
        w.bind("<Next>", lambda e: self.step(1))
        w.bind("<space>", self._key_flip)
        w.bind("<Key-f>", self._key_fit)
        w.bind("<Key-F>", self._key_fit)
        w.bind("<Key-n>", self._key_names)
        w.bind("<Key-N>", self._key_names)
        w.protocol("WM_DELETE_WINDOW", self.close)
        w.focus_set()
        self._poll_after = w.after(400, self._poll)

        self.sources_changed()

    # ---------------- COLORMAP lighting
    def _build_light_row(self):
        from tkinter import ttk

        tk = self.app.tk
        lf = ttk.Frame(self.win, padding=(8, 4, 8, 0))
        lf.grid(row=3, column=0, sticky="ew")
        ttk.Checkbutton(lf, text="Apply COLORMAP lighting", variable=self.light_on,
                        command=self._light_changed).grid(row=0, column=0, sticky="w")
        self.light_widgets = []
        ttk.Label(lf, text="Sector light").grid(row=0, column=1, sticky="e", padx=(12, 4))
        sc = tk.Scale(lf, from_=0, to=255, orient="horizontal", showvalue=1, length=160,
                      variable=self.light_val, command=lambda v: self._light_changed())
        sc.grid(row=0, column=2, sticky="w")
        ttk.Label(lf, text="Distance").grid(row=0, column=3, sticky="e", padx=(12, 4))
        sd = tk.Scale(lf, from_=0, to=100, orient="horizontal", showvalue=0, length=140,
                      variable=self.dist_pos, command=lambda v: self._light_changed())
        sd.grid(row=0, column=4, sticky="w")
        self.dist_lbl = tk.StringVar()
        ttk.Label(lf, textvariable=self.dist_lbl, width=11).grid(row=0, column=5, sticky="w")
        r2 = ttk.Frame(lf)
        r2.grid(row=1, column=0, columnspan=6, sticky="w", pady=(2, 0))
        cb1 = ttk.Combobox(r2, textvariable=self.surface_var, values=SURFACES,
                           state="readonly", width=15)
        cb1.pack(side="left")
        cb1.bind("<<ComboboxSelected>>", lambda e: self._light_changed())
        cb2 = ttk.Combobox(r2, textvariable=self.orient_var, values=WALL_ORIENTATIONS,
                           state="readonly", width=22)
        cb2.pack(side="left", padx=(6, 0))
        cb2.bind("<<ComboboxSelected>>", lambda e: self._light_changed())
        c1 = ttk.Checkbutton(r2, text="Corridor (single view)", variable=self.corridor_var,
                             command=self._light_changed)
        c1.pack(side="left", padx=(10, 0))
        c2 = ttk.Checkbutton(r2, text="Invulnerability", variable=self.invul_var,
                             command=self._light_changed)
        c2.pack(side="left", padx=(10, 0))
        self.invul_chk = c2
        self.cmp_chk = ttk.Checkbutton(r2, text="Space compares with loaded COLORMAP",
                                       variable=self.compare_var,
                                       command=self._light_changed)
        self.cmp_chk.pack(side="left", padx=(10, 0))
        self.light_widgets = [sc, sd, cb1, cb2, c1, c2, self.cmp_chk]
        self._light_states()
        self.sync_extra()

    def sync_extra(self):
        """Invulnerability tick box only when the COLORMAP view shows those rows."""
        show = bool(getattr(self.app, "cmap_show_extra", None) and
                    self.app.cmap_show_extra.get())
        if show:
            if not self.invul_chk.winfo_manager():
                self.invul_chk.pack(side="left", padx=(10, 0), before=self.cmp_chk)
        else:
            self.invul_chk.pack_forget()
            if self.invul_var.get():
                self.invul_var.set(False)
                self.schedule()

    def _dist(self):
        return int(round(16 * (128.0 ** (self.dist_pos.get() / 100.0))))

    def _orientation(self):
        return WALL_ORIENTATIONS.index(self.orient_var.get())

    def _light_row(self):
        if self.invul_var.get():
            return 32
        return surface_row(self.surface_var.get(), self.light_val.get(), self._dist(),
                           self._orientation())

    def _light_states(self):
        on = self.light_on.get()
        for w in self.light_widgets:
            try:
                if w.winfo_class() in ("Scale",):
                    w.configure(state="normal" if on else "disabled")
                else:
                    w.state(["!disabled"] if on else ["disabled"])
            except Exception:
                pass
        if on and not self.app.cmap_loaded:
            self.cmp_chk.state(["disabled"])
        self.dist_lbl.set("%d units" % self._dist())

    def _light_changed(self):
        self._light_states()
        if not (self.light_on.get() and self.compare_var.get()):
            self._flip_cmp = False
        self.schedule()

    def _lighting(self):
        return self.light_on.get() and self.view_var.get() == "pal"

    def _p(self, it, img, pal):
        ck = (tuple(pal), self.dither_var.get())
        if ck != self.p_cache_key:
            self.p_cache.clear()
            self.p_cache_key = ck
        k = it["key"]
        if k not in self.p_cache:
            if len(self.p_cache) > self.MAX_CACHE:
                self.p_cache.clear()
            self.p_cache[k] = palettise_p(img, pal, self.dither_var.get())
        return self.p_cache[k]

    def _lit(self, it, img):
        """The image relit through a COLORMAP row (or as a corridor)."""
        from PIL import Image

        compare = bool(self._flip_cmp and self.app.cmap_loaded)
        pal = self.app.compare_palette() if compare else self._wip_pal()
        if not pal:
            return img
        if compare:
            ck = (tuple(pal), self.dither_var.get())
            if ck != self.p_cache_key:
                self.p_cache.clear()
                self.p_cache_key = ck
        p, alpha = self._p(it, img, pal)
        if not (self.corridor_var.get() and not self._grid()):
            row = self._light_row()
            self.lit_text = "row %d" % row
            return relight(p, alpha, self.app.light_palette(row, pal, compare,
                                                            applied=self._applied()))
        # corridor: a wall receding from near (left) to far (right)
        w, h = p.size
        near, far = 48.0, 2048.0
        Wc = max(480, min(1400, w * 5))
        Hc = max(h, 64) * 2
        out = Image.new("RGBA", (Wc, Hc), (24, 24, 24, 255))
        lit_rows = {}
        flat = self.surface_var.get() == SURFACES[1]
        lo_r, hi_r = 99, -1
        for x in range(Wc):
            # true perspective: screen x and column height both go as 1/distance
            t = x / float(Wc - 1)
            d = 1.0 / (1.0 / near + t * (1.0 / far - 1.0 / near))
            if self.invul_var.get():
                r = 32
            elif flat:
                r = flat_row(self.light_val.get(), d)
            else:
                r = wall_row(self.light_val.get(), d, self._orientation())
            lo_r, hi_r = min(lo_r, r), max(hi_r, r)
            if r not in lit_rows:
                lit_rows[r] = relight(p, alpha, self.app.light_palette(
                    r, pal, compare, applied=self._applied()))
            hc = max(1, int(round(Hc * near / d)))
            u = int(d) % w
            col = lit_rows[r].crop((u, 0, u + 1, h)).resize((1, hc), Image.NEAREST)
            out.alpha_composite(col, (x, (Hc - hc) // 2))
        self.lit_text = "corridor %d-%d units, rows %d-%d" % (near, far, lo_r, hi_r)
        return out

    def usage_counts(self):
        """Pixel count per palettised colour over the converted images."""
        counts = {}
        for img in list(self.conv_cache.values()):
            if img is None:
                continue
            for n, c in img.getcolors(1 << 16) or []:
                if c[3]:
                    counts[c[:3]] = counts.get(c[:3], 0) + n
        if not counts and self.p_cache_key is not None:
            pal = list(self.p_cache_key[0])
            for p, alpha in list(self.p_cache.values()):
                for n, i in p.getcolors(256) or []:
                    if i < len(pal):
                        counts[pal[i]] = counts.get(pal[i], 0) + n
        return counts

    # ---------------- helpers
    @staticmethod
    def _clamp(v):
        try:
            return max(1, min(16, int(v)))
        except (TypeError, ValueError):
            return 4

    @staticmethod
    def _typing(ev):
        return ev.widget.winfo_class() in ("TEntry", "Entry", "TCombobox", "TSpinbox")

    def _key_flip(self, ev):
        if self._typing(ev):
            return
        return self.flip()

    def _key_fit(self, ev):
        if self._typing(ev):
            return
        return self.fit()

    def _key_names(self, ev):
        if self._typing(ev):
            return
        self.names_var.set(not self.names_var.get())
        self.redraw()
        return "break"

    def _grid(self):
        return self.layout_var.get() == "grid"

    def _per_page(self):
        return self.cols * self.rows

    # ---------------- layout controls
    def _spin(self, var, n):
        var.set(str(self._clamp(self._clamp(var.get()) + n)))
        return "break"

    def _on_grid_size(self):
        try:
            c, r = int(self.cols_var.get()), int(self.rows_var.get())
        except ValueError:
            return                      # partial typing - wait
        if not (1 <= c <= 16 and 1 <= r <= 16):
            return
        if (c, r) != (self.cols, self.rows):
            self.cols, self.rows = c, r
            self.pick_boxes = []             # the layout moved: boxes no longer fit
            if self._grid():
                self.show(refit=True)

    def _on_layout(self):
        self.pick_boxes = []
        self.show(refit=True)

    # ---------------- sources
    def open_folder_dialog(self):
        from tkinter import filedialog

        d = filedialog.askdirectory(parent=self.win, title="Folder of PNGs",
                                    initialdir=self.folder or self.app.s.get("preview_dir")
                                    or None)
        if d:
            self.add_source("folder", d)

    def open_wad_dialog(self):
        from tkinter import filedialog

        last = self.app.s.get("preview_wad")
        p = filedialog.askopenfilename(
            parent=self.win, title="Open WAD",
            initialdir=os.path.dirname(last) if last else None,
            filetypes=[("WAD", "*.wad"), ("All files", "*.*")])
        if p:
            self.add_source("wad", p)

    # ---------------- source list (the IWAD is always first)
    def _sources(self):
        a = self.app
        iw = a.iwad_path()
        st = getattr(a, "_preview_iwad_state", None)
        if st is None:
            st = a._preview_iwad_state = {"type": None, "filter": "", "item": None}
        first = dict(st, kind="wad", path=iw, iwad=True)
        return [first] + list(a.preview_sources)

    @staticmethod
    def _src_label(d):
        name = os.path.basename(os.path.normpath(d["path"])) if d.get("path") else "(none)"
        if d.get("iwad"):
            return "IWAD: %s" % name
        return "%s (%s)" % (name, "WAD" if d["kind"] == "wad" else "folder")

    def _refresh_src_list(self):
        srcs = self._sources()
        self.src_cb.configure(values=["%d. %s" % (k + 1, self._src_label(d))
                                      for k, d in enumerate(srcs)])
        cur = min(self.app.preview_cur, len(srcs) - 1)
        self.src_cb.current(cur)

    def save_source_state(self):
        """Remember Type / Name filter / current image for the current source."""
        a = self.app
        if self.mode is None:
            return
        st = {"type": self.type_var.get(), "filter": self.filter_var.get(),
              "item": self.view[self.idx]["name"] if self.view and
              0 <= self.idx < len(self.view) else None}
        if a.preview_cur == 0:
            a._preview_iwad_state = st
        elif 0 < a.preview_cur <= len(a.preview_sources):
            a.preview_sources[a.preview_cur - 1].update(st)

    def sources_changed(self):
        """List or current index changed from outside (project load / startup)."""
        a = self.app
        a.preview_cur = max(0, min(a.preview_cur, len(a.preview_sources)))
        self._open_current()

    def _open_current(self):
        a = self.app
        srcs = self._sources()
        d = srcs[a.preview_cur]
        self._refresh_src_list()
        if not d.get("path"):
            self.mode, self.items, self.view = None, [], []
            self.name_var.set("No IWAD set - choose one in the main window.")
            self.redraw()
            return
        self._switching = True
        try:
            self.filter_var.set(d.get("filter") or "")
        finally:
            self._switching = False
        if d["kind"] == "wad":
            self.open_wad(d["path"], d.get("item"), want_type=d.get("type"))
        else:
            self.open_folder(d["path"], d.get("item"))

    def switch_source(self, i):
        a = self.app
        srcs = self._sources()
        if not 0 <= i < len(srcs) or i == a.preview_cur and self.mode is not None:
            self._refresh_src_list()
            return
        self.save_source_state()
        a.preview_cur = i
        self._open_current()

    def step_source(self, n):
        a = self.app
        i = a.preview_cur + n
        if not 0 <= i < len(self._sources()):
            self.name_var.set("No %s source." % ("earlier" if n < 0 else "more"))
            return
        self.switch_source(i)

    def add_source(self, kind, path):
        a = self.app
        path = os.path.abspath(path)
        for k, d in enumerate(self._sources()):
            if d.get("path") and d["kind"] == kind and \
                    os.path.normcase(os.path.abspath(d["path"])) == os.path.normcase(path):
                self.switch_source(k)
                return
        self.save_source_state()
        a.preview_sources.append({"kind": kind, "path": path, "type": None, "filter": "",
                                  "item": None})
        a.preview_cur = len(a.preview_sources)
        self._open_current()

    def close_source(self):
        a = self.app
        if a.preview_cur == 0:
            self.name_var.set("The IWAD always stays in the list.")
            return
        del a.preview_sources[a.preview_cur - 1]
        a.preview_cur = min(a.preview_cur, len(a.preview_sources))
        self._open_current()

    def close_all_sources(self):
        a = self.app
        if not a.preview_sources:
            self.name_var.set("Only the IWAD is open.")
            return
        a.preview_sources = []
        a.preview_cur = 0
        self._open_current()

    def _reset_caches(self):
        self.orig_cache.clear()
        self.idx_cache.clear()
        self.conv_cache.clear()
        self.__dict__.get("_orig_tr", {}).clear()
        self.errors.clear()
        self.content_key = None

    def open_folder(self, folder, select=None):
        """Every PNG in the folder and its subfolders (type "Loose")."""
        if not os.path.isdir(folder):
            self.name_var.set("Can't read folder: %s" % folder)
            return
        names = []
        for root, dirs, files in os.walk(folder):
            dirs.sort(key=str.lower)
            for f in files:
                if f.lower().endswith(".png"):
                    names.append(os.path.relpath(os.path.join(root, f), folder))
        names.sort(key=lambda n: n.lower())
        self.mode, self.folder, self.wad = "folder", folder, None
        self.items = [{"name": n, "kind": "loose", "fmt": "file",
                       "path": os.path.join(folder, n),
                       "key": ("file", os.path.join(folder, n))} for n in names]
        self._reset_caches()
        self.app.s.update(preview_mode="folder", preview_dir=folder)
        self.type_cb.configure(values=self.FOLDER_TYPES)
        self.type_var.set("Loose")
        self.type_cb.state(["!disabled"])
        self.apply_filter(select)

    def open_wad(self, path, select=None, want_type=None):
        from tkinter import messagebox

        fallback = None
        if self.app.history:
            fallback = [c if c is not None else (0, 0, 0)
                        for c in self.app.history[0]["palette"]]
        if fallback is None:
            fallback = [(i, i, i) for i in range(256)]
        iwad = self.app.iwad_archive(prompt=True, parent=self.win)
        try:
            wad = WadSource(path, fallback, iwad)
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not open WAD:\n%s\n\n%s" % (path, e),
                                 parent=self.win)
            return
        self.mode, self.wad, self.folder = "wad", wad, None
        self.items = wad.items
        self._reset_caches()
        self.app.s.update(preview_mode="wad", preview_wad=path)
        types = self.TYPES + [KIND_LABEL[k] for k in ("texture1", "texture2")
                              if k in wad.tex_src]
        self.type_cb.configure(values=types)
        want = want_type or "All"
        self.type_var.set(want if want in types else "All")
        self.type_cb.state(["!disabled"])
        self.apply_filter(select)

    def reload(self):
        """IWAD changed: re-open the current WAD (the IWAD entry follows the new
        IWAD; folders don't use it)."""
        if self.app.preview_cur == 0:
            self.save_source_state()
            self._open_current()
        elif self.mode == "wad" and self.wad is not None:
            sel = self.view[self.idx]["name"] if self.view else None
            self.open_wad(self.wad.path, sel, want_type=self.type_var.get())

    def apply_filter(self, select=None):
        if self._switching:
            return
        if select is None and self.view and 0 <= self.idx < len(self.view):
            select = self.view[self.idx]["name"]
        kind = self.type_var.get()
        text = self.filter_var.get().strip().upper()
        self.app.s.update(preview_filter=self.filter_var.get())
        if self.mode == "wad":
            self.app.s.update(preview_type=kind)

        def keep(it):
            if self.mode != "wad":
                return True
            if kind == "All":       # this WAD's own graphics + textures it defines
                return it.get("tex_src", "WAD") == "WAD"
            return KIND_LABEL.get(it["kind"]) == kind

        eng = self._engine()
        ticks = self.filter_ticks()
        self.view = [it for it in self.items
                     if keep(it) and (not text or text in it["name"].upper())
                     and eng.keep(it, ticks)]
        self._filt_label(ticks)
        if self.filt_win is not None:
            self.filt_win.type_changed()
            self.filt_win.update_info()
        names = [it["name"] for it in self.view]
        self.idx = names.index(select) if select in names else 0
        self.show(refit=True)

    # ---------------- images
    def _orig(self, it):
        from PIL import Image

        k = it["key"]
        if k in self.orig_cache:
            return self.orig_cache[k]
        if len(self.orig_cache) > self.MAX_CACHE:
            self.orig_cache.clear()
        try:
            if it["fmt"] == "file":
                with Image.open(it["path"]) as im:   # read only
                    im.load()
                    img = im.convert("RGBA")
            else:
                img = self.wad.image(it)
        except Exception as e:      # bad data: report, keep browsing
            img = None
            self.errors[k] = str(e)
        self.orig_cache[k] = img
        return img

    def _conv(self, it, img, pal):
        pm = self._player_mode()
        cells = self._player_cells(pm)
        ck = (tuple(pal), self.dither_var.get(), pm, cells, self._lost_key())
        if ck != self.conv_cache_key:
            self.conv_cache.clear()
            self.conv_cache_key = ck
        k = it["key"]
        if k not in self.conv_cache:
            if len(self.conv_cache) > self.MAX_CACHE:
                self.conv_cache.clear()
            out = palettise(img, pal, self.dither_var.get())
            if pm and self._is_player(it):
                out = self._translate(img, out, pm, cells)
            if self.lost_var.get():
                out = self._mark_lost(img, out)
            self.conv_cache[k] = out
        return self.conv_cache[k]

    # ---------------- player translation (Filters: Player 1-4)
    def _player_mode(self):
        return player_mode(self.filter_ticks())

    def _player_cells(self, pm):
        """The 16 cells the player's green goes to, from the working palette."""
        if not pm:
            return None
        a = self.app
        sel = self._sel_rgbs()
        if sel is not None:
            pal = sel
        elif self._applied() and a.history:
            pal = a.history[a.hist_pos]["palette"]
        else:
            pal = a.rgbs or []
        base = PLAYER_RANGE[pm]
        return tuple(tuple(pal[base + k]) if base + k < len(pal) and pal[base + k]
                     else None for k in range(16))

    def _is_player(self, it):
        return it.get("kind") in ("sprite", "loose") and item_name(it).startswith("PLAY")

    def _source_pal(self):
        if self.mode == "wad" and self.wad is not None:
            return self.wad.pal
        if self.app.history:
            return [c if c is not None else (0, 0, 0) for c in self.app.history[0]["palette"]]
        return None

    def _orig_view(self, it, img):
        """Original view: Player 2-4 shown as the stock game shows them -
        green 112-127 onto the source palette's own player range."""
        pm = self._player_mode()
        if pm < 2 or not self._is_player(it):
            return img
        src = self._source_pal()
        if not src:
            return img
        k = (it["key"], pm, hash(tuple(tuple(c) for c in src)))
        cache = self.__dict__.setdefault("_orig_tr", {})
        if k not in cache:
            if len(cache) > self.MAX_CACHE:
                cache.clear()
            base = PLAYER_RANGE[pm]
            cells = tuple(tuple(src[base + j]) for j in range(16))
            cache[k] = self._translate(img, img, pm, cells)
        return cache[k]

    def _source_greens(self):
        """Source colour -> green offset 0-15 (the palette the art was made with)."""
        src = self._source_pal()
        if not src:
            return {}
        out = {}
        for k in range(16):
            c = tuple(src[PLAYER_GREEN + k])
            out.setdefault(c, k)
        return out

    def _translate(self, src, out, pm, cells):
        """Pixels that are the source's green 112-127 go onto the player's
        range, index for index (Doom's translation tables); empty target
        cells keep the normal result."""
        greens = self._source_greens()
        if not greens or cells is None:
            return out
        out = out.copy()
        ps, po = src.load(), out.load()
        w, h = src.size
        for y in range(h):
            for x in range(w):
                r, g, b, a = ps[x, y]
                if a >= 128:
                    k = greens.get((r, g, b))
                    if k is not None and cells[k] is not None:
                        c = cells[k]
                        po[x, y] = (c[0], c[1], c[2], 255)
        return out

    def _native_checker(self, size):
        from PIL import Image

        if size in self._native_checkers:
            return self._native_checkers[size]
        w, h = size
        cell = 4
        img = Image.new("RGBA", size)
        img.putdata([(90, 90, 90, 255) if ((x // cell) + (y // cell)) % 2
                     else (122, 122, 122, 255) for y in range(h) for x in range(w)])
        if len(self._native_checkers) > 64:
            self._native_checkers.clear()
        self._native_checkers[size] = img
        return img

    def _page_range(self):
        per = self._per_page()
        start = (self.idx // per) * per
        return start, min(start + per, len(self.view))

    def _key(self):
        """(content key, palette, palettised?, lit?) for what would show now."""
        pal = self._pal()
        pal_on = self.view_var.get() == "pal" and bool(pal)
        if pal_on and self.light_on.get():       # the lit view is always the WIP
            pal = self._wip_pal() or pal
        pm = self._player_mode()
        palkey = ((tuple(pal), self.dither_var.get(), pm, self._player_cells(pm),
                   self._lost_key())
                  if pal_on else (("orig", pm) if pm else None))
        lit_on = pal_on and self.light_on.get()
        if lit_on:
            palkey = palkey + (self.light_val.get(), self._dist(), self.surface_var.get(),
                               self.orient_var.get(), self.corridor_var.get(),
                               self.invul_var.get(), self._flip_cmp,
                               self.app.cmap_signature(applied=self._applied()))
        if self._grid():
            a, b = self._page_range()
            key = ("grid", tuple(it["key"] for it in self.view[a:b]), self.cols, palkey)
        else:
            key = ("single", self.view[self.idx]["key"], palkey)
        return key, pal, pal_on, lit_on

    def _applied(self):
        return self.live_var.get() == "applied"

    def _wip_pal(self):
        return self.app.preview_palette(applied=self._applied())

    def _pal(self):
        """The colours images are palettised with: the WIP, or the chosen
        Palette Browser palette."""
        rgbs = self._sel_rgbs()
        if rgbs is None:
            return self._wip_pal()
        return list(dict.fromkeys(tuple(c) for c in rgbs[:256] if c is not None))

    # ---------------- palette choice (WIP / Palette Browser palettes)
    def _browser_entries(self):
        from .gui_playpals_tool import playpal_entries
        try:
            return playpal_entries(self.app) or []
        except Exception:      # noqa: BLE001 - IWAD / files unreadable: WIP only
            return []

    @staticmethod
    def _ekey(e):
        return (e.get("name"), e.get("path") or "")

    def _sel_entry(self):
        if self.pal_sel is None:
            return None
        for e in self._browser_entries():
            if self._ekey(e) == self.pal_sel:
                return e
        self.pal_sel = None                     # gone from the browser: back to WIP
        self._pal_ui()
        return None

    def _sel_rgbs(self):
        e = self._sel_entry()
        return e["rgbs"] if e is not None and e.get("rgbs") else None

    def _fill_pal_list(self):
        self._pal_list = [("WIP", None)] + [(e["name"], self._ekey(e))
                                            for e in self._browser_entries()]
        self.palsel_cb.configure(values=[t for t, _k in self._pal_list])

    def choose_pal(self, i):
        self._fill_pal_list()
        if not 0 <= i < len(self._pal_list):
            i = 0
        self.pal_sel = self._pal_list[i][1]
        self._pal_ui()
        self.schedule(now=True)

    def step_pal(self, n):
        self._fill_pal_list()
        cur = next((k for k, (_t, key) in enumerate(self._pal_list) if key == self.pal_sel),
                   0)
        self.choose_pal((cur + n) % len(self._pal_list))

    def _pal_ui(self):
        e = None
        if self.pal_sel is not None:
            e = next((x for x in self._browser_entries() if self._ekey(x) == self.pal_sel),
                     None)
            if e is None:
                self.pal_sel = None
        name = e["name"] if e is not None else "WIP"
        try:
            self.palsel_var.set(name)
            self.win.title(TITLE if e is None else "%s - %s" % (TITLE, name))
            for rb in self.live_rbs:
                rb.state(["disabled"] if e is not None else ["!disabled"])
        except self.app.tk.TclError:
            pass

    def _live_changed(self):
        self.app.s["preview_live"] = not self._applied()
        self.schedule(now=True)

    def _apply_pin(self):
        try:
            self.win.attributes("-topmost", bool(self.pin_var.get()))
        except self.app.tk.TclError:
            pass
        self.app.s["preview_pin"] = bool(self.pin_var.get())

    def _poll(self):
        """Catch every edit (tools, sessions, settings): redraw when what
        would be shown differs from what is shown."""
        self._poll_after = None
        try:
            if self.view and self.win.state() != "withdrawn" and self._after is None:
                if self._key()[0] != self.content_key:
                    self.schedule()
        except Exception:      # noqa: BLE001 - mid-edit states: try again next tick
            pass
        self._poll_after = self.win.after(250, self._poll)

    def toggle(self):
        """F9: hide / show."""
        if self.win.state() == "withdrawn":
            self.pal_sel = None                  # every open starts on the WIP
            self._pal_ui()
            self.win.deiconify()
            self.win.lift()
            self.schedule(now=True)
        else:
            self.store_state()
            self.win.withdraw()

    def _content(self):
        """The image to display (single image or a whole grid page)."""
        from PIL import Image

        if not self.view:
            return None
        key, pal, pal_on, lit_on = self._key()
        if key == self.content_key:
            return self.content

        used = set()

        def get(it):
            img = self._orig(it)
            if img is not None and lit_on:
                img = self._lit(it, img)
            elif img is not None and pal_on:
                img = self._conv(it, img, pal)
                cols = img.getcolors(1 << 16)
                if cols:
                    used.update(c[:3] for _, c in cols if c[3])
            elif img is not None:
                img = self._orig_view(it, img)
            return img

        self.cells = []
        if not self._grid():
            img = get(self.view[self.idx])
        else:
            a, b = self._page_range()
            ims = [(i, get(self.view[i])) for i in range(a, b)]
            sizes = [im.size for _, im in ims if im is not None] or [(64, 64)]
            cw = max(s[0] for s in sizes)
            ch = max(s[1] for s in sizes)
            G = self.GAP
            nrows = -(-len(ims) // self.cols)
            W = self.cols * cw + (self.cols + 1) * G
            H = nrows * ch + (nrows + 1) * G
            img = Image.new("RGBA", (W, H), (30, 30, 30, 255))
            for k, (i, im) in enumerate(ims):
                cx = G + (k % self.cols) * (cw + G)
                cy = G + (k // self.cols) * (ch + G)
                self.cells.append((i, cx, cy, cw, ch))
                if im is None:
                    continue
                ox, oy = cx + (cw - im.size[0]) // 2, cy + (ch - im.size[1]) // 2
                img.paste(self._native_checker(im.size), (ox, oy))
                img.alpha_composite(im, (ox, oy))
        self._used = len(used)
        self.content = img
        self.content_key = key
        return img

    # ---------------- navigation
    def show(self, refit=False):
        prev = self.content.size if self.content is not None else None
        self.content_key = None
        if not self.view:
            self.content = None
            what = "PNGs" if self.mode == "folder" else "matching graphics"
            self.name_var.set("No %s" % what if self.mode else
                              "Open a folder of PNGs or a WAD")
            self.info_var.set("")
            self.redraw()
            return
        img = self._content()
        if self._grid():
            per = self._per_page()
            a, b = self._page_range()
            pages = -(-len(self.view) // per)
            self.name_var.set("Page %d/%d  (%d-%d of %d)" % (
                a // per + 1, pages, a + 1, b, len(self.view)))
        else:
            it = self.view[self.idx]
            self.app.s["preview_item"] = it["name"]
            if img is None:
                self.name_var.set("%d/%d  %s  (can't decode: %s)" % (
                    self.idx + 1, len(self.view), it["name"],
                    self.errors.get(it["key"], "?")))
            else:
                self.name_var.set("%d/%d  %s  [%s]" % (
                    self.idx + 1, len(self.view), it["name"], self._describe(it, img)))
        if refit:
            self.auto_fit = True
        elif (not self.auto_fit and img is not None and prev is not None
              and prev != img.size):
            # same zoom, new image: keep the old image's centre on the new one's
            cw = max(self.canvas.winfo_width(), 1)
            ch = max(self.canvas.winfo_height(), 1)
            sc = self.view_scale
            cx = (cw / 2.0 - self.off_x) / (prev[0] * sc)
            cy = (ch / 2.0 - self.off_y) / (prev[1] * sc)
            self.off_x = cw / 2.0 - cx * img.size[0] * sc
            self.off_y = ch / 2.0 - cy * img.size[1] * sc
        self.redraw()

    def _view_changed(self):
        self.redraw()
        self._showpal_ui()

    def step(self, n):
        if self.view:
            if self._grid():
                per = self._per_page()
                pages = -(-len(self.view) // per)
                page = (self.idx // per + n) % pages
                self.idx = page * per
            else:
                self.idx = (self.idx + n) % len(self.view)
            self.pick_boxes = []
            self.show()
        return "break"

    def flip(self):
        if self.light_on.get() and self.compare_var.get() and self.app.cmap_loaded \
                and self.view_var.get() == "pal":
            self._flip_cmp = not self._flip_cmp
            self.schedule()
            return "break"
        self.view_var.set("orig" if self.view_var.get() == "pal" else "pal")
        self._view_changed()
        return "break"

    def _cell_at(self, x, y):
        if not self._grid() or self.content is None:
            return None
        px = (x - self.off_x) / self.view_scale
        py = (y - self.off_y) / self.view_scale
        for c in self.cells:
            i, cx, cy, cw, ch = c
            if cx <= px < cx + cw and cy <= py < cy + ch:
                return c
        return None

    # ---------------- Show on palette (like SLADE's colour remap preview)
    def _showpal_toggled(self):
        if self._nonpal:                         # red: nothing to show, setting kept
            self.showpal_var.set(False)
            self.hover_var.set("Non-paletted image: it has no palette indices to show "
                               "(picking colours still works).")
            return
        self.app.s["preview_show_pal"] = bool(self.showpal_var.get())
        if not self.showpal_var.get():
            self.app.pv_set_hover(None)
        self._update_marks()

    # Original view: marks go on the stored INDEX numbers, not on colours
    def _orig_mode(self):
        return self.view_var.get() != "pal" or not self._pal()

    def _index_img(self, it):
        """Stored palette indices of an item (RGBA, R = index), None = true
        colour. Player 2-4 (Filters) move 112-127 the way the game does."""
        k = it["key"]
        if k not in self.idx_cache:
            img = None
            try:
                if it["fmt"] == "file":
                    from PIL import Image
                    with Image.open(it["path"]) as im:
                        im.load()
                        img = index_from_png(im)
                elif self.wad is not None:
                    img = self.wad.index_image(it)
            except Exception:      # noqa: BLE001 - undecodable: treat as no indices
                img = None
            if len(self.idx_cache) > self.MAX_CACHE:
                self.idx_cache.clear()
            self.idx_cache[k] = img
        img = self.idx_cache[k]
        pm = self._player_mode()
        if img is not None and pm >= 2 and self._is_player(it):
            base = PLAYER_RANGE[pm]
            lut = [base + (i - PLAYER_GREEN) if PLAYER_GREEN <= i < PLAYER_GREEN + 16 else i
                   for i in range(256)]
            r, g, b, a = img.split()
            r = r.point(lut)
            from PIL import Image
            img = Image.merge("RGBA", (r, r, r, a))
        return img

    def _shown_items(self):
        if not self.view:
            return []
        if self._grid():
            a, b = self._page_range()
            return self.view[a:b]
        return [self.view[self.idx]]

    def _showpal_ui(self):
        """Original view of true-colour image(s) only: the button goes red,
        unpressed, "Non-paletted image" (the saved setting is untouched)."""
        items = self._shown_items()
        nonpal = bool(items) and self._orig_mode() and all(
            self._orig(it) is None or self._index_img(it) is None for it in items)
        if nonpal == self._nonpal:
            return
        self._nonpal = nonpal
        b = self.showpal_btn
        try:
            if nonpal:
                self.showpal_var.set(False)
                b.configure(text=NONPAL_TEXT, background=NONPAL_BG,
                            activebackground=NONPAL_BG, selectcolor=NONPAL_BG)
                self.app.pv_set_hover(None)
                self.app.pv_set_mark(None)
            else:
                self.showpal_var.set(bool(self.app.s.get("preview_show_pal", False)))
                b.configure(text=SHOWPAL_TEXT, background=self._showpal_bg,
                            activebackground=self._showpal_bg,
                            selectcolor=self._showpal_sel)
                self._update_marks()
        except self.app.tk.TclError:
            pass

    def _index_at(self, x, y):
        """Original view: the stored index under canvas x, y -> int, "tc"
        (true-colour image there) or None (off the image / transparent)."""
        if self.content is None or not self.view:
            return None
        if self._grid():
            r = self._img_rect_at(x, y)
            if r is None:
                return None
            i, ox, oy, _iw, _ih = r
            it = self.view[i]
            px, py = self._to_img(x, y)
            px, py = int(px - ox), int(py - oy)
        else:
            it = self.view[self.idx]
            px, py = self._to_img(x, y)
            px, py = int(px), int(py)
        img = self._index_img(it)
        if img is None:
            return "tc" if self._orig(it) is not None else None
        if not (0 <= px < img.size[0] and 0 <= py < img.size[1]):
            return None
        r, _g, _b, a = img.getpixel((px, py))
        return None if a < 128 else r

    def _box_indices(self):
        """Original view: every stored index inside the box selection."""
        if not self.view or not self.pick_boxes or self.content is None:
            return None
        ox = oy = 0
        if self._grid():
            cell = next((c for c in self.cells if c[0] == self.pick_item), None)
            if cell is None or self.pick_item is None or self.pick_item >= len(self.view):
                return None
            it = self.view[self.pick_item]
            shown = self._display_img(it)
            if shown is None:
                return None
            _i, cx, cy, cw, ch = cell
            ox, oy = cx + (cw - shown.size[0]) // 2, cy + (ch - shown.size[1]) // 2
        else:
            it = self.view[self.idx]
        img = self._index_img(it)
        if img is None:
            return None
        out = set()
        for box in self.pick_boxes:
            part = img.crop((box[0] - ox, box[1] - oy, box[2] - ox, box[3] - oy))
            for _n, c in part.getcolors(part.size[0] * part.size[1] + 1) or []:
                if c[3] >= 128:
                    out.add(int(c[0]))
        return out

    def _on_leave(self, _ev=None):
        self.hover_var.set("")
        self.app.pv_set_hover(None)

    def _pixel_at(self, x, y):
        """The displayed colour under canvas x, y (None off the image or on a
        transparent pixel)."""
        if self.content is None or not self.view:
            return None
        if self._grid():
            r = self._img_rect_at(x, y)
            if r is None:
                return None
            i, ox, oy, iw, ih = r
            img = self._display_img(self.view[i])
            if img is None:
                return None
            px, py = self._to_img(x, y)
            px, py = int(px - ox), int(py - oy)
        else:
            img = self.content
            px, py = self._to_img(x, y)
            px, py = int(px), int(py)
        if not (0 <= px < img.size[0] and 0 <= py < img.size[1]):
            return None
        c = img.getpixel((px, py))
        if isinstance(c, int):
            return None
        if len(c) == 4 and c[3] < 128:
            return None
        return tuple(c[:3])

    def _box_colours(self):
        """Every opaque colour inside the box selection (as displayed)."""
        img = self.content
        if img is None or not self.pick_boxes:
            return None
        ox = oy = 0
        if self._grid():
            cell = next((c for c in self.cells if c[0] == self.pick_item), None)
            if cell is None or self.pick_item is None or self.pick_item >= len(self.view):
                return None
            img = self._display_img(self.view[self.pick_item])
            if img is None:
                return None
            _i, cx, cy, cw, ch = cell
            ox, oy = cx + (cw - img.size[0]) // 2, cy + (ch - img.size[1]) // 2
        out = set()
        for box in self.pick_boxes:
            part = img.crop((box[0] - ox, box[1] - oy, box[2] - ox,
                             box[3] - oy)).convert("RGBA")
            for _n, c in part.getcolors(part.size[0] * part.size[1] + 1) or []:
                if c[3] >= 128:
                    out.add(c[:3])
        return out

    def _update_marks(self):
        if not self.showpal_var.get():
            self.app.pv_set_mark(None)
            return
        if self._orig_mode():
            self.app.pv_set_mark(self._box_indices())
        else:
            self.app.pv_set_mark(self._box_colours())

    def open_picked_btn(self):
        if not self.pick_boxes:
            self.app.open_picked()
            self.hover_var.set("Drag a box on the image to pick its colours "
                               "(Shift+drag adds boxes, a click clears).")
            return
        self._send_pick(open_win=True)

    def _on_motion(self, ev):
        if self.showpal_var.get() and self._orig_mode():
            k = self._index_at(ev.x, ev.y)
            if k == "tc":
                self.app.pv_set_hover(None)
                self.hover_var.set("true colour - no index")
                return
            hit = self.app.pv_set_hover(k)
            if k is not None:
                self.hover_var.set("stored index %d -> %s" % (k, hit))
                return
        elif self.showpal_var.get():
            rgb = self._pixel_at(ev.x, ev.y)
            hit = self.app.pv_set_hover(rgb)
            if rgb is not None:
                self.hover_var.set("pixel #%02X%02X%02X -> %s" % (rgb + (hit,)))
                return
        elif self._nonpal and self._index_at(ev.x, ev.y) == "tc":
            self.hover_var.set("true colour - no index")
            return
        c = self._cell_at(ev.x, ev.y)
        if c is None:
            self.hover_var.set("")
            return
        it = self.view[c[0]]
        im = self.orig_cache.get(it["key"])
        desc = self._describe(it, im) if im is not None else "can't decode"
        self.hover_var.set("%s  [%s]   double-click = open single" % (it["name"], desc))

    @staticmethod
    def _describe(it, img):
        size = "%dx%d" % img.size
        if it["fmt"] == "file":
            return size
        if it["fmt"] == "tex":
            t = it["tex"]
            n = len(t["patches"])
            txt = "%s (%s) %s, %d patch%s" % (KIND_LABEL[it["kind"]], it["tex_src"], size,
                                              n, "" if n == 1 else "es")
            miss = it.get("missing")
            if miss:
                txt += ", MISSING: " + " ".join(miss[:6]) + (" ..." if len(miss) > 6 else "")
            return txt
        return "%s %s" % (it["kind"], size)

    def _on_double_click(self, ev):
        c = self._cell_at(ev.x, ev.y)
        if c is None:
            return
        self.idx = c[0]
        self.pick_boxes = []
        self.layout_var.set("single")
        self.show(refit=True)

    # ---------------- colour picking (single view)
    def _to_img(self, x, y):
        sc = self.view_scale or 1.0
        return (x - self.off_x) / sc, (y - self.off_y) / sc

    def _pick_press(self, ev):
        self.canvas.focus_set()
        if self.content is None:
            self._pick_drag = None
            return
        cell = None
        if self._grid():
            cell = self._img_rect_at(ev.x, ev.y)
            if cell is None:                  # not on an image: nothing to sample
                self._pick_drag = None
                return
        self._pick_drag = {"x0": ev.x, "y0": ev.y, "add": bool(ev.state & 0x0001),
                           "moved": False, "cell": cell}

    def _pick_motion(self, ev):
        d = self._pick_drag
        if d is None:
            return
        if abs(ev.x - d["x0"]) + abs(ev.y - d["y0"]) > 4:
            d["moved"] = True
        cv = self.canvas
        cv.delete("pickdrag")
        lw = max(2, round(3 * getattr(self.app, "ui", 1.0)))
        x1, y1 = ev.x, ev.y
        if d["cell"] is not None:              # grid: stay inside the one image
            _i, ix, iy, iw, ih = d["cell"]
            sc = self.view_scale or 1.0
            x1 = min(max(x1, self.off_x + ix * sc), self.off_x + (ix + iw) * sc)
            y1 = min(max(y1, self.off_y + iy * sc), self.off_y + (iy + ih) * sc)
        cv.create_rectangle(d["x0"], d["y0"], x1, y1, outline="#000000", width=lw + 3,
                            tags="pickdrag")
        cv.create_rectangle(d["x0"], d["y0"], x1, y1, outline="#00ffff", width=lw,
                            tags="pickdrag")

    def _pick_release(self, ev):
        d, self._pick_drag = self._pick_drag, None
        self.canvas.delete("pickdrag")
        if d is None:
            return
        if not d["moved"]:
            if not d["add"] and self.pick_boxes:          # plain click clears the box
                self.pick_boxes = []
                self.redraw()
                self._update_marks()
            return
        w, h = self.content.size
        lx, ly, hx, hy = 0, 0, w, h
        if d["cell"] is not None:
            i, ix, iy, iw, ih = d["cell"]
            lx, ly, hx, hy = ix, iy, ix + iw, iy + ih
        x0, y0 = self._to_img(d["x0"], d["y0"])
        x1, y1 = self._to_img(ev.x, ev.y)
        x0, x1 = sorted((x0, x1))
        y0, y1 = sorted((y0, y1))
        box = (max(lx, int(x0)), max(ly, int(y0)), min(hx, int(x1) + 1), min(hy, int(y1) + 1))
        if box[2] <= box[0] or box[3] <= box[1]:
            return
        item = d["cell"][0] if d["cell"] is not None else None
        keep = d["add"] and item == self.pick_item
        self.pick_item = item
        self.pick_boxes = (self.pick_boxes if keep else []) + [box]
        self.redraw()
        self._send_pick()                      # updates Picked colours if it's open
        self._update_marks()

    def _img_rect_at(self, x, y):
        """Grid view: (view index, x, y, w, h) of the image under canvas x, y,
        in content pixels - the image itself, not its whole grid cell."""
        c = self._cell_at(x, y)
        if c is None:
            return None
        i, cx, cy, cw, ch = c
        img = self._display_img(self.view[i])
        if img is None:
            return None
        iw, ih = img.size
        ox, oy = cx + (cw - iw) // 2, cy + (ch - ih) // 2
        px, py = self._to_img(x, y)
        if not (ox <= px < ox + iw and oy <= py < oy + ih):
            return None
        return (i, ox, oy, iw, ih)

    def _display_img(self, it):
        """One image exactly as the preview shows it (original / palettised /
        lit), with its own transparency - no grid checkerboard."""
        img = self._orig(it)
        if img is None:
            return None
        _k, pal, pal_on, lit_on = self._key()
        if lit_on:
            return self._lit(it, img)
        if pal_on:
            return self._conv(it, img, pal)
        return self._orig_view(it, img)

    def _pick_source(self):
        it = self.view[self.pick_item if (self._grid() and self.pick_item is not None)
                       else self.idx]
        if self.view_var.get() != "pal" or not self._pal():
            how = "original"
        elif self.light_on.get():
            how = "palettised, lit at %d%s" % (self.light_val.get(),
                                               " (corridor)" if self.corridor_var.get() else "")
        else:
            how = "palettised" + (" (dithered)" if self.dither_var.get() else "")
            e = self._sel_entry()
            if e is not None:
                how += " to " + e["name"]
        return "From %s - %s" % (it["name"], how), how == "original"

    def _send_pick(self, open_win=False):
        """The colours under the boxes, exactly as displayed, to Picked colours."""
        self._pick_key = self.content_key
        img = self.content
        if img is None or not self.pick_boxes:
            return
        ox = oy = 0
        if self._grid():                       # sample the image itself
            cell = next((c for c in self.cells if c[0] == self.pick_item), None)
            if cell is None or self.pick_item >= len(self.view):
                return
            img = self._display_img(self.view[self.pick_item])
            if img is None:
                return
            _i, cx, cy, cw, ch = cell
            ox, oy = cx + (cw - img.size[0]) // 2, cy + (ch - img.size[1]) // 2
        counts = {}
        for box in self.pick_boxes:
            part = img.crop((box[0] - ox, box[1] - oy, box[2] - ox,
                             box[3] - oy)).convert("RGBA")
            cols = part.getcolors(part.size[0] * part.size[1] + 1) or []
            for n, c in cols:
                if c[3] >= 128:                           # ignore transparent pixels
                    counts[c[:3]] = counts.get(c[:3], 0) + n
        if self.app.picked is None:
            if not open_win:
                return
            self.app.open_picked()
        src, original = self._pick_source()
        self.app.picked.set_colours([(n, c) for c, n in counts.items()], src, original)

    # ---------------- conversion
    def schedule(self, now=False):
        """Throttled redraw: changes during a drag show every ~0.1 s (longer
        when a page takes longer to render), never queue up behind each other."""
        if self._after is not None:
            if not now:
                return                       # one is coming - it will see the latest
            self.win.after_cancel(self._after)
        delay = 10 if now else int(max(80.0, min(1000.0, 1.3 * self._render_ms)))
        self._after = self.win.after(delay, self._refresh)

    def _refresh(self):
        import time
        self._after = None
        t = time.perf_counter()
        self.redraw()
        self._render_ms = (time.perf_counter() - t) * 1000.0

    # ---------------- view transform
    def _fit_scale(self, size):
        cw = max(self.canvas.winfo_width(), 1)
        ch = max(self.canvas.winfo_height(), 1)
        return max(min((cw - 2 * self.PAD) / size[0], (ch - 2 * self.PAD) / size[1]), 0.01)

    def fit(self):
        self.auto_fit = True
        self.redraw()
        return "break"

    def _zoom_at(self, x, y, factor):
        if self.content is None:
            return
        fit = self._fit_scale(self.content.size)
        new = min(max(self.view_scale * factor, fit * 0.25), max(fit * 8, 32.0))
        if new == self.view_scale:
            return
        wx = (x - self.off_x) / self.view_scale
        wy = (y - self.off_y) / self.view_scale
        self.view_scale = new
        self.off_x = x - wx * new
        self.off_y = y - wy * new
        self.auto_fit = False
        self.redraw()

    def _on_wheel(self, ev):
        if ev.delta:
            self._zoom_at(ev.x, ev.y, self.ZOOM_STEP ** (ev.delta / 120.0))

    def _pan_start(self, ev):
        self._pan = (ev.x, ev.y, self.off_x, self.off_y)
        self.canvas.configure(cursor="fleur")

    def _pan_move(self, ev):
        if self._pan is None:
            return
        x0, y0, ox, oy = self._pan
        self.off_x = ox + ev.x - x0
        self.off_y = oy + ev.y - y0
        self.auto_fit = False
        self.redraw()

    def _pan_end(self, _ev):
        self._pan = None
        self.canvas.configure(cursor="")

    # ---------------- drawing
    def _checker_img(self, size):
        from PIL import Image

        if self._checker[0] == size:
            return self._checker[1]
        cell = 8
        cw, ch = -(-size[0] // cell), -(-size[1] // cell)
        small = Image.new("RGBA", (cw, ch))
        small.putdata([(90, 90, 90, 255) if (x + y) % 2 else (122, 122, 122, 255)
                       for y in range(ch) for x in range(cw)])
        big = small.resize((cw * cell, ch * cell), _pil_const("Resampling", "NEAREST"))
        img = big.crop((0, 0, size[0], size[1]))
        self._checker = (size, img)
        return img

    def redraw(self):
        from PIL import ImageTk

        cv = self.canvas
        cv.delete("all")
        im = self._content()
        self._showpal_ui()
        if im is None:
            msg = "Open a folder of PNGs or a WAD" if not self.mode else "Nothing to show"
            cv.create_text(cv.winfo_width() / 2, cv.winfo_height() / 2, text=msg,
                           fill="#888")
            return
        cw, ch = cv.winfo_width(), cv.winfo_height()
        w, h = im.size
        if self.auto_fit:
            self.view_scale = self._fit_scale(im.size)
            self.off_x = (cw - w * self.view_scale) / 2
            self.off_y = (ch - h * self.view_scale) / 2
        sc = self.view_scale
        sx0 = max(0, math.floor(-self.off_x / sc))
        sy0 = max(0, math.floor(-self.off_y / sc))
        sx1 = min(w, math.ceil((cw - self.off_x) / sc))
        sy1 = min(h, math.ceil((ch - self.off_y) / sc))
        if sx1 > sx0 and sy1 > sy0:
            dw = max(1, round((sx1 - sx0) * sc))
            dh = max(1, round((sy1 - sy0) * sc))
            disp = im.crop((sx0, sy0, sx1, sy1)).resize(
                (dw, dh), _pil_const("Resampling", "NEAREST"))
            out = self._checker_img((dw, dh)).copy()
            out.alpha_composite(disp)
            self._tkimg = ImageTk.PhotoImage(out)
            cv.create_image(round(self.off_x + sx0 * sc), round(self.off_y + sy0 * sc),
                            image=self._tkimg, anchor="nw")
        if self._grid() and self.pick_boxes and \
                not any(c[0] == self.pick_item for c in self.cells):
            self.pick_boxes = []               # its image is no longer on this page
            self._update_marks()
        if self.pick_boxes:
            lw = max(2, round(3 * getattr(self.app, "ui", 1.0)))
            for x0, y0, x1, y1 in self.pick_boxes:
                X0, Y0 = self.off_x + x0 * sc, self.off_y + y0 * sc
                X1, Y1 = self.off_x + x1 * sc, self.off_y + y1 * sc
                cv.create_rectangle(X0, Y0, X1, Y1, outline="#000000", width=lw + 3)
                cv.create_rectangle(X0, Y0, X1, Y1, outline="#00ffff", width=lw)
            if self.content_key != self._pick_key:
                if self.app.picked is not None:
                    self._send_pick()
                self._pick_key = self.content_key
                self._update_marks()
        # names on grid cells when big enough to read
        for i, cx, cy, cwid, chei in (self.cells if self.names_var.get() else ()):
            if cwid * sc < 70:
                break
            x = self.off_x + cx * sc
            y = self.off_y + cy * sc
            if x > cw or y > ch or x + cwid * sc < 0 or y + chei * sc < 0:
                continue
            t = cv.create_text(x + 4, y + 3, text=self.view[i]["name"], anchor="nw",
                               fill="#ff6060" if self.view[i].get("missing") else "#ffffff",
                               font=("Consolas", 9))
            bx = cv.bbox(t)
            r = cv.create_rectangle(bx[0] - 2, bx[1] - 1, bx[2] + 2, bx[3] + 1,
                                    fill="#000000", outline="")
            cv.tag_lower(r, t)

        src = ""
        if self.mode == "wad":
            src = "   source pal: %s" % self.wad.pal_src
            k = {"TEXTURE1": "texture1", "TEXTURE2": "texture2"}.get(self.type_var.get())
            if k in self.wad.tex_src:
                src += "   %s" % self.wad.tex_src[k]
            ip = self.app.iwad_path()
            src += "   IWAD: %s" % (os.path.basename(ip) if ip else "not set")
        pal = self._pal() or []
        if self.view_var.get() == "pal" and pal and self.light_on.get():
            who = "LOADED PLAYPAL + COLORMAP" if self._flip_cmp else "CURRENT"
            self.info_var.set("LIT (%s)   light %d  %s   %s   zoom %.0f%%   (Space = %s)" % (
                who, self.light_val.get(), self.lit_text,
                "invulnerability" if self.invul_var.get() else self.surface_var.get(),
                sc * 100, "current" if self._flip_cmp else
                ("loaded" if self.compare_var.get() and self.app.cmap_loaded else
                 "original")))
        elif self.view_var.get() == "pal" and pal:
            self.info_var.set("PALETTISED   palette: %d colours   used: %d   dither: %s   "
                              "zoom %.0f%%%s   (Space = original)" % (
                                  len(pal), self._used,
                                  "on" if self.dither_var.get() else "off", sc * 100, src))
        else:
            self.info_var.set("ORIGINAL   zoom %.0f%%%s   (Space = palettised)" % (
                sc * 100, src))

    # ---------------- close
    def store_state(self):
        try:
            self.app.s["preview_geometry"] = self.win.geometry()
        except Exception:
            pass
        self.app.s.update(preview_light_on=self.light_on.get(),
                          preview_light=self.light_val.get(),
                          preview_dist=self.dist_pos.get(),
                          preview_surface=self.surface_var.get(),
                          preview_orient=self.orient_var.get(),
                          preview_corridor=self.corridor_var.get())
        self.app.s.update(preview_dither=self.dither_var.get(),
                          preview_layout=self.layout_var.get(),
                          preview_names=self.names_var.get(),
                          preview_cols=self.cols, preview_rows=self.rows)

    # ---------------- filters (Filters... window)
    def filter_ticks(self):
        return set(self.app.s.get("preview_filter_ticks") or [])

    def _engine(self):
        custom = self.app.custom_filters
        key = (id(self.items), len(self.items),
               tuple((c["id"], c["section"], tuple(c["match"])) for c in custom))
        if self.filt_engine is None or key != self._filt_key:
            arch = self.wad.arch if self.mode == "wad" and self.wad is not None else None
            self.filt_engine = FilterEngine(self.items, custom, arch)
            self._filt_key = key
        return self.filt_engine

    def _filt_label(self, ticks):
        eng = self.filt_engine
        n = len([t for t in ticks if eng is not None and t in eng.entries])
        self.filt_btn.configure(text="Filters (%d)" % n if n else "Filters...")

    def open_filters(self):
        if self.filt_win is not None:
            self.filt_win.lift()
            return
        from .gui_filters_window import FiltersWindow
        self.filt_win = FiltersWindow(self)

    def filters_changed(self):
        self.apply_filter()

    def custom_changed(self):
        self.filt_engine = None
        self.apply_filter()

    # ---------------- lost colours (window + Show lost overlay)
    def open_scene(self):
        from .gui_scene import open_scene
        open_scene(self.app)

    def open_lost(self):
        if self.lost_win is not None:
            self.lost_win.lift()
            return
        from .gui_lost_window import LostWindow
        self.lost_win = LostWindow(self)

    def _lost_toggled(self):
        self.app.s["preview_show_lost"] = bool(self.lost_var.get())
        self.schedule(now=True)

    def _lost_key(self):
        if not self.lost_var.get():
            return None
        from .gui_lost_window import lost_settings, palette_cells
        return (lost_settings(self.app), tuple(palette_cells(self.app, self._applied())))

    def _mark_lost(self, src, out):
        """Lost pixels magenta, greyed ones cyan, on the palettised image."""
        from ..cleanpal_lib_scan import classify
        from .gui_lost_window import GREY_COL, LOST_COL, lost_settings, palette_cells
        m, close, greyed = lost_settings(self.app)
        cells = palette_cells(self.app, self._applied())
        key = (tuple(cells), m, close, greyed)
        if getattr(self, "_lost_cache_key", None) != key:
            self._lost_cache_key, self._lost_cls = key, {}
        known = self._lost_cls
        im = src.convert("RGBA")
        cols = [c[:3] for _n, c in (im.getcolors(im.width * im.height + 1) or ()) if c[3] >= 128]
        new = [c for c in cols if c not in known]
        if new:
            for c, v in classify(new, cells, m, close, greyed).items():
                known[c] = v[0]
        if not any(known.get(c, "ok") != "ok" for c in cols):
            return out
        lost = tuple(int(LOST_COL[i:i + 2], 16) for i in (1, 3, 5)) + (255,)
        grey = tuple(int(GREY_COL[i:i + 2], 16) for i in (1, 3, 5)) + (255,)
        out = out.copy()
        ps, po = im.load(), out.load()
        for y in range(im.height):
            for x in range(im.width):
                r, g, b, a = ps[x, y]
                if a >= 128:
                    k = known.get((r, g, b))
                    if k == "lost":
                        po[x, y] = lost
                    elif k == "greyed":
                        po[x, y] = grey
        return out

    def close(self):
        self.save_source_state()
        self.app.pv_set_hover(None)
        self.app.pv_set_mark(None)
        if self.lost_win is not None:
            self.lost_win.close()
        if self.filt_win is not None:
            self.filt_win.close()
        self.store_state()
        if self._after is not None:
            self.win.after_cancel(self._after)
        if self._poll_after is not None:
            self.win.after_cancel(self._poll_after)
        self.app.preview = None
        self.win.destroy()
