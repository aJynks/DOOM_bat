"""Ramp tool window."""

import json
import math

from .gui_gradslider import draw_node
import os

from ..cleanpal_lib_colour import hex_of, parse_colour, rgb_round
from ..cleanpal_lib_constants import PRESET_DIR, VERSION, fmt_tol
from ..cleanpal_lib_rampedit import Snapper
from ..cleanpal_lib_ramps import (
    RAMP_CLOSENESS, RAMP_EASES, RAMP_EASE_SCOPES, RAMP_SPACES, _ease, clean_ramp_state,
    default_ramp_state, fit_ramp_nodes, ramp_colour_at, ramp_colours,
)

COPY_BUSY = "Copy ramp is on - only Closeness can change. Press Copy ramp again to finish."


def closeness_var(app):
    """One Closeness setting shared by Paint and Palette Browser."""
    v = getattr(app, "_ramp_close_var", None)
    if v is None:
        want = app.s.get("ramp_closeness")
        v = app.tk.StringVar(value=want if want in RAMP_CLOSENESS else "Normal")
        app._ramp_close_var = v

        def changed(*_a):
            app.s["ramp_closeness"] = v.get()
            r = app.ramp
            if r is not None and getattr(r, "copy", None):
                r.copy_refit()
        v.trace_add("write", changed)
    return v


def copy_toggle_style(btn, on, base_bg):
    try:
        btn.configure(relief="sunken" if on else "raised",
                      background="#7fd47f" if on else base_bg,
                      activebackground="#a6e6a6" if on else base_bg)
    except Exception:  # noqa: BLE001 - window going away
        pass


# ============================================================ ramp tool



MARK_PITCH = 1.2        # Paint steps: line height / square size (marker room)
TOGGLE_COLOUR = "#c9a0ff"   # lavender press-in buttons (CTOOL_COLOUR)
MATCHES = (("rgb", "RGB"), ("oklab", "Perceptual"))

LOCK_MODES = (("slide", "Sliding"), ("drop", "Drop"), ("push", "Push"))


class RampTool:
    """Gradient editor: nodes on a bar, blend space + easing. Fills the
    selected palette cells (blank or filled) in index order."""

    STATE_KEY = "ramp"
    TITLE = "Ramp tool"
    FADE = False
    GEOM_KEY = "ramp_geometry"
    GEOM_DEFAULT = "680x500"
    MIN_SIZE = (560, 420)

    def __init__(self, app):
        from tkinter import ttk

        tk = app.tk
        self.app = app
        s = app.s
        ui = getattr(app, "ui", 1.0)
        self.ui = ui
        try:
            self.st = clean_ramp_state(s.get(self.STATE_KEY) or {})
        except ValueError:
            self.st = default_ramp_state()
        self.active = self.st["nodes"][0]
        self.ru_sync()
        self._drag = None
        self._img = None
        self._strip_cells = []
        self._after = None

        self.win = tk.Toplevel(app.root)
        self.win.title(self.TITLE)
        self.win.transient(app.root)
        self.win.minsize(*self.MIN_SIZE)
        try:
            self.win.geometry(s.get(self.GEOM_KEY) or self.GEOM_DEFAULT)
        except tk.TclError:
            pass
        self.win.columnconfigure(0, weight=1)
        self.win.rowconfigure(4, weight=1)

        gf = ttk.LabelFrame(self.win, padding=(4, 2, 4, 4),
                            text="Gradient (right-click node = select · drag = move · "
                                 "◀ ▶ = one cell · Alt+right-click = add · "
                                 "Alt+click = delete)")
        gf.grid(row=0, column=0, sticky="ew", padx=8, pady=(6, 0))
        gf.columnconfigure(0, weight=1)
        self._flip = False               # Hold button: the other view while held
        self._snap_cache = (None, None)
        self._bar_key = None
        if not self.FADE:                # Paint: True colour / Palettised view
            tf = ttk.Frame(gf)
            tf.grid(row=0, column=0, sticky="w", pady=(0, 4))
            self.true_btn = tk.Button(tf, text="True colour", relief="raised",
                                      command=self._true_click)
            self.true_btn.pack(side="left")
            self._true_bg = self.true_btn.cget("background")
            ttk.Label(tf, text="Match").pack(side="left", padx=(12, 0))
            m = s.get("paint_match")
            self.pmatch_var = tk.StringVar(value=m if m in dict(MATCHES) else "rgb")
            for v, txt in MATCHES:
                ttk.Radiobutton(tf, text=txt, value=v, variable=self.pmatch_var,
                                command=self._pmatch_click).pack(side="left", padx=(6, 0))
            self.view_var = tk.StringVar()
            ttk.Label(tf, textvariable=self.view_var, foreground="#666").pack(
                side="left", padx=(12, 0))
        self.bar = tk.Canvas(gf, height=int(70 * ui), highlightthickness=0,
                             bg="#2a2a2a", cursor="hand2")
        self.bar.grid(row=1, column=0, sticky="ew")
        self.bar.bind("<Configure>", lambda e: self.draw_bar())
        self.bar.bind("<ButtonPress-1>", self._bar_press)
        self.bar.bind("<B1-Motion>", self._bar_motion)
        self.bar.bind("<ButtonRelease-1>", self._bar_release)
        self.bar.bind("<Double-Button-1>", self._bar_double)
        self.bar.bind("<ButtonPress-3>", self._bar_right)

        nf = ttk.Frame(self.win, padding=(8, 6, 8, 0))
        nf.grid(row=1, column=0, sticky="ew")
        self.node_var = tk.StringVar()
        ttk.Label(nf, textvariable=self.node_var, width=13).pack(side="left")
        self.node_sw = tk.Canvas(nf, width=int(44 * ui), height=int(22 * ui),
                                 highlightthickness=1, highlightbackground="#888",
                                 cursor="hand2")
        self.node_sw.pack(side="left")
        self.node_sw.bind("<Button-1>", lambda e: self.open_picker())
        ttk.Label(nf, text="#").pack(side="left", padx=(8, 0))
        self.hex_var = tk.StringVar()
        he = ttk.Entry(nf, textvariable=self.hex_var, width=9)
        he.pack(side="left")
        he.bind("<Return>", lambda e: self._on_hex())
        he.bind("<FocusOut>", lambda e: self._on_hex())
        ttk.Label(nf, text="Pos %").pack(side="left", padx=(8, 0))
        self.pos_var = tk.StringVar()
        self.pos_sp = ttk.Spinbox(nf, textvariable=self.pos_var, from_=0, to=100,
                                  increment=1, width=6, command=self._on_pos)
        self.pos_sp.pack(side="left", padx=(4, 0))
        self.pos_sp.bind("<Return>", lambda e: self._on_pos())
        self.pos_sp.bind("<FocusOut>", lambda e: self._on_pos())
        ttk.Button(nf, text="Picker...", command=self.open_picker).pack(side="left",
                                                                        padx=(8, 0))
        ttk.Button(nf, text="Eyedropper", command=self.node_eyedropper).pack(
            side="left", padx=(6, 0))
        self.left_btn = ttk.Button(nf, text="◀", width=3, command=lambda: self.nudge(-1))
        self.left_btn.pack(side="left", padx=(8, 0))
        self.right_btn = ttk.Button(nf, text="▶", width=3, command=lambda: self.nudge(1))
        self.right_btn.pack(side="left", padx=(2, 0))
        self.del_btn = ttk.Button(nf, text="Delete node", command=self.delete_active)
        self.del_btn.pack(side="left", padx=(6, 0))

        of = ttk.Frame(self.win, padding=(8, 6, 8, 0))
        of.grid(row=2, column=0, sticky="ew")
        self.space_var = tk.StringVar(value=self.st["space"])
        self.ease_var = tk.StringVar(value=self.st["ease"])
        self.str_var = tk.StringVar(value=fmt_tol(self.st["strength"]))
        self.scope_var = tk.StringVar(value=self.st["ease_scope"])
        ttk.Label(of, text="Blend").pack(side="left")
        w = ttk.Combobox(of, textvariable=self.space_var, values=RAMP_SPACES,
                         state="readonly", width=16)
        w.pack(side="left", padx=(4, 0))
        w.bind("<<ComboboxSelected>>", lambda e: self._on_opts())
        ttk.Label(of, text="Ease").pack(side="left", padx=(10, 0))
        w = ttk.Combobox(of, textvariable=self.ease_var, values=RAMP_EASES,
                         state="readonly", width=11)
        w.pack(side="left", padx=(4, 0))
        w.bind("<<ComboboxSelected>>", lambda e: self._on_opts())
        ttk.Label(of, text="Strength").pack(side="left", padx=(10, 0))
        self.str_sp = ttk.Spinbox(of, textvariable=self.str_var, from_=1, to=6,
                                  increment=0.25, width=5, command=self._on_opts)
        self.str_sp.pack(side="left", padx=(4, 0))
        self.str_sp.bind("<Return>", lambda e: self._on_opts())
        self.str_sp.bind("<FocusOut>", lambda e: self._on_opts())
        of2 = ttk.Frame(self.win, padding=(8, 4, 8, 0))
        of2.grid(row=3, column=0, sticky="ew")
        ttk.Label(of2, text="Ease applies to:").pack(side="left")
        self.scope_rbs = []
        for v in RAMP_EASE_SCOPES:
            rb = ttk.Radiobutton(of2, text=v, value=v, variable=self.scope_var,
                                 command=self._on_opts)
            rb.pack(side="left", padx=(6, 0))
            self.scope_rbs.append(rb)
        ttk.Button(of2, text="Reverse", command=self.reverse).pack(side="right")
        self.copy = None                 # Copy ramp mini tool state (Paint)
        self.copy_btn = self.close_cb = None
        if self.FADE:
            ttk.Button(of2, text="Use selection ends",
                       command=self.use_selection_ends).pack(side="right", padx=(0, 6))
        else:
            self.close_cb = ttk.Combobox(of2, textvariable=closeness_var(app),
                                         values=RAMP_CLOSENESS, state="readonly", width=7)
            self.close_cb.pack(side="right", padx=(0, 6))
            self.copy_btn = tk.Button(of2, text="Copy ramp", relief="raised",
                                      command=self.copy_toggle)
            self.copy_btn.pack(side="right", padx=(0, 4))
            self._copy_bg = self.copy_btn.cget("background")
        ttk.Button(of2, text="Clear nodes",
                   command=self.clear_nodes).pack(side="right", padx=(0, 6))

        self.match_var = tk.BooleanVar(value=bool(s.get("ramp_match_rows", False)))
        stitle = "Steps (one per selected cell, index order)"
        if self.FADE:
            sf = ttk.LabelFrame(self.win, text=stitle, padding=6)
        else:                            # Paint: row / size controls in the title
            hf = ttk.Frame(self.win)
            self.sf_title = ttk.Label(hf, text=stitle)
            self.sf_title.pack(side="left")
            ttk.Checkbutton(hf, text="Match palette rows", variable=self.match_var,
                            command=self._match_changed).pack(side="left", padx=(10, 0))
            ttk.Label(hf, text="Locks:").pack(side="left", padx=(12, 2))
            self.locks_var = tk.StringVar(value=dict(LOCK_MODES)[app.paint_lock_mode()])
            self.locks_cb = ttk.Combobox(hf, textvariable=self.locks_var, state="readonly",
                                         values=[t for _k, t in LOCK_MODES], width=8)
            self.locks_cb.pack(side="left")
            self.locks_cb.bind("<<ComboboxSelected>>", lambda e: self._locks_changed())
            sf = ttk.LabelFrame(self.win, labelwidget=hf, padding=6)
        sf.grid(row=4, column=0, sticky="nsew", padx=8, pady=(8, 0))
        sf.columnconfigure(0, weight=1)
        sf.rowconfigure(0, weight=1)
        self.strip = tk.Canvas(sf, height=int(60 * ui), highlightthickness=0, bg="#2a2a2a")
        self.strip.grid(row=0, column=0, sticky="nsew")
        self.strip.bind("<Configure>", lambda e: self.draw_strip())
        self.strip.bind("<Motion>", self._strip_hover)
        self.strip.bind("<Leave>", lambda e: self.info_var.set(""))
        r0 = 1
        if not self.FADE:                # Paint: grip - drag to resize the steps box
            g = tk.Canvas(sf, height=max(6, int(7 * ui)), highlightthickness=0,
                          bg="#3c3c3c", cursor="sb_v_double_arrow")
            g.grid(row=1, column=0, sticky="ew")
            g.bind("<Configure>", lambda e: self._draw_grip())
            g.bind("<ButtonPress-1>", self._grip_press)
            g.bind("<B1-Motion>", self._grip_motion)
            g.bind("<ButtonRelease-1>", lambda e: setattr(self, "_grip", None))
            self.grip = g
            self._grip = None
            r0 = 2
        self.info_var = tk.StringVar()
        ttk.Label(sf, textvariable=self.info_var, font=("Consolas", 9)).grid(
            row=r0, column=0, sticky="w", pady=(4, 0))
        self.skip_cells = set()          # Paint: cells crossed out by hand
        if not self.FADE:
            fcf = ttk.Frame(sf)
            fcf.grid(row=r0 + 1, column=0, sticky="w", pady=(4, 0))
            ttk.Button(fcf, text="Fill cells", command=self.fill_cells).pack(side="left")
            ttk.Label(fcf, text="picker = one colour into every selected cell, live; "
                                "closing the picker finishes it",
                      foreground="#888").pack(side="left", padx=(8, 0))
            r0 += 1
            uf = ttk.Frame(sf)
            uf.grid(row=r0 + 1, column=0, sticky="w", pady=(4, 0))
            self.edsel = False
            self.edsel_btn = tk.Button(uf, text="Edit Selection", relief="raised",
                                       command=self.edsel_toggle)
            self.edsel_btn.pack(side="left")
            self._edsel_bg = self.edsel_btn.cget("background")
            self.edsel_btns = []
            for txt, cmd in (("Add", app.paint_sel_add), ("Remove", app.paint_sel_remove),
                             ("Align edits", app.paint_sel_align)):
                b = ttk.Button(uf, text=txt, width=11 if txt == "Align edits" else 7,
                               command=cmd)
                b.pack(side="left", padx=(4, 0))
                self.edsel_btns.append(b)
            ttk.Label(sf, foreground="#888", wraplength=int(760 * ui), justify="left",
                      text="••• under a step = the selected node · white O = same colour "
                           "as an earlier step · orange O = colour already elsewhere in the "
                           "palette (O marks only - every step is painted) · red X = not "
                           "painted (Edit Selection) · padlock = locked cell, step not "
                           "painted (Locks: Drop) · Locks: Sliding = locked cells left out, "
                           "Drop = their steps skipped, Push = extra cells after the "
                           "selection").grid(row=r0 + 2, column=0,
                                                            sticky="w", pady=(2, 0))
            self.strip.bind("<ButtonPress-1>", self._strip_click)
            self.strip.bind("<ButtonPress-3>", self._strip_right)
            self._edsel_ui()

        ff = ttk.Frame(self.win, padding=(8, 8, 8, 0))
        ff.grid(row=5, column=0, sticky="ew")
        ttk.Button(ff, text="Load ramp...", command=self.load_ramp).pack(side="left")
        ttk.Button(ff, text="Save ramp...", command=self.save_ramp).pack(side="left",
                                                                         padx=(6, 0))
        ttk.Button(ff, text="Scratch palette...",
                   command=app.open_scratch).pack(side="right")
        if not self.FADE:                # Paint: pick colours off the art
            ttk.Button(ff, text="Sample region...",
                       command=app.sample_region).pack(side="right", padx=(0, 6))
        bf = ttk.Frame(self.win, padding=8)
        bf.grid(row=6, column=0, sticky="ew")
        self.btn_frame = bf
        self.prev_btn = tk.Button(bf, text="Preview: OFF", width=12, relief="raised",
                                  command=self.toggle_preview)
        self._btn_bg = self.prev_btn.cget("background")
        self.prev_btn.pack(side="left")
        if not self.FADE:
            self.hold_btn = tk.Button(bf, text="Hold: palettised", relief="raised",
                                      width=16)
            self.hold_btn.pack(side="left", padx=(6, 0))
            self.hold_btn.bind("<ButtonPress-1>", lambda e: self._hold(True))
            self.hold_btn.bind("<ButtonRelease-1>", lambda e: self._hold(False))
            self.hold_btn.bind("<Leave>", lambda e: self._hold(False) if self._flip
                               else None)
            self._true_ui()
        self.apply_btn = ttk.Button(bf, text="Apply", command=self.apply)
        self.apply_btn.pack(side="left", padx=(6, 0))
        self.cancel_btn = ttk.Button(bf, text="Cancel", command=self.cancel)
        self.cancel_btn.pack(side="left", padx=(6, 0))
        self.close_btn = ttk.Button(bf, text="Close", command=self.close)
        self.close_btn.pack(side="right")

        def get():
            return tuple(self.active["rgb"])

        def put(rgb):
            self.set_node_colour(self.active, rgb)
            p = app.picker
            if p is not None and getattr(p, "owner", None) is self:
                self._target_picker(p)
        app.register_colour_widget(he, get, put)
        app.register_colour_widget(self.pos_sp, get, put)
        self.node_sw.bind("<Button-3>", lambda e: app.colour_menu(e, get, put))

        self.win.protocol("WM_DELETE_WINDOW", self.close)
        self.win.bind("<Delete>", self._on_del_key)
        self.win.bind("<Escape>", lambda e: self.cancel() if self.previewing() else None)
        self.sf = sf
        self.reverse_btn = [w for w in of2.winfo_children() if w.winfo_class() == "TButton"]

        self.setup()
        self.update_buttons()
        self.changed(store=False)
        app.recompute()
        self._fit_width()

    def _fit_width(self):
        """Widen the window (never shrink it) if its rows need more room than
        the saved size gives them, so no button is cut off."""
        w = self.win
        try:
            w.update_idletasks()
            need, have = w.winfo_reqwidth(), w.winfo_width()
            if have > 1 and need > have:
                w.geometry("%dx%d" % (need, w.winfo_height()))
        except self.app.tk.TclError:
            pass

    # ---------------------------------------------------------- hooks (fade mode overrides)
    def setup(self):
        pass

    def previewing(self):
        return self.app._ramp_backup is not None

    # ---------------------------------------------------------- helpers
    def nodes(self):
        return self.st["nodes"]

    def idx(self, node):
        for k, n in enumerate(self.nodes()):
            if n is node:
                return k
        return 0

    def _bar_geom(self):
        W = max(self.bar.winfo_width(), 40)
        H = max(self.bar.winfo_height(), 40)
        m = int(12 * self.ui)
        return m, W - m, 4, H - int(24 * self.ui), H

    def _x(self, t):
        x0, x1, _y0, _y1, _H = self._bar_geom()
        return x0 + t * (x1 - x0)

    def _t(self, x):
        x0, x1, _y0, _y1, _H = self._bar_geom()
        return min(max((x - x0) / max(x1 - x0, 1), 0.0), 1.0)

    # node positions live in eased space when easing applies to the whole
    # ramp; the bar shows them where their colour actually appears
    def _whole(self):
        return self.st["ease_scope"] == "Whole ramp" and self.st["ease"] != "Linear"

    def _to_pos(self, t):
        return _ease(t, self.st["ease"], self.st["strength"]) if self._whole() else t

    def _to_bar(self, pos):
        if not self._whole():
            return pos
        lo, hi = 0.0, 1.0
        for _ in range(40):
            mid = (lo + hi) / 2.0
            if _ease(mid, self.st["ease"], self.st["strength"]) < pos:
                lo = mid
            else:
                hi = mid
        return (lo + hi) / 2.0

    def targets(self):
        """The ramp's step cells (Locks mode: Sliding leaves locked cells
        out, Drop keeps them as unpainted steps, Push adds cells after)."""
        a = self.app
        if a._ramp_backup is not None:
            return list(a._ramp_targets)
        if self.FADE or not hasattr(a, "ramp_plan"):
            return sorted(a.selection)
        return list(a.ramp_plan()["steps"])

    def colours(self, n=None):
        return ramp_colours(self.st, len(self.targets()) if n is None else n)

    def _base(self):
        """The strip the steps are written onto (Push: already pushed)."""
        a = self.app
        if self.FADE or not hasattr(a, "ramp_plan"):
            return a._ramp_backup[0] if a._ramp_backup else a.rgbs
        if a._ramp_backup is not None:
            plan = getattr(a, "_ramp_plan", None)
            return plan["base"] if plan is not None else a._ramp_backup[0]
        return a.ramp_plan()["base"] if a.rgbs is not None else None

    def step_plan(self):
        """[(cell, colour, why)] per step: why = None (painted), "marked"
        (red X - Edit Selection: not painted), "locked" (padlock - Locks:
        Drop, not painted), "dup" (white O - same as an
        earlier step) or "inpal" (orange O - already elsewhere in the palette /
        below the line). White / orange are only marks: those steps ARE
        painted."""
        tg = self.targets()
        cs = self.colours()
        if self.FADE:
            return [(i, c, None) for i, c in zip(tg, cs)]
        base = self._base() or []
        tset = set(tg)
        have = {tuple(c) for i, c in enumerate(base) if c is not None and i not in tset}
        out, seen = [], set()
        lk = self.app.locked
        for i, c in zip(tg, cs):
            c = tuple(c)
            if i in lk:                          # Locks: Drop - step not written
                out.append((i, c, "locked"))
                continue
            if i in self.skip_cells:
                out.append((i, c, "marked"))
                continue
            why = "dup" if c in seen else "inpal" if c in have else None
            seen.add(c)
            out.append((i, c, why))
        return out

    def out_colours(self):
        """What each target cell gets: the step colour, or - skipped steps -
        the colour it already had (None = stays empty)."""
        base = self._base() or []
        return [c if why not in ("marked", "locked") else
                (base[i] if i < len(base) else None)
                for i, c, why in self.step_plan()]

    def _locks_changed(self):
        a = self.app
        key = {t: k for k, t in LOCK_MODES}.get(self.locks_var.get(), "slide")
        a.s["paint_locks"] = key
        if a._ramp_backup is not None:        # live preview: rebuild on the new cells
            a._ramp_restore_base()
            a._ramp_retarget()
            self.skip_cells &= set(a._ramp_targets)
            a.ramp_preview_set(self.out_colours())
        self._bar_key = None
        self.update_buttons()
        self.draw_strip()
        a.status_var.set("Locks: %s - %s" % (self.locks_var.get(), {
            "slide": "locked cells are left out of the ramp",
            "drop": "one step per selected cell; locked steps aren't painted",
            "push": "one step per selected cell; locked cells push the ramp on into "
                    "the cells after the selection"}[key]))

    def _match_changed(self):
        self.app.s["ramp_match_rows"] = bool(self.match_var.get())
        self.draw_strip()

    def _draw_grip(self):
        g = self.grip
        g.delete("all")
        W, H = g.winfo_width(), g.winfo_height()
        u = max(1.0, self.ui)
        for k in (-1, 0, 1):
            x = W / 2.0 + k * 6 * u
            g.create_oval(x - u, H / 2.0 - u, x + u, H / 2.0 + u, fill="#aaaaaa",
                          outline="")

    def _grip_press(self, ev):
        self._grip = (ev.y_root, self.win.winfo_height(), self.strip.winfo_height())

    def _grip_motion(self, ev):
        """Drag the grip: the whole window grows / shrinks by the same amount,
        the steps box (the window's stretchy row) takes it all."""
        if not self._grip:
            return
        y0, wh0, ch0 = self._grip
        dy = ev.y_root - y0
        dy = max(dy, int(40 * self.ui) - ch0)                 # box minimum
        dy = min(dy, self.win.winfo_screenheight() - 40 - wh0)  # stay on screen
        try:
            self.win.geometry("%dx%d" % (self.win.winfo_width(), wh0 + dy))
        except self.app.tk.TclError:
            pass

    @staticmethod
    def best_cols(n, aw, ah):
        """One continuous line of n steps wrapped like text in aw x ah: the
        biggest square size that still fits them all, and as many squares per
        line as that size allows (so lines run the full width)."""
        n = max(n, 1)
        bc = 0.0
        for cols in range(1, n + 1):
            rows = (n + cols - 1) // cols
            bc = max(bc, min(aw / cols, ah / rows))
        cols = max(1, min(n, int(aw / bc + 1e-6))) if bc > 0 else n
        return cols, bc

    @staticmethod
    def palette_slots(tg):
        """Lay sorted cell indices out like the 16-wide palette.
        Returns [(line, col, k_or_None)]: k = step number, None = a gap arrow.
        Runs keep their real columns and always wrap at a palette row end; a
        gap becomes one arrow, and the next run follows it on the same line if
        it fits in 16, else starts a new line at its real column."""
        pieces = []                                  # [start index, [k...]]
        for k, i in enumerate(tg):
            if pieces and i == tg[k - 1] + 1 and i % 16:
                pieces[-1][1].append(k)
            else:
                pieces.append([i, [k]])
        out = []
        line, col, prev_end = 0, 0, None
        for start, ks in pieces:
            n = len(ks)
            if prev_end is None:
                col = start % 16
            elif start == prev_end + 1:              # same run, next palette row
                line, col = line + 1, start % 16
            else:                                    # gap: one arrow
                out.append((line, col, None))
                col += 1
                if col + n > 16:
                    line, col = line + 1, start % 16
            for k in ks:
                out.append((line, col, k))
                col += 1
            prev_end = tg[ks[-1]]
        return out

    def _strip_step(self, ev):
        """(step k, cell slot) under the mouse in the steps box, or (None, None)."""
        ex_, ey_ = self.strip.canvasx(ev.x), self.strip.canvasy(ev.y)
        for x, y, cell, k, _col, _dup, _ex, slot, _sh in self._strip_cells:
            if x <= ex_ < x + cell and y <= ey_ < y + cell:
                return k, slot
        return None, None

    def _note(self, txt):
        self.info_var.set(txt)
        self.app.status_var.set(txt)
        self.app.root.after(60, lambda: self.app.status_var.set(txt))

    def _strip_click(self, ev):
        """Left-click a step: select the node on it; Alt = delete that node.
        Edit Selection: toggle the step's X (not painted)."""
        k, slot = self._strip_step(ev)
        if k is None:
            return
        if getattr(self, "edsel", False):
            self.skip_cells ^= {slot}
            self.changed(store=False)
            self._strip_hover(ev)
            return
        if self.app._alt_down(ev):
            self._note(self.delete_node_at_step(k))
        else:
            self._note(self.select_node_at_step(k))

    def edsel_toggle(self):
        self.edsel = not self.edsel
        self._edsel_ui()
        a = self.app
        a.status_var.set("Edit Selection: select cells in the main grid (click, drag, Ctrl, "
                         "Shift); click a step = X." if self.edsel else
                         "Selection locked and its outline hidden - press Edit Selection "
                         "to change it.")
        a.redraw()

    def _edsel_ui(self):
        on = self.edsel
        bg = TOGGLE_COLOUR if on else self._edsel_bg
        self.edsel_btn.configure(relief="sunken" if on else "raised", background=bg,
                                 activebackground=bg,
                                 text="Editing selection (click to stop)" if on
                                 else "Edit Selection")
        for b in self.edsel_btns:
            b.state(["!disabled"] if on else ["disabled"])
        self.sf_title.configure(
            text="Ramp steps – Edit Selection (click = X · Add / Remove / Align edits)" if on
            else "Ramp steps (click / right-click = select node · Alt+right-click = add · "
                 "Alt+click = delete)")

    # ---------------------------------------------------------- true colour / palettised
    def truecol(self):
        """True = the gradient bar and steps show the true colours; False =
        each step snapped to the nearest pal0 colour (VIEW ONLY - Apply and
        Snapshot always paint the true colours)."""
        if self.FADE:
            return True
        return bool(self.app.s.get("paint_true", True)) != self._flip

    def _true_click(self):
        self._flip = False
        self.app.s["paint_true"] = not bool(self.app.s.get("paint_true", True))
        self._true_ui()
        self._redraw_view()

    def _pmatch_click(self):
        self.app.s["paint_match"] = self.pmatch_var.get()
        self._redraw_view()

    def _hold(self, on):
        on = bool(on)
        if on == self._flip:
            return
        self._flip = on
        try:
            self.hold_btn.configure(relief="sunken" if on else "raised")
        except self.app.tk.TclError:
            pass
        self._redraw_view()

    def _true_ui(self):
        on = bool(self.app.s.get("paint_true", True))
        bg = TOGGLE_COLOUR if on else self._true_bg
        try:
            self.true_btn.configure(relief="sunken" if on else "raised", background=bg,
                                    activebackground=bg,
                                    text="True colour (on)" if on else "True colour")
            self.hold_btn.configure(text="Hold: palettised" if on else "Hold: true colour")
            self.view_var.set("" if self.truecol() else
                              "Palettised view - Apply paints the true colours")
        except (AttributeError, self.app.tk.TclError):
            pass

    def _redraw_view(self):
        self._bar_key = None
        self.draw_bar()
        self.draw_strip()
        self._true_ui()

    def _view_snap(self):
        """Snapper onto pal0 minus the cells being painted (and deleted /
        empty ones), or None in the true-colour view."""
        if self.truecol():
            return None
        a = self.app
        base = self._base() or []
        deleted = a._ramp_backup[3] if a._ramp_backup else a.deleted
        tg = tuple(self.targets())
        metric = self.app.s.get("paint_match")
        metric = metric if metric in dict(MATCHES) else "rgb"
        key = (tuple(base[:256]), tg, frozenset(deleted), metric)
        if self._snap_cache[0] != key:
            sn = Snapper(base, set(deleted) | set(tg), metric, limit=256)
            self._snap_cache = (key, sn if sn.idx else False)
        return self._snap_cache[1] or None

    def _snap_rgb(self, sn, rgb):
        """(shown colour, pal0 index or None)."""
        from ..cleanpal_lib_colour import oklab
        rgb = tuple(rgb)
        j = sn.nearest(oklab(rgb) if sn.metric != "rgb" else None, rgb)
        if j is None:
            return rgb, None
        return tuple(self._base()[j]), j

    # ---------------------------------------------------------- drawing
    def draw_bar(self):
        from PIL import Image, ImageTk

        c = self.bar
        x0, x1, y0, y1, H = self._bar_geom()
        c.delete("all")
        w = int(x1 - x0)
        if w < 4 or int(y1 - y0) < 1:   # not laid out yet - redrawn later
            return
        strip = Image.new("RGB", (200, 1))
        sn = self._view_snap()
        n = len(self.targets())
        self._bar_key = (self._snap_cache[0] if sn is not None else None, n)
        if sn is None:
            px = [rgb_round(ramp_colour_at(self.st, i / 199.0)) for i in range(200)]
        elif n >= 2:                     # one block per step, snapped
            cs = [self._snap_rgb(sn, col)[0] for col in self.colours()]
            px = [cs[int(round(i / 199.0 * (n - 1)))] for i in range(200)]
        else:
            px = [self._snap_rgb(sn, rgb_round(ramp_colour_at(self.st, i / 199.0)))[0]
                  for i in range(200)]
        strip.putdata(px)
        self._img = ImageTk.PhotoImage(strip.resize(
            (w, int(y1 - y0)), Image.BILINEAR if sn is None else Image.NEAREST))
        c.create_image(x0, y0, anchor="nw", image=self._img)
        c.create_rectangle(x0 - 1, y0 - 1, x1, y1, outline="#000000")
        sz = 9 * self.ui
        for n in self.nodes():
            x = self._x(self._to_bar(n["pos"]))
            act = n is self.active
            c.create_line(x, y0, x, y1, fill="#000000" if act else "", width=1)
            pts = (x, y1 + 2, x - sz, y1 + 2 + sz * 1.6, x + sz, y1 + 2 + sz * 1.6)
            draw_node(c, pts, hex_of(n["rgb"]), act, self.ui)

    def draw_strip(self):
        c = self.strip
        c.delete("all")
        tg = self.targets()
        n = len(tg)
        self._strip_cells = []
        W = max(c.winfo_width(), 40)
        if n == 0:
            c.create_text(10, 20, anchor="w", fill="#bbbbbb",
                          text="Select cells in the main grid (blank or filled) - "
                               "one ramp step per cell.")
            return
        avail = W - 8
        availh = max(c.winfo_height(), 20) - 8
        if self.FADE:
            cols = min(n, 32)
            cell = min(40 * self.ui, avail / cols)
            rows = (n + cols - 1) // cols
            pos = [((k // cols), (k % cols), k) for k in range(n)]
        else:
            # auto-fit: the biggest squares that fit the box (drag the grip);
            # each line is a bit taller than its squares - room under them
            # for the selected-node marker
            if self.match_var.get():
                pos = self.palette_slots(tg)
                rows = max(p[0] for p in pos) + 1
                cell = min(avail / 17.0, availh / (rows * MARK_PITCH))  # + gap arrow
            else:
                cols, cell = self.best_cols(n, avail, availh / MARK_PITCH)
                pos = [((k // cols), (k % cols), k) for k in range(n)]
            cell = max(cell, 3.0)
        if self.FADE:
            need = int(((n + cols - 1) // cols) * cell + 8)
            if int(c.cget("height")) < need:
                c.configure(height=need)
        plan = self.step_plan()
        cs = [c for _i, c, _w in plan]
        sn = None if self.FADE else self._view_snap()
        if not self.FADE and self._bar_key != (self._snap_cache[0] if sn is not None
                                               else None, n):
            self.draw_bar()              # the palettised bar depends on the steps
        shown = ([self._snap_rgb(sn, col) for col in cs] if sn is not None
                 else [(col, None) for col in cs])
        base = self._base()
        deleted = self.app._ramp_backup[3] if self.app._ramp_backup else self.app.deleted
        tset = set(tg)
        where = {}
        if base is not None:
            for i, col in enumerate(base):
                if col is not None and i not in tset and i not in deleted:
                    where.setdefault(tuple(col), i)
        seen = {}
        pitch = cell * (1.0 if self.FADE else MARK_PITCH)
        kxy = {}
        for line, cx, k in pos:
            x = 4 + cx * cell
            y = 4 + line * pitch
            if k is not None:
                kxy[k] = (x, y, line)
            if k is None:                             # gap between runs
                c.create_rectangle(x, y, x + cell - 2, y + cell - 2, fill="#1a1a1a",
                                   outline="#555555")
                m = (cell - 2) / 2.0
                c.create_line(x + cell * 0.2, y + m, x + cell * 0.8 - 2, y + m,
                              fill="#bbbbbb", width=max(1, round(cell / 14)),
                              arrow="last",
                              arrowshape=(max(4, cell / 4), max(5, cell / 3.5),
                                          max(2, cell / 9)))
                continue
            col = cs[k]
            c.create_rectangle(x, y, x + cell - 2, y + cell - 2, fill=hex_of(shown[k][0]),
                               outline="")
            dup = seen.get(col)
            ex = where.get(col)
            seen.setdefault(col, k)
            why = plan[k][2]
            lw = max(2, round(cell / 12))
            if why == "locked":                       # padlock: Locks: Drop
                self.app._draw_lock_mark(c, x, y, cell - 2)
            elif why == "marked":                     # red X: not painted
                for xa, ya, xb, yb in ((x + 3, y + 3, x + cell - 5, y + cell - 5),
                                       (x + cell - 5, y + 3, x + 3, y + cell - 5)):
                    c.create_line(xa, ya, xb, yb, fill="#000000", width=lw + 2)
                    c.create_line(xa, ya, xb, yb, fill="#ff4040", width=lw)
            elif why in ("dup", "inpal"):             # O: just a mark
                i0 = cell * 0.3
                box = (x + i0, y + i0, x + cell - 2 - i0, y + cell - 2 - i0)
                c.create_oval(*box, outline="#000000", width=lw + 2)
                c.create_oval(*box, outline="#ffffff" if why == "dup" else "#ff9a2e",
                              width=lw)
            self._strip_cells.append((x, y, cell, k, col, dup, ex, tg[k], shown[k]))
        if not self.FADE and n >= 2:
            self._draw_node_mark(c, kxy, cell, n)

    def _draw_node_mark(self, c, kxy, cell, n):
        """Three white dots under the step the SELECTED node sits on (under
        the gap when it's between two cells) - nothing drawn on the colours."""
        u = self._to_bar(self.active["pos"]) * (n - 1)
        k = int(math.floor(u + 1e-6))
        f = u - k
        if f > 1 - 1e-6:
            k, f = k + 1, 0.0
        k = min(max(k, 0), n - 1)
        if k not in kxy:
            return
        x, y, line = kxy[k]
        cx = x + (cell - 2) / 2.0
        if f > 1e-6 and k + 1 in kxy:
            x2, _y2, line2 = kxy[k + 1]
            cx = cx + (x2 - x) * f if line2 == line else x + cell - 1
        gap = max(2.0, cell * 0.05)
        band = cell * (MARK_PITCH - 1.0) - gap
        cy = y + cell - 2 + gap + band / 2.0
        r = max(1.5, min(cell / 16.0, band / 2.5))
        for d in (-3.2, 0.0, 3.2):
            c.create_oval(cx + d * r - r, cy - r, cx + d * r + r, cy + r,
                          fill="#ffffff", outline="")

    def _strip_right(self, ev):
        """Right-click a step: select the node on it. Alt+right-click: add a
        node exactly where that step sits (the gradient's colour there, so
        nothing changes) - not selected."""
        k, _slot = self._strip_step(ev)
        if k is None or getattr(self, "edsel", False):
            return
        if self.app._alt_down(ev):
            self._note(self.node_at_step(k, select=False))
        else:
            self._note(self.select_node_at_step(k))

    def _step_node(self, k):
        """(bar position of step k, the node sitting on it or None)."""
        n = len(self.targets())
        if n < 2:
            return None, None
        t = k / (n - 1.0)                           # where the step sits on the bar
        near = 0.5 / (n - 1.0)
        hit = min(self.nodes(), key=lambda q: abs(self._to_bar(q["pos"]) - t))
        return t, (hit if abs(self._to_bar(hit["pos"]) - t) < near else None)

    def select_node_at_step(self, k):
        t, hit = self._step_node(k)
        if hit is None:
            return "No node on step %d (Alt+right-click adds one)." % (k + 1)
        self.set_active(hit)
        return "Node %d selected (step %d)." % (self.idx(hit) + 1, k + 1)

    def node_at_step(self, k, select=False):
        """Add a node exactly on step k (the gradient's colour there, so nothing
        changes). Not selected unless select. -> status text."""
        t, hit = self._step_node(k)
        if t is None:
            return "The ramp needs at least 2 cells."
        if hit is not None:
            return "There's already a node on step %d (right-click selects it)." % (k + 1)
        self._add_node_at(t, select)
        return "Node added at step %d - right-click it to select it." % (k + 1)

    def _add_node_at(self, t, select=False):
        """New node at bar position t (0..1) in the gradient's colour there."""
        col = rgb_round(ramp_colour_at(self.st, t))
        node = {"pos": min(max(self._to_pos(t), 0.001), 0.999), "rgb": list(col),
                "hsl": None}
        nodes = self.nodes()
        nodes.append(node)
        nodes.sort(key=lambda q: q["pos"])
        if select:
            self.set_active(node)
        self.changed()
        return node

    def delete_node_at_step(self, k):
        t, hit = self._step_node(k)
        if hit is None:
            return "No node on step %d." % (k + 1)
        i = self.idx(hit)
        if i in (0, len(self.nodes()) - 1):
            return "The start and end nodes can't be deleted."
        self.delete_node(hit)
        return "Node on step %d deleted." % (k + 1)

    def _strip_hover(self, ev):
        ex_, ey_ = self.strip.canvasx(ev.x), self.strip.canvasy(ev.y)
        for x, y, cell, k, col, dup, ex, slot, sh in self._strip_cells:
            if x <= ex_ < x + cell and y <= ey_ < y + cell:
                t = "Step %d -> index %d   %s   %d,%d,%d" % ((k + 1, slot, hex_of(col))
                                                           + tuple(col))
                if sh[1] is not None:
                    t += "   shown as pal0 %d %s" % (sh[1], hex_of(sh[0]))
                if dup is not None:
                    t += "   same as step %d" % (dup + 1)
                if ex is not None:
                    t += "   already in palette at %d" % ex
                why = next((w for i, _c, w in self.step_plan() if i == slot), None)
                if why == "marked":
                    t += "   NOT PAINTED (red X)"
                elif why == "locked":
                    t += "   NOT PAINTED (locked - Locks: Drop)"
                self.info_var.set(t)
                return
        self.info_var.set("")

    def refresh_node_row(self):
        n = self.active
        k = self.idx(n)
        last = len(self.nodes()) - 1
        self.node_var.set("Node %d/%d" % (k + 1, last + 1) + (
            " (start)" if k == 0 else " (end)" if k == last else ""))
        self.node_sw.configure(background=hex_of(n["rgb"]))
        self.hex_var.set(hex_of(n["rgb"])[1:])
        self.pos_var.set(fmt_tol(round(self._to_bar(n["pos"]) * 100.0, 2)))
        end = k in (0, last)
        self.pos_sp.state(["disabled"] if end else ["!disabled"])
        self.del_btn.state(["disabled"] if end or getattr(self, "copy", None)
                           else ["!disabled"])
        for b in (self.left_btn, self.right_btn):
            b.state(["disabled"] if end or getattr(self, "copy", None) else ["!disabled"])

    def ru_sync(self):
        """The ramp as the undo list last saw it."""
        self._ru_st = json.loads(json.dumps(self.st))

    def changed(self, store=True):
        self.draw_bar()
        self.refresh_node_row()
        self.draw_strip()
        if store:
            self.app.s[self.STATE_KEY] = json.loads(json.dumps(self.st))
            if not self.FADE and self.st != self._ru_st:
                if not getattr(self.app, "_pu_applying", False):
                    self.app._pu_ramp(self._ru_st, json.loads(json.dumps(self.st)),
                                      bool(getattr(self, "copy", None)))
                self.ru_sync()
        if self.previewing():
            if self._after is not None:
                self.win.after_cancel(self._after)
            self._after = self.win.after(50, self._push_preview)

    def _push_preview(self):
        self._after = None
        if self.app._ramp_backup is not None:
            self.app.ramp_preview_set(self.out_colours())

    # ---------------------------------------------------------- nodes
    def set_active(self, node):
        self.active = node
        self.changed(store=False)
        p = self.app.picker
        if p is not None and getattr(p, "owner", None) is self:
            self._target_picker(p)

    def _target_picker(self, p):
        node = self.active
        k = self.idx(node)
        p.owner = self
        p.set_target(lambda rgb, hsl, nd=node: self.set_node_colour(nd, rgb, hsl),
                     tuple(node["rgb"]), node.get("hsl"),
                     "ramp node %d of %d" % (k + 1, len(self.nodes())))

    def open_picker(self):
        p = self.app.open_picker()
        self._target_picker(p)

    def node_eyedropper(self):
        """Screen eyedropper straight onto the active node (no Picker window)."""
        from .gui_picker import EyeDropper
        node = self.active
        EyeDropper(self.app, lambda rgb, nd=node: self._dropped_node(nd, rgb))

    def _dropped_node(self, node, rgb):
        self.set_node_colour(node, tuple(rgb))
        p = self.app.picker
        if p is not None and getattr(p, "owner", None) is self \
                and not getattr(self, "_picker_fill", False) \
                and getattr(self, "cell_target", None) is None and node is self.active:
            RampTool._target_picker(self, p)        # keep an open Picker in step

    def set_node_colour(self, node, rgb, hsl=None):
        if not any(n is node for n in self.nodes()):
            return
        node["rgb"] = list(rgb)
        node["hsl"] = list(hsl) if hsl else None
        self.changed()

    def _hit(self, x, y):
        x0, x1, y0, y1, H = self._bar_geom()
        best, bd = None, 10 * self.ui
        for n in self.nodes():
            d = abs(self._x(self._to_bar(n["pos"])) - x)
            if d <= bd and (y >= y1 - 2 or d <= 4 * self.ui):
                best, bd = n, d
        return best

    # Node rules (every gradient bar): right-click a node = select it;
    # left-drag = move the SELECTED node only; Alt+right-click = add a node
    # (not selected); Alt+left-click a node = delete it.
    def _bar_press(self, ev):
        self._drag = None
        n = self._hit(ev.x, ev.y)
        if self.app._alt_down(ev):
            if n is None:
                return
            k = self.idx(n)
            if k in (0, len(self.nodes()) - 1):
                self.info_var.set("The start and end nodes can't be deleted.")
                return
            self.delete_node(n)
            self.info_var.set("Node deleted.")
            return
        if n is None or n is not self.active:
            if n is not None:
                self.info_var.set("Right-click a node to select it, then drag it.")
            return
        k = self.idx(n)
        if 0 < k < len(self.nodes()) - 1:
            self._drag = n

    def _bar_motion(self, ev):
        n = self._drag
        if n is None:
            return
        n["pos"] = min(max(self._to_pos(self._t(ev.x)), 0.001), 0.999)
        self.nodes().sort(key=lambda q: q["pos"])
        self.changed(store=False)

    def _bar_release(self, _ev):
        if self._drag is not None:
            self._drag = None
            self.changed()

    def _bar_double(self, ev):
        n = self._hit(ev.x, ev.y)
        if n is not None and n is self.active and not self.app._alt_down(ev):
            self.open_picker()

    def _bar_right(self, ev):
        n = self._hit(ev.x, ev.y)
        if self.app._alt_down(ev):
            if n is not None:
                self.info_var.set("There's a node there already - right-click selects it.")
                return
            self._add_node_at(self._t(ev.x))
            self.info_var.set("Node added - right-click it to select it.")
            return
        if n is not None:
            self.set_active(n)

    def nudge(self, d):
        """Move the selected node one cell (one step) left / right; from
        between two cells it lands on the next cell in that direction."""
        n = self.active
        k = self.idx(n)
        if k in (0, len(self.nodes()) - 1):
            return
        cells = len(self.targets())
        if cells < 3:
            self.info_var.set("Select at least 3 cells to step a node between them.")
            return
        steps = cells - 1
        u = self._to_bar(n["pos"]) * steps
        j = (math.floor(u + 1e-6) + 1) if d > 0 else (math.ceil(u - 1e-6) - 1)
        if j <= 0 or j >= steps:
            self.info_var.set("The node is next to the %s already." % (
                "end" if d > 0 else "start"))
            return
        n["pos"] = min(max(self._to_pos(j / float(steps)), 0.001), 0.999)
        self.nodes().sort(key=lambda q: q["pos"])
        self.changed()
        self.info_var.set("Node on step %d." % (j + 1))

    def delete_node(self, n):
        nodes = self.nodes()
        k = self.idx(n)
        if k in (0, len(nodes) - 1):
            return
        del nodes[k]
        if self.active is n:
            self.set_active(nodes[min(k, len(nodes) - 1)])
        self.changed()

    def delete_active(self):
        self.delete_node(self.active)

    def _on_del_key(self, ev):
        if ev.widget.winfo_class() in ("TEntry", "Entry", "TSpinbox", "Spinbox"):
            return
        self.delete_active()

    def _on_hex(self):
        c = parse_colour(self.hex_var.get())
        if c is None:
            self.refresh_node_row()
            return
        if tuple(self.active["rgb"]) != c:
            self.set_node_colour(self.active, c)
            p = self.app.picker
            if p is not None and getattr(p, "owner", None) is self:
                self._target_picker(p)

    def _on_pos(self):
        k = self.idx(self.active)
        if k in (0, len(self.nodes()) - 1):
            return
        try:
            v = float(self.pos_var.get())
        except ValueError:
            self.refresh_node_row()
            return
        self.active["pos"] = min(max(self._to_pos(min(max(v / 100.0, 0.0), 1.0)),
                                     0.001), 0.999)
        self.nodes().sort(key=lambda q: q["pos"])
        self.changed()

    def _on_opts(self):
        self.st["space"] = self.space_var.get()
        self.st["ease"] = self.ease_var.get()
        self.st["ease_scope"] = self.scope_var.get()
        try:
            v = float(self.str_var.get())
            self.st["strength"] = min(max(v, 1.0), 6.0)
        except ValueError:
            pass
        self.str_var.set(fmt_tol(self.st["strength"]))
        self.changed()

    def reverse(self):
        nodes = self.nodes()
        for n in nodes:
            n["pos"] = 1.0 - n["pos"]
        nodes.reverse()
        nodes[0]["pos"], nodes[-1]["pos"] = 0.0, 1.0
        self.set_active(self.active)
        self.changed()

    def clear_nodes(self):
        """Back to a plain two-node ramp: start white, end black (blend / ease
        settings kept)."""
        nodes = self.nodes()
        start, end = nodes[0], nodes[-1]
        start.update(pos=0.0, rgb=[255, 255, 255], hsl=None)
        end.update(pos=1.0, rgb=[0, 0, 0], hsl=None)
        nodes[:] = [start, end]
        self.set_active(start)
        self.changed()

    # ---------------------------------------------------------- Copy ramp (mini tool)
    # On: the ramp's nodes are fitted live to a source run of colours (main
    # palette cells captured on press, or the Palette Browser selection); the rest of
    # the Paint UI is locked except Closeness / Preview / Apply / Cancel /
    # Snapshot / Close (those last four finish it first).
    def copy_toggle(self):
        if self.copy:
            self.copy_off()
        else:
            self.copy_on_palette()

    def copy_on_palette(self):
        a = self.app
        base = a._ramp_backup[0] if a._ramp_backup else a.rgbs
        if base is None:
            return
        cells = [i for i in sorted(a.selection) if i < len(base) and base[i] is not None]
        if len(cells) < 2:
            a.status_var.set("Copy ramp: select the ramp to copy (2+ coloured cells) first.")
            copy_toggle_style(self.copy_btn, False, self._copy_bg)
            return
        self._copy_start({"src": "palette", "cells": cells,
                          "cols": [tuple(base[i]) for i in cells]})

    def copy_on_cols(self, cols, name=""):
        """Palette Browser: start Copy ramp from these colours (kept live by Palette Browser)."""
        self._copy_start({"src": "playpals", "cells": [], "cols": [tuple(c) for c in cols],
                          "name": name})

    def _copy_start(self, d):
        if self.copy:
            self.copy_off(quiet=True)
        self.copy = d
        self.st["ease"] = "Linear"                 # the fit assumes straight blends
        self.ease_var.set("Linear")
        self._copy_lock(True)
        self._copy_buttons()
        self.copy_refit()
        self.app.redraw()

    def copy_set_cols(self, cols, name=""):
        """Palette Browser selection changed while its Copy ramp is on."""
        c = self.copy
        if not c or c["src"] != "playpals":
            return
        cols = [tuple(x) for x in cols]
        if cols == c["cols"]:
            return
        c["cols"], c["name"] = cols, name
        self.copy_refit()

    def copy_refit(self):
        c = self.copy
        if not c:
            return
        cols = c["cols"]
        if len(cols) < 2:
            self.app.status_var.set("Copy ramp: select 2+ colours to copy.")
            return
        close = closeness_var(self.app).get()
        self.st["nodes"] = fit_ramp_nodes(cols, self.st["space"], close)
        self.active = self.st["nodes"][0]
        self.changed()
        self.app.status_var.set("Copy ramp: %d colours -> %d nodes (%s)%s." % (
            len(cols), len(self.st["nodes"]), close,
            "" if c["src"] == "playpals" else
            " - select the target cells; press Copy ramp again to finish"))

    def copy_off(self, quiet=False):
        if not getattr(self, "copy", None):
            return
        src = self.copy["src"]
        self.copy = None
        try:
            self._copy_lock(False)
            self._copy_buttons()
        except self.app.tk.TclError:
            pass
        if not quiet:
            self.app.status_var.set("Copy ramp finished - %d nodes, edit them freely."
                                    % len(self.nodes()))
        if src == "palette":
            self.app.redraw()

    def _copy_buttons(self):
        on = bool(self.copy)
        if self.copy_btn is not None:
            copy_toggle_style(self.copy_btn, on and self.copy["src"] == "palette",
                              self._copy_bg)
        pp = self.app.playpals
        if pp is not None:
            pp.copy_state(on and self.copy["src"] == "playpals")

    def _copy_lock(self, on):
        """Grey out every control but the ones Copy ramp leaves usable."""
        keep = {self.copy_btn, self.close_cb, self.prev_btn, self.apply_btn,
                self.cancel_btn, self.close_btn, getattr(self, "snap_btn", None)}
        if on:
            self._locked = []

            def walk(w):
                for ch in w.winfo_children():
                    walk(ch)
                    if ch in keep:
                        continue
                    cls = ch.winfo_class()
                    if cls in ("TButton", "TCheckbutton", "TRadiobutton", "TCombobox",
                               "TEntry", "TSpinbox"):
                        if not ch.instate(["disabled"]):
                            ch.state(["disabled"])
                            self._locked.append(ch)
                    elif cls in ("Button", "Entry", "Checkbutton"):
                        if str(ch.cget("state")) != "disabled":
                            ch.configure(state="disabled")
                            self._locked.append(ch)
            walk(self.win)
        else:
            for ch in getattr(self, "_locked", []):
                try:
                    if ch.winfo_class().startswith("T"):
                        ch.state(["!disabled"])
                    else:
                        ch.configure(state="normal")
                except self.app.tk.TclError:
                    pass
            self._locked = []
            self.refresh_node_row()
            self.update_buttons()
            self.refresh()

    def use_selection_ends(self):
        a = self.app
        base = self._base()
        tg = self.targets()
        if base is None or len(tg) < 2:
            a.status_var.set("Select at least two cells first.")
            return
        first, last = base[tg[0]], base[tg[-1]]
        if first is None or last is None:
            a.status_var.set("The first and last selected cells must hold colours.")
            return
        nodes = self.nodes()
        nodes[0]["rgb"], nodes[0]["hsl"] = list(first), None
        nodes[-1]["rgb"], nodes[-1]["hsl"] = list(last), None
        self.set_active(nodes[0])
        self.changed()

    def drop_colour(self, x_root, rgb):
        """A swatch dropped on the bar: recolour the node there, or add one."""
        x = x_root - self.bar.winfo_rootx()
        n = self._hit(x, 10 ** 6)
        if n is None:
            t = min(max(self._to_pos(self._t(x)), 0.001), 0.999)
            n = {"pos": t, "rgb": list(rgb), "hsl": None}
            self.nodes().append(n)
            self.nodes().sort(key=lambda q: q["pos"])
        else:
            n["rgb"], n["hsl"] = list(rgb), None
        self.set_active(n)
        self.changed()

    # ---------------------------------------------------------- preview / apply
    def update_buttons(self):
        on = self.previewing()
        self.prev_btn.configure(text="Preview: ON" if on else "Preview: OFF",
                                relief="sunken" if on else "raised",
                                background="#ffb36b" if on else self._btn_bg,
                                activebackground="#ffcb94" if on else self._btn_bg)
        self.cancel_btn.state(["!disabled"] if on else ["disabled"])

    def toggle_preview(self):
        if self.app._ramp_backup is not None:
            self.cancel()
        elif self.app.ramp_preview_start():
            self.app.ramp_preview_set(self.out_colours())
        self.update_buttons()
        self.draw_strip()

    def apply(self):
        a = self.app
        self.copy_off()
        if a._ramp_backup is None:
            if not a.ramp_preview_start():
                self.update_buttons()
                return
        if self._after is not None:
            self.win.after_cancel(self._after)
            self._after = None
        cs = self.out_colours()
        a.ramp_preview_set(cs)
        a.ramp_apply(cs, [n["rgb"] for n in self.nodes()])
        self.update_buttons()
        self.draw_strip()

    def cancel(self):
        if self.app._ramp_backup is not None:
            self.app.ramp_cancel()
        self.update_buttons()
        self.draw_strip()

    def save_ramp(self):
        from tkinter import filedialog, messagebox

        initdir = self.app.s.get("ramp_dir") or PRESET_DIR
        try:
            os.makedirs(initdir, exist_ok=True)
        except OSError:
            initdir = None
        p = filedialog.asksaveasfilename(
            parent=self.win, title="Save ramp", initialdir=initdir,
            initialfile="ramp.json", defaultextension=".json",
            filetypes=[("cleanpal ramp", "*.json")])
        if not p:
            return
        try:
            with open(p, "w", encoding="utf-8") as fh:
                json.dump({"cleanpal_ramp": 1, "version": VERSION, "ramp": self.st}, fh,
                          indent=2)
        except OSError as e:
            messagebox.showerror("cleanpal", "Could not save ramp:\n%s" % e, parent=self.win)
            return
        self.app.s["ramp_dir"] = os.path.dirname(p)
        self.app.status_var.set("Saved ramp %s" % p)

    def load_ramp(self):
        from tkinter import filedialog, messagebox

        initdir = self.app.s.get("ramp_dir") or PRESET_DIR
        if not os.path.isdir(initdir):
            initdir = None
        p = filedialog.askopenfilename(
            parent=self.win, title="Load ramp", initialdir=initdir,
            filetypes=[("cleanpal ramp", "*.json"), ("All files", "*.*")])
        if not p:
            return
        try:
            with open(p, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if not isinstance(data, dict) or data.get("cleanpal_ramp") != 1:
                raise ValueError("Not a cleanpal ramp file.")
            st = clean_ramp_state(data.get("ramp"))
        except (OSError, ValueError) as e:
            messagebox.showerror("cleanpal", "Could not load ramp:\n%s\n\n%s" % (p, e),
                                 parent=self.win)
            return
        self.app.s["ramp_dir"] = os.path.dirname(p)
        self.set_state(st)

    def set_state(self, st):
        self.st = st
        self.space_var.set(st["space"])
        self.ease_var.set(st["ease"])
        self.str_var.set(fmt_tol(st["strength"]))
        self.scope_var.set(st["ease_scope"])
        self.set_active(self.st["nodes"][0])
        self.changed()

    def teardown(self):
        """Store state, release the picker, destroy the window."""
        a = self.app
        self.copy_off(quiet=True)
        if self._after is not None:
            self.win.after_cancel(self._after)
            self._after = None
        try:
            a.s[self.GEOM_KEY] = self.win.geometry()
        except a.tk.TclError:
            pass
        a.s[self.STATE_KEY] = json.loads(json.dumps(self.st))
        p = a.picker
        if p is not None and getattr(p, "owner", None) is self:
            p.owner = None
            p.set_target(None, p.rgb(), p.hsl(), "")
        self.win.destroy()

    def close(self):
        a = self.app
        if a._ramp_backup is not None:
            a.ramp_cancel()
        self.teardown()
        a.ramp = None
        a.recompute()

    # tool-host interface (Paint)
    def lift(self):
        self.win.deiconify()
        self.win.lift()

    def refresh(self):
        pass


# ============================================================ Paint tools
class PaintTool(RampTool):
    """PLAYPAL Paint tools: the palette ramp + a solid Fill section. Opened and
    closed by the tool host (needs a clean snapshot)."""

    TITLE = "Paint tools"
    GEOM_KEY = "paint_geometry"
    GEOM_DEFAULT = "720x760"
    MIN_SIZE = (580, 640)

    def setup(self):
        from tkinter import ttk

        a = self.app
        tk = a.tk
        ui = self.ui
        self._edsel_ui()                         # steps heading with the click hints
        # The old Fill section is no longer shown (5.0.8); its widgets are still
        # built, un-gridded, so the fill helpers keep working if called.
        ff = ttk.LabelFrame(self.win, text="Fill", padding=6)
        self.btn_frame.grid(row=9, column=0, sticky="ew")

        # clipboard: cut / copy / paste over / insert paste
        cf = ttk.LabelFrame(self.win, text="Clipboard  (Ctrl+X cut / Ctrl+C copy / Ctrl+V "
                                           "insert / Ctrl+Shift+V paste over)", padding=6)
        cf.grid(row=7, column=0, sticky="ew", padx=8, pady=(8, 0))
        ttk.Button(cf, text="Cut", command=a.clip_cut).pack(side="left")
        ttk.Button(cf, text="Copy", command=a.clip_copy).pack(side="left", padx=(6, 0))
        ttk.Button(cf, text="Paste", command=a.clip_paste).pack(side="left", padx=(6, 0))
        ttk.Button(cf, text="Insert paste",
                   command=lambda: a.clip_paste(insert=True)).pack(side="left", padx=(6, 0))
        ttk.Button(cf, text="Clear cells", command=a.paint_clear_cells).pack(
            side="left", padx=(12, 0))
        self.clip_var = tk.StringVar(value=a.clip_text())
        ttk.Label(cf, textvariable=self.clip_var, foreground="#666").pack(side="left",
                                                                           padx=(10, 0))
        a._bind_clip_keys(self.win)
        from .gui_tool_windows import focus_on_click
        focus_on_click(self.win)

        # session: edits stay pending until Snapshot (one history entry)
        pf = ttk.LabelFrame(self.win, text="Paint session", padding=6)
        pf.grid(row=8, column=0, sticky="ew", padx=8, pady=(8, 0))
        self.pend_var = tk.StringVar()
        ttk.Label(pf, textvariable=self.pend_var, foreground="#666").pack(side="left")
        self.snap_btn = ttk.Button(pf, text="Snapshot", command=a.paint_snapshot)
        self.snap_btn.pack(side="right")
        self.revert_btn = ttk.Button(pf, text="Revert", command=a.paint_revert)
        self.revert_btn.pack(side="right", padx=(0, 6))
        self.cell_target = None
        self._picker_fill = False
        self.fill_rgb = parse_colour(a.s.get("paint_fill") or "") or (128, 128, 128)
        self.fill_sw = tk.Canvas(ff, width=int(44 * ui), height=int(22 * ui),
                                 highlightthickness=1, highlightbackground="#888",
                                 cursor="hand2")
        self.fill_sw.pack(side="left")
        self.fill_sw.bind("<Button-1>", lambda e: self.fill_picker())
        ttk.Label(ff, text="#").pack(side="left", padx=(8, 0))
        self.fill_hex = tk.StringVar()
        he = ttk.Entry(ff, textvariable=self.fill_hex, width=9)
        he.pack(side="left")
        he.bind("<Return>", lambda e: self._on_fill_hex())
        he.bind("<FocusOut>", lambda e: self._on_fill_hex())
        ttk.Button(ff, text="Picker...", command=self.fill_picker).pack(side="left",
                                                                        padx=(8, 0))
        ttk.Button(ff, text="Eyedropper", command=self.fill_eyedropper).pack(
            side="left", padx=(6, 0))
        ttk.Button(ff, text="From selection",
                   command=self.fill_from_selection).pack(side="left", padx=(6, 0))
        ttk.Button(ff, text="Fill selected", command=self.fill_selected).pack(side="right")
        ttk.Button(ff, text="Clear all", command=self.app.paint_clear_all).pack(
            side="right", padx=(0, 6))
        a.register_colour_widget(he, lambda: tuple(self.fill_rgb), self.set_fill)
        self.fill_sw.bind("<Button-3>", lambda e: a.colour_menu(
            e, lambda: tuple(self.fill_rgb), self.set_fill))
        self.win.protocol("WM_DELETE_WINDOW", a.close_tool)
        for w in self.btn_frame.winfo_children():          # Close -> tool host
            if w.winfo_class() == "TButton" and w.cget("text") == "Close":
                w.configure(command=a.close_tool)
        self.win.bind("<Control-z>", a._on_undo_key)
        self.win.bind("<Control-Z>", a._on_undo_key)
        self.win.bind("<Control-y>", a._on_redo_key)
        self.win.bind("<Control-Y>", a._on_redo_key)
        u, r = a._pu_stacks()                  # a new Paint session: fresh undo list
        u[:], r[:] = [], []
        a._pu_reset()
        self._show_fill()
        self.refresh()

    def refresh(self):
        a = self.app
        try:
            if a.paint_pending():
                self.pend_var.set("Unsnapshotted: " + a.paint_summary())
                st = ["!disabled"]
            else:
                self.pend_var.set("No pending edits")
                st = ["disabled"]
            self.snap_btn.state(st)
            self.revert_btn.state(["disabled"] if self.copy else st)
            self.clip_var.set(a.clip_text())
        except a.tk.TclError:
            pass

    def target_cell(self, idx):
        """Picker edits one palette cell live (double-click in the grid)."""
        a = self.app
        p = a.open_picker()
        p.owner = self
        self._picker_fill = False
        self.cell_target = idx
        cur = a.rgbs[idx] if a.rgbs[idx] is not None else (128, 128, 128)
        p.set_target(lambda rgb, hsl, i=idx: a.paint_cell_live(i, rgb), tuple(cur), None,
                     "palette index %d" % idx)
        a.status_var.set("Picker on index %d - changes apply live; Snapshot records them."
                         % idx)

    def _show_fill(self):
        self.fill_sw.configure(background=hex_of(self.fill_rgb))
        self.fill_hex.set(hex_of(self.fill_rgb).lstrip("#"))

    def set_fill(self, rgb, hsl=None):
        self.fill_rgb = tuple(rgb)
        self.app.s["paint_fill"] = hex_of(self.fill_rgb)
        self._show_fill()

    def fill_eyedropper(self):
        """Screen eyedropper straight into the fill colour (no Picker window)."""
        from .gui_picker import EyeDropper
        EyeDropper(self.app, self._dropped_fill)

    def _dropped_fill(self, rgb):
        self.set_fill(tuple(rgb))
        p = self.app.picker
        if p is not None and getattr(p, "owner", None) is self \
                and getattr(self, "_picker_fill", False):
            self.fill_picker()

    def _on_fill_hex(self):
        c = parse_colour(self.fill_hex.get())
        if c is None:
            self._show_fill()
            return
        if c != tuple(self.fill_rgb):
            self.set_fill(c)
            p = self.app.picker
            if p is not None and getattr(p, "owner", None) is self \
                    and getattr(self, "_picker_fill", False):
                self.fill_picker()

    def fill_picker(self):
        p = self.app.open_picker()
        p.owner = self
        self._picker_fill = True
        self.cell_target = None
        self.app.redraw()
        p.set_target(lambda rgb, hsl: self.set_fill(rgb, hsl), tuple(self.fill_rgb),
                     None, "Paint fill colour")

    def _target_picker(self, p):
        self._picker_fill = False
        if self.cell_target is not None:
            self.cell_target = None
            self.app.redraw()
        super()._target_picker(p)

    def fill_cells(self):
        """Fill cells: the picker (starting on black) writes one colour into
        every selected cell live; closing / retargeting the picker ends it."""
        a = self.app
        if a.rgbs is None:
            return
        want = sorted(a.selection)
        if not want:
            a.status_var.set("Fill cells: select the cells to fill first (Edit Selection).")
            return
        cells = a.editable(want)
        if not cells:
            a.status_var.set("Fill cells: those cells are all locked.")
            return
        if a._preview_busy_msg():            # (pauses the live ramp preview)
            return
        p = a.open_picker()
        p.owner = self
        self._picker_fill = False
        if self.cell_target is not None:
            self.cell_target = None
            a.redraw()
        a._fill_seq = getattr(a, "_fill_seq", 0) + 1
        a._fill_live = a._fill_seq
        a._fill_wrote = False
        self._fill_list = list(cells)
        p.set_target(lambda rgb, hsl: a.paint_fill_live(self._fill_list, rgb), (0, 0, 0),
                     None, "Fill %d cell%s" % (len(cells), "" if len(cells) == 1 else "s"))
        p.on_release = self._fill_end
        a.status_var.set("Fill cells: %d cell(s)%s - choose a colour, close the picker "
                         "when done." % (len(cells), a._lock_note(want, cells)))

    def _fill_end(self):
        a = self.app
        a._fill_live = None
        cells = getattr(self, "_fill_list", [])
        if getattr(a, "_fill_wrote", False) and cells and a.rgbs is not None:
            c = a.rgbs[cells[0]]
            a.status_var.set("Filled %d cell(s) with %s - Snapshot in the Paint tools "
                             "records it (Ctrl+Z undoes it)." % (
                                 len(cells), hex_of(c) if c is not None else "?"))
        self._fill_list = []
        a._fill_wrote = False

    def fill_from_selection(self):
        a = self.app
        cols = [a.rgbs[i] for i in sorted(a.selection) if a.rgbs[i] is not None]
        if not cols:
            a.status_var.set("Select a coloured cell to take the fill colour from.")
            return
        self.set_fill(cols[0])

    # ---------------------------------------------------------- live preview
    def update_buttons(self):
        """Preview button = the live preview switch (on by default)."""
        a = self.app
        on = a.paint_live()
        try:
            self.prev_btn.configure(text="Preview: ON" if on else "Preview: OFF",
                                    relief="sunken" if on else "raised",
                                    background="#ffb36b" if on else self._btn_bg,
                                    activebackground="#ffcb94" if on else self._btn_bg)
            self.cancel_btn.state(["!disabled"] if self.previewing() else ["disabled"])
        except a.tk.TclError:
            pass

    def toggle_preview(self):
        a = self.app
        live = not a.paint_live()
        a.s["paint_preview"] = live
        if live:
            a._ramp_resume()
        else:
            if a._ramp_backup is not None:
                a.ramp_cancel()
            a._ramp_paused = False
        self.update_buttons()
        self.draw_strip()

    def cancel(self):
        """Clear the current preview; it comes back on the next selection."""
        a = self.app
        self.copy_off()
        if a._ramp_backup is not None:
            a.ramp_cancel()
            a._ramp_paused = a.paint_live()
        self.update_buttons()
        self.draw_strip()

    def changed(self, store=True):
        super().changed(store)
        if not self.previewing():
            self.app._ramp_sel_changed()        # a ramp edit wakes a paused preview

    def fill_selected(self):
        a = self.app
        if not a.selection:
            a.status_var.set("Select the palette cells to fill first.")
            return
        a.set_cells_colour(sorted(a.selection), self.fill_rgb, what="Fill")

    def close(self):
        self.app.close_tool()


def _copy_guard(cls, names):
    """While Copy ramp is on, these do nothing (status says why)."""
    for name in names:
        f = getattr(cls, name)

        def g(self, *a, _f=f, **k):
            if getattr(self, "copy", None):
                self.app.status_var.set(COPY_BUSY)
                return "break"
            return _f(self, *a, **k)
        g.__name__ = name
        setattr(cls, name, g)


_copy_guard(RampTool, ("_strip_click", "_strip_right", "_bar_press", "_bar_double",
                       "_bar_right", "_on_del_key", "drop_colour", "open_picker",
                       "node_eyedropper", "set_node_colour", "clear_nodes", "reverse",
                       "load_ramp", "delete_node", "_on_hex", "_on_pos", "_on_opts"))
_copy_guard(PaintTool, ("target_cell", "fill_eyedropper", "fill_picker", "fill_cells",
                        "fill_from_selection", "fill_selected"))
