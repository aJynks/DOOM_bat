"""Edit Ramps engine (COLORMAP): one shared ramp for a set of fades.

The ramp has 32 positions (0 = top, 31 = end). Every fade in the set enters
the ramp where the ramp is as dark as the fade's own colour, then walks down
it:

* "same"    - one ramp position per row, so darker colours reach the end
              sooner and stay there
* "stretch" - each fade spreads the rest of the ramp over all 31 rows

Row 0 is always the fade's own colour. "Blend in" rows ease from the fade's
own colour into the ramp, so a colour that doesn't quite match the ramp
where it enters doesn't jump.

Two kinds of ramp:

* "gradient" - colour nodes (pos, rgb), blended in OKLab ("straight"),
  around the hue wheel ("wheel") or in RGB ("rgb")
* "lc"       - lightness + colour: a lightness strip (pos, L 0..1) decides
  how dark each position is; a colour strip (pos, rgb) only gives hue and
  colourfulness. Changing the colour never changes the darkness.

All maths is stdlib only. Every target is pulled into the displayable
range by lowering colourfulness at the same lightness and hue.
"""

import math

from .cleanpal_lib_colour import oklab

POSITIONS = 32                  # ramp positions 0-31 (row 0 .. row 31)
ROWS = 31                       # fade rows written (1-31)
MODES = ("gradient", "lc")
BLENDS = ("straight", "wheel", "rgb")
PACES = ("same", "stretch")
METRICS = ("rgb", "oklab")

RAMP_DEFAULTS = {"re_mode": "gradient", "re_blend": "wheel", "re_pace": "same",
                 "re_blendin": 3, "re_metric": "rgb", "re_add_max": 4,
                 "re_add_place": "insert", "re_add_together": True}


def clean_re_settings(d):
    o = dict(RAMP_DEFAULTS)
    if isinstance(d, dict):
        o.update({k: v for k, v in d.items() if k in RAMP_DEFAULTS})
    if o["re_mode"] not in MODES:
        o["re_mode"] = "gradient"
    if o["re_blend"] not in BLENDS:
        o["re_blend"] = "wheel"
    if o["re_pace"] not in PACES:
        o["re_pace"] = "same"
    if o["re_metric"] not in METRICS:
        o["re_metric"] = "rgb"
    if o["re_add_place"] not in ("insert", "empty"):
        o["re_add_place"] = "insert"
    for k, lo, hi in (("re_blendin", 0, 8), ("re_add_max", 1, 32)):
        try:
            o[k] = int(min(max(int(o[k]), lo), hi))
        except (TypeError, ValueError):
            o[k] = RAMP_DEFAULTS[k]
    o["re_add_together"] = bool(o["re_add_together"])
    return o


# ============================================================ colour maths
def _lin(c):
    c /= 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _unlin(c):
    c = min(max(c, 0.0), 1.0)
    c = c * 12.92 if c <= 0.0031308 else 1.055 * (c ** (1.0 / 2.4)) - 0.055
    return c * 255.0


def _lab_to_linear(L, a, b):
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    return (4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
            -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
            -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s)


def _fits(L, a, b):
    return all(-0.0005 <= v <= 1.0005 for v in _lab_to_linear(L, a, b))


def fit_gamut(L, a, b):
    """Same lightness and hue, colourfulness lowered until it can be shown."""
    if L <= 0.0:
        return (0.0, 0.0, 0.0)
    if L >= 1.0:
        return (1.0, 0.0, 0.0)
    if _fits(L, a, b):
        return (L, a, b)
    lo, hi = 0.0, 1.0
    for _i in range(16):
        k = (lo + hi) / 2.0
        if _fits(L, a * k, b * k):
            lo = k
        else:
            hi = k
    return (L, a * lo, b * lo)


def lab_to_rgb(lab):
    L, a, b = fit_gamut(*lab)
    return tuple(int(min(max(round(_unlin(v)), 0), 255)) for v in _lab_to_linear(L, a, b))


def grey_of(L):
    """Grey with OKLab lightness L (0..1)."""
    return lab_to_rgb((min(max(L, 0.0), 1.0), 0.0, 0.0))


def _mix_lab(A, B, f, how):
    if how == "rgb":
        ra = [_lin(v) for v in A[1]]
        rb = [_lin(v) for v in B[1]]
        c = [_unlin(ra[i] + (rb[i] - ra[i]) * f) for i in range(3)]
        return oklab(c)
    A, B = A[0], B[0]
    if how == "straight":
        return tuple(A[i] + (B[i] - A[i]) * f for i in range(3))
    CA, CB = math.hypot(A[1], A[2]), math.hypot(B[1], B[2])
    hA, hB = math.atan2(A[2], A[1]), math.atan2(B[2], B[1])
    if CA < 0.02:                      # grey end: take the other end's hue
        hA = hB
    if CB < 0.02:
        hB = hA
    dh = (hB - hA + math.pi) % (2.0 * math.pi) - math.pi
    L = A[0] + (B[0] - A[0]) * f
    C = CA + (CB - CA) * f
    h = hA + dh * f
    return (L, C * math.cos(h), C * math.sin(h))


def _clean_nodes(nodes):
    """Sorted, one node per position, positions 0-31; position 0 must exist."""
    out = {}
    for p, v in nodes:
        p = int(min(max(int(round(p)), 0), POSITIONS - 1))
        out[p] = v
    return sorted(out.items())


def _interp(nodes, t, fn):
    """Value at position t (float) from sorted (pos, v) nodes; held past the ends."""
    if t <= nodes[0][0]:
        return fn(nodes[0][1], nodes[0][1], 0.0)
    for (p0, v0), (p1, v1) in zip(nodes, nodes[1:]):
        if t <= p1:
            return fn(v0, v1, (t - p0) / float(p1 - p0))
    return fn(nodes[-1][1], nodes[-1][1], 0.0)


# ============================================================ the ramp
class Ramp:
    """A ramp you can sample anywhere between position 0 and 31.

    gradient: nodes = [(pos, rgb)]
    lc:       light = [(pos, L)], colour = [(pos, rgb)]
    """

    def __init__(self, mode, blend="wheel", nodes=None, light=None, colour=None):
        self.mode = mode
        self.blend = blend
        self.nodes = _clean_nodes(nodes or [(0, (255, 255, 255)), (31, (0, 0, 0))])
        self.light = _clean_nodes(light or [(0, 1.0), (31, 0.0)])
        self.colour = _clean_nodes(colour or [(0, (128, 128, 128))])
        self._gl = [(p, (oklab(c), c)) for p, c in self.nodes]
        self._cl = [(p, (oklab(c), c)) for p, c in self.colour]
        self._cache = {}

    def lab(self, t):
        t = min(max(float(t), 0.0), POSITIONS - 1.0)
        k = round(t, 4)
        hit = self._cache.get(k)
        if hit is not None:
            return hit
        if self.mode == "gradient":
            v = _interp(self._gl, t, lambda A, B, f: _mix_lab(A, B, f, self.blend))
        else:
            L = _interp(self.light, t, lambda a, b, f: a + (b - a) * f)
            c = _interp(self._cl, t, lambda A, B, f: _mix_lab(A, B, f, "wheel"))
            C = math.hypot(c[1], c[2])
            h = math.atan2(c[2], c[1])
            v = (L, C * math.cos(h), C * math.sin(h))
        v = fit_gamut(*v)
        self._cache[k] = v
        return v

    def rgb(self, t):
        return lab_to_rgb(self.lab(t))

    def strip(self):
        """32 colours, one per position (what the window draws)."""
        return [self.rgb(p) for p in range(POSITIONS)]

    def entry(self, L):
        """First position (float) where the ramp is as dark as L. A colour
        lighter than the top enters at 0; darker than everything at 31."""
        prev_t, prev_L = 0.0, self.lab(0.0)[0]
        if L >= prev_L:
            return 0.0
        n = (POSITIONS - 1) * 8
        for i in range(1, n + 1):
            t = i / 8.0
            Lt = self.lab(t)[0]
            if Lt <= L:
                if prev_L - Lt > 1e-9:
                    return prev_t + (t - prev_t) * (prev_L - L) / (prev_L - Lt)
                return t
            prev_t, prev_L = t, Lt
        return POSITIONS - 1.0


def fade_targets(ramp, rgb0, pace="same", blendin=3):
    """True-colour targets for rows 1-31 of the fade whose colour is rgb0
    -> (list of 31 OKLab, entry position)."""
    lab0 = oklab(rgb0)
    t0 = ramp.entry(lab0[0])
    top = ramp.lab(t0)
    off = tuple(lab0[i] - top[i] for i in range(3))
    out = []
    for r in range(1, ROWS + 1):
        if pace == "stretch":
            t = t0 + (POSITIONS - 1 - t0) * r / float(ROWS)
        else:
            t = min(t0 + r, POSITIONS - 1.0)
        v = ramp.lab(t)
        if blendin and r <= blendin:
            k = 1.0 - r / float(blendin + 1)
            v = fit_gamut(*(v[i] + off[i] * k for i in range(3)))
        out.append(v)
    return out, t0


# ============================================================ palettising
class Snapper:
    """Nearest palette colour: plain RGB distance (first minimum wins, like
    SLADE) or OKLab."""

    def __init__(self, rgbs, deleted=(), metric="rgb", limit=256):
        self.metric = metric
        self.idx = [i for i in range(min(limit, len(rgbs)))
                    if rgbs[i] is not None and i not in deleted]
        self.rgb = [tuple(rgbs[i]) for i in self.idx]
        self.lab = [oklab(c) for c in self.rgb]
        self._memo = {}

    def nearest(self, lab, rgb):
        key = rgb if self.metric == "rgb" else tuple(round(v, 4) for v in lab)
        hit = self._memo.get(key)
        if hit is not None:
            return hit
        best, bd = None, None
        if self.metric == "rgb":
            r, g, b = rgb
            for k, c in enumerate(self.rgb):
                d = (c[0] - r) ** 2 + (c[1] - g) ** 2 + (c[2] - b) ** 2
                if bd is None or d < bd:
                    best, bd = k, d
        else:
            L, a, bb = lab
            for k, c in enumerate(self.lab):
                d = (c[0] - L) ** 2 + (c[1] - a) ** 2 + (c[2] - bb) ** 2
                if bd is None or d < bd:
                    best, bd = k, d
        out = self.idx[best] if best is not None else None
        self._memo[key] = out
        return out


def build_ramp_fades(rgbs, deleted, scope, ramp, o):
    """-> (overrides {(row, src): slot}, targets {(row, src): rgb},
    entries {src: position})."""
    snap = Snapper(rgbs, deleted, o["re_metric"])
    over, targets, entries = {}, {}, {}
    for s in scope:
        c = rgbs[s]
        if c is None:
            continue
        labs, t0 = fade_targets(ramp, c, o["re_pace"], o["re_blendin"])
        entries[s] = t0
        for r, lab in enumerate(labs, 1):
            rgb = lab_to_rgb(lab)
            targets[(r, s)] = rgb
            k = snap.nearest(lab, rgb)
            if k is not None:
                over[(r, s)] = k
    return over, targets, entries


def missing_colours(rgbs, deleted, targets, max_new, tol=0.03):
    """Up to max_new colours worth adding so the targets palettise better.
    Greedy: each pick removes the most total error (OKLab distance beyond
    tol) across every target cell; picks are target colours themselves."""
    pal = [oklab(rgbs[i]) for i in range(min(256, len(rgbs)))
           if rgbs[i] is not None and i not in deleted]
    cells = {}
    for rgb in targets.values():
        cells[rgb] = cells.get(rgb, 0) + 1
    pts = []
    for rgb, n in cells.items():
        lab = oklab(rgb)
        if lab[0] < 0.2:                       # near-black: never worth a slot
            continue
        d = min(math.sqrt(sum((lab[i] - p[i]) ** 2 for i in range(3))) for p in pal) \
            if pal else 1.0
        if d > tol:
            pts.append([lab, rgb, n, d])
    if not pts:
        return []
    pts.sort(key=lambda p: -p[3] * p[2])
    cand = pts[:300]
    picks = []
    for _k in range(max_new):
        best, bg = None, 0.0
        for c in cand:
            g = 0.0
            for p in pts:
                if p[3] <= tol:
                    continue
                d = math.sqrt(sum((c[0][i] - p[0][i]) ** 2 for i in range(3)))
                if d < p[3]:
                    g += (p[3] - max(d, tol)) * p[2]
            if g > bg:
                best, bg = c, g
        if best is None or bg < 0.02:
            break
        picks.append(best[1])
        for p in pts:
            d = math.sqrt(sum((best[0][i] - p[0][i]) ** 2 for i in range(3)))
            p[3] = min(p[3], d)
        cand = [c for c in cand if c is not best]
    return picks
