"""Colour scans of WAD graphics / PNG folders, and Lost-colours maths.

A scan is, per image, how many pixels use each colour: palette-index counts
for Doom-format lumps (counted straight from the index bytes - no image is
built), or an RGB histogram for PNG / true-colour art.

Results are cached for good:
  * per lump, keyed by crc32 + size of its bytes (any WAD / version that
    contains the same lump reuses it), seeded with built-in data for the
    stock Doom / Doom II IWADs (data/iwad_scans.json.gz)
  * per PNG file, keyed by path + size + modified time
in %APPDATA%\\cleanpal\\scans. .cpscan files (Save / Load scan) carry a whole
source's scan between machines / projects.
"""

import gzip
import json
import math
import os
import struct
import zlib
from collections import Counter

from .cleanpal_lib_colour import dist_de2000, dist_lab, dist_rgb, oklab, srgb_to_lab
from .cleanpal_lib_constants import APP_DIR

SCAN_DIR = os.path.join(APP_DIR, "scans")
SCAN_EXT = ".cpscan"
_BUILTIN = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data",
                        "iwad_scans.json.gz")
PNG_CACHE_MAX = 6000


# ------------------------------------------------------------------ counting
def count_picture(d):
    """{index: pixels} of a Doom picture, from its post bytes."""
    w = struct.unpack_from("<H", d, 0)[0]
    buf = bytearray()
    n = len(d)
    for x in range(w):
        p = struct.unpack_from("<I", d, 8 + 4 * x)[0]
        for _ in range(1024):
            if p >= n or d[p] == 0xFF or p + 1 >= n:
                break
            ln = d[p + 1]
            buf += d[p + 3:p + 3 + ln]
            p += 4 + ln
    return dict(Counter(buf))


def count_flat(d):
    return dict(Counter(d[:4096]))


def rgb_hist(img):
    """{(r, g, b): pixels} of the opaque pixels of a PIL image."""
    im = img.convert("RGBA")
    out = {}
    for n, (r, g, b, a) in im.getcolors(im.width * im.height + 1) or ():
        if a >= 128:
            out[(r, g, b)] = out.get((r, g, b), 0) + n
    return out


def _hx(c):
    return "%02x%02x%02x" % tuple(c)


def _unhx(s):
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def _icounts(c):
    return {int(k): int(v) for k, v in c.items()}


# ------------------------------------------------------------------ store
class ScanStore:
    """Built-in + cached scans. One per app."""

    def __init__(self):
        self.lumps = {}          # "crc:n" -> {index: px}
        self.pngs = {}           # "path|size|mtime" -> {"rrggbb": px}
        self.files = {}          # whole-file md5 -> {"kind/name": counts or "crc:n"}
        self._builtin = None
        self._dirty = False
        self._loaded = False

    # ---- persistence
    def _load(self):
        if self._loaded:
            return
        self._loaded = True
        try:
            with gzip.open(_BUILTIN, "rt", encoding="utf-8") as fh:
                b = json.load(fh)
            self._builtin = {k: _icounts(v) for k, v in b.get("lumps", {}).items()}
            for md5, f in (b.get("files") or {}).items():
                self.files[md5] = f["lumps"]
        except (OSError, ValueError):
            self._builtin = {}
        for name, attr in (("lumps.json.gz", "lumps"), ("pngs.json.gz", "pngs")):
            try:
                with gzip.open(os.path.join(SCAN_DIR, name), "rt", encoding="utf-8") as fh:
                    data = json.load(fh)
                if attr == "lumps":
                    self.lumps = {k: _icounts(v) for k, v in data.items()}
                else:
                    self.pngs = data
            except (OSError, ValueError):
                pass

    def save(self):
        if not self._dirty:
            return
        try:
            os.makedirs(SCAN_DIR, exist_ok=True)
            if len(self.pngs) > PNG_CACHE_MAX:
                for k in list(self.pngs)[:len(self.pngs) - PNG_CACHE_MAX]:
                    del self.pngs[k]
            for name, data in (("lumps.json.gz", self.lumps), ("pngs.json.gz", self.pngs)):
                tmp = os.path.join(SCAN_DIR, name + ".tmp")
                with gzip.open(tmp, "wt", encoding="utf-8") as fh:
                    json.dump(data, fh, separators=(",", ":"))
                os.replace(tmp, os.path.join(SCAN_DIR, name))
            self._dirty = False
        except OSError:
            pass

    # ---- lookups
    def lump_counts(self, d, kind):
        """{index: px} for a Doom-format lump (picture or flat), cached by
        crc + size; built-in IWAD data first."""
        self._load()
        key = "%08x:%d" % (zlib.crc32(d) & 0xFFFFFFFF, len(d))
        c = self._builtin.get(key) or self.lumps.get(key)
        if c is None:
            c = count_flat(d) if kind == "flat" else count_picture(d)
            self.lumps[key] = c
            self._dirty = True
        return c

    def file_lump(self, md5, name):
        """Counts for kind/name in a whole-file scan (built-in 1993/1994 IWADs
        or a loaded v1 .cpscan), or None."""
        self._load()
        f = self.files.get(md5)
        if not f or name not in f:
            return None
        v = f[name]
        if isinstance(v, str):
            return self._builtin.get(v) or self.lumps.get(v)
        return _icounts(v) if not isinstance(next(iter(v), 0), int) else v

    def png_hist(self, path):
        self._load()
        try:
            st = os.stat(path)
        except OSError:
            return {}
        key = "%s|%d|%d" % (os.path.abspath(path), st.st_size, int(st.st_mtime))
        h = self.pngs.get(key)
        if h is not None:
            return {_unhx(k): v for k, v in h.items()}
        from PIL import Image
        try:
            with Image.open(path) as im:
                im.load()
                hist = rgb_hist(im)
        except Exception:  # noqa: BLE001 - unreadable file: nothing
            return {}
        self.pngs[key] = {_hx(c): n for c, n in hist.items()}
        self._dirty = True
        return hist

    # ---- .cpscan files
    def import_scan(self, data):
        """Fold a loaded .cpscan into the caches. -> (source, lumps added)."""
        self._load()
        if not isinstance(data, dict) or not data.get("cleanpal_scan"):
            raise ValueError("Not a cleanpal scan file.")
        n = 0
        no_crc = {}
        for name, v in (data.get("lumps") or {}).items():
            if isinstance(v, dict) and "crc" in v and "c" in v:
                key = "%08x:%d" % (int(v["crc"]), int(v["n"]))
                if key not in self.lumps and key not in self._builtin:
                    self.lumps[key] = _icounts(v["c"])
                    n += 1
            elif isinstance(v, dict):
                no_crc[name] = _icounts(v.get("c", v))
        if no_crc and data.get("md5"):
            self.files[data["md5"]] = no_crc
            n += len(no_crc)
        for name, v in (data.get("rgb") or {}).items():
            key = v.get("key")
            if key and key not in self.pngs:
                self.pngs[key] = v.get("h", {})
                n += 1
        self._dirty = True
        return str(data.get("source") or "?"), n


_STORE = None


def store():
    global _STORE
    if _STORE is None:
        _STORE = ScanStore()
    return _STORE


def wad_md5(wad):
    m = getattr(wad, "_cp_md5", None)
    if m is None:
        import hashlib
        m = wad._cp_md5 = hashlib.md5(wad.data).hexdigest()
    return m


def item_hist(it, wad=None, image=None):
    """{(r, g, b): px} for one preview item. Doom-format lumps come from the
    (cached) index counts mapped through the WAD's palette; anything else
    from its decoded image (image = a callable giving the RGBA image)."""
    st = store()
    f = it.get("fmt")
    if wad is not None and f in ("doom", "flat") and it.get("lump") is not None:
        name = "%s/%s" % (it["kind"], it["name"])
        c = st.file_lump(wad_md5(wad), name)
        if c is None:
            c = st.lump_counts(wad.arch.lump_at(it["lump"]), it["kind"])
        pal = wad.pal
        out = {}
        for i, n in c.items():
            col = tuple(pal[i])
            out[col] = out.get(col, 0) + n
        return out
    if f == "file":
        return st.png_hist(it["path"])
    if image is not None:
        img = image(it)
        return rgb_hist(img) if img is not None else {}
    return {}


def save_scan(path, source, hists, wad=None):
    """Write a .cpscan: Doom-format lumps as index counts + crc, the rest as
    RGB histograms."""
    st = store()
    out = {"cleanpal_scan": 3, "source": source, "lumps": {}, "rgb": {}}
    if wad is not None:
        out["md5"] = wad_md5(wad)
        out["playpal"] = [list(c) for c in wad.pal]
        for it in wad.items:
            if it.get("fmt") in ("doom", "flat") and it.get("lump") is not None:
                d = wad.arch.lump_at(it["lump"])
                out["lumps"]["%s/%s" % (it["kind"], it["name"])] = {
                    "crc": zlib.crc32(d) & 0xFFFFFFFF, "n": len(d),
                    "c": {str(k): v for k, v in st.lump_counts(d, it["kind"]).items()}}
    for key, (cachekey, h) in hists.items():
        out["rgb"][key] = {"key": cachekey, "h": {_hx(c): n for c, n in h.items()}}
    with gzip.open(path, "wt", encoding="utf-8") as fh:
        json.dump(out, fh, separators=(",", ":"))


def load_scan(path):
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        data = json.load(fh)
    src, n = store().import_scan(data)
    return data, src, n


# ------------------------------------------------------------------ lost colours
def _dist_fn(metric):
    labs = {}

    def lab(c):
        v = labs.get(c)
        if v is None:
            v = labs[c] = srgb_to_lab(*c)
        return v

    if metric == "rgb":
        return dist_rgb
    if metric == "lab":
        return lambda a, b: dist_lab(lab(a), lab(b))
    return lambda a, b: dist_de2000(lab(a), lab(b))


def _chroma(c):
    _L, a, b = oklab(c)
    return math.hypot(a, b)


def classify(colours, cells, metric, close, greyed=True):
    """colour -> (class, cell index, distance) for every colour, against the
    palette cells (index-aligned, None = empty). class: "ok" / "lost" (the
    cell it lands on is further than close) / "greyed" (a colourful pixel
    landing on a grey). Landing = nearest RGB, exactly as palettising does."""
    from PIL import Image
    idx = [i for i, c in enumerate(cells) if c is not None]
    out = {}
    if not idx or not colours:
        return out
    flat = []
    for i in idx:
        flat.extend(cells[i])
    flat.extend(list(cells[idx[0]]) * (256 - len(idx)))
    palimg = Image.new("P", (1, 1))
    palimg.putpalette(flat)
    cols = list(colours)
    strip = Image.new("RGB", (len(cols), 1))
    strip.putdata(cols)
    try:
        dither = Image.Dither.NONE
    except AttributeError:
        dither = 0
    q = list(strip.quantize(palette=palimg, dither=dither).getdata())
    dist = _dist_fn(metric)
    cchroma = {}
    for c, k in zip(cols, q):
        cell = idx[k] if k < len(idx) else idx[0]
        tgt = cells[cell]
        d = 0.0 if tgt == c else dist(c, tgt)
        cls = "lost" if d > close else "ok"
        if greyed and d > 0:                    # colourful -> grey wins over lost
            sc = _chroma(c)
            if sc > 0.045:
                tc = cchroma.get(cell)
                if tc is None:
                    tc = cchroma[cell] = _chroma(tgt)
                if tc < 0.02:
                    cls = "greyed"
        out[c] = (cls, cell, d)
    return out


def group_lost(hist, cls, metric, close, cap=200):
    """Lost / greyed colours (from classify) grouped: colours within twice
    close of a group's first (biggest) colour join it. -> [{"rep", "px", "members",
    "kind", "cell", "dist"}] biggest first; rep = pixel-weighted mean."""
    bad = [(n, c) for c, n in hist.items() if cls.get(c, ("ok",))[0] != "ok"]
    bad.sort(key=lambda t: -t[0])
    dist = _dist_fn(metric)
    radius = max(2.0 * close, 1.0)
    groups = []
    for n, c in bad:
        best = None
        for g in groups:
            if g["kind"] == cls[c][0] and dist(c, g["seed"]) <= radius:
                best = g
                break
        if best is None and len(groups) >= cap:
            best = min(groups, key=lambda g: dist(c, g["seed"]))
        if best is None:
            best = {"seed": c, "kind": cls[c][0], "members": [], "px": 0, "sum": [0, 0, 0]}
            groups.append(best)
        best["members"].append(c)
        best["px"] += n
        for k in range(3):
            best["sum"][k] += c[k] * n
    for g in groups:
        g["rep"] = tuple(int(round(v / g["px"])) for v in g["sum"])
        _k, g["cell"], g["dist"] = cls[g["seed"]]
    groups.sort(key=lambda g: -g["px"])
    return groups
