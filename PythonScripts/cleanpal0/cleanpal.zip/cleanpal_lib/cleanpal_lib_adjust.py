"""Adjust tool maths: the Paint filters plus extra adjustments, and the stack.

apply_stack(stack, colours, ctx) runs the enabled adjustments in order. Each
has its own Mix % and Fade (Even / Dark end / Light end / Middle - by the
colour's lightness within the selection). Param specs are the filters'
(num / choice / bool) plus "curve" ([[x, y], ...] in 0..1) and "colour"
("#rrggbb")."""

import math
import random

from .cleanpal_lib_colour import oklab, oklab_to_rgbf, parse_colour
from .cleanpal_lib_filters import FILTERS, apply_filter

FADES = ["Even", "Dark end", "Light end", "Middle"]


def _lch(c):
    L, a, b = oklab(c)
    return L, math.hypot(a, b), math.atan2(b, a)


def _from_lch(L, C, h):
    return oklab_to_rgbf(min(max(L, 0.0), 1.0), C * math.cos(h), C * math.sin(h))


def _lerp_angle(a, b, t):
    d = (b - a + math.pi) % (2 * math.pi) - math.pi
    return a + d * t


def _ranks(colours):
    """0..1 lightness position of each colour within the set."""
    Ls = [oklab(c)[0] for c in colours]
    lo, hi = min(Ls), max(Ls)
    return [0.5 if hi - lo < 1e-6 else (L - lo) / (hi - lo) for L in Ls]


def curve_y(pts, x):
    """Monotone cubic through the points (a straight line stays straight)."""
    pts = sorted((float(a), float(b)) for a, b in pts)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    n = len(pts)
    if n == 1 or x <= xs[0]:
        return ys[0]
    if x >= xs[-1]:
        return ys[-1]
    d = [(ys[i + 1] - ys[i]) / max(xs[i + 1] - xs[i], 1e-9) for i in range(n - 1)]
    m = [d[0]] + [0.0 if d[i - 1] * d[i] <= 0 else (d[i - 1] + d[i]) / 2
                  for i in range(1, n - 1)] + [d[-1]]
    for i in range(n - 1):
        if abs(d[i]) < 1e-12:
            m[i] = m[i + 1] = 0.0
        else:
            a, b = m[i] / d[i], m[i + 1] / d[i]
            r = a * a + b * b
            if r > 9:
                t = 3 / math.sqrt(r)
                m[i], m[i + 1] = t * a * d[i], t * b * d[i]
    for i in range(n - 1):
        if x <= xs[i + 1]:
            h = max(xs[i + 1] - xs[i], 1e-9)
            t = (x - xs[i]) / h
            h00, h10 = 2 * t ** 3 - 3 * t ** 2 + 1, t ** 3 - 2 * t ** 2 + t
            h01, h11 = -2 * t ** 3 + 3 * t ** 2, t ** 3 - t ** 2
            return min(max(h00 * ys[i] + h10 * h * m[i] + h01 * ys[i + 1]
                           + h11 * h * m[i + 1], 0.0), 1.0)
    return ys[-1]


# ---------------------------------------------------------------- new adjustments
def _curves(p, cols, _ctx):
    pts = p["points"]
    ch = p["channel"]
    out = []
    for c in cols:
        if ch == "Lightness":
            L, C, h = _lch(c)
            out.append(_from_lch(curve_y(pts, L), C, h))
        else:
            v = list(c)
            for k, nm in enumerate("RGB"):
                if ch == "RGB" or ch == {"R": "Red", "G": "Green", "B": "Blue"}[nm]:
                    v[k] = curve_y(pts, v[k] / 255.0) * 255.0
            out.append(tuple(v))
    return out


def _vibrance(p, cols, _ctx):
    a = p["amount"] / 100.0
    out = []
    for c in cols:
        L, C, h = _lch(c)
        f = 1 + a * max(0.0, 1 - C / 0.32) if a > 0 else 1 + a
        out.append(_from_lch(L, C * f, h))
    return out


def _hue_shift_ramp(p, cols, _ctx):
    hd, hl = math.radians(p["dark_hue"]), math.radians(p["light_hue"])
    s = p["strength"] / 100.0
    out = []
    for c, t in zip(cols, _ranks(cols)):
        L, C, h = _lch(c)
        tgt = _lerp_angle(hd, hl, t)
        w = s * abs(2 * t - 1) if p["mids"] else s
        out.append(_from_lch(L, max(C, p["min_chroma"] / 100.0 * w), _lerp_angle(h, tgt, w)))
    return out


def _sat_along(p, cols, _ctx):
    e, m = p["ends"] / 100.0, p["middle"] / 100.0
    out = []
    for c, t in zip(cols, _ranks(cols)):
        L, C, h = _lch(c)
        mid = 1 - abs(2 * t - 1)
        out.append(_from_lch(L, C * (e + (m - e) * mid), h))
    return out


def _shadows_highlights(p, cols, _ctx):
    s, hi = p["shadows"] / 100.0, p["highlights"] / 100.0
    out = []
    for c in cols:
        L, C, h = _lch(c)
        L2 = L + 0.25 * s * (1 - L) ** 2 + 0.25 * hi * L ** 2
        out.append(_from_lch(L2, C, h))
    return out


def _colour_balance(p, cols, _ctx):
    out = []
    for c in cols:
        L = oklab(c)[0]
        w = {"Shadows": (1 - L) ** 2, "Midtones": 1 - abs(2 * L - 1),
             "Highlights": L ** 2}[p["range"]]
        k = 0.45 * 255 * w
        out.append((c[0] + k * p["cyan_red"] / 100.0,
                    c[1] + k * p["magenta_green"] / 100.0,
                    c[2] + k * p["yellow_blue"] / 100.0))
    return out


def _split_tone(p, cols, _ctx):
    hs, hh = math.radians(p["shadow_hue"]), math.radians(p["highlight_hue"])
    st = p["strength"] / 100.0 * 0.08
    bal = p["balance"] / 100.0
    out = []
    for c in cols:
        L, a, b = oklab(c)
        ws = max(0.0, 1 - L - bal * 0.5) * st
        wh = max(0.0, L + bal * 0.5) * st
        a += ws * math.cos(hs) + wh * math.cos(hh)
        b += ws * math.sin(hs) + wh * math.sin(hh)
        out.append(oklab_to_rgbf(L, a, b))
    return out


def _channel_mixer(p, cols, _ctx):
    m = [[p[o + i] / 100.0 for i in "rgb"] for o in ("r_", "g_", "b_")]
    return [tuple(sum(m[o][i] * c[i] for i in range(3)) for o in range(3)) for c in cols]


def _selective_hue(p, cols, _ctx):
    hc = math.radians(p["hue"])
    width = math.radians(max(p["width"], 1))
    out = []
    for c in cols:
        L, C, h = _lch(c)
        d = abs((h - hc + math.pi) % (2 * math.pi) - math.pi)
        w = max(0.0, 1 - d / width) if C > 0.02 else 0.0
        w = w * w * (3 - 2 * w)
        out.append(_from_lch(L * (1 + w * p["lightness"] / 100.0),
                             C * (1 + w * p["saturation"] / 100.0),
                             h + w * math.radians(p["shift"])))
    return out


def _exposure(p, cols, _ctx):
    f = 2.0 ** p["stops"]

    def lin(v):
        v /= 255.0
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4

    def enc(v):
        v = min(max(v, 0.0), 1.0)
        return 255.0 * (12.92 * v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055)
    return [tuple(enc(lin(v) * f) for v in c) for c in cols]


def _s_curve(p, cols, _ctx):
    k = p["strength"] / 100.0
    piv = p["pivot"] / 100.0
    out = []
    for c in cols:
        L, C, h = _lch(c)
        x = L - piv
        span = piv if x < 0 else 1 - piv
        if span > 1e-6:
            t = abs(x) / span
            s = t * t * (3 - 2 * t) if k > 0 else t ** (1 + 0) * (2 - t)
            t2 = t + (s - t) * abs(k)
            L = piv + math.copysign(t2 * span, x)
        out.append(_from_lch(L, C, h))
    return out


def _match_lightness(p, cols, ctx):
    src = [c for c in (ctx.get("clip") or []) if c is not None]
    if len(src) < 2:
        return cols
    Ls = [oklab(c)[0] for c in src]
    n = len(cols)
    out = []
    for k, c in enumerate(cols):
        x = k / (n - 1.0) * (len(Ls) - 1) if n > 1 else 0
        i = min(int(x), len(Ls) - 2)
        tgt = Ls[i] + (Ls[i + 1] - Ls[i]) * (x - i)
        if p["direction"] == "Reversed":
            x = (n - 1 - k) / max(n - 1.0, 1) * (len(Ls) - 1)
            i = min(int(x), len(Ls) - 2)
            tgt = Ls[i] + (Ls[i + 1] - Ls[i]) * (x - i)
        L, C, h = _lch(c)
        out.append(_from_lch(tgt, C, h))
    return out


def _jitter(p, cols, _ctx):
    rnd = random.Random(int(p["seed"]))
    a = p["amount"] / 100.0
    out = []
    for c in cols:
        L, aa, bb = oklab(c)
        out.append(oklab_to_rgbf(L + rnd.uniform(-1, 1) * 0.04 * a,
                                 aa + rnd.uniform(-1, 1) * 0.03 * a,
                                 bb + rnd.uniform(-1, 1) * 0.03 * a))
    return out


def _replace(p, cols, _ctx):
    f, t = parse_colour(p["from"]), parse_colour(p["to"])
    if f is None or t is None:
        return cols
    fl, tl = oklab(f), oklab(t)
    tol = max(p["tolerance"], 0.1) / 100.0
    out = []
    for c in cols:
        L, a, b = oklab(c)
        d = math.sqrt((L - fl[0]) ** 2 + (a - fl[1]) ** 2 + (b - fl[2]) ** 2)
        w = max(0.0, 1 - d / tol)
        out.append(oklab_to_rgbf(L + w * (tl[0] - fl[0]), a + w * (tl[1] - fl[1]),
                                 b + w * (tl[2] - fl[2])))
    return out


def _n(key, label, lo, hi, step, default):
    return (key, label, "num", lo, hi, step, default)


EXTRA = {
    "Curves": {"desc": "Drag the points (double-click adds, right-click removes).",
               "params": [("channel", "Channel", "choice",
                           ["Lightness", "RGB", "Red", "Green", "Blue"], "Lightness"),
                          ("points", "Curve", "curve", [[0, 0], [0.5, 0.5], [1, 1]])],
               "fn": _curves},
    "Vibrance": {"desc": "Boosts dull colours more than already saturated ones.",
                 "params": [_n("amount", "Amount", -100, 100, 1, 30)], "fn": _vibrance},
    "Hue shift ramp": {"desc": "Pushes darks toward one hue and lights toward another "
                               "(the pixel-art warm / cool ramp).",
                       "params": [_n("dark_hue", "Dark hue", 0, 359, 1, 260),
                                  _n("light_hue", "Light hue", 0, 359, 1, 70),
                                  _n("strength", "Strength %", 0, 100, 1, 35),
                                  _n("min_chroma", "Add colour to greys", 0, 10, 0.5, 0),
                                  ("mids", "Leave the middle alone", "bool", False)],
                       "fn": _hue_shift_ramp},
    "Saturation along ramp": {"desc": "Saturation at the ends vs the middle (by lightness).",
                              "params": [_n("ends", "Ends %", 0, 200, 1, 70),
                                         _n("middle", "Middle %", 0, 200, 1, 120)],
                              "fn": _sat_along},
    "Shadows / Highlights": {"desc": "Lift or deepen darks and lights separately.",
                             "params": [_n("shadows", "Shadows", -100, 100, 1, 20),
                                        _n("highlights", "Highlights", -100, 100, 1, 0)],
                             "fn": _shadows_highlights},
    "Colour balance": {"desc": "Tint shadows, midtones or highlights.",
                       "params": [("range", "Range", "choice",
                                   ["Shadows", "Midtones", "Highlights"], "Midtones"),
                                  _n("cyan_red", "Cyan - Red", -100, 100, 1, 0),
                                  _n("magenta_green", "Magenta - Green", -100, 100, 1, 0),
                                  _n("yellow_blue", "Yellow - Blue", -100, 100, 1, 0)],
                       "fn": _colour_balance},
    "Split toning": {"desc": "One hue into the shadows, another into the highlights.",
                     "params": [_n("shadow_hue", "Shadow hue", 0, 359, 1, 230),
                                _n("highlight_hue", "Highlight hue", 0, 359, 1, 60),
                                _n("strength", "Strength %", 0, 100, 1, 40),
                                _n("balance", "Balance", -100, 100, 1, 0)],
                     "fn": _split_tone},
    "Channel mixer": {"desc": "Each output channel as a mix of the input channels (%).",
                      "params": [_n(o + i, "%s from %s" % (o[0].upper(), i.upper()),
                                    -200, 200, 1, 100 if o[0] == i else 0)
                                 for o in ("r_", "g_", "b_") for i in "rgb"],
                      "fn": _channel_mixer},
    "Selective hue": {"desc": "Change only colours near one hue (soft edge).",
                      "params": [_n("hue", "Hue", 0, 359, 1, 120),
                                 _n("width", "Width", 1, 180, 1, 40),
                                 _n("shift", "Hue shift", -180, 180, 1, 0),
                                 _n("saturation", "Saturation %", -100, 100, 1, 0),
                                 _n("lightness", "Lightness %", -100, 100, 1, 0)],
                      "fn": _selective_hue},
    "Exposure": {"desc": "Light-linear brightness in stops.",
                 "params": [_n("stops", "Stops", -3, 3, 0.05, 0.5)], "fn": _exposure},
    "Contrast S-curve": {"desc": "Smooth contrast around a pivot lightness.",
                         "params": [_n("strength", "Strength", -100, 100, 1, 40),
                                    _n("pivot", "Pivot (L)", 5, 95, 1, 50)],
                         "fn": _s_curve},
    "Match lightness": {"desc": "Copy the lightness steps of the clipboard's colours "
                                "(Ctrl+C another ramp first); hue and chroma stay.",
                        "params": [("direction", "Direction", "choice",
                                    ["Same order", "Reversed"], "Same order")],
                        "fn": _match_lightness},
    "Jitter": {"desc": "Tiny random variation - breaks up identical-looking steps.",
               "params": [_n("amount", "Amount", 0, 100, 1, 20),
                          _n("seed", "Seed", 0, 999, 1, 1)],
               "fn": _jitter},
    "Replace colour": {"desc": "Moves colours near one colour toward another.",
                       "params": [("from", "From", "colour", "#808080"),
                                  ("to", "To", "colour", "#a05030"),
                                  _n("tolerance", "Tolerance", 1, 60, 1, 12)],
                       "fn": _replace},
}

ADJUSTMENTS = dict(FILTERS)
ADJUSTMENTS.update(EXTRA)
ADJ_NAMES = sorted(ADJUSTMENTS, key=str.lower)


def defaults(name):
    out = {}
    for spec in ADJUSTMENTS[name]["params"]:
        out[spec[0]] = [list(p) for p in spec[3]] if spec[2] == "curve" else spec[-1]
    return out


def apply_one(name, params, cols, ctx):
    if name in EXTRA:
        return EXTRA[name]["fn"](params, cols, ctx)
    return apply_filter(name, params, cols, ctx)


def _clamp(c):
    return tuple(int(round(min(max(v, 0.0), 255.0))) for v in c)


def apply_stack(stack, colours, ctx):
    """[{"name", "params", "on", "mix", "fade"}] over the colours, in order."""
    cur = [tuple(c) for c in colours]
    for a in stack:
        if not a.get("on", True) or not cur:
            continue
        new = apply_one(a["name"], a["params"], cur, ctx)
        mix = a.get("mix", 100) / 100.0
        fade = a.get("fade", "Even")
        ranks = _ranks(cur) if fade != "Even" else [0.5] * len(cur)
        out = []
        for c, n, t in zip(cur, new, ranks):
            w = mix * {"Even": 1.0, "Dark end": 1 - t, "Light end": t,
                       "Middle": 1 - abs(2 * t - 1)}[fade]
            out.append(_clamp(tuple(c[k] + (n[k] - c[k]) * w for k in range(3))))
        cur = out
    return cur
