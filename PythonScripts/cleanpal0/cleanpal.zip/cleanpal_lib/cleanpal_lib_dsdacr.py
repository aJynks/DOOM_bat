"""DSDACR (dsda-doom / Nyan Doom font colour ranges): model, lump text,
and an exact copy of how each port turns the ranges into translation tables.

DSDACR holds two RGB colours per colour range (1-14) - no palette indices.
The engine builds the index -> index tables itself at start-up against the
loaded PLAYPAL:

  1. the reference letter (STCFN065, the font's "A") gives the darkest and
     lightest pixel of the font;
  2. every palette index gets a 0..1 "length": its brightness rescaled to
     that span, clamped (index 176 is always 1 - the extended HUD bright
     value);
  3. target = start + (int)(length * (end - start)) per channel;
  4. nearest palette colour (red-dominant targets use a weighted distance).

dsda-doom (prboom2/src/dsda/cr_table.c, palette.c):
  brightness = CIELAB L* / 100.  Disabled = targets halved.  Highlighted =
  the normal result brightened x1.4 (capped) and snapped with V_BestColor.
Nyan Doom (same files in its tree):
  brightness = "intensity" (L* pulled toward HSV value by saturation), a
  one-colour font uses 0..1.  Disabled = targets x0.5, Highlighted = targets
  x1.4 (Default + Highlighted = the pixel's own colour x1.4), all snapped
  with the weighted distance.
Both: Default (range 0) normal = COLORMAP row 0 (no change), Default
disabled = COLORMAP row 15.  Nyan text shadow = index 0 (its shadow table
is built before the darkest colour is known - start-up order bug).
"""

import struct

HEADER = "STCFN065 FONTA33 FONTA33"
REF_LUMP = "STCFN065"

NAMES = ("BRICK", "TAN", "GRAY", "GREEN", "BROWN", "GOLD", "RED", "BLUE", "ORANGE",
         "YELLOW", "LIGHTBLUE", "BLACK", "PURPLE", "WHITE")

# dsda-doom.wad's DSDACR lump (prboom2/data/lumps/dsdacr.lmp) - Nyan's is the same
DEFAULTS = (
    ((0x47, 0x00, 0x00), (0xFF, 0xB8, 0xB8)),
    ((0x33, 0x2B, 0x13), (0xFF, 0xEB, 0xDF)),
    ((0x27, 0x27, 0x27), (0xEF, 0xEF, 0xEF)),
    ((0x0B, 0x17, 0x07), (0x77, 0xFF, 0x6F)),
    ((0x53, 0x3F, 0x2F), (0xBF, 0xA7, 0x8F)),
    ((0x73, 0x2B, 0x00), (0xFF, 0xFF, 0x73)),
    ((0x3F, 0x00, 0x00), (0xFF, 0x00, 0x00)),
    ((0x00, 0x00, 0x27), (0x00, 0x00, 0xFF)),
    ((0x20, 0x00, 0x00), (0xFF, 0x80, 0x00)),
    ((0x77, 0x77, 0x00), (0xFF, 0xFF, 0x00)),
    ((0x20, 0x20, 0xA0), (0xB4, 0xB4, 0xFF)),
    ((0x13, 0x13, 0x13), (0x50, 0x50, 0x50)),
    ((0x23, 0x00, 0x23), (0xCF, 0x00, 0xCF)),
    ((0x24, 0x24, 0x24), (0xFF, 0xFF, 0xFF)),
)
DEFAULT0 = ((0, 0, 0), (255, 255, 255))      # CR_DEFAULT in the code (never in the lump)

PORTS = ("nyan", "dsda")
PORT_LABEL = {"nyan": "Nyan Doom", "dsda": "dsda-doom"}
VARIANTS = ("normal", "dark", "light")
VARIANT_LABEL = {"normal": "Normal", "dark": "Disabled", "light": "Highlighted"}
BRIGHT_INDEX = 176


def default_ranges():
    return [(tuple(a), tuple(b)) for a, b in DEFAULTS]


def clean_ranges(v):
    """14 (start, end) RGB pairs from project / settings data (hex strings or
    lists), or None when it doesn't look right."""
    from .cleanpal_lib_colour import parse_colour

    if not isinstance(v, list) or len(v) != 14:
        return None
    out = []
    for pair in v:
        if not isinstance(pair, (list, tuple)) or len(pair) != 2:
            return None
        cols = []
        for c in pair:
            if isinstance(c, str):
                c = parse_colour(c)
            elif isinstance(c, (list, tuple)) and len(c) == 3 and all(
                    isinstance(x, int) and 0 <= x <= 255 for x in c):
                c = tuple(c)
            else:
                c = None
            if c is None:
                return None
            cols.append(tuple(c))
        out.append((cols[0], cols[1]))
    return out


# ============================================================ lump text
def _c_int(tok):
    """sscanf %i: 0x.. hex, 0.. octal, else decimal."""
    t = tok.strip().lower()
    neg = t.startswith("-")
    if neg or t.startswith("+"):
        t = t[1:]
    if t.startswith("0x"):
        v = int(t[2:], 16)
    elif len(t) > 1 and t.startswith("0"):
        v = int(t, 8)
    else:
        v = int(t, 10)
    return -v if neg else v


def parse_dsdacr(text, base=None):
    """DSDACR text -> (ranges, header, notes). Lines are applied on top of
    `base` (default: dsda's lump defaults), the way the engine overrides its
    table. Raises ValueError on a line the engine would reject."""
    ranges = list(base or default_ranges())
    lines = [ln for ln in text.replace("\r", "\n").split("\n") if ln.strip()]
    if not lines:
        raise ValueError("Empty DSDACR.")
    header = lines[0].split()[:3]
    seen = []
    for ln in lines[1:]:
        toks = ln.split()
        try:
            vals = [_c_int(t) for t in toks[:7]]
        except ValueError:
            vals = []
        if len(vals) != 7:
            raise ValueError("Line the engine can't read (\"DSDACR lump has unknown "
                             "format\"): %s" % ln.strip())
        i = vals[0]
        if not 1 <= i <= 14:
            raise ValueError("Colour range %d is out of bounds (1-14)." % i)
        if any(not 0 <= x <= 255 for x in vals[1:]):
            raise ValueError("Colour range %d has a colour out of range (0-255)." % i)
        ranges[i - 1] = (tuple(vals[1:4]), tuple(vals[4:7]))
        seen.append(i)
    return ranges, header, seen


def dsdacr_text(ranges):
    """All 14 ranges in the dsda lump's own layout (trailing (NAME) comment -
    a comment-only line would stop the engine)."""
    out = [HEADER]
    for k, (a, b) in enumerate(ranges):
        num = str(k + 1)
        out.append("%-2s %s (%s)" % (num, " ".join("0x%02X" % v for v in tuple(a) + tuple(b)),
                                     NAMES[k]))
    return "\n".join(out) + "\n"


# ============================================================ brightness
def lightness(rgb):
    """dsda_PaletteEntryLightness: CIELAB L* (0-100)."""
    def lin(c):
        c = c / 255.0
        return ((c + 0.055) / 1.055) ** 2.4 if c > 0.04045 else c / 12.92
    r, g, b = (lin(c) * 100 for c in rgb)
    y1 = 0.2126729 * r + 0.7151522 * g + 0.0721750 * b
    y2 = y1 / 100.0
    y2 = y2 ** (1.0 / 3) if y2 > 0.008856 else 7.787 * y2 + 4.0 / 29
    return 116 * y2 - 16


def intensity(rgb):
    """Nyan's dsda_PaletteEntryIntensity (0..1)."""
    r, g, b = rgb
    hi = max(r, g, b)
    lo = min(r, g, b)
    value = hi / 255.0
    light = lightness(rgb) / 100.0
    sat = (hi - lo) / float(hi) if hi else 0.0
    if value > light:
        light += sat * (value - light)
    return light


def brightness(rgb, port):
    return intensity(rgb) if port == "nyan" else lightness(rgb) / 100.0


# ============================================================ pictures
def picture_posts(d):
    """Palette indices of every pixel, walking the posts exactly like
    dsda_CalculateFontBounds (no tall-patch handling). None if not a picture."""
    try:
        w = struct.unpack_from("<h", d, 0)[0]
        out = []
        for i in range(w):
            p = struct.unpack_from("<i", d, 8 + 4 * i)[0]
            while d[p] != 0xFF:
                p += 1
                ln = d[p]
                p += 2
                out.extend(d[p:p + ln])
                p += ln + 1
        return out
    except (struct.error, IndexError):
        return None


def decode_glyph(d):
    """Doom picture -> (w, h, left offset, top offset, [(x, y, index)], None),
    or a paletted PNG -> (..., the PNG's own palette as 256 RGB tuples) with
    grAb offsets, or None."""
    if d is None or len(d) < 8:
        return None
    if d[:8] == b"\x89PNG\r\n\x1a\n":
        from .cleanpal_lib_wadgfx import decode_png_index
        try:
            im = decode_png_index(d)
        except Exception:
            im = None
        if im is None:
            return None
        w, h = im.size
        px = im.load()
        pts = [(x, y, px[x, y][0]) for y in range(h) for x in range(w) if px[x, y][3]]
        lo, to = _png_grab(d)
        return w, h, lo, to, pts, png_palette(d)
    from .cleanpal_lib_wadgfx import is_doom_picture
    if not is_doom_picture(d):
        return None
    w, h, lo, to = struct.unpack_from("<HHhh", d, 0)
    pts = []
    for x in range(w):
        p = struct.unpack_from("<I", d, 8 + 4 * x)[0]
        prev = -1
        while p < len(d) and d[p] != 0xFF:
            top = d[p]
            ln = d[p + 1]
            if top <= prev:              # tall patches
                top += prev
            prev = top
            src = p + 3
            for k in range(ln):
                if src + k < len(d):
                    pts.append((x, top + k, d[src + k]))
            p += 4 + ln
    return w, h, lo, to, pts, None


def png_palette(d):
    """The PLTE of a paletted PNG as a list of RGB tuples, or None."""
    import io
    try:
        from PIL import Image
        with Image.open(io.BytesIO(d)) as im:
            if im.mode != "P":
                return None
            raw = im.getpalette() or []
    except Exception:
        return None
    return [tuple(raw[i:i + 3]) for i in range(0, len(raw) - 2, 3)]


def png_translation(png_pal, playpal):
    """Nyan's r_png.c for paletted PNGs: an entry equal to the loaded
    PLAYPAL's entry keeps its index, any other is re-matched by colour
    (V_BestColor). None when nothing changes."""
    if not png_pal:
        return None
    out = {}
    for i, c in enumerate(png_pal[:256]):
        if i < len(playpal) and tuple(playpal[i]) == tuple(c):
            continue
        out[i] = best_plain(playpal, c)
    return out or None


def _png_grab(d):
    """grAb chunk offsets of a PNG (0, 0 when there is none)."""
    p = 8
    while p + 8 <= len(d):
        ln = struct.unpack_from(">I", d, p)[0]
        typ = d[p + 4:p + 8]
        if typ == b"grAb" and ln >= 8:
            return struct.unpack_from(">ii", d, p + 8)
        if typ == b"IEND":
            break
        p += 12 + ln
    return 0, 0


# ============================================================ colour matching
def best_weighted(pal, t):
    """The cr_table nearest-colour search (first minimum wins)."""
    tr, tg, tb = t
    best_i = 0
    best = None
    redd = tr > tg and tr > tb
    for i, (pr, pg, pb) in enumerate(pal):
        dr = tr - pr
        dg = tg - pg
        db = tb - pb
        if redd:
            avg = (tr + pr) // 2
            dist = (((512 + avg) * dr * dr) >> 8) + 4 * dg * dg + \
                (((767 - avg) * db * db) >> 8)
        else:
            dist = dr * dr + dg * dg + db * db
        if best is None or dist < best:
            best = dist
            best_i = i
    return best_i


def best_plain(pal, t):
    """V_BestColor: plain RGB distance, first minimum, exact match stops."""
    tr, tg, tb = t
    best_i = 0
    best = 257 * 257 * 3
    for i, (pr, pg, pb) in enumerate(pal):
        dist = (tr - pr) ** 2 + (tg - pg) ** 2 + (tb - pb) ** 2
        if dist < best:
            if dist == 0:
                return i
            best = dist
            best_i = i
    return best_i


def _ctrunc(v):
    """C (int) cast of a double: truncate toward zero."""
    return int(v)


class CRBuilder:
    """Translation tables for one palette + reference font + port. Entries
    are worked out on demand and cached (a preview only needs the indices
    the font uses)."""

    def __init__(self, pal, ref_indices, port):
        self.pal = [tuple(c) if c is not None else (0, 0, 0) for c in pal[:256]]
        while len(self.pal) < 256:
            self.pal.append((0, 0, 0))
        self.port = port if port in PORTS else "nyan"
        self._bright = [brightness(c, self.port) for c in self.pal]
        lo, hi = 1.0, 0.0
        for i in (ref_indices or ()):
            v = self._bright[i]
            lo = min(lo, v)
            hi = max(hi, v)
        if not ref_indices:
            lo, hi = 0.0, 1.0
        self.flat = hi <= lo
        if self.flat:                      # Nyan's guard (dsda would divide by 0)
            lo, hi = 0.0, 1.0
        self.lo, self.hi = lo, hi
        self.mult = 1.0 / (hi - lo)
        self._match = {}
        self._plain = {}
        self._brighten = {}

    def length(self, i):
        v = (self._bright[i] - self.lo) * self.mult
        v = 0.0 if v < 0 else (1.0 if v > 1 else v)
        if i == BRIGHT_INDEX:
            v = 1.0
        return v

    @staticmethod
    def target(rng, length):
        (r1, g1, b1), (r2, g2, b2) = rng
        return (r1 + _ctrunc(length * (r2 - r1)), g1 + _ctrunc(length * (g2 - g1)),
                b1 + _ctrunc(length * (b2 - b1)))

    def match(self, t):
        k = self._match.get(t)
        if k is None:
            k = self._match[t] = best_weighted(self.pal, t)
        return k

    def _brighten_entry(self, e):
        """dsda_BrightenPaletteEntry."""
        k = self._brighten.get(e)
        if k is not None:
            return k
        r, g, b = self.pal[e]
        mx = max(r, g, b)
        if not mx:
            self._brighten[e] = e
            return e
        scale = 1.4
        if mx * scale > 255.0:
            scale = 255.0 / mx
        t = (int(r * scale + 0.5), int(g * scale + 0.5), int(b * scale + 0.5))
        k = self._plain.get(t)
        if k is None:
            k = self._plain[t] = best_plain(self.pal, t)
        self._brighten[e] = k
        return k

    def variant_target(self, rng, length, variant):
        """The RGB the port snaps for this range / length / variant (Nyan
        targets can go past 255 when brightened - the search copes)."""
        t = self.target(rng, length)
        if self.port == "nyan":
            f = {"normal": 1.0, "dark": 0.5, "light": 1.4}[variant]
            return tuple(_ctrunc(c * f) for c in t)
        if variant == "dark":
            return tuple(c // 2 for c in t)
        return t

    def entry(self, rng, i, variant="normal"):
        """Translated index of palette index i through a range (1-14)."""
        ln = self.length(i)
        if self.port == "dsda" and variant == "light":
            return self._brighten_entry(self.match(self.target(rng, ln)))
        return self.match(self.variant_target(rng, ln, variant))

    def default_entry(self, i, variant, row15=None):
        """Range 0 (Default): no translation; Disabled = COLORMAP row 15;
        Highlighted = dsda brighten / Nyan own colour x1.4."""
        if variant == "dark":
            return row15[i] if row15 else i
        if variant == "light":
            if self.port == "dsda":
                return self._brighten_entry(i)
            return self.match(tuple(_ctrunc(c * 1.4) for c in self.pal[i]))
        return i

    def strip(self, rng, n, variant="normal"):
        """n samples along the range (length 0..1): [(true rgb, index)]."""
        out = []
        for k in range(n):
            ln = k / float(max(1, n - 1))
            t = self.variant_target(rng, ln, variant)
            if self.port == "dsda" and variant == "light":
                idx = self._brighten_entry(self.match(self.target(rng, ln)))
            else:
                idx = self.match(t)
            out.append((tuple(max(0, min(255, c)) for c in t), idx))
        return out


# ============================================================ test messages
MESSAGES = (
    "Picked up the armor.", "Picked up the MegaArmor!", "Picked up a health bonus.",
    "Picked up an armor bonus.", "Supercharge!", "MegaSphere!",
    "Picked up a blue keycard.", "Picked up a yellow keycard.", "Picked up a red keycard.",
    "Picked up a blue skull key.", "Picked up a yellow skull key.",
    "Picked up a red skull key.", "Picked up a stimpack.",
    "Picked up a medikit that you REALLY need!", "Picked up a medikit.",
    "Invulnerability!", "Berserk!", "Partial Invisibility", "Radiation Shielding Suit",
    "Computer Area Map", "Light Amplification Visor", "Picked up a clip.",
    "Picked up a box of bullets.", "Picked up a rocket.", "Picked up a box of rockets.",
    "Picked up an energy cell.", "Picked up an energy cell pack.",
    "Picked up 4 shotgun shells.", "Picked up a box of shotgun shells.",
    "Picked up a backpack full of ammo!", "You got the BFG9000!  Oh, yes.",
    "You got the chaingun!", "A chainsaw!  Find some meat!",
    "You got the rocket launcher!", "You got the plasma gun!", "You got the shotgun!",
    "You got the super shotgun!", "You need a blue key to activate this object",
    "You need a red key to activate this object",
    "You need a yellow key to activate this object",
    "You need a blue key to open this door", "You need a red key to open this door",
    "You need a yellow key to open this door", "A secret is revealed!",
    "Game saved.", "Messages OFF", "Messages ON", "Degreelessness Mode On",
    "Very Happy Ammo Added", "Ammo (no keys) Added", "No Clipping Mode ON",
    "level 1: entryway", "level 2: underhalls", "level 7: dead simple",
    "Kills: 100%  Items: 100%  Secrets: 100%", "Time 01:23.45", "0123456789",
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "!\"#$%&'()*+,-./:;<=>?@[\\]^_",
)

FONTS = (
    # key, label, kind
    ("stcfn", "Messages / menus (STCFN)", "text"),
    ("dig", "Extended HUD (DIG)", "text"),
    ("sttnum", "Status bar big numbers (STTNUM)", "num"),
    ("stysnum", "Status bar small numbers (STYSNUM)", "small"),
)
FONT_LABEL = {k: lbl for k, lbl, _x in FONTS}
SPACE_WIDTH = {"stcfn": 4, "dig": 5, "sttnum": 4, "stysnum": 4}


def glyph_names(font, ch):
    """Lump names to try for one character (first found wins)."""
    o = ord(ch)
    if font == "stcfn":
        u = ord(ch.upper()) if ch.isalpha() else o
        return ["STCFN%03d" % u] if 33 <= u <= 127 else []
    if font == "dig":
        names = ["DIG%03d" % o] if 33 <= o <= 127 else []
        if ch.isalpha() and ch.upper() != ch:
            names.append("DIG%03d" % ord(ch.upper()))
        return names
    if font == "sttnum":
        if ch.isdigit():
            return ["STTNUM%s" % ch]
        return {"-": ["STTMINUS"], "%": ["STTPRCNT"]}.get(ch, [])
    if font == "stysnum":
        return ["STYSNUM%s" % ch] if ch.isdigit() else []
    return []
