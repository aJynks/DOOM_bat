"""Automap colours (OPTIONS lump mapcolor_* keys) for dsda-doom / Nyan Doom.

Model: {key: palette index 0-255}. OPTIONS is a text lump, one "name value"
per line, '#' at column 1 = comment, lines over 79 characters are cut by the
port (dsda/options.c dsda_ParseOptionsLump). In the automap a value of 0
turns a FEATURE off (locked doors, closed doors, teleporters, secrets,
exits, flat lines, keys) - those lines then draw by the plain rules.

Line colours copy dsda / Nyan am_map.c AM_wallStyle + AM_drawWalls (the two
ports are identical there) for Doom-format maps (Doom / Boom / MBF21
binary): dsda/map_format.c door / exit / teleport tests, P_IsSecret (sector
special 9 or the Boom secret bit), P_IsDeathExit (sector 11 / MBF21 death
exit bits).

CLASSIC = vanilla Doom's automap (id am_map.c) through those rules:
background BLACK 0, walls REDS 176, floor change BROWNS 64, ceiling change
YELLOWS 231, grid GRAYS+8 104, player WHITE 209, things GREENS 112,
crosshair GRAYS 96, IDDT plain two-sided GRAYS 96, computer map GRAYS+3 99,
teleporters (special 39) WALLCOLORS+WALLRANGE/2 184; every modern feature
off (0) so those lines draw as vanilla's plain ones.
"""

import struct

# key, group, label, help, feature (0 = feature off)
KEYS = (
    ("mapcolor_back", "Lines", "Background", "automap background", False),
    ("mapcolor_grid", "Lines", "Grid", "grid lines (and blinking locked doors)", False),
    ("mapcolor_wall", "Lines", "One-sided walls", "solid walls; secret doors too", False),
    ("mapcolor_fchg", "Lines", "Floor change", "two-sided, floor heights differ", False),
    ("mapcolor_cchg", "Lines", "Ceiling change", "two-sided, ceiling heights differ "
     "(also locked doors whose colour is off)", False),
    ("mapcolor_clsd", "Lines", "Closed doors", "two-sided, a side has floor = ceiling",
     True),
    ("mapcolor_rdor", "Lines", "Red locked door", "red key door lines", True),
    ("mapcolor_bdor", "Lines", "Blue locked door", "blue key door lines", True),
    ("mapcolor_ydor", "Lines", "Yellow locked door", "yellow key door lines", True),
    ("mapcolor_tele", "Lines", "Teleporters", "two-sided teleport lines (39, 97, 125, "
     "126)", True),
    ("mapcolor_secr", "Lines", "Secret sectors", "lines of secrets not found yet", True),
    ("mapcolor_revsecr", "Lines", "Found secrets", "lines of secrets already found", True),
    ("mapcolor_exit", "Lines", "Exits", "exit lines (11, 52, 197) + death exits", True),
    ("mapcolor_exitsecr", "Lines", "Secret exits", "secret exit lines (51, 124, 198)",
     True),
    ("mapcolor_unsn", "Lines", "Unseen (computer map)", "lines shown by the computer "
     "area map", False),
    ("mapcolor_flat", "Lines", "Flat two-sided", "two-sided lines with no height change "
     "(IDDT / computer map)", True),
    ("mapcolor_tagfinder", "Lines", "Tag finder", "dsda tag finder highlight "
     "(not in the preview)", False),
    ("mapcolor_hair", "HUD", "Crosshair", "automap crosshair (not in the preview)", False),
    ("mapcolor_sngl", "HUD", "Player arrow", "single-player arrow (not in the preview)",
     False),
    ("mapcolor_me", "HUD", "Your arrow (net)", "your arrow in netgames (not in the "
     "preview)", False),
    ("mapcolor_sprt", "Things", "Things", "IDDT things (not in the preview)", False),
    ("mapcolor_enemy", "Things", "Enemies", "IDDT counted monsters (not in the preview)",
     False),
    ("mapcolor_frnd", "Things", "Friends", "IDDT friendly monsters (not in the preview)",
     False),
    ("mapcolor_item", "Things", "Items", "IDDT counted items (not in the preview)", False),
    ("mapcolor_pickup", "Things", "Pickups", "IDDT other pickups (not in the preview)",
     False),
    ("mapcolor_rkey", "Things", "Red key", "IDDT red keys (not in the preview)", True),
    ("mapcolor_bkey", "Things", "Blue key", "IDDT blue keys (not in the preview)", True),
    ("mapcolor_ykey", "Things", "Yellow key", "IDDT yellow keys (not in the preview)",
     True),
    ("mapcolor_marker", "Nyan only", "Marks", "Nyan map mark numbers (not in the "
     "preview)", False),
    ("mapcolor_hitbox", "Nyan only", "Hitboxes", "Nyan thing hitboxes (not in the "
     "preview)", False),
)
KEY_NAMES = tuple(k[0] for k in KEYS)
FEATURE = {k[0] for k in KEYS if k[4]}
NYAN_ONLY = {"mapcolor_marker", "mapcolor_hitbox"}

CLASSIC = {
    "mapcolor_back": 0, "mapcolor_grid": 104, "mapcolor_wall": 176, "mapcolor_fchg": 64,
    "mapcolor_cchg": 231, "mapcolor_clsd": 0, "mapcolor_rdor": 0, "mapcolor_bdor": 0,
    "mapcolor_ydor": 0, "mapcolor_tele": 184, "mapcolor_secr": 0, "mapcolor_revsecr": 0,
    "mapcolor_exit": 0, "mapcolor_exitsecr": 0, "mapcolor_unsn": 99, "mapcolor_flat": 96,
    "mapcolor_tagfinder": 252, "mapcolor_hair": 96, "mapcolor_sngl": 209,
    "mapcolor_me": 209, "mapcolor_sprt": 112, "mapcolor_enemy": 112, "mapcolor_frnd": 112,
    "mapcolor_item": 112, "mapcolor_pickup": 112, "mapcolor_rkey": 0, "mapcolor_bkey": 0,
    "mapcolor_ykey": 0, "mapcolor_marker": 208, "mapcolor_hitbox": 104,
}
# dsda-doom's own defaults (configuration.c) - for reference / a reset
DSDA_DEFAULTS = {
    "mapcolor_back": 247, "mapcolor_grid": 104, "mapcolor_wall": 23, "mapcolor_fchg": 55,
    "mapcolor_cchg": 215, "mapcolor_clsd": 208, "mapcolor_rkey": 175, "mapcolor_bkey": 204,
    "mapcolor_ykey": 231, "mapcolor_rdor": 175, "mapcolor_bdor": 204, "mapcolor_ydor": 231,
    "mapcolor_tele": 119, "mapcolor_secr": 252, "mapcolor_revsecr": 112,
    "mapcolor_tagfinder": 252, "mapcolor_exit": 0, "mapcolor_exitsecr": 0,
    "mapcolor_unsn": 104, "mapcolor_flat": 88, "mapcolor_sprt": 88, "mapcolor_item": 231,
    "mapcolor_hair": 208, "mapcolor_sngl": 208, "mapcolor_me": 112, "mapcolor_enemy": 177,
    "mapcolor_frnd": 112, "mapcolor_pickup": 112, "mapcolor_marker": 208,
    "mapcolor_hitbox": 104,
}


def classic():
    return dict(CLASSIC)


def clean_colours(v):
    """{key: 0-255} from project data, or None."""
    if not isinstance(v, dict):
        return None
    out = classic()
    for k, x in v.items():
        if k in out and isinstance(x, int) and not isinstance(x, bool) and 0 <= x <= 255:
            out[k] = x
    return out


# ============================================================ OPTIONS text
def parse_options(text):
    """OPTIONS text -> (colours found {key: value}, other lines kept in
    order). Mirrors the port: '#' at column 1 = comment, "%79s %d", values
    clamped 0-255."""
    found = {}
    other = []
    for raw in text.replace("\r", "").split("\n"):
        line = raw[:79]
        toks = line.split()
        key = toks[0] if toks else ""
        if not line.startswith("#") and key in KEY_NAMES and len(toks) >= 2:
            try:
                found[key] = max(0, min(255, int(toks[1])))
                continue
            except ValueError:
                pass
        other.append(raw)
    while other and not other[-1].strip():
        other.pop()
    return found, other


def options_text(colours, other=()):
    """The OPTIONS lump: the other (gameplay / comp / comment) lines first,
    unchanged, then every mapcolor_* key."""
    out = [ln for ln in other]
    if out:
        out.append("")
    out.append("# Automap colours (PLAYPAL indices) - cleanpal")
    for k in KEY_NAMES:
        if k in NYAN_ONLY:
            continue
        out.append("%s %d" % (k, colours[k]))
    out.append("# Nyan Doom only")
    for k in KEY_NAMES:
        if k in NYAN_ONLY:
            out.append("%s %d" % (k, colours[k]))
    return "\n".join(out) + "\n"


# ============================================================ maps
MAP_LUMPS = ("THINGS", "LINEDEFS", "SIDEDEFS", "VERTEXES", "SEGS", "SSECTORS", "NODES",
             "SECTORS", "REJECT", "BLOCKMAP", "BEHAVIOR")


def find_maps(arch):
    """[(name, index of the marker)] for the Doom-format maps of a
    WadArchive (UDMF / Hexen maps are skipped). Order as in the WAD."""
    out = []
    lumps = arch.lumps
    n = len(lumps)
    for i in range(n - 1):
        if lumps[i + 1][0] != "THINGS":
            continue
        names = set()
        j = i + 1
        while j < n and lumps[j][0] in MAP_LUMPS:
            names.add(lumps[j][0])
            j += 1
        if "BEHAVIOR" in names or not {"LINEDEFS", "SIDEDEFS", "VERTEXES",
                                        "SECTORS"} <= names:
            continue
        out.append((lumps[i][0], i))
    return out


class DoomMap:
    """The parts of a Doom-format map the automap needs."""

    def __init__(self, arch, marker):
        lumps = arch.lumps
        found = {}
        j = marker + 1
        while j < len(lumps) and lumps[j][0] in MAP_LUMPS:
            found.setdefault(lumps[j][0], j)
            j += 1

        def raw(name):
            k = found.get(name)
            return arch.lump_at(k) if k is not None else b""
        self.name = lumps[marker][0]
        v = raw("VERTEXES")
        self.verts = [struct.unpack_from("<hh", v, o) for o in range(0, len(v) - 3, 4)]
        s = raw("SECTORS")
        # floor, ceiling, special
        self.sectors = [(struct.unpack_from("<hh", s, o) +
                         (struct.unpack_from("<H", s, o + 22)[0],))
                        for o in range(0, len(s) - 25, 26)]
        sd = raw("SIDEDEFS")
        self.side_sector = [struct.unpack_from("<H", sd, o + 28)[0]
                            for o in range(0, len(sd) - 29, 30)]
        ld = raw("LINEDEFS")
        self.lines = []
        nv, ns = len(self.verts), len(self.side_sector)
        for o in range(0, len(ld) - 13, 14):
            v1, v2, flags, special, tag, s0, s1 = struct.unpack_from("<HHHHHHH", ld, o)
            if v1 >= nv or v2 >= nv:
                continue
            fs = self._sec(s0, ns)
            bs = self._sec(s1, ns) if s1 != 0xFFFF else None
            if fs is None:
                continue
            self.lines.append((v1, v2, flags, special, fs, bs))
        bm = raw("BLOCKMAP")
        self.bmorg = struct.unpack_from("<hh", bm, 0) if len(bm) >= 4 else (0, 0)
        if self.verts:
            xs = [p[0] for p in self.verts]
            ys = [p[1] for p in self.verts]
            self.bbox = (min(xs), min(ys), max(xs), max(ys))
        else:
            self.bbox = (0, 0, 1, 1)

    def _sec(self, side, ns):
        if side >= ns:
            return None
        sec = self.side_sector[side]
        return sec if sec < len(self.sectors) else None


# ============================================================ line rules
ML_SECRET, ML_DONTDRAW, ML_MAPPED = 0x0020, 0x0080, 0x0100
SECRET_MASK, DEATH_MASK, DAMAGE_MASK, DAMAGE_SHIFT = 0x80, 0x1000, 0x60, 5
GEN_LOCKED_BASE, GEN_DOOR_BASE, LOCKED_KEY, LOCKED_KEY_SHIFT = 0x3800, 0x3C00, 0x01C0, 6
REVEALS = ("normal", "allmap", "iddt")
REVEAL_LABEL = {"normal": "Normal (all seen)", "allmap": "Computer map",
                "iddt": "IDDT"}


def door_type(special):
    """dsda_DoorType for Doom-format maps: -1 none, 0 red, 1 blue,
    2 yellow / unknown, 3 multiple."""
    if GEN_LOCKED_BASE <= special < GEN_DOOR_BASE:
        k = ((special - GEN_LOCKED_BASE) & LOCKED_KEY) >> LOCKED_KEY_SHIFT
        if not k or k == 7:
            return 3
        return (k - 1) % 3
    if special in (26, 32, 99, 133):
        return 1
    if special in (27, 34, 136, 137):
        return 2
    if special in (28, 33, 134, 135):
        return 0
    return -1


def _is_secret(special):
    if special < 32:
        return special == 9
    return bool(special & SECRET_MASK)


def _death(special):
    """0 none, 2 death exit, 3 death secret exit (MBF21 / sector 11 = both)."""
    if special < 32:
        return 23 if special == 11 else 0
    if special & DEATH_MASK:
        i = (special & DAMAGE_MASK) >> DAMAGE_SHIFT
        return i if i in (2, 3) else 0
    return 0


EXIT_LINES = (11, 52, 197)
SECRET_EXIT_LINES = (51, 124, 198)
TELE_LINES = (39, 97, 125, 126)


def line_colour_key(m, ln, c, reveal="iddt", found=False):
    """The mapcolor key a line draws with, or None (not drawn). c = the
    colour values (only whether a feature key is 0 matters here); reveal =
    normal (every line counts as seen) / allmap (computer map: lines not
    marked mapped in the map count as unseen) / iddt; found = secrets
    already found (revealed secrets) or not."""
    v1, v2, flags, special, fs, bs = ln
    secs = m.sectors
    iddt = reveal == "iddt"
    seen = iddt or reveal == "normal" or (flags & ML_MAPPED)
    fsec = secs[fs]

    def secret(si):
        return _is_secret(secs[si][2])
    hidden_secrets = bool(c["mapcolor_secr"]) and not found
    revealed = bool(c["mapcolor_revsecr"]) and found

    if seen:
        if (flags & ML_DONTDRAW) and not iddt:
            return None
        if (c["mapcolor_bdor"] or c["mapcolor_ydor"] or c["mapcolor_rdor"]) and \
                not (flags & ML_SECRET) and door_type(special) != -1:
            t = door_type(special)
            key = ("mapcolor_rdor", "mapcolor_bdor", "mapcolor_ydor", "mapcolor_clsd")[t]
            return key if c[key] else "mapcolor_cchg"
        sec_exit = special in SECRET_EXIT_LINES
        is_exit = special in EXIT_LINES
        if c["mapcolor_exitsecr"] and sec_exit and not is_exit:
            return "mapcolor_exitsecr"
        if c["mapcolor_exit"] and (is_exit or sec_exit):
            return "mapcolor_exit"
        d = _death(fsec[2])
        de, dse = d in (2, 23), d in (3, 23)
        if c["mapcolor_exitsecr"] and dse and not de:
            return "mapcolor_exitsecr"
        if c["mapcolor_exit"] and (de or dse):
            return "mapcolor_exit"
        if bs is None:
            if hidden_secrets and secret(fs):
                return "mapcolor_secr"
            if revealed and secret(fs):
                return "mapcolor_revsecr"
            return "mapcolor_wall"
        bsec = secs[bs]
        if c["mapcolor_tele"] and not (flags & ML_SECRET) and special in TELE_LINES:
            return "mapcolor_tele"
        if flags & ML_SECRET:
            return "mapcolor_wall"
        if c["mapcolor_clsd"] and (bsec[0] == bsec[1] or fsec[0] == fsec[1]):
            return "mapcolor_clsd"
        if hidden_secrets and (secret(fs) or secret(bs)):
            return "mapcolor_secr"
        if revealed and (secret(fs) or secret(bs)):
            return "mapcolor_revsecr"
        dx = _death(fsec[2]) or _death(bsec[2])
        if c["mapcolor_exitsecr"] and not c["mapcolor_exit"] and dx:
            return "mapcolor_exitsecr"
        if (c["mapcolor_exit"] or c["mapcolor_exitsecr"]) and dx:
            return "mapcolor_exit"
        if bsec[0] != fsec[0]:
            return "mapcolor_fchg"
        if bsec[1] != fsec[1]:
            return "mapcolor_cchg"
        if c["mapcolor_flat"] and iddt:
            return "mapcolor_flat"
        return None
    # computer map, line not seen
    if not (flags & ML_DONTDRAW):
        if c["mapcolor_flat"] or bs is None or secs[bs][0] != fsec[0] or \
                secs[bs][1] != fsec[1]:
            return "mapcolor_unsn"
    return None
