"""Shared constants, paths and small formatting helpers."""

import os


VERSION = "6.0.3"
SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "cleanpal")
SETTINGS_PATH = os.path.join(APP_DIR, "cleanpal_settings.json")
LEGACY_SETTINGS_PATH = os.path.join(SCRIPT_DIR, "cleanpal_settings.json")
PRESET_DIR = os.path.join(APP_DIR, "presets")
PRESET_MARKER = "cleanpal_preset"


# ============================================================ constants
ENTRIES = 256
GREEN = (0, 255, 0)
METRICS = ("de2000", "lab", "rgb")
METRIC_LABEL = {"de2000": "CIEDE2000", "lab": "CIE Lab dE76", "rgb": "Weighted RGB"}
METRIC_TOKEN = {"de2000": "DE2000", "lab": "CIE", "rgb": "RGB"}
METRIC_HOVER = {"de2000": "dE00", "lab": "dE", "rgb": "dRGB"}
DEFAULT_TOL = {"de2000": 1.5, "lab": 2.0, "rgb": 1.1}
TOL_RANGE = {"de2000": (10.0, 0.05), "lab": (10.0, 0.05), "rgb": (5.0, 0.05)}  # (max, step)
SETTINGS_VERSION = 2

# Doom dcolors.c palette shifts: (target, fraction) per palette, index 0 = none
# PLAYPAL rows 1-13 exactly as SLADE's "Generate Palettes" (Doom, 14) makes
# them (Palette::idtint): new = c + (target - c) * shift / steps, C integer
# division (truncates toward zero), clamped 0-255. (target, shift, steps)
TINTS = (
    [None]
    + [((255, 0, 0), a, 9) for a in range(1, 9)]       # 1-8  pain (REDPALS)
    + [((215, 186, 69), a, 8) for a in range(1, 5)]    # 9-12 item pickup (BONUSPALS)
    + [((0, 256, 0), 1, 8)]                            # 13   radsuit
)
# overlay images written with the blank DoomTools playpal: name, rows
TINT_OVERLAYS = (("pain", range(1, 9)), ("items", range(9, 13)), ("radsuit", (13,)))

EXPORTS = [
    # label, default file name, extension (the save dialog allows any name)
    ("slade : playpal", "slade_playpal.pal", ".pal"),
    ("slade : pal0", "slade_pal0.pal", ".pal"),
    ("slade : png", "slade_pal0.png", ".png"),
    ("doomtools : playpal", "doomtools_playpal.png", ".png"),
    ("doomtools : blank", "doomtools_playpal_blank.png", ".png"),
    ("colourmap : png", "colormap.png", ".png"),
    ("colourmap : lump", "colormap.cmp", ".cmp"),
    ("playpal : lump", "playpal.lmp", ".lmp"),
]
EXPORT_LABELS = [e[0] for e in EXPORTS]
EXPORT_DEFAULT = "doomtools : playpal"
# old labels found in settings / presets / projects -> current label
EXPORT_LEGACY = {"DoomTools playpal.png": "doomtools : playpal",
                 "DoomTools blank playpal.png": "doomtools : blank",
                 "SLADE pal0.png": "slade : png",
                 "SLADE pal0.pal": "slade : pal0",
                 "SLADE playpal.pal": "slade : playpal",
                 "Analysis PNGs (identical / similar / aligned)": "slade : playpal",
                 "Analysis PNGs (identical / simular / aligned)": "slade : playpal"}


PICKER_MODES = ["RGB Sliders", "HSL Sliders", "HSL Colour Wheel", "HSL Box", "Photoshop",
                "OKLCH Sliders", "LAB Sliders", "Greyscale Slider"]


def fmt_tol(v):
    s = ("%.3f" % v).rstrip("0")
    if s.endswith("."):
        s += "0"
    return s
