"""Exact / similar colour analysis and distance-pair tables."""

import heapq

from .cleanpal_lib_colour import dist_de2000, dist_lab, dist_rgb, srgb_to_lab
from .cleanpal_lib_constants import ENTRIES, METRICS


# ============================================================ union-find
class UF:
    def __init__(self, n):
        self.p = list(range(n))

    def find(self, x):
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            # lower index becomes root (cosmetic; groups are sorted anyway)
            if ra < rb:
                self.p[rb] = ra
            else:
                self.p[ra] = rb



def _dist(m, labs, rgbs, a, b):
    if m == "de2000":
        return dist_de2000(labs[a], labs[b])
    if m == "lab":
        return dist_lab(labs[a], labs[b])
    return dist_rgb(rgbs[a], rgbs[b])


class Pairs(dict):
    """metric -> sorted (distance, a, b) list, exact pairs excluded. Built on
    first use per metric, so only the metric Cull actually uses costs time."""

    def __init__(self, rgbs, labs, done=None):
        super().__init__(done or {})
        self.rgbs, self.labs = rgbs, labs

    def __missing__(self, m):
        rgbs, labs = self.rgbs, self.labs
        out = []
        n = min(ENTRIES, len(rgbs))
        for a in range(n):
            if rgbs[a] is None:
                continue
            for b in range(a + 1, n):
                if rgbs[b] is None or rgbs[a] == rgbs[b]:
                    continue
                out.append((_dist(m, labs, rgbs, a, b), a, b))
        out.sort()
        self[m] = out
        return out


def build_pairs(rgbs):
    labs = [srgb_to_lab(*c) if c is not None else None for c in rgbs]
    return labs, Pairs(list(rgbs), labs)


KEEP_RULES = ["First index", "Most saturated", "Lightest", "Darkest", "Nearest average"]


def _survivor(g, rgbs, rule):
    """Which cell of a similar group is kept."""
    if rule == "First index" or len(g) < 2:
        return g[0]
    labs = {i: srgb_to_lab(*rgbs[i]) for i in g}
    if rule == "Most saturated":
        return max(g, key=lambda i: (labs[i][1] ** 2 + labs[i][2] ** 2, -i))
    if rule == "Lightest":
        return max(g, key=lambda i: (labs[i][0], -i))
    if rule == "Darkest":
        return min(g, key=lambda i: (labs[i][0], i))
    mean = [sum(labs[i][k] for i in g) / len(g) for k in range(3)]
    return min(g, key=lambda i: (sum((labs[i][k] - mean[k]) ** 2 for k in range(3)), i))


# ============================================================ analysis
def analyse(rgbs, pairs, do_exact, do_similar, tol, selection=None, deleted=None,
            locked=None, keep="First index"):
    """rgbs may contain None (empty slots). selection: None = similar matching
    works on the whole palette; a set = only those colours (they can only
    merge with each other; an empty set culls nothing).
    rgbs can be longer than the palette: entries past ENTRIES are the held
    cells below the red line - status "held" (or "empty"), never culled.
    locked: palette cells that take no part in matching (never culled, never
    keepers) and stay in place in the Align packing."""
    locked = set(locked or ())
    status = ["kept" if c is not None else "empty" for c in rgbs[:ENTRIES]]
    status += ["held" if c is not None else "empty" for c in rgbs[ENTRIES:]]
    for i in deleted or ():
        if i < ENTRIES and status[i] == "kept" and i not in locked:
            status[i] = "deleted"  # manual delete: out of all matching
    owner = list(range(len(rgbs)))
    identical, similar = [], []

    if do_exact:
        first = {}
        groups = {}
        for i, c in enumerate(rgbs[:ENTRIES]):
            if status[i] != "kept" or i in locked:
                continue
            if c in first:
                status[i] = "exact"
                owner[i] = first[c]
                groups[first[c]].append(i)
            else:
                first[c] = i
                groups[i] = [i]
        identical = sorted(g for g in groups.values() if len(g) > 1)

    nxt = None
    if do_similar:                    # works with or without the exact pass
        alive = [status[i] == "kept" and i not in locked and
                 (selection is None or i in selection) for i in range(ENTRIES)]
        uf = UF(ENTRIES)
        if not do_exact:              # duplicates are distance 0: same group
            first = {}
            for i in range(ENTRIES):
                if alive[i]:
                    c = rgbs[i]
                    if c in first:
                        uf.union(first[c], i)
                    else:
                        first[c] = i
        for d, a, b in pairs:
            if alive[a] and alive[b]:
                if d > tol:
                    if uf.find(a) != uf.find(b):
                        nxt = (d, a, b)       # the next pair the slider would merge
                        break
                    continue
                uf.union(a, b)
        clusters = {}
        for i in range(ENTRIES):
            if alive[i]:
                clusters.setdefault(uf.find(i), []).append(i)
        for g in clusters.values():
            if len(g) > 1:
                similar.append(g)
                s = _survivor(g, rgbs, keep)
                for i in g:
                    if i != s:
                        status[i] = "similar"
                        owner[i] = s
        similar.sort()

    kept = [i for i in range(ENTRIES) if status[i] == "kept"]
    # Align packing: locked cells stay put, the other kept colours fill the
    # remaining slots from index 0 in order
    aligned = [None] * ENTRIES
    for i in locked:
        if i < ENTRIES:
            aligned[i] = i if status[i] == "kept" else None
    rest = iter(i for i in kept if i not in locked)
    for s in range(ENTRIES):
        if s not in locked:
            aligned[s] = next(rest, None)
    return {"status": status, "owner": owner, "identical": identical,
            "similar": similar, "kept": kept, "aligned": aligned,
            "exact_all": identical, "similar_all": similar, "next": nxt}


def result_entries(rgbs, res, align):
    if align:
        return [rgbs[i] if i is not None else None for i in res["aligned"]]
    return [rgbs[i] if res["status"][i] == "kept" else None for i in range(ENTRIES)]



def update_pairs(rgbs, labs, pairs, changed):
    """New (labs, pairs) after the colours at `changed` indices changed.
    Much faster than build_pairs when few entries change."""
    changed = set(changed)
    labs = list(labs) + [None] * max(0, len(rgbs) - len(labs))
    for i in changed:
        labs[i] = srgb_to_lab(*rgbs[i]) if rgbs[i] is not None else None
    out = Pairs(list(rgbs), labs)
    for m in [m for m in METRICS if m in pairs]:     # metrics not built yet stay lazy
        keep = [t for t in pairs[m] if t[1] not in changed and t[2] not in changed]
        new = []
        for a in changed:
            if a >= ENTRIES or rgbs[a] is None:     # held cells have no pairs
                continue
            for b in range(ENTRIES):
                if b == a or b >= len(rgbs) or rgbs[b] is None or rgbs[a] == rgbs[b]:
                    continue
                if b in changed and b < a:
                    continue                  # pair already done from b's side
                if m == "de2000":
                    d = dist_de2000(labs[a], labs[b])
                elif m == "lab":
                    d = dist_lab(labs[a], labs[b])
                else:
                    d = dist_rgb(rgbs[a], rgbs[b])
                new.append((d, min(a, b), max(a, b)))
        new.sort()
        out[m] = list(heapq.merge(keep, new))
    return labs, out
