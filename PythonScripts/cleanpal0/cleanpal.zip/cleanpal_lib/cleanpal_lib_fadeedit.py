"""Edit Fades engine (COLORMAP tool 4): one fade = rows 0-31 as a gradient.

* A fade's gradient uses the Paint ramp state format (cleanpal_lib_ramps):
  nodes [{"pos" 0..1, "rgb", "hsl"}], space (blend), ease, strength,
  ease_scope - always "Each segment" here, so a node's position is the row
  it sits on (pos = row / 31).
* Row 0 is always the fade's own colour; rows 1-31 are the gradient snapped
  to the palette (nearest RGB like SLADE, or OKLab).
* fit_fade(): as few nodes as possible that redraw the CURRENT fade - nodes
  sit in the middle of each run of repeated indices (a palettised fade is
  stepped), and are added where the palettised gradient misses, until it
  lands on exactly the same indices. Grey "holes" (rows much less colourful
  than the rows either side - a colour that had no palette match and fell to
  grey) are left out of the fit, so the true-colour gradient keeps the
  fade's hue through them; fit_greys=True fits them too.
"""

import math

from .cleanpal_lib_colour import oklab, rgb_round
from .cleanpal_lib_ramps import ramp_colour_at
from .cleanpal_lib_rampedit import Snapper

ROWS = 32                     # rows 0-31
LAST = ROWS - 1
FADE_DEFAULTS = {"fe_space": "RGB", "fe_ease": "Linear", "fe_strength": 2.0,
                 "fe_metric": "rgb", "fe_fitgreys": False, "fe_true": False,
                 "fe_mono": True, "fe_end": 31, "fe_curve": 1.0, "fe_dark": 100, "fe_blendin": 3,
                 "fe_hideind": False}
MAX_FIT_NODES = 8
FIT_TOL = 0.04            # OKLab: near-identical palette colours count as a match


def clean_fe_settings(d):
    o = dict(FADE_DEFAULTS)
    if isinstance(d, dict):
        o.update({k: v for k, v in d.items() if k in FADE_DEFAULTS})
        if "fe_dark" not in d and d.get("fe_pace") == "stretch":   # 5.2.10 Pace radios
            o["fe_dark"] = 0
    if o["fe_space"] not in ("OKLab", "RGB", "OKLCH (hue path)"):
        o["fe_space"] = "RGB"
    if o["fe_ease"] not in ("Linear", "Ease in", "Ease out", "Ease in-out"):
        o["fe_ease"] = "Linear"
    try:
        o["fe_strength"] = min(max(float(o["fe_strength"]), 1.0), 6.0)
    except (TypeError, ValueError):
        o["fe_strength"] = 2.0
    if o["fe_metric"] not in ("rgb", "oklab"):
        o["fe_metric"] = "rgb"
    o["fe_fitgreys"] = bool(o["fe_fitgreys"])
    o["fe_true"] = bool(o["fe_true"])
    o["fe_mono"] = bool(o["fe_mono"])
    o["fe_hideind"] = bool(o["fe_hideind"])
    try:
        o["fe_curve"] = min(max(float(o["fe_curve"]), 0.25), 4.0)
    except (TypeError, ValueError):
        o["fe_curve"] = 1.0
    for k, lo, hi, df in (("fe_end", 1, LAST, LAST), ("fe_blendin", 0, 8, 3),
                          ("fe_dark", 0, 100, 100)):
        try:
            o[k] = min(max(int(o[k]), lo), hi)
        except (TypeError, ValueError):
            o[k] = df
    return o


def make_state(nodes, o):
    return {"nodes": nodes, "space": o["fe_space"], "ease": o["fe_ease"],
            "strength": o["fe_strength"], "ease_scope": "Each segment"}


def node(row, rgb):
    return {"pos": min(max(row / float(LAST), 0.0), 1.0), "rgb": list(rgb), "hsl": None}


def true_rows(state):
    """32 true-colour rows (rounded RGB)."""
    return [rgb_round(ramp_colour_at(state, r / float(LAST))) for r in range(ROWS)]


def snap_rows(state, snap, src, mono=False):
    """-> (true rows, palette index per row); row 0 = src itself. mono =
    never lighter than the row before."""
    tr = true_rows(state)
    if not mono:
        return tr, [src] + [snap.nearest(oklab(c), c) for c in tr[1:]]
    idx, _c, _e = RowSnap(snap, tr).path(src, mono=True)
    return tr, idx


def _sat(rgb):
    L, a, b = oklab(rgb)
    return math.hypot(a, b) / max(L, 0.05), L


def grey_holes(cols):
    """Rows 1-30 that are a grey 'hole': much less colourful than the row
    before the run and some row within 4 after it. Near-black rows never
    count; a fade that greys out and stays grey has no hole."""
    sat = [_sat(c) for c in cols]
    low = [s < 0.15 and L >= 0.12 for s, L in sat]
    out = set()
    r = 1
    while r < LAST:
        if not low[r]:
            r += 1
            continue
        a = r
        while r < LAST and low[r]:
            r += 1
        b = r                                      # first row after the run
        before = sat[a - 1][0] > 0.3 and sat[a - 1][1] >= 0.12
        after = any(sat[k][0] > 0.3 and sat[k][1] >= 0.12
                    for k in range(b, min(ROWS, b + 4)))
        if before and after:
            out.update(range(a, b))
    return out


def _solve(A, b):
    """Gaussian elimination (small dense system); None if singular."""
    n = len(A)
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[p][c]) < 1e-12:
            return None
        M[c], M[p] = M[p], M[c]
        for r in range(n):
            if r != c:
                f = M[r][c] / M[c][c]
                if f:
                    for k in range(c, n + 1):
                        M[r][k] -= f * M[c][k]
    return [M[i][n] / M[i][i] for i in range(n)]


def _to_space(rgb, space):
    return tuple(float(v) for v in rgb) if space == "RGB" else oklab(rgb)


def _from_space(v, space):
    if space == "RGB":
        return tuple(int(min(max(round(x), 0), 255)) for x in v)
    from .cleanpal_lib_colour import oklab_to_rgbf
    return rgb_round(oklab_to_rgbf(*v))


def _ls_knots(knots, pinned, rows, targets, space):
    """Piecewise-linear least squares: knot rows (sorted, include 0 and 31),
    pinned {row: rgb} fixed; free knots fitted to targets[row] over rows.
    -> {knot row: rgb}."""
    free = [k for k in knots if k not in pinned]
    out = {k: tuple(pinned[k]) for k in pinned}
    if not free:
        return out
    fi = {k: n for n, k in enumerate(free)}
    pv = {k: _to_space(v, space) for k, v in pinned.items()}
    n = len(free)
    sol = []
    for ch in range(3):
        A = [[0.0] * n for _ in range(n)]
        b = [0.0] * n
        for r in rows:
            k1 = max(k for k in knots if k <= r)
            k2 = min((k for k in knots if k > r), default=k1)
            u = 0.0 if k2 == k1 else (r - k1) / float(k2 - k1)
            w = {k1: 1.0 - u}
            if k2 != k1:
                w[k2] = w.get(k2, 0.0) + u
            y = _to_space(targets[r], space)[ch]
            for k, wk in w.items():
                if k in pv:
                    y -= wk * pv[k][ch]
            fw = [(fi[k], wk) for k, wk in w.items() if k in fi]
            for a, wa in fw:
                b[a] += wa * y
                for c2, wc in fw:
                    A[a][c2] += wa * wc
        for a in range(n):                      # tiny ridge: keep it solvable
            A[a][a] += 1e-6
        x = _solve(A, b)
        if x is None:
            x = [0.0] * n
        sol.append(x)
    for k in free:
        out[k] = _from_space(tuple(sol[ch][fi[k]] for ch in range(3)), space)
    return out


def fit_fade(cols, idxs, snap, src, o, tol=FIT_TOL, max_nodes=MAX_FIT_NODES):
    """cols / idxs: the fade's current 32 rows (rgb, index). -> (nodes,
    flagged rows, rows that still differ). Knots start at rows 0 and 31;
    free knot colours are least-squares fitted to the fade's colours; where
    the palettised gradient still misses, a knot pinned to that row's own
    colour is added (so that row matches) and the rest refitted."""
    flagged = set() if o["fe_fitgreys"] else grey_holes(cols)
    use = [r for r in range(1, ROWS) if r not in flagged]
    space = "RGB" if o["fe_space"] == "RGB" else "OKLab"
    knots = [0, LAST]
    pinned = {0: tuple(cols[0])}

    def build():
        vals = _ls_knots(knots, pinned, use, cols, space)
        return [node(k, vals[k]) for k in knots]

    lab_of = {}

    def lab(i):
        v = lab_of.get(i)
        if v is None:
            v = lab_of[i] = oklab(snap.rgb[snap.idx.index(i)])
        return v

    def misses(ns):
        """Rows whose palettised index differs from now - by more than tol
        (two near-identical palette colours count as the same)."""
        _tr, got = snap_rows(make_state(ns, o), snap, src, o.get("fe_mono", False))
        bad = []
        for r in use:
            if got[r] == idxs[r]:
                continue
            if tol > 0 and got[r] is not None and idxs[r] in snap.idx:
                a, b = lab(got[r]), lab(idxs[r])
                if sum((a[j] - b[j]) ** 2 for j in range(3)) <= tol * tol:
                    continue
            bad.append(r)
        return bad, got

    nodes = build()
    bad, _g = misses(nodes)
    while bad and len(knots) < max_nodes:
        st = make_state(nodes, o)
        cand = [r for r in bad if r not in knots]
        if not cand:
            break

        def err(r):
            p = oklab(ramp_colour_at(st, r / float(LAST)))
            q = oklab(cols[r])
            return sum((p[j] - q[j]) ** 2 for j in range(3))
        r = max(cand, key=err)
        knots = sorted(knots + [r])
        pinned[r] = tuple(cols[r])
        nodes = build()
        bad, _g = misses(nodes)
    return nodes, flagged, bad


def make_snapper(rgbs, deleted, metric):
    return Snapper(rgbs, deleted, metric)


# ============================================================ new colours
NEW_TOL = 0.025               # OKLab: a row this close to its true colour is "fine"


def _d(p, q):
    return math.sqrt(sum((p[j] - q[j]) ** 2 for j in range(3)))


class RowSnap:
    """Snapping the 32 rows of one gradient to the palette (+ new colours).

    * mono: a row may only use a colour no lighter than the row before it
      (else it repeats the previous row's colour).
    * pal0 first: a row uses its best pal0 colour whenever that is within tol
      of the true colour; a new colour only when pal0 can't get that close
      and the new one is closer.
    pal0 candidates per row are ordered by the match metric (RGB like SLADE,
    or OKLab); "close enough" is always measured in OKLab."""

    def __init__(self, snap, true_rgbs):
        self.snap = snap
        self.tr = [tuple(c) for c in true_rgbs]
        self.tl = [oklab(c) for c in self.tr]
        self.dist = [None] * ROWS            # match-metric distance per palette colour
        for r in range(1, ROWS):
            if snap.metric == "rgb":
                c0, c1, c2 = self.tr[r]
                self.dist[r] = [(p[0] - c0) ** 2 + (p[1] - c1) ** 2 + (p[2] - c2) ** 2
                                for p in snap.rgb]
            else:
                q0, q1, q2 = self.tl[r]
                self.dist[r] = [(p[0] - q0) ** 2 + (p[1] - q1) ** 2 + (p[2] - q2) ** 2
                                for p in snap.lab]

    def path(self, src, new=(), mono=True, tol=NEW_TOL, limit=256, force=None):
        """-> (index per row - new colours numbered limit + j -, rgb per row,
        OKLab error per row). force {row: j}: that row uses new colour j
        whatever (lighter or not); the rows after carry on from it."""
        sn = self.snap
        new = [(tuple(c), oklab(c)) for c in new]
        idx, cols, errs = [src], [], [0.0]
        src_rgb = sn.rgb[sn.idx.index(src)] if src in sn.idx else self.tr[0]
        cols.append(tuple(src_rgb))
        prevL = oklab(src_rgb)[0] + 1e-6
        prev = (src, tuple(src_rgb))
        for r in range(1, ROWS):
            q = self.tl[r]
            if force and r in force and 0 <= force[r] < len(new):
                j = force[r]
                choice = (limit + j, new[j][0])
                idx.append(choice[0])
                cols.append(choice[1])
                errs.append(_d(new[j][1], q))
                prev = choice
                prevL = new[j][1][0] + 1e-6
                continue
            dist = self.dist[r]
            if mono:
                ok = [k for k in range(len(dist)) if sn.lab[k][0] <= prevL]
            else:
                ok = range(len(dist))
            pk = min(ok, key=dist.__getitem__, default=None)   # first minimum wins
            dp = _d(sn.lab[pk], q) if pk is not None else None
            nj, dn = None, None
            for j, (_c, lab) in enumerate(new):
                if mono and lab[0] > prevL:
                    continue
                d = _d(lab, q)
                if dn is None or d < dn:
                    nj, dn = j, d
            if pk is None and nj is None:                  # nothing darker: repeat
                choice = prev
                lab = oklab(choice[1])
            elif nj is None or (dp is not None and (dp <= tol or dp <= dn)):
                choice = (sn.idx[pk], tuple(sn.rgb[pk]))
                lab = sn.lab[pk]
            else:
                choice = (limit + nj, new[nj][0])
                lab = new[nj][1]
            idx.append(choice[0])
            cols.append(choice[1])
            errs.append(_d(lab, q))
            prev = choice
            if mono:
                prevL = min(prevL, lab[0] + 1e-6)
        return idx, cols, errs


def suggest_new(true_rgbs, snap, src, mono=True, tol=NEW_TOL, limit=256, max_n=None):
    """Rows (1-31) whose true colour, added as a new palette colour, helps
    most - most useful first. Each pick is the one that lowers the total
    error (beyond tol) most, with pal0 colours still used wherever they're
    close enough and never-lighter respected. Stops when every row is within
    tol or nothing helps. The first N = the best N new colours."""
    rs = RowSnap(snap, true_rgbs)
    tr = rs.tr

    def cost(cols):
        _i, _c, e = rs.path(src, cols, mono, tol, limit)
        return sum(max(0.0, x - tol) for x in e[1:]), max(e[1:])

    order, cols = [], []
    cur, worst = cost(cols)
    while worst > tol and (max_n is None or len(order) < max_n):
        best, bc = None, cur
        for c in range(1, ROWS):
            if c in order or tr[c] in cols:
                continue
            v, _w = cost(cols + [tr[c]])
            if v < bc - 1e-4:
                best, bc = c, v
        if best is None:
            break
        order.append(best)
        cols.append(tr[best])
        cur, worst = cost(cols)
    return order


def snap_with_new(true_rgbs, rgbs, deleted, metric, new_cols, src, limit=256, mono=True,
                  force=None):
    """Rows snapped to the palette PLUS new_cols (pal0 first, never lighter;
    force {row: j} pins new colour j on that row).
    -> (index per row - new colours numbered limit + j -, rgb per row)."""
    snap = Snapper(rgbs, deleted, metric, limit=limit)
    idx, cols, _e = RowSnap(snap, true_rgbs).path(src, new_cols, mono, NEW_TOL, limit,
                                                  force)
    return idx, cols


# ============================================================ apply ramp to selection
class MasterRamp:
    """The edited fade's true-colour gradient, sampled anywhere 0..31 (OKLab,
    table at 1/8 row)."""

    STEP = 8

    def __init__(self, state):
        n = LAST * self.STEP
        self.tab = [oklab(ramp_colour_at(state, i / float(n))) for i in range(n + 1)]

    def lab(self, t):
        t = min(max(float(t), 0.0), float(LAST)) * self.STEP
        i = int(math.floor(t))
        if i >= len(self.tab) - 1:
            return self.tab[-1]
        f = t - i
        a, b = self.tab[i], self.tab[i + 1]
        return tuple(a[j] + (b[j] - a[j]) * f for j in range(3))

    def entry(self, L):
        """First row (float) where the ramp is as dark as L: lighter than the
        top -> 0; darker than everything -> 31."""
        tab = self.tab
        if L >= tab[0][0]:
            return 0.0
        for i in range(1, len(tab)):
            if tab[i][0] <= L:
                a, b = tab[i - 1][0], tab[i][0]
                f = (a - L) / (a - b) if a - b > 1e-9 else 1.0
                return (i - 1 + f) / float(self.STEP)
        return float(LAST)


def spread_targets(master, rgb0, end_row=LAST, curve=1.0, dark=100, blendin=3):
    """True-colour rows 0-31 for the fade whose colour is rgb0, carried down
    the master ramp from where it is as dark as rgb0. -> (rows, entry row).

    * end_row: the row by which fades reach the ramp's end (31 = the
      master's own speed).
    * dark 0-100 (Dark colours finish sooner): 100 = one speed for all, so a
      fade entering low on the ramp finishes sooner (end row scaled by the
      ramp left below it); 0 = every fade reaches the end at end_row
      (stretched); between = a mix.
    * curve (Darken curve): progress along the rest of the ramp =
      (row / the fade's end row) ^ curve - 1 = even.
    * blendin: the first rows ease from the fade's own colour into the ramp.
    Rows past the end hold the ramp's last colour."""
    from .cleanpal_lib_rampedit import fit_gamut, lab_to_rgb
    lab0 = oklab(rgb0)
    t0 = master.entry(lab0[0])
    top = master.lab(t0)
    off = tuple(lab0[j] - top[j] for j in range(3))
    d = min(max(float(dark), 0.0), 100.0) / 100.0
    left = (LAST - t0) / float(LAST)
    end_s = max(int(end_row), 1) * (1.0 - d + d * left)
    out = [tuple(int(v) for v in rgb0)]
    for r in range(1, ROWS):
        p = 1.0 if end_s <= 1e-6 else min(r / end_s, 1.0) ** float(curve)
        v = master.lab(t0 + (LAST - t0) * p)
        if blendin and r <= blendin:
            k = 1.0 - r / float(blendin + 1)
            v = fit_gamut(*(v[j] + off[j] * k for j in range(3)))
        out.append(lab_to_rgb(v))
    return out, t0
