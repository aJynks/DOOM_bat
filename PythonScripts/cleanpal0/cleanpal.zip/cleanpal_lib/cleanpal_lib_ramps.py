"""Ramp maker: multi-node gradients, blend spaces and easing."""

import math

from .cleanpal_lib_colour import oklab, oklab_to_rgbf, rgb_round


RAMP_SPACES = ["OKLab", "RGB", "OKLCH (hue path)"]
RAMP_EASES = ["Linear", "Ease in", "Ease out", "Ease in-out"]
RAMP_EASE_SCOPES = ["Whole ramp", "Each segment"]


def default_ramp_state():
    return {"nodes": [{"pos": 0.0, "rgb": [255, 183, 183], "hsl": None},
                      {"pos": 1.0, "rgb": [167, 0, 0], "hsl": None}],
            "space": RAMP_SPACES[0], "ease": RAMP_EASES[0], "strength": 2.0,
            "ease_scope": RAMP_EASE_SCOPES[0]}


def clean_ramp_state(src):
    """Validated ramp state; raises ValueError on garbage."""
    if not isinstance(src, dict):
        raise ValueError("Bad ramp data.")
    st = default_ramp_state()
    nodes = src.get("nodes")
    if isinstance(nodes, list) and len(nodes) >= 2:
        out = []
        for n in nodes:
            if not isinstance(n, dict):
                raise ValueError("Bad ramp node.")
            rgb = n.get("rgb")
            pos = n.get("pos")
            if not (isinstance(rgb, (list, tuple)) and len(rgb) == 3
                    and all(isinstance(v, int) and 0 <= v <= 255 for v in rgb)):
                raise ValueError("Bad ramp node colour.")
            if isinstance(pos, bool) or not isinstance(pos, (int, float)):
                raise ValueError("Bad ramp node position.")
            hsl = n.get("hsl")
            if not (isinstance(hsl, (list, tuple)) and len(hsl) == 3
                    and all(isinstance(v, (int, float)) and not isinstance(v, bool)
                            for v in hsl)):
                hsl = None
            out.append({"pos": min(max(float(pos), 0.0), 1.0), "rgb": list(rgb),
                        "hsl": list(hsl) if hsl else None})
        out.sort(key=lambda n: n["pos"])
        out[0]["pos"], out[-1]["pos"] = 0.0, 1.0
        st["nodes"] = out
    for k, choices in (("space", RAMP_SPACES), ("ease", RAMP_EASES),
                       ("ease_scope", RAMP_EASE_SCOPES)):
        if src.get(k) in choices:
            st[k] = src[k]
    v = src.get("strength")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        st["strength"] = min(max(float(v), 1.0), 6.0)
    return st


def _ease(u, kind, p):
    if kind == "Ease in":
        return u ** p
    if kind == "Ease out":
        return 1.0 - (1.0 - u) ** p
    if kind == "Ease in-out":
        return 0.5 * (2.0 * u) ** p if u < 0.5 else 1.0 - 0.5 * (2.0 - 2.0 * u) ** p
    return u


def _mix(c1, c2, u, space):
    if space == "RGB":
        return tuple(c1[k] + (c2[k] - c1[k]) * u for k in range(3))
    l1, l2 = oklab(c1), oklab(c2)
    if space.startswith("OKLCH"):
        C1, C2 = math.hypot(l1[1], l1[2]), math.hypot(l2[1], l2[2])
        h1, h2 = math.atan2(l1[2], l1[1]), math.atan2(l2[2], l2[1])
        if C1 < 1e-4:
            h1 = h2
        if C2 < 1e-4:
            h2 = h1
        dh = (h2 - h1 + math.pi) % (2 * math.pi) - math.pi     # shortest way round
        L = l1[0] + (l2[0] - l1[0]) * u
        C = C1 + (C2 - C1) * u
        h = h1 + dh * u
        return oklab_to_rgbf(L, C * math.cos(h), C * math.sin(h))
    return oklab_to_rgbf(*(l1[k] + (l2[k] - l1[k]) * u for k in range(3)))


def ramp_colour_at(state, t):
    """Float RGB at t (0..1) along the ramp."""
    nodes = state["nodes"]
    ease, p = state["ease"], state["strength"]
    per_seg = state["ease_scope"] == "Each segment"
    t = min(max(t, 0.0), 1.0)
    if not per_seg:
        t = _ease(t, ease, p)
    k = 0
    while k < len(nodes) - 2 and t > nodes[k + 1]["pos"]:
        k += 1
    a, b = nodes[k], nodes[k + 1]
    span = b["pos"] - a["pos"]
    u = 0.0 if span <= 1e-9 else (t - a["pos"]) / span
    u = min(max(u, 0.0), 1.0)
    if per_seg:
        u = _ease(u, ease, p)
    return _mix(tuple(a["rgb"]), tuple(b["rgb"]), u, state["space"])


def ramp_colours(state, n):
    if n <= 0:
        return []
    if n == 1:
        return [tuple(state["nodes"][0]["rgb"])]
    return [rgb_round(ramp_colour_at(state, k / (n - 1.0))) for k in range(n)]


# ------------------------------------------------------------ incremental pairs


# ============================================================ palette ramps (COLORMAP Ramps tool)
# A fade ramp for one colour across the 32 light levels, built only from
# palette colours. Nodes = {level: palette index}; level 0 is the colour itself.
# The IDEAL is either a smooth blend between nodes (manual) or a shaped fade
# (Auto: darken curve, hue drift, colour fade, end colour). The RESULT is the
# run of palette colours closest to the ideal overall (a shortest path), with
# optional never-lighter and smoothness rules and weighted matching.

LEVELS = 32
DEFAULT_WEIGHTS = (1.0, 1.0, 1.0)          # lightness, colourfulness, hue


def _lab3(c):
    L, a, b = oklab(c)
    return (L * 100.0, a * 100.0, b * 100.0)


def _d2(p, q):
    return (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2


def _wd(p, q, w):
    """Weighted squared difference: lightness / colourfulness (chroma) / hue.
    With weights (1, 1, 1) this equals the plain OKLab distance squared."""
    dL = p[0] - q[0]
    c1, c2 = math.hypot(p[1], p[2]), math.hypot(q[1], q[2])
    dC = c1 - c2
    dH2 = max(0.0, (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2 - dC * dC)
    return w[0] * dL * dL + w[1] * dC * dC + w[2] * dH2


def ramp_ideal(nodes, pal, blend="OKLab"):
    """Manual ideal: blend between nodes; after the last node hold its colour."""
    keys = sorted(nodes)
    out = [None] * LEVELS
    for a, b in zip(keys, keys[1:]):
        ca, cb = pal[nodes[a]], pal[nodes[b]]
        for lv in range(a, b + 1):
            out[lv] = _mix(ca, cb, (lv - a) / float(b - a), blend)
    last = keys[-1]
    for lv in range(last, LEVELS):
        out[lv] = tuple(float(v) for v in pal[nodes[last]])
    return out


def auto_ideal(start_rgb, end_rgb, curve=1.0, drift=0.0, fade_start=16, grey_by=31):
    """Auto ideal in OKLCH: lightness falls from the colour to the end colour
    (curve > 1 holds bright longer), hue turns by `drift` degrees on the way
    down, colourfulness holds until fade_start then fades to grey by grey_by,
    and the last levels lean into the end colour's tint."""
    L0, a0, b0 = oklab(start_rgb)
    Le, ae, be = oklab(end_rgb)
    C0, h0 = math.hypot(a0, b0), math.atan2(b0, a0)
    fade_start = max(0, min(LEVELS - 1, int(fade_start)))
    grey_by = max(fade_start + 1, min(LEVELS - 1, int(grey_by))) if fade_start < LEVELS - 1 \
        else LEVELS - 1
    out = []
    for lv in range(LEVELS):
        t = lv / float(LEVELS - 1)
        L = L0 + (Le - L0) * (t ** max(curve, 0.05))
        if lv <= fade_start:
            k = 1.0
        elif lv >= grey_by:
            k = 0.0
        else:
            u = (lv - fade_start) / float(grey_by - fade_start)
            k = 1.0 - u * u * (3 - 2 * u)            # smoothstep down to grey
        C = C0 * k
        h = h0 + math.radians(drift) * t
        a, b = C * math.cos(h), C * math.sin(h)
        a, b = a + (ae - a) * t ** 3, b + (be - b) * t ** 3   # tint of the end colour
        out.append(tuple(min(max(v, 0.0), 255.0) for v in oklab_to_rgbf(L, a, b)))
    out[0] = tuple(float(v) for v in start_rgb)
    return out


def _path(levels, ideal_labs, cand, labs, start, end, mono, lam, weights, k):
    """Choose palette indices for consecutive `levels` (start fixed before,
    `end` fixed after or None = open). Shortest path on: distance to ideal
    + lam * step size, with the never-lighter rule if `mono`."""
    la = labs[start]
    lb = labs[end] if end is not None else None
    mono = mono and (lb is None or la[0] + 1e-6 >= lb[0])
    options = []
    for il in ideal_labs:
        lo = (lb[0] - 0.5) if lb is not None else -1e9
        pool = [c for c in cand if not mono or lo <= labs[c][0] <= la[0] + 0.5] or list(cand)
        pool.sort(key=lambda c: _wd(labs[c], il, weights))
        options.append([(c, _wd(labs[c], il, weights)) for c in pool[:k]])
    prev = {start: (0.0, None)}
    back = []
    for opts in options:
        cur = {}
        for c, dc in opts:
            lc = labs[c]
            best = None
            for p, (cost, _) in prev.items():
                lp = labs[p]
                if mono and lc[0] > lp[0] + 0.5:
                    continue
                v = cost + dc + lam * _wd(lp, lc, weights)
                if best is None or v < best[0]:
                    best = (v, p)
            if best is not None:
                cur[c] = best
        if not cur:                                       # rule too strict here - relax
            p, (cost, _) = min(prev.items(), key=lambda kv: kv[1][0])
            cur = {c: (cost + dc, p) for c, dc in opts}
        back.append(cur)
        prev = cur
    if end is not None:
        best = None
        for p, (cost, _) in prev.items():
            v = cost + lam * _wd(labs[p], lb, weights)
            if mono and lb[0] > labs[p][0] + 0.5:
                v += 1e6
            if best is None or v < best[0]:
                best = (v, p)
        pick = best[1]
    else:
        pick = min(prev.items(), key=lambda kv: kv[1][0])[0]
    out = [None] * len(levels)
    for j in range(len(levels) - 1, -1, -1):
        out[j] = pick
        pick = back[j][pick][1]
    return out


def palette_ramp(nodes, pal, blend="OKLab", monotonic=True, smooth=True, k=24,
                 ideal=None, weights=None, allowed=None, open_end=False):
    """(ideal colours, palette indices) for the 32 levels. Node levels keep
    their palette index; the rest are chosen together as the palette path
    closest to the ideal. ideal = a given ideal (Auto) instead of the node
    blend; allowed = palette indices that may be used (nodes always may);
    open_end = levels after the last node follow the ideal (Auto)."""
    weights = weights or DEFAULT_WEIGHTS
    if ideal is None:
        ideal = ramp_ideal(nodes, pal, blend)
    seen = {}
    for i, c in enumerate(pal):
        if c is not None and tuple(c) not in seen and (allowed is None or i in allowed):
            seen[tuple(c)] = i
    cand = list(seen.values())
    labs = {i: _lab3(pal[i]) for i in cand}
    for i in nodes.values():
        labs.setdefault(i, _lab3(pal[i]))
    if not cand:
        cand = list(nodes.values())
    ilabs = [_lab3(c) for c in ideal]
    result = [None] * LEVELS
    keys = sorted(nodes)
    for lv in keys:
        result[lv] = nodes[lv]
    lam = 0.35 if smooth else 0.0
    for a, b in zip(keys, keys[1:]):
        inner = list(range(a + 1, b))
        if inner:
            for lv, c in zip(inner, _path(inner, ilabs[a + 1:b], cand, labs, nodes[a],
                                           nodes[b], monotonic, lam, weights, k)):
                result[lv] = c
    last = keys[-1]
    tail = list(range(last + 1, LEVELS))
    if tail:
        if open_end:
            for lv, c in zip(tail, _path(tail, ilabs[last + 1:], cand, labs, nodes[last],
                                         None, monotonic, lam, weights, k)):
                result[lv] = c
        else:
            for lv in tail:
                result[lv] = nodes[last]
    return ideal, result


def ramp_misses(ideal, result, pal):
    """Per level: how far the palette colour is from the ideal (OKLab x 100,
    roughly a delta-E - under ~2 is hard to see)."""
    return [math.sqrt(_d2(_lab3(ideal[lv]), _lab3(pal[result[lv]]))) for lv in range(LEVELS)]


def _ramp_cost(ideal, result, pal, weights):
    return sum(_wd(_lab3(ideal[lv]), _lab3(pal[result[lv]]), weights) for lv in range(LEVELS))


def suggest_new_colours(nodes, pal, ideal, n, monotonic=True, smooth=True, weights=None,
                        allowed=None, open_end=True, tries=6, k=16):
    """Pick up to n NEW colours (taken from the ideal) that improve the ramp
    the most. Greedy: each round tries the ideal colour at the worst-missing
    levels and keeps the one that lowers the whole ramp's cost the most.
    Returns [(level, rgb), ...] in pick order."""
    weights = weights or DEFAULT_WEIGHTS
    work = list(pal)
    allow = set(allowed) if allowed is not None else None
    picks = []
    have = {tuple(c) for c in pal if c is not None}
    for _ in range(max(0, int(n))):
        _i, res = palette_ramp(nodes, work, monotonic=monotonic, smooth=smooth, ideal=ideal,
                               weights=weights, allowed=allow, open_end=open_end, k=k)
        base = _ramp_cost(ideal, res, work, weights)
        miss = ramp_misses(ideal, res, work)
        order = sorted((lv for lv in range(1, LEVELS) if lv not in nodes),
                       key=lambda lv: -miss[lv])[:tries]
        best = None
        for lv in order:
            rgb = tuple(int(round(min(max(v, 0), 255))) for v in ideal[lv])
            if rgb in have:
                continue
            trial = work + [rgb]
            al = (allow | {len(work)}) if allow is not None else None
            _i, r2 = palette_ramp(nodes, trial, monotonic=monotonic, smooth=smooth,
                                  ideal=ideal, weights=weights, allowed=al, open_end=open_end,
                                  k=k)
            gain = base - _ramp_cost(ideal, r2, trial, weights)
            if best is None or gain > best[0]:
                best = (gain, lv, rgb)
        if best is None or best[0] <= 0:
            break
        picks.append((best[1], best[2]))
        have.add(best[2])
        work.append(best[2])
        if allow is not None:
            allow.add(len(work) - 1)
    return picks


def fit_nodes(current, start, pal, blend="OKLab", monotonic=True, smooth=True,
              weights=None, allowed=None):
    """Fewest nodes that rebuild `current` (32 palette indices for one colour):
    start with level 0 (the colour) and level 31, then keep adding a node at
    the level that's furthest off until the rebuilt ramp matches."""
    def col(i):
        return tuple(pal[i]) if i is not None and pal[i] is not None else None
    nodes = {0: start, LEVELS - 1: current[LEVELS - 1]}
    for _ in range(LEVELS):
        _ideal, res = palette_ramp(nodes, pal, blend, monotonic, smooth, weights=weights,
                                   allowed=allowed)
        worst, wd = None, 0.0
        for lv in range(1, LEVELS):
            want, got = col(current[lv]), col(res[lv])
            if want == got:
                continue
            d = _d2(_lab3(want), _lab3(got)) if want and got else 1e9
            if d > wd:
                worst, wd = lv, d
        if worst is None:
            break
        nodes[worst] = current[worst]
    return nodes


# ============================================================ AutoRamps (whole palette)
# Goal: every fade as smooth to black as possible, letting hue wander a
# little rather than going grey. Matching uses HUE FREEDOM: hue may wander
# by up to `hue_free` degrees, growing with depth (free at no cost inside the
# window), losing colourfulness costs extra, and an optional lean (warm /
# cool) breaks ties toward one family.

WARM_HUE = math.radians(40.0)        # OKLab hue of red-orange / brown
COOL_HUE = math.radians(250.0)       # OKLab hue of blue


def _lch(lab):
    return lab[0], math.hypot(lab[1], lab[2]), math.atan2(lab[2], lab[1])


def _angdiff(a, b):
    return abs((a - b + math.pi) % (2 * math.pi) - math.pi)


def make_level_cost(weights=DEFAULT_WEIGHTS, hue_free=0.0, keep_colour=1.0, lean=0,
                    lean_w=0.6):
    """Cost of using palette colour (lab) at a level for an ideal (lab).
    t = depth 0..1. Returns cost(ideal_lch, cand_lch, t)."""
    wl, wc, wh = weights
    free = math.radians(max(0.0, hue_free))
    target = WARM_HUE if lean > 0 else COOL_HUE if lean < 0 else None

    def cost(il, cl, t):
        L1, C1, h1 = il
        L2, C2, h2 = cl
        dL = L1 - L2
        dC = C1 - C2
        cst = wl * dL * dL + wc * dC * dC
        if C2 < C1:                                   # greying out costs extra
            cst += keep_colour * wc * (C1 - C2) ** 2
        if C1 > 1.0 and C2 > 1.0:
            dh = max(0.0, _angdiff(h1, h2) - free * t)
            dH = 2.0 * math.sqrt(C1 * C2) * math.sin(dh / 2.0)
            cst += wh * dH * dH
            if target is not None:
                cst += lean_w * t * C2 * _angdiff(h2, target)
        return cst
    return cost


def fast_ramp(start, pal, ideal, cand, cand_lch, cost, monotonic=True, smooth=True,
              k=12, band=14.0):
    """One colour's auto ramp, tuned for whole-palette use: candidates come
    from a lightness band around each level's ideal, k best per level, then
    the shortest path (never lighter / smooth as in palette_ramp)."""
    lam = 0.35 if smooth else 0.0
    ilch = [_lch(_lab3(c)) for c in ideal]
    s_lch = _lch(_lab3(pal[start]))
    prev = {start: (0.0, None)}
    prev_l = {start: s_lch}
    back = []
    for lv in range(1, LEVELS):
        t = lv / float(LEVELS - 1)
        il = ilch[lv]
        opts = []
        for c in cand:
            cl = cand_lch[c]
            if abs(cl[0] - il[0]) > band:
                continue
            opts.append((cost(il, cl, t), c))
        if not opts:
            opts = [(cost(il, cand_lch[c], t), c) for c in cand]
        opts.sort()
        opts = opts[:k]
        cur = {}
        for dc, c in opts:
            cl = cand_lch[c]
            best = None
            for p, (pc, _) in prev.items():
                pl = prev_l[p]
                if monotonic and cl[0] > pl[0] + 0.5:
                    continue
                v = pc + dc + lam * ((cl[0] - pl[0]) ** 2 + 0.25 * (cl[1] - pl[1]) ** 2)
                if best is None or v < best[0]:
                    best = (v, p)
            if best is not None:
                cur[c] = best
        if not cur:
            p, (pc, _) = min(prev.items(), key=lambda kv: kv[1][0])
            cur = {c: (pc + dc, p) for dc, c in opts}
        back.append(cur)
        prev = cur
        prev_l = {c: cand_lch[c] for c in cur}
    pick = min(prev.items(), key=lambda kv: kv[1][0])[0]
    out = [start] + [None] * (LEVELS - 1)
    for j in range(LEVELS - 2, -1, -1):
        out[j + 1] = pick
        pick = back[j][pick][1]
    return out


def candidates(pal, allowed=None):
    seen = {}
    for i, c in enumerate(pal):
        if c is not None and tuple(c) not in seen and (allowed is None or i in allowed):
            seen[tuple(c)] = i
    cand = list(seen.values())
    return cand, {i: _lch(_lab3(pal[i])) for i in range(len(pal)) if pal[i] is not None}


def auto_ramps(scope, pal, opts, allowed=None, extra_allowed=()):
    """Ramps for every colour in `scope`. opts: curve, drift, fade_start,
    grey_by, end (rgb), weights, hue_free, keep_colour, lean, monotonic,
    smooth. Returns {colour: (ideal, result)}."""
    al = None if allowed is None else set(allowed) | set(extra_allowed)
    cand, lch = candidates(pal, al)
    cost = make_level_cost(opts["weights"], opts["hue_free"], opts["keep_colour"],
                           opts["lean"])
    out = {}
    for s in scope:
        if pal[s] is None:
            continue
        ideal = auto_ideal(pal[s], opts["end"], opts["curve"], opts["drift"],
                           opts["fade_start"], opts["grey_by"])
        out[s] = (ideal, fast_ramp(s, pal, ideal, cand, lch, cost, opts["monotonic"],
                                   opts["smooth"]))
    return out


def ramps_summary(ramps, pal):
    """(average miss, (worst miss, colour, level), colours that go grey early,
    per-colour worst miss)."""
    tot, n, worst, grey, per = 0.0, 0, (0.0, None, None), 0, {}
    for s, (ideal, res) in ramps.items():
        m = ramp_misses(ideal, res, pal)
        per[s] = max(m[1:])
        tot += sum(m[1:])
        n += LEVELS - 1
        lv = max(range(1, LEVELS), key=lambda r: m[r])
        if m[lv] > worst[0]:
            worst = (m[lv], s, lv)
        # "grey early": the ideal still has colour but the result has none,
        # before the last few levels
        for r in range(1, LEVELS - 4):
            iL, iC, _h = _lch(_lab3(ideal[r]))
            rL, rC, _h2 = _lch(_lab3(pal[res[r]]))
            if iC > 6.0 and rC < 2.0 and rL > 3.0:
                grey += 1
                break
    return (tot / n if n else 0.0), worst, grey, per


def suggest_global(ramps, pal, n, opts, max_new=64, pool=24):
    """Pick up to n new colours that help the most fades at once. Greedy on
    the per-level cost (fast approximation of the full rebuild): each round
    takes the ideal colours at the worst-served levels as candidates and
    keeps the one with the biggest total improvement. Returns
    [(rgb, helps_count), ...]."""
    cost = make_level_cost(opts["weights"], opts["hue_free"], opts["keep_colour"],
                           opts["lean"])
    entries = []                     # (colour, level, ideal lch, ideal rgb, current cost, t)
    for s, (ideal, res) in ramps.items():
        for lv in range(1, LEVELS):
            il = _lch(_lab3(ideal[lv]))
            t = lv / float(LEVELS - 1)
            cc = cost(il, _lch(_lab3(pal[res[lv]])), t)
            if cc > 4.0:                                   # only levels worth fixing
                entries.append([s, lv, il, ideal[lv], cc, t])
    picks = []
    have = {tuple(c) for c in pal if c is not None}
    for _ in range(min(n, max_new)):
        if not entries:
            break
        entries.sort(key=lambda e: -e[4])
        cands, seen = [], set()
        for e in entries[:pool * 3]:
            rgb = tuple(int(round(min(max(v, 0), 255))) for v in e[3])
            key = tuple(v // 6 for v in rgb)
            if rgb in have or key in seen:
                continue
            seen.add(key)
            cands.append((rgb, _lch(_lab3(rgb))))
            if len(cands) >= pool:
                break
        best = None
        for rgb, cl in cands:
            gain, helps = 0.0, set()
            for e in entries:
                g = e[4] - cost(e[2], cl, e[5])
                if g > 0:
                    gain += g
                    helps.add(e[0])
            if best is None or gain > best[0]:
                best = (gain, rgb, cl, helps)
        if best is None or best[0] <= 0:
            break
        _g, rgb, cl, helps = best
        picks.append((rgb, len(helps)))
        have.add(rgb)
        for e in entries:
            e[4] = min(e[4], cost(e[2], cl, e[5]))
        entries = [e for e in entries if e[4] > 4.0]
    return picks


def suggest_culls(pal, pairs, n, usage=None, careful=False, protect=()):
    """Up to n colours that could be merged into a near-identical twin to make
    room. pairs: [(distance, a, b)] (closest first). usage: {index: how many
    fades use it} - careful mode keeps the more used twin and skips colours
    many fades rely on. Returns [(cull, keep, distance)]."""
    out, gone, kept = [], set(), set()
    protect = set(protect)
    for d, a, b in sorted(pairs):
        if len(out) >= n:
            break
        if a in gone or b in gone or pal[a] is None or pal[b] is None:
            continue
        cull, keep = (b, a) if b not in protect else (a, b)
        if usage is not None and careful:
            if usage.get(cull, 0) > usage.get(keep, 0):
                cull, keep = keep, cull
            if usage.get(cull, 0) > 24:                # many fades rely on it
                continue
        if cull in protect or cull in kept:
            continue
        out.append((cull, keep, d))
        gone.add(cull)
        kept.add(keep)
    return out


def chain_gap_colours(cols_lab_order, n, end_rgb=(0, 0, 0)):
    """Fade through + new colours: given chain colours light -> dark, return n
    new colours that split the biggest lightness gaps (OKLab midpoints)."""
    chain = [tuple(c) for c in cols_lab_order] + [tuple(end_rgb)]
    new = []
    for _ in range(max(0, n)):
        best, bi = 0.0, None
        for i in range(len(chain) - 1):
            g = abs(_lab3(chain[i])[0] - _lab3(chain[i + 1])[0])
            if g > best:
                best, bi = g, i
        if bi is None or best < 3.0:
            break
        mid = tuple(int(round(min(max(v, 0), 255)))
                    for v in _mix(chain[bi], chain[bi + 1], 0.5, "OKLab"))
        if mid in chain:
            break
        chain.insert(bi + 1, mid)
        new.append(mid)
    return new


# ============================================================ Light curve (lighten / darken)
def light_source_pos(r, brightness, black_at):
    """Which (fractional) level of the original fade level r takes its colour
    from. brightness -100..100 (+ = lighter: stays bright longer); black_at =
    the level where the fade's darkest step is reached (31 = as now, higher =
    later / lighter, lower = sooner / darker)."""
    if r <= 0:
        return 0.0
    g = 2.0 ** (brightness / 60.0)                    # >1 lighter, <1 darker
    t = min(1.0, r / float(max(1.0, black_at)))
    return (LEVELS - 1) * (t ** g)


def light_curve(fades, pal, brightness=0.0, black_at=31.0, smooth=True, skip=()):
    """fades: {colour: [32 palette indices]} -> {colour: new 32 indices}.
    Each level takes its colour from another level of the same fade; with
    smooth, in-between positions use the palette colour nearest the blend of
    the two neighbouring steps (cached - many fades share colours)."""
    skip = set(skip)
    labs = [(i, _lab3(c)) for i, c in enumerate(pal) if c is not None]
    cache = {}

    def nearest(c1, c2, u):
        key = (c1, c2, int(round(u * 8)))
        hit = cache.get(key)
        if hit is not None:
            return hit
        a, b = pal[c1], pal[c2]
        want = _lab3(_mix(a, b, key[2] / 8.0, "OKLab"))
        best = min(labs, key=lambda il: _d2(il[1], want))[0]
        cache[key] = best
        return best

    out = {}
    for s, rows in fades.items():
        if s in skip:
            continue
        new = [rows[0]]
        for r in range(1, LEVELS):
            p = light_source_pos(r, brightness, black_at)
            lo = int(math.floor(p))
            hi = min(LEVELS - 1, lo + 1)
            u = p - lo
            if not smooth or u < 1e-6 or rows[lo] == rows[hi]:
                new.append(rows[lo] if u < 0.5 or not smooth else rows[hi])
            elif u > 1 - 1e-6:
                new.append(rows[hi])
            else:
                new.append(nearest(rows[lo], rows[hi], u))
        out[s] = new
    return out
