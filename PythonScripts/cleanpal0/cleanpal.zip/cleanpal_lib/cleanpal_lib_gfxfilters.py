"""Preview filters: stock Doom / Doom II groups for sprites, graphics, flats
and textures, user (custom) entries, and the matcher the preview uses.

A filter tree is blocks (Sprites, Graphics, Flats, Textures / patches) of
sections (Monsters, Screens, ...). A section either holds child entries
(Monsters -> Imp, ...) or is an entry itself (Decorations). Every block ends
in a Misc entry: whatever of that block's kinds no other entry matched.

Match patterns: a 4-letter name with no wildcards is a sprite-style prefix
(TROO = every TROO frame); anything else is a full lump name with * and ?.
"""

import fnmatch
import os
import struct

# kinds the preview uses -> filter block
KIND_BLOCK = {"sprite": "sprite", "graphic": "graphic", "flat": "flat",
              "patch": "texture", "texture1": "texture", "texture2": "texture"}
BLOCKS = [("sprite", "Sprites"), ("graphic", "Graphics"), ("flat", "Flats"),
          ("texture", "Textures / patches")]
# preview Type -> blocks shown in the Filters window
TYPE_BLOCKS = {"Sprites": ["sprite"], "Graphics": ["graphic"], "Flats": ["flat"],
               "Patches": ["texture"], "TEXTURE1": ["texture"], "TEXTURE2": ["texture"]}
ALL_BLOCKS = [b for b, _n in BLOCKS]

MONSTERS = [
    ("Arachnotron", "BSPI APLS APBX"),
    ("Arch-vile", "VILE FIRE"),
    ("Baron of Hell", "BOSS BAL7"),
    ("Cacodemon", "HEAD BAL2"),
    ("Chaingunner", "CPOS"),
    ("Commander Keen", "KEEN"),
    ("Cyberdemon", "CYBR MISL"),
    ("Demon / Spectre", "SARG"),
    ("Hell Knight", "BOS2 BAL7"),
    ("Icon of Sin", "BBRN BOSF"),
    ("Imp", "TROO BAL1"),
    ("Lost Soul", "SKUL"),
    ("Mancubus", "FATT MANF"),
    ("Pain Elemental", "PAIN SKUL"),
    ("Revenant", "SKEL FATB FBXP"),
    ("Shotgun guy", "SPOS"),
    ("Spider Mastermind", "SPID"),
    ("Wolfenstein SS", "SSWV"),
    ("Zombieman", "POSS"),
]
WEAPONS = [
    ("BFG 9000", "BFGG BFGF BFS1 BFE1 BFE2 BFUG"),
    ("Chaingun", "CHGG CHGF MGUN"),
    ("Chainsaw", "SAWG CSAW"),
    ("Fist", "PUNG"),
    ("Pistol", "PISG PISF"),
    ("Plasma rifle", "PLSG PLSF PLSS PLSE PLAS"),
    ("Rocket launcher", "MISG MISF MISL LAUN"),
    ("Shotgun", "SHTG SHTF SHOT"),
    ("Super shotgun", "SHT2 SGN2"),
]
# Player: plain palettisation, or players 1-4 (green 112-127 put on Doom's
# translation ranges, index for index - see PLAYER_RANGE)
PLAYER = [("Player", "PLAY"), ("Player 1 (Green)", "PLAY", "player_1"),
          ("Player 2 (Grey)", "PLAY", "player_2"), ("Player 3 (Brown)", "PLAY", "player_3"),
          ("Player 4 (Red)", "PLAY", "player_4")]
PLAYER_GREEN = 112
PLAYER_RANGE = {1: 112, 2: 96, 3: 64, 4: 32}


def player_mode(ticks):
    """0 = normal palettisation, 1-4 = that player's translation."""
    for n in (1, 2, 3, 4):
        if "sprite:player:player_%d" % n in ticks:
            return n
    return 0


DECORATIONS = ("BAR1 BEXP FCAN COLU CAND CBRA TLMP TLP2 ELEC TRE1 TRE2 SMIT "
               "COL1 COL2 COL3 COL4 COL5 COL6 CEYE FSKU TBLU TGRN TRED SMBT SMGT SMRT "
               "GOR1 GOR2 GOR3 GOR4 GOR5 HDB1 HDB2 HDB3 HDB4 HDB5 HDB6 "
               "POL1 POL2 POL3 POL4 POL5 POL6 POB1 POB2 BRS1")
ITEMS = ("ARM1 ARM2 BON1 BON2 STIM MEDI SOUL MEGA PINV PSTR PINS SUIT PMAP PVIS "
         "BKEY RKEY YKEY BSKU RSKU YSKU CLIP AMMO ROCK BROK CELL CELP SHEL SBOX BPAK")

GRAPHICS = [
    ("Screens", "TITLEPIC CREDIT HELP HELP1 HELP2 VICTORY2 ENDPIC BOSSBACK INTERPIC "
                "PFUB1 PFUB2 END0 END1 END2 END3 END4 END5 END6", None),
    ("Menus", "M_*", None),
    ("Status bar", None, [("Bar & arms", "STBAR STARMS"),
                          ("Mugshot", "STF*"),
                          ("Status bar fonts", "STTNUM* STYSNUM* STGNUM* STTPRCNT STTMINUS"),
                          ("Keys", "STKEYS*")]),
    ("Fonts", None, [("HUD / message font", "STCFN*"),
                     ("Intermission font", "WINUM* WIPCNT WIMINUS WICOLON"),
                     ("Automap numbers", "AMMNUM*")]),
    ("Intermission", "WI* CWILV*", None),
]
FLATS = [
    ("Animated flats", "NUKAGE? FWATER? SWATER? LAVA? BLOOD? RROCK05 RROCK06 RROCK07 "
                       "RROCK08 SLIME??", "anim_flat"),
    ("Sky flats", "F_SKY*", None),
    ("Teleport / gates", "GATE?", None),
]
TEXTURES = [
    ("Switches", "SW1* SW2*", "switch"),
    ("Doors", "DOOR* BIGDOOR* SPCDOOR* EXITDOOR*", None),
    ("Animated textures", "BLODGR? SLADRIP? BLODRIP? FIREWAL? GSTFONT? FIRELAV* FIREMAG? "
                          "FIREBLU? ROCKRED? BFALL? SFALL? WFALL? DBRAIN?", "anim_tex"),
    ("Skies", "SKY? RSKY?", None),
]

# section names a custom entry can go into (Misc can't)
STOCK_SECTIONS = (["Monsters", "Weapons", "Decorations", "Items"]
                  + [g[0] for g in GRAPHICS] + [f[0] for f in FLATS]
                  + [t[0] for t in TEXTURES])
SECTION_BLOCK = dict([(n, "sprite") for n in ("Monsters", "Weapons", "Decorations", "Items")]
                     + [(g[0], "graphic") for g in GRAPHICS]
                     + [(f[0], "flat") for f in FLATS]
                     + [(t[0], "texture") for t in TEXTURES])
CUSTOM_BLOCK = "custom"


def _slug(s):
    return "".join(c.lower() if c.isalnum() else "_" for c in s)


def _entry(eid, name, pats, block, dyn=None):
    return {"id": eid, "name": name, "pat": (pats or "").split(), "block": block,
            "dyn": dyn, "custom": False}


def stock_tree():
    """[(block id, block label, [section])]; section = {"id", "name", "own":
    entry or None, "children": [entry]}."""
    def leaf(block, name, pats, dyn=None):
        sid = "%s:%s" % (block, _slug(name))
        return {"id": sid, "name": name, "own": _entry(sid, name, pats, block, dyn),
                "children": []}

    def parent(block, name, kids):
        sid = "%s:%s" % (block, _slug(name))
        return {"id": sid, "name": name, "own": None,
                "children": [_entry("%s:%s" % (sid, k[2] if len(k) > 2 else _slug(k[0])),
                                    k[0], k[1], block) for k in kids]}

    def misc(block):
        e = _entry("%s:misc" % block, "Misc", "", block)
        e["misc"] = True
        return {"id": e["id"], "name": "Misc", "own": e, "children": []}

    player = parent("sprite", "Player", PLAYER)
    player["exclusive"] = True                     # one at a time; 1-4 = translation
    spr = [parent("sprite", "Monsters", MONSTERS), parent("sprite", "Weapons", WEAPONS),
           player, leaf("sprite", "Decorations", DECORATIONS), leaf("sprite", "Items", ITEMS),
           misc("sprite")]
    gfx = [(parent("graphic", n, kids) if kids else leaf("graphic", n, p))
           for n, p, kids in GRAPHICS] + [misc("graphic")]
    fl = [leaf("flat", n, p, d) for n, p, d in FLATS] + [misc("flat")]
    tx = [leaf("texture", n, p, d) for n, p, d in TEXTURES] + [misc("texture")]
    return [("sprite", "Sprites", spr), ("graphic", "Graphics", gfx), ("flat", "Flats", fl),
            ("texture", "Textures / patches", tx)]


# ------------------------------------------------------------------ custom entries
def clean_custom(lst):
    """Validated custom filter entries (project / export file data)."""
    out = []
    if not isinstance(lst, list):
        return out
    seen = set()
    for e in lst[:2000]:
        if not isinstance(e, dict):
            continue
        name = str(e.get("name") or "").strip()[:60]
        sec = str(e.get("section") or "").strip()[:60]
        m = e.get("match")
        if isinstance(m, str):
            m = m.replace(",", " ").split()
        if not (name and sec and isinstance(m, list)):
            continue
        pats = [str(p).strip().upper()[:16] for p in m if str(p).strip()][:200]
        if not pats or sec.lower() == "misc":
            continue
        eid = str(e.get("id") or "")
        if not eid.startswith("c:") or eid in seen:
            eid = new_custom_id(seen)
        seen.add(eid)
        out.append({"id": eid, "name": name, "section": sec, "match": pats})
    return out


def new_custom_id(taken=()):
    import random
    while True:
        eid = "c:%08x" % random.getrandbits(32)
        if eid not in taken:
            return eid


def parse_patterns(text):
    return [p.strip().upper()[:16] for p in text.replace(",", " ").split() if p.strip()]


# ------------------------------------------------------------------ WAD lists
def _name(b):
    return b.split(b"\0", 1)[0].decode("ascii", "replace").strip().upper()


def wad_anim_switch(arch):
    """(ANIMATED records [(is_texture, first, last)], SWITCHES names) from a
    WAD's BOOM-format lumps; None for a lump the WAD doesn't have."""
    anim = sw = None
    try:
        d = arch.lump("ANIMATED")
    except Exception:  # noqa: BLE001 - broken WAD: no list
        d = None
    if d:
        anim = []
        for k in range(0, len(d) - 22, 23):
            t = d[k]
            if t == 255:
                break
            anim.append((bool(t & 1), _name(d[k + 10:k + 19]), _name(d[k + 1:k + 10])))
    try:
        d = arch.lump("SWITCHES")
    except Exception:  # noqa: BLE001
        d = None
    if d:
        sw = set()
        for k in range(0, len(d) - 19, 20):
            ep = struct.unpack_from("<h", d, k + 18)[0]
            if ep == 0:
                break
            sw.add(_name(d[k:k + 9]))
            sw.add(_name(d[k + 9:k + 18]))
    return anim, sw


# ------------------------------------------------------------------ matcher
def item_name(it):
    n = it["name"]
    if it.get("kind") == "loose":
        n = os.path.splitext(os.path.basename(n))[0]
    return n.upper()


def pat_match(p, name):
    if len(p) == 4 and not any(c in p for c in "*?["):
        return name.startswith(p)
    return fnmatch.fnmatchcase(name, p)


class FilterEngine:
    """Classifies preview items against the stock tree + custom entries."""

    def __init__(self, items, custom, arch=None):
        self.tree = stock_tree()
        self.custom = custom
        self.entries = {}                 # id -> entry (stock + custom)
        for _b, _l, secs in self.tree:
            for s in secs:
                for e in ([s["own"]] if s["own"] else []) + s["children"]:
                    self.entries[e["id"]] = e
        for c in custom:
            blk = SECTION_BLOCK.get(c["section"], CUSTOM_BLOCK)
            self.entries[c["id"]] = {"id": c["id"], "name": c["name"], "pat": c["match"],
                                     "block": blk, "dyn": None, "custom": True}
        self.dyn = {}
        if arch is not None:
            anim, sw = wad_anim_switch(arch)
            order = {"flat": [item_name(i) for i in items if i["kind"] == "flat"],
                     "tex": [item_name(i) for i in items
                             if i["kind"] in ("texture1", "texture2")]}
            if anim is not None:
                for want, key in ((True, "anim_tex"), (False, "anim_flat")):
                    names = set()
                    seq = order["tex" if want else "flat"]
                    for is_tex, first, last in anim:
                        if is_tex != want:
                            continue
                        names.update((first, last))
                        if first in seq and last in seq:
                            a, b = seq.index(first), seq.index(last)
                            names.update(seq[min(a, b):max(a, b) + 1])
                    self.dyn[key] = names
            if sw is not None:
                self.dyn["switch"] = sw
        self.match = {}                   # item key -> set of entry ids
        self.blocks_hit = {}              # custom id -> blocks it matched something in
        for it in items:
            self.match[it["key"]] = self._classify(it)

    def _hits(self, e, name):
        if e.get("dyn") and e["dyn"] in self.dyn:
            return name in self.dyn[e["dyn"]]
        return any(pat_match(p, name) for p in e["pat"])

    def _classify(self, it):
        name = item_name(it)
        blk = KIND_BLOCK.get(it["kind"])           # None = loose file: any block
        hit = set()
        for e in self.entries.values():
            if e.get("misc"):
                continue
            if not e["custom"] and blk is not None and e["block"] != blk:
                continue
            if self._hits(e, name):
                hit.add(e["id"])
                if e["custom"]:
                    self.blocks_hit.setdefault(e["id"], set()).add(blk)
        if not hit:
            for b in ([blk] if blk else ALL_BLOCKS):
                hit.add("%s:misc" % b)
        return hit

    def keep(self, it, ticked):
        """Is this item shown with these entry ids ticked?"""
        if not ticked:
            return True
        blk = KIND_BLOCK.get(it["kind"])
        rel = set()
        for eid in ticked:
            e = self.entries.get(eid)
            if e is None:
                continue
            if e["custom"]:
                bl = self.blocks_hit.get(eid, ())
                if blk is None or blk in bl or None in bl:
                    rel.add(eid)
            elif blk is None or e["block"] == blk:
                rel.add(eid)
        if not rel:
            return True                            # this kind isn't being filtered
        return bool(self.match.get(it["key"], set()) & rel)
