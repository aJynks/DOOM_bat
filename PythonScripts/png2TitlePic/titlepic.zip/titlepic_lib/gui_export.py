"""titlepic - Export dialog: pick what to write."""
import os

import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk

from .steps import has_doom
from .gui_base import S, SMALL


def export_items(sprite, doom):
    """-> [(kind, settings key, label, file suffix)] for the mode / step list."""
    if not sprite:
        return [("t_pal", "x_t_pal", "Paletted  426x200", "-paletted.png"),
                ("t_tc", "x_t_tc", "Truecolour  426x240", "-truecolour.png"),
                ("t_tc200", "x_t_tc200", "Truecolour  426x200", "-truecolour-200.png")]
    if doom:
        return [("doom_pal", "x_doom_pal", "Doom paletted  (squashed, the lump for the WAD)", "-doom-paletted.png"),
                ("doom_tc", "x_doom_tc", "Doom truecolour  (squashed)", "-doom-truecolour.png"),
                ("pal", "x_pal", "Normal paletted  (normal aspect)", "-paletted.png"),
                ("tc", "x_tc", "Normal truecolour  (normal aspect)", "-truecolour.png")]
    return [("pal", "x_pal", "Paletted", "-paletted.png"),
            ("tc", "x_tc", "Truecolour", "-truecolour.png")]


class ExportDialog:
    def __init__(self, app):
        self.app = app
        V = app.v
        sprite = app._sprite()
        doom = sprite and has_doom(app.steps)
        self.items = export_items(sprite, doom)
        self.top = tk.Toplevel(app.root)
        self.top.title("Export")
        self.top.transient(app.root)
        self.top.protocol("WM_DELETE_WINDOW", self.close)
        self.top.bind("<Escape>", lambda e: self.close())
        self.top.bind("<Return>", lambda e: self.run())
        f = ttk.Frame(self.top, padding=S(10))
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        self.folder = tk.StringVar(value=app.outdir or os.path.dirname(app.src_path))
        self.stem = tk.StringVar(value=os.path.splitext(os.path.basename(app.src_path))[0])
        ttk.Label(f, text="Folder").grid(row=0, column=0, sticky="w", padx=(0, S(6)), pady=S(4))
        ttk.Entry(f, textvariable=self.folder, width=50).grid(row=0, column=1, sticky="ew", pady=S(4))
        ttk.Button(f, text="Browse...", command=self.browse).grid(row=0, column=2, padx=(S(6), 0), pady=S(4))
        ttk.Label(f, text="Name").grid(row=1, column=0, sticky="w", padx=(0, S(6)), pady=S(4))
        ttk.Entry(f, textvariable=self.stem, width=50).grid(row=1, column=1, sticky="ew", pady=S(4))
        r = 2
        if sprite:
            w, h = app.cur.size
            info = f"Current image {w}x{h}" + ("  (Doom-squashed)" if doom else "")
            ttk.Label(f, text=info, foreground="#246", font=SMALL).grid(
                row=r, column=0, columnspan=3, sticky="w", pady=(S(6), S(2)))
            r += 1
        for kind, key, label, suffix in self.items:
            row = ttk.Frame(f)
            row.grid(row=r, column=0, columnspan=3, sticky="w", pady=S(1))
            ttk.Checkbutton(row, text="  " + label, variable=V[key], style="Big.TCheckbutton").pack(side="left")
            ttk.Label(row, text="   <name>" + suffix, foreground="#666", font=SMALL).pack(side="left")
            r += 1
        if doom:
            ttk.Label(f, text="The normal versions are rebuilt from the steps with the Doom squash switched "
                              "off, so each Scale step still resamples only once.",
                      foreground="#666", wraplength=S(520), font=SMALL).grid(
                row=r, column=0, columnspan=3, sticky="w", pady=(S(4), 0))
            r += 1
        ttk.Label(f, text="Process Folder writes the same ticked files.",
                  foreground="#666", font=SMALL).grid(row=r, column=0, columnspan=3, sticky="w", pady=(S(2), 0))
        r += 1
        bf = ttk.Frame(f)
        bf.grid(row=r, column=0, columnspan=3, sticky="ew", pady=(S(8), 0))
        ttk.Button(bf, text="Export", command=self.run).pack(side="left")
        ttk.Button(bf, text="Cancel", command=self.close).pack(side="right")
        self.top.grab_set()

    def browse(self):
        d = filedialog.askdirectory(parent=self.top, initialdir=self.folder.get() or None)
        if d:
            self.folder.set(os.path.normpath(d))

    def run(self):
        folder, stem = self.folder.get().strip(), self.stem.get().strip()
        if not folder or not stem:
            messagebox.showerror("Export", "Set a folder and a name.", parent=self.top)
            return
        jobs = {kind: os.path.join(folder, stem + suffix)
                for kind, key, _, suffix in self.items if self.app.v[key].get()}
        if not jobs:
            messagebox.showerror("Export", "Tick at least one file to write.", parent=self.top)
            return
        try:
            os.makedirs(folder, exist_ok=True)
        except OSError as e:
            messagebox.showerror("Export", f"Could not create the folder:\n{e}", parent=self.top)
            return
        exist = [os.path.basename(q) for q in jobs.values() if os.path.exists(q)]
        if exist and not messagebox.askyesno("Export", "Overwrite?\n\n" + "\n".join(exist), parent=self.top):
            return
        self.app.outdir = folder
        self.close()
        self.app.start_export(jobs)

    def close(self):
        try:
            self.top.grab_release()
        except tk.TclError:
            pass
        self.top.destroy()
