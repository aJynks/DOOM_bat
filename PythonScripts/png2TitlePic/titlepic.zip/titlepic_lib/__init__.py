"""titlepic / spritepic library. Run titlepic_script.py (titlepic.bat / spritepic.bat)."""
