"""titlepic - GUI shared bits: DPI scaling (S / F), fonts and GUI constants."""


UI_SCALE = 1.0          # extra manual multiplier on top of the DPI factor
DPI_F = 1.0             # real screen DPI / 96, set by init()


def init(root):
    """Measure the screen DPI once the Tk root exists. Fonts are in points so Tk
    scales them; anything sized in pixels goes through S()."""
    global DPI_F
    try:
        DPI_F = max(1.0, root.winfo_fpixels("1i") / 96.0)
    except Exception:
        DPI_F = 1.0


def S(v):
    return max(1, int(round(v * UI_SCALE * DPI_F)))


def F(pt):
    return max(6, int(round(pt * UI_SCALE)))


METRICS = [("OKLab (perceptual)", "oklab"), ("CIELAB", "cielab"),
           ("Redmean RGB", "redmean"), ("RGB (euclidean)", "rgb")]
METRIC_NAMES = [m[0] for m in METRICS]
METRIC_CODE = dict(METRICS)
METRIC_NAME = {v: k for k, v in METRICS}
MAX_ZOOM = 16
ZOOM_STEPS = 4          # preview zoom steps per wheel notch (Shift+wheel = 1)
BG = "#1e1e1e"
FONT = ("Segoe UI", F(10))
SMALL = ("Segoe UI", F(9))
