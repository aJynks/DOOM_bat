"""titlepic - Sprite steps (Crop / Ungrid / Scale), applied in any order."""
from PIL import Image

from .const import DOOM_ASPECT
from .imaging import make_getter, resize_rgba, rgba_u8
from .ungrid import UG_CONF_MIN, ungrid_image


# --------------------------------------------------------------------------
#  Sprite steps (Crop / Ungrid / Scale), applied in any order
# --------------------------------------------------------------------------
def scale_image(img, size, filter_name, linear, thr):
    rgb, m = resize_rgba(make_getter(img), tuple(size), None, filter_name, linear, thr)
    im = Image.fromarray(rgba_u8(rgb, m), "RGBA")
    return im.convert("RGB") if m.all() else im


def step_label(st):
    w, h = st.get("out_size", (0, 0))
    if st["op"] == "ungrid":
        return f"Mosaic {w}x{h}"
    if st["op"] == "snap":
        gw, gh = st.get("grid", (0, 0))
        return f"Snap (grid {gw}x{gh})"
    return f"{st['op'].capitalize()} {w}x{h}"


def run_step(img, step, acut, batch=False, normal=False):
    """Apply one step -> (image or None if skipped, note, step as actually applied).
    When the image reaching a step has the size the step was made on (and not in
    batch), the stored values are used exactly. Otherwise Ungrid re-detects, a
    Linked Scale uses its percentage, an Unlinked Scale its exact size, and Crop
    is skipped.
    normal=True replays with every Scale step's Doom squash switched off, so the
    normal-aspect version is still resampled only once per Scale step."""
    op = step["op"]
    same = (not batch) and tuple(step.get("in_size", ())) == tuple(img.size)
    if op == "crop":
        if not same:
            if normal and not batch and step.get("in_size"):
                iw, ih = step["in_size"]
                sx, sy = img.width / iw, img.height / ih
                x0, y0, x1, y1 = step["box"]
                bx0 = min(max(0, int(round(x0 * sx))), img.width - 1)
                by0 = min(max(0, int(round(y0 * sy))), img.height - 1)
                bx1 = min(max(bx0 + 1, int(round(x1 * sx))), img.width)
                by1 = min(max(by0 + 1, int(round(y1 * sy))), img.height)
                out = img.crop((bx0, by0, bx1, by1))
                return out, f"crop {out.width}x{out.height}", dict(step, out_size=list(out.size))
            return None, "crop skipped", None
        x0, y0, x1, y1 = (int(v) for v in step["box"])
        out = img.crop((x0, y0, x1, y1))
        return out, f"crop {out.width}x{out.height}", dict(step, out_size=list(out.size))
    if op in ("ungrid", "snap"):
        snap = op == "snap"
        tile = tuple(step["tile"]) if same and step.get("tile") else None
        out, cols, rows, tile, conf = ungrid_image(img, acut, step["area"], step["pick"], step["refine"], tile,
                                                   step.get("square", True), keep_size=snap)
        grid = [len(cols) - 1, len(rows) - 1]
        weak = "" if conf >= UG_CONF_MIN else " (no clear grid)"
        note = (f"snap grid {grid[0]}x{grid[1]}" if snap else f"mosaic {out.width}x{out.height}") + weak
        return out, note, dict(step, tile=[float(v) for v in tile], grid=grid,
                               in_size=list(img.size), out_size=list(out.size))
    if op == "scale":
        off = normal and step.get("doom")
        n_size = step.get("n_size") or [step["w"], max(1, int(round(step["h"] * DOOM_ASPECT)))]
        nfy = step.get("nfy", step["fy"] * DOOM_ASPECT)
        if same:
            size = (int(n_size[0]), int(n_size[1])) if off else (int(step["w"]), int(step["h"]))
        elif step["link"] or normal:
            fy = nfy if off else step["fy"]
            size = (max(1, int(round(img.width * step["fx"]))), max(1, int(round(img.height * fy))))
        else:
            size = (int(step["w"]), int(step["h"]))
        out = img if size == tuple(img.size) else scale_image(img, size, step["filter"], step["linear"],
                                                               acut / 255.0)
        return out, f"scale {size[0]}x{size[1]}", dict(step, w=size[0], h=size[1], in_size=list(img.size),
                                                        out_size=list(size))
    raise ValueError(f"unknown step '{op}'")


def has_doom(steps):
    return any(st.get("op") == "scale" and st.get("doom") for st in steps)


def normal_image(src, steps, acut, batch=False):
    """The step list replayed with every Doom squash off (the normal-aspect version)."""
    img = src
    for st in steps:
        out, _, _ = run_step(img, st, acut, batch=batch, normal=True)
        if out is not None:
            img = out
    return img
