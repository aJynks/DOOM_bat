"""titlepic - Loading, resampling (incl. Majority), transparency helpers and palettising."""
import json

import numpy as np
from PIL import Image
from PIL import ImageOps

from .const import CROP_RATIO, DOOM_ASPECT
from .colour import ORDERED, error_diffuse, linear_to_srgb, ordered_offsets, srgb_to_linear

Image.MAX_IMAGE_PIXELS = None


# --------------------------------------------------------------------------
#  Resampling / palettising helpers
# --------------------------------------------------------------------------
MAJORITY = "Majority (pixel art)"
FILTERS = ["Lanczos", "Box (area average)", "Bicubic", "Hamming", "Bilinear", "Nearest", MAJORITY]


def _pil_filter(name):
    R = Image.Resampling
    return {"Lanczos": R.LANCZOS, "Box (area average)": R.BOX, "Bicubic": R.BICUBIC,
            "Hamming": R.HAMMING, "Bilinear": R.BILINEAR, "Nearest": R.NEAREST}[name]


def max_crop(sw, sh, ratio=CROP_RATIO):
    """Largest centred crop box with the given ratio; ratio None = the whole image."""
    if ratio is None:
        return (0.0, 0.0, float(sw), float(sh))
    if sw / sh > ratio:
        h = float(sh)
        w = h * ratio
    else:
        w = float(sw)
        h = w / ratio
    x = (sw - w) / 2.0
    y = (sh - h) / 2.0
    return (x, y, x + w, y + h)


def snap_crop(c, sw, sh):
    """Round a crop box to whole source pixels (Sprite mode), at least 1x1."""
    x0, y0, x1, y1 = (int(round(v)) for v in c)
    x0 = min(max(0, x0), sw - 1)
    y0 = min(max(0, y0), sh - 1)
    x1 = min(max(x0 + 1, x1), sw)
    y1 = min(max(y0 + 1, y1), sh)
    return (float(x0), float(y0), float(x1), float(y1))


def linked_height(w, crop_w, crop_h, doom):
    return max(1, int(round(w * crop_h / crop_w / (DOOM_ASPECT if doom else 1.0))))


def linked_width(h, crop_w, crop_h, doom):
    return max(1, int(round(h * crop_w / crop_h * (DOOM_ASPECT if doom else 1.0))))


def load_source(path):
    """-> PIL image: RGBA if the source has any transparency, otherwise RGB."""
    im = Image.open(path)
    im = ImageOps.exif_transpose(im)
    if im.mode in ("RGBA", "LA", "PA") or (im.mode == "P" and "transparency" in im.info):
        im = im.convert("RGBA")
        if im.getextrema()[3][0] == 255:          # alpha channel, but nothing transparent
            return im.convert("RGB")
        return im
    if im.mode in ("I;16", "I;16B", "I;16L", "I"):
        arr = np.asarray(im, dtype=np.float32)
        arr = np.clip(arr / (65535.0 if arr.max() > 255 else 255.0) * 255.0, 0, 255).astype(np.uint8)
        im = Image.fromarray(arr, "L")
    return im.convert("RGB")


def flatten(img):
    """RGBA -> RGB over black (Title mode ignores transparency)."""
    if img.mode == "RGBA":
        bg = Image.new("RGBA", img.size, (0, 0, 0, 255))
        return Image.alpha_composite(bg, img).convert("RGB")
    return img


def float_channels(img, linear):
    a = np.asarray(img, dtype=np.float32) / 255.0
    if linear:
        a = srgb_to_linear(a)
    return [Image.fromarray(np.ascontiguousarray(a[..., i]), "F") for i in range(3)]


def rgba_channels(img, linear):
    """-> 4 'F' images: alpha-premultiplied R, G, B (linear light optional) + alpha."""
    a = np.asarray(img.convert("RGBA"), dtype=np.float32) / 255.0
    al = np.ascontiguousarray(a[..., 3])
    rgb = srgb_to_linear(a[..., :3]) if linear else a[..., :3]
    rgb = rgb * al[..., None]
    return [Image.fromarray(np.ascontiguousarray(rgb[..., i]), "F") for i in range(3)] + \
           [Image.fromarray(al, "F")]


def make_getter(img):
    """Lazy single-entry cache of the source in the form a resizer asks for:
    rgb (flattened float channels), rgba (premultiplied float channels),
    u8 (RGBA uint8 array), u8f (flattened, as RGBA uint8 array)."""
    cache = {}

    def get(kind, linear=False):
        key = (kind, bool(linear) if kind in ("rgb", "rgba") else None)
        if key not in cache:
            cache.clear()
            if kind == "rgb":
                cache[key] = float_channels(flatten(img), linear)
            elif kind == "rgba":
                cache[key] = rgba_channels(img, linear)
            elif kind == "u8f":
                cache[key] = np.asarray(flatten(img).convert("RGBA"), dtype=np.uint8)
            else:
                cache[key] = np.asarray(img.convert("RGBA"), dtype=np.uint8)
        return cache[key]
    return get


def resample(chans, size, box, filter_name, linear):
    filt = _pil_filter(filter_name)
    out = np.stack([np.asarray(c.resize(size, resample=filt, box=box), dtype=np.float32)
                    for c in chans], axis=-1)
    if linear:
        return linear_to_srgb(out)
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def resample_rgba(chans, size, box, filter_name, linear, thr):
    """Premultiplied resize -> (rgb (h,w,3) sRGB 0..1, mask (h,w) bool)."""
    filt = _pil_filter(filter_name)
    arr = [np.asarray(c.resize(size, resample=filt, box=box), dtype=np.float32) for c in chans]
    al = np.clip(arr[3], 0.0, 1.0)
    rgb = np.stack(arr[:3], axis=-1) / np.maximum(al, 1e-4)[..., None]
    rgb = linear_to_srgb(rgb) if linear else np.clip(rgb, 0.0, 1.0)
    return rgb.astype(np.float32), al >= max(thr, 1e-3)


def majority_resample(src, size, box, thr=0.5):
    """Pixel-art downscale. Each output pixel takes the most common source colour
    in its footprint (sampled on an up-to-6x6 grid); ties go to the colour closest
    to the footprint's average, and transparent loses ties.
    src (H,W,4) uint8 -> (rgb (h,w,3) float 0..1, mask (h,w) bool)."""
    SH, SW = src.shape[:2]
    W, H = size
    x0, y0, x1, y1 = box if box else (0.0, 0.0, float(SW), float(SH))
    sx, sy = (x1 - x0) / W, (y1 - y0) / H
    kx = int(min(6, max(1, round(sx))))
    ky = int(min(6, max(1, round(sy))))
    xi = np.floor(x0 + (np.arange(W)[:, None] + (np.arange(kx)[None, :] + 0.5) / kx) * sx).astype(np.int64)
    yi = np.floor(y0 + (np.arange(H)[:, None] + (np.arange(ky)[None, :] + 0.5) / ky) * sy).astype(np.int64)
    xi = np.clip(xi, 0, SW - 1)
    yi = np.clip(yi, 0, SH - 1)
    n = kx * ky
    a_cut = max(1, int(round(thr * 255)))
    rgb_out = np.zeros((H, W, 3), dtype=np.float32)
    mask = np.zeros((H, W), dtype=bool)
    rows = max(1, int(4000000 // max(1, W * n * n)))
    for r0 in range(0, H, rows):
        r1 = min(H, r0 + rows)
        smp = src[yi[r0:r1][:, None, :, None], xi[None, :, None, :]].reshape(r1 - r0, W, n, 4)
        op = smp[..., 3] >= a_cut
        key = (smp[..., 0].astype(np.int64) << 16) | (smp[..., 1].astype(np.int64) << 8) | smp[..., 2]
        key = np.where(op, key, -1)
        counts = (key[..., :, None] == key[..., None, :]).sum(-1)
        rgbf = smp[..., :3].astype(np.float32)
        nop = op.sum(-1, keepdims=True)
        mean = (rgbf * op[..., None]).sum(-2) / np.maximum(nop, 1)
        dist = ((rgbf - mean[..., None, :]) ** 2).sum(-1)
        dist = np.where(op, dist, 200000.0)
        best = np.argmax(counts.astype(np.float64) * 1e6 - dist, axis=-1)
        pick = np.take_along_axis(smp, best[..., None, None], axis=2)[..., 0, :]
        rgb_out[r0:r1] = pick[..., :3] / 255.0
        mask[r0:r1] = pick[..., 3] >= a_cut
    return rgb_out, mask


def bleed(rgb, mask, iters=6):
    """Fill transparent pixels' colour from opaque neighbours so tweaks and
    sharpen don't drag black halos in from the empty background."""
    if mask is None or mask.all() or not mask.any():
        return rgb
    out = rgb.copy()
    known = mask.copy()
    for _ in range(iters):
        if known.all():
            break
        kp = np.pad(known.astype(np.float32), 1)
        vp = np.pad(out * known[..., None], ((1, 1), (1, 1), (0, 0)))
        cnt = kp[:-2, 1:-1] + kp[2:, 1:-1] + kp[1:-1, :-2] + kp[1:-1, 2:]
        sm = vp[:-2, 1:-1] + vp[2:, 1:-1] + vp[1:-1, :-2] + vp[1:-1, 2:]
        new = (~known) & (cnt > 0)
        out[new] = sm[new] / cnt[new][:, None]
        known |= new
    if not known.all():
        out[~known] = out[mask].mean(axis=0)
    return out.astype(np.float32)


def resize_rgb(get, size, box, filter_name, linear):
    """Title mode resize (transparency flattened over black)."""
    if filter_name == MAJORITY:
        return majority_resample(get("u8f"), size, box)[0]
    return resample(get("rgb", linear), size, box, filter_name, linear)


def resize_rgba(get, size, box, filter_name, linear, thr):
    """Sprite mode resize -> (rgb, mask). An exact 1:1 whole-pixel crop is copied
    straight through, no filter touches it."""
    u8 = get("u8")
    SH, SW = u8.shape[:2]
    bx = box if box else (0.0, 0.0, float(SW), float(SH))
    if all(abs(v - round(v)) < 1e-6 for v in bx) and \
            (int(round(bx[2] - bx[0])), int(round(bx[3] - bx[1]))) == tuple(size):
        x0, y0, x1, y1 = (int(round(v)) for v in bx)
        blk = u8[y0:y1, x0:x1]
        m = blk[..., 3] >= max(1, int(round(thr * 255)))
        return bleed(blk[..., :3].astype(np.float32) / 255.0, m), m
    if filter_name == MAJORITY:
        rgb, m = majority_resample(get("u8"), size, box, thr)
    else:
        rgb, m = resample_rgba(get("rgba", linear), size, box, filter_name, linear, thr)
    return bleed(rgb, m), m


def doom_stretch(im):
    """Preview only: show pixels the way Doom's 1.2 vertical stretch does."""
    return im.resize((im.width, max(1, int(round(im.height * DOOM_ASPECT)))), Image.Resampling.NEAREST)


def palettize(pl, matcher, pal_rgb, mode, strength_pct, clamp, serpentine, cancel=None, mask=None, tidx=None):
    """pl (H,W,3) sRGB 0..1 -> (H,W) uint8 palette indices, or None if cancelled.
    mask False pixels are skipped by dithering and set to tidx."""
    H, W, _ = pl.shape
    st = strength_pct / 100.0
    if mode == "None" or st <= 0.0:
        idx = matcher.match(pl.reshape(-1, 3), cancel)
        if idx is None:
            return None
        idx = idx.reshape(H, W)
    elif mode in ORDERED:
        off = ordered_offsets(mode, H, W) * (st * 64.0 / 255.0)
        src = np.clip(pl + off[..., None], 0.0, 1.0)
        idx = matcher.match(src.reshape(-1, 3), cancel)
        if idx is None:
            return None
        idx = idx.reshape(H, W)
    else:
        lut = matcher.lut(cancel)
        if lut is None:
            return None
        idx = error_diffuse(pl * 255.0, lut, pal_rgb, mode, st, float(clamp), serpentine, cancel, mask)
        if idx is None:
            return None
    if mask is not None and tidx is not None:
        idx = np.where(mask, idx, tidx)
    return idx.astype(np.uint8)


def to_u8(x):
    return (np.clip(x, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)


def paletted_image(idx, pal):
    im = Image.fromarray(idx, "P")
    im.putpalette(pal.pil_palette())
    return im


def save_paletted(idx, pal, path, tidx=None):
    im = paletted_image(idx, pal)
    if tidx is None:
        im.save(path, optimize=True)
    else:
        im.save(path, optimize=True, transparency=int(tidx))


def rgba_u8(rgb, mask):
    return np.dstack([to_u8(rgb), np.where(mask, 255, 0).astype(np.uint8)])


def ops_key(ops):
    return json.dumps(ops, sort_keys=True)
