"""titlepic - Stage-cached processing pipeline and Process Folder."""
import os

import numpy as np
from PIL import Image

from .const import DISP_H, IMAGE_EXTS, MODE_SPRITE, OUT_H, OUT_W
from .colour import Matcher
from .tweaks import apply_sharpen, apply_tool, apply_tweaks
from .imaging import (
    max_crop, load_source, make_getter, ops_key, palettize, resize_rgb, resize_rgba, rgba_u8, save_paletted, to_u8)
from .steps import normal_image, run_step


# --------------------------------------------------------------------------
#  Processing pipeline (stage cached)
# --------------------------------------------------------------------------
class Pipeline:
    """Stage values are (tc, pl, mask). Title: tc 426x240, pl 426x200, mask None.
    Sprite: tc is pl (one W x H image), mask (H,W) bool."""

    def __init__(self):
        self.src_key = None
        self.get = None
        self._matchers = {}
        self._reset()

    def _reset(self):
        self._c_resize = (None, None)
        self._c_base = (None, None)
        self._c_adjust = (None, None)
        self._c_pal = (None, None)

    def set_source(self, key, img):
        if key != self.src_key:
            self.src_key = key
            self.get = make_getter(img)
            self._reset()

    def resized(self, p):
        key = (self.src_key, p["mode"], p["crop"], p["filter"], p["linear"], p["tc_size"], p["pl_size"],
               p["alpha_thr"])
        if self._c_resize[0] != key:
            if p["mode"] == MODE_SPRITE:
                pl, m = resize_rgba(self.get, p["pl_size"], p["crop"], p["filter"], p["linear"], p["alpha_thr"])
                val = (pl, pl, m)
            else:
                tc = resize_rgb(self.get, p["tc_size"], p["crop"], p["filter"], p["linear"])
                pl = resize_rgb(self.get, p["pl_size"], p["crop"], p["filter"], p["linear"])
                val = (tc, pl, None)
            self._c_resize = (key, val)
        return key, self._c_resize[1]

    def base(self, p):
        """resized + applied tweaks (before the tool currently being edited)."""
        rkey, (tc, pl, m) = self.resized(p)
        key = (rkey, ops_key(p["tweaks"]))
        if self._c_base[0] != key:
            pl2 = apply_tweaks(pl, p["tweaks"])
            tc2 = pl2 if tc is pl else apply_tweaks(tc, p["tweaks"])
            self._c_base = (key, (tc2, pl2, m))
        return key, self._c_base[1]

    def adjusted(self, p):
        bkey, (tc, pl, m) = self.base(p)
        pend = p.get("pending")
        key = (bkey, ops_key(pend), p["sharpen"], p["radius"])
        if self._c_adjust[0] != key:
            same = tc is pl
            if pend:
                pl = apply_tool(pl, pend["tool"], pend["params"])
                tc = pl if same else apply_tool(tc, pend["tool"], pend["params"])
            pl = apply_sharpen(pl, p["sharpen"], p["radius"])
            tc = pl if same else apply_sharpen(tc, p["sharpen"], p["radius"])
            self._c_adjust = (key, (tc, pl, m))
        return key, self._c_adjust[1]

    def matcher(self, p):
        pal = p["palette"]
        mkey = (pal.uid, tuple(sorted(p["excluded"])), p["metric"], p["kL"], p["protect"])
        m = self._matchers.get(mkey)
        if m is None:
            if len(self._matchers) > 4:
                self._matchers.clear()
            m = Matcher(pal, p["excluded"], p["metric"], p["kL"], p["protect"])
            self._matchers[mkey] = m
        return mkey, m

    def paletted(self, p, cancel=None):
        akey, (_, pl, mask) = self.adjusted(p)
        mkey, m = self.matcher(p)
        dkey = (p["dither"], p["strength"], p["clamp"], p["serpentine"], p["tidx"])
        key = (akey, mkey, dkey)
        if self._c_pal[0] == key:
            return self._c_pal[1]
        idx = palettize(pl, m, p["palette"].rgb, p["dither"], p["strength"], p["clamp"],
                        p["serpentine"], cancel, mask=mask, tidx=p["tidx"])
        if idx is None:
            return None
        self._c_pal = (key, idx)
        return idx


def list_folder_images(folder):
    out = []
    for name in sorted(os.listdir(folder), key=str.lower):
        low = name.lower()
        if not low.endswith(IMAGE_EXTS):
            continue
        stem = os.path.splitext(low)[0]
        if stem.endswith(("-paletted", "-truecolour", "-truecolour-200")):
            continue
        if os.path.isfile(os.path.join(folder, name)):
            out.append(name)
    return out


def process_folder(p, matcher, indir, outdir, do_tweaks, do_sharpen, progress=None):
    """Batch run, writing the files ticked in the Export dialog.
    Returns (processed, skipped[(name, (w,h))], errors[(name, msg)])."""
    files = list_folder_images(indir)
    os.makedirs(outdir, exist_ok=True)
    ops = p["tweaks"] if do_tweaks else []
    sprite = p["mode"] == MODE_SPRITE
    want = p["export"]
    processed, skipped, errors = [], [], []

    def finish(x):
        x = apply_tweaks(x, ops)
        return apply_sharpen(x, p["sharpen"], p["radius"]) if do_sharpen else x

    def render(img):
        rgb, m = resize_rgba(make_getter(img), img.size, None, "Nearest", False, p["alpha_thr"])  # 1:1 copy
        rgb = finish(rgb)
        idx = palettize(rgb, matcher, p["palette"].rgb, p["dither"], p["strength"], p["clamp"],
                        p["serpentine"], None, mask=m, tidx=p["tidx"])
        return rgb, m, idx

    def write(rgb, m, idx, stem, pal_key, tc_key, suffix):
        if want.get(pal_key):
            save_paletted(idx, p["palette"], os.path.join(outdir, f"{stem}{suffix}paletted.png"),
                          None if m.all() else p["tidx"])
        if want.get(tc_key):
            Image.fromarray(rgba_u8(rgb, m), "RGBA").save(
                os.path.join(outdir, f"{stem}{suffix}truecolour.png"), optimize=True)

    for n, name in enumerate(files, 1):
        if progress:
            progress(n, len(files), name)
        path = os.path.join(indir, name)
        stem = os.path.splitext(name)[0]
        try:
            src = load_source(path)
            if sprite:
                acut = max(1, int(round(p["alpha_thr"] * 255)))
                img, notes = src, []
                for st in p["steps"]:
                    out, note, _ = run_step(img, st, acut, batch=True)
                    notes.append(note)
                    if out is not None:
                        img = out
                if p["has_doom"]:
                    if want.get("x_doom_pal") or want.get("x_doom_tc"):
                        write(*render(img), stem, "x_doom_pal", "x_doom_tc", "-doom-")
                        notes.append(f"doom {img.width}x{img.height}")
                    if want.get("x_pal") or want.get("x_tc"):
                        nimg = normal_image(src, p["steps"], acut, batch=True)
                        write(*render(nimg), stem, "x_pal", "x_tc", "-")
                        notes.append(f"normal {nimg.width}x{nimg.height}")
                else:
                    write(*render(img), stem, "x_pal", "x_tc", "-")
                    notes.append(f"{img.width}x{img.height}")
                processed.append(f"{name}   ({src.width}x{src.height} -> " + " -> ".join(notes) + ")")
                continue
            get = make_getter(src)
            tnote = ""
            if p["steps"]:
                # title steps (Snap Pixels) first, then the centred 426:240 crop and resize
                acut = max(1, int(round(p["alpha_thr"] * 255)))
                img, notes = src, []
                for st in p["steps"]:
                    out, note, _ = run_step(img, st, acut, batch=True)
                    notes.append(note)
                    if out is not None:
                        img = out
                get = make_getter(img)
                box = max_crop(img.width, img.height)
                tc240 = resize_rgb(get, (OUT_W, DISP_H), box, p["filter"], p["linear"])
                pl = resize_rgb(get, (OUT_W, OUT_H), box, p["filter"], p["linear"])
                tnote = f"   ({src.width}x{src.height} -> " + " -> ".join(notes) + f" -> {OUT_W}x{OUT_H})"
            elif src.size == (OUT_W, OUT_H):
                tc = get("u8f")[..., :3].astype(np.float32) / 255.0
                pl, tc240 = tc, None
            elif src.size == (OUT_W, DISP_H):
                tc240 = get("u8f")[..., :3].astype(np.float32) / 255.0
                pl = resize_rgb(get, (OUT_W, OUT_H), None, p["filter"], p["linear"])
            else:
                skipped.append((name, src.size))
                continue
            pl = finish(pl)
            if want.get("x_t_pal"):
                idx = palettize(pl, matcher, p["palette"].rgb, p["dither"], p["strength"], p["clamp"],
                                p["serpentine"], None)
                save_paletted(idx, p["palette"], os.path.join(outdir, f"{stem}-paletted.png"))
            if want.get("x_t_tc") and tc240 is not None:
                Image.fromarray(to_u8(finish(tc240)), "RGB").save(
                    os.path.join(outdir, f"{stem}-truecolour.png"), optimize=True)
            if want.get("x_t_tc200"):
                Image.fromarray(to_u8(pl), "RGB").save(os.path.join(outdir, f"{stem}-truecolour-200.png"),
                                                       optimize=True)
            processed.append(name + tnote)
        except Exception as e:
            errors.append((name, str(e)))
    return processed, skipped, errors
