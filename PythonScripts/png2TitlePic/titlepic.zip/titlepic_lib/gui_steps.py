"""titlepic - Ungrid and Scale step windows."""
import numpy as np
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk

from .const import DOOM_ASPECT
from .imaging import FILTERS
from .ungrid import UG_CONF_MIN, UG_CONF_OK, UG_RATIO_WARN, ug_confidence, ug_detect, UG_MIN_TILE, UG_PICKS, ug_build, ug_estimate, ug_image, ug_profiles
from .steps import scale_image
from .gui_base import S, SMALL


class GridWindow:
    """kind "mosaic": Mosaic -> Pixels, one pixel per block (the image shrinks).
    kind "snap":   Snap Pixels, every block redrawn flat on a perfect grid at the same size.
    Both find the block grid the same way. Apply adds the step."""

    def __init__(self, app, kind):
        self.app = app
        self.kind = kind
        self.snap = kind == "snap"
        V = app.v
        self.base = app.cur
        self.acut = app._acut()
        self.arr = np.asarray(self.base.convert("RGBA"))
        self.prof = ug_profiles(self.arr, self.acut)
        self.result = None
        self.cuts = None
        self.conf = 0.0
        self.after = None
        self._setting = False
        name = "Snap Pixels" if self.snap else "Mosaic \u2192 Pixels"
        self.name = name
        self.top = tk.Toplevel(app.root)
        self.top.title(name)
        self.top.transient(app.root)
        self.top.protocol("WM_DELETE_WINDOW", self.close)
        self.top.bind("<Escape>", lambda e: self.close())
        f = ttk.Frame(self.top, padding=S(10))
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        self.v = {"tw": tk.DoubleVar(value=32.0), "th": tk.DoubleVar(value=32.0),
                  "ox": tk.DoubleVar(value=0.0), "oy": tk.DoubleVar(value=0.0),
                  "square": tk.BooleanVar(value=V["w_square"].get()),
                  "refine": tk.BooleanVar(value=V["w_refine"].get()),
                  "area": tk.IntVar(value=V["w_area"].get()),
                  "pick": tk.StringVar(value=V["w_pick"].get()),
                  "view": tk.StringVar(value="Result")}
        r = 0
        intro = ("Redraws every block as one flat colour on a perfect grid, at the same size "
                 if self.snap else "Rebuilds the image with one pixel per block, so it shrinks ")
        ttk.Label(f, text=intro + f"(current image {self.base.width}x{self.base.height}).",
                  foreground="#666", wraplength=S(380), font=SMALL).grid(
            row=r, column=0, columnspan=2, sticky="w", pady=(0, S(6)))
        r += 1
        ttk.Checkbutton(f, text="  Square tiles", variable=self.v["square"],
                        style="Big.TCheckbutton").grid(row=r, column=0, columnspan=2, sticky="w", pady=S(2))
        r += 1
        self.spins = {}
        for label, key, inc, lo in (("Tile W", "tw", 0.05, UG_MIN_TILE), ("Tile H", "th", 0.05, UG_MIN_TILE),
                                    ("Offset X", "ox", 0.5, 0.0), ("Offset Y", "oy", 0.5, 0.0)):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(2))
            sp = ttk.Spinbox(f, textvariable=self.v[key], from_=lo, to=4096.0, increment=inc, width=10,
                             format="%.2f")
            sp.grid(row=r, column=1, sticky="w", pady=S(2))
            sp.bind("<MouseWheel>", lambda e: "break")
            self.spins[key] = sp
            r += 1
        ttk.Button(f, text="Re-detect", command=self.detect).grid(row=r, column=0, columnspan=2,
                                                                   sticky="w", pady=S(4))
        r += 1
        ttk.Checkbutton(f, text="  Refine lines (follow drifting tiles)", variable=self.v["refine"],
                        style="Big.TCheckbutton").grid(row=r, column=0, columnspan=2, sticky="w", pady=S(2))
        r += 1
        ttk.Label(f, text="Sample area %").grid(row=r, column=0, sticky="sw", padx=(0, S(8)))
        tk.Scale(f, from_=20, to=100, orient="horizontal", variable=self.v["area"], showvalue=True,
                 highlightthickness=0, length=S(200), sliderlength=S(22), width=S(14), font=SMALL).grid(
            row=r, column=1, sticky="ew")
        r += 1
        ttk.Label(f, text="Pick").grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(2))
        cb = ttk.Combobox(f, textvariable=self.v["pick"], values=UG_PICKS, state="readonly")
        cb.grid(row=r, column=1, sticky="ew", pady=S(2))
        cb.bind("<MouseWheel>", lambda e: "break")
        r += 1
        vf = ttk.Frame(f)
        vf.grid(row=r, column=0, columnspan=2, sticky="w", pady=S(4))
        ttk.Label(vf, text="View").pack(side="left", padx=(0, S(8)))
        for t in ("Result", "Grid"):
            ttk.Radiobutton(vf, text=t, value=t, variable=self.v["view"]).pack(side="left", padx=S(4))
        r += 1
        self.info = ttk.Label(f, text="", wraplength=S(380), font=SMALL)
        self.info.grid(row=r, column=0, columnspan=2, sticky="w", pady=(S(4), 0))
        r += 1
        self.conf_lbl = ttk.Label(f, text="", wraplength=S(380), font=SMALL)
        self.conf_lbl.grid(row=r, column=0, columnspan=2, sticky="w", pady=(S(2), S(4)))
        r += 1
        bf = ttk.Frame(f)
        bf.grid(row=r, column=0, columnspan=2, sticky="ew", pady=(S(6), 0))
        ttk.Button(bf, text="Apply", command=self.apply).pack(side="left")
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")
        for k, var in self.v.items():
            if k == "view":
                var.trace_add("write", lambda *a: self.update_view())
            elif k == "square":
                var.trace_add("write", lambda *a: self.on_square())
            else:
                var.trace_add("write", lambda *a, k=k: self.on_change(k))
        self._square_state()
        self.detect()

    def _square_state(self):
        self.spins["th"].state(["disabled"] if self.v["square"].get() else ["!disabled"])

    def on_square(self):
        self._square_state()
        self.detect()

    def on_change(self, key):
        if self._setting:
            return
        if key == "tw" and self.v["square"].get():
            self._setting = True
            try:
                self.v["th"].set(self.v["tw"].get())
            except tk.TclError:
                pass
            finally:
                self._setting = False
        self.schedule(10 if key in ("refine", "pick") else 250)

    def detect(self):
        det = ug_detect(self.prof, self.v["square"].get())
        if det is None:
            self.result, self.cuts = None, None
            self.info.configure(text="No tile grid found. Set Tile W / H by hand.", foreground="#a33")
            self.conf_lbl.configure(text="")
            self.update_view()
            return
        self._setting = True
        try:
            self.v["tw"].set(round(det[0], 2))
            self.v["th"].set(round(det[1], 2))
            self.v["ox"].set(round(det[2], 2))
            self.v["oy"].set(round(det[3], 2))
        finally:
            self._setting = False
        self.rebuild()

    def schedule(self, delay=250):
        if self._setting:
            return
        if self.after:
            self.top.after_cancel(self.after)
        self.after = self.top.after(delay, self.rebuild)

    def tile(self):
        try:
            tw, th = float(self.v["tw"].get()), float(self.v["th"].get())
            ox, oy = float(self.v["ox"].get()), float(self.v["oy"].get())
        except (tk.TclError, ValueError):
            raise ValueError("tile size / offset is not a number")
        if self.v["square"].get():
            th = tw
        if tw < UG_MIN_TILE or th < UG_MIN_TILE:
            raise ValueError(f"tile size must be at least {UG_MIN_TILE:.0f} px")
        return tw, th, ox, oy

    def rebuild(self):
        if self.after:
            self.top.after_cancel(self.after)
        self.after = None
        try:
            tw, th, ox, oy = self.tile()
            cols, rows = ug_build(self.prof, self.base.size, tw, th, ox, oy, self.v["refine"].get())
            self.result = ug_image(self.arr, cols, rows, self.v["area"].get() / 100.0, self.acut,
                                   self.v["pick"].get(), size=self.base.size if self.snap else None)
            self.cuts = (cols, rows)
            gw, gh = len(cols) - 1, len(rows) - 1
            out = (f"output {self.result.width}x{self.result.height} (same size)" if self.snap
                   else f"output {self.result.width}x{self.result.height}")
            self.info.configure(text=f"Grid {gw} x {gh} blocks   (tile {tw:.2f} x {th:.2f} px)   {out}",
                                foreground="#246")
            self.conf = ug_confidence(self.prof, tw, th, ox, oy)
            self._show_conf(tw, th)
        except ValueError as e:
            self.result, self.cuts, self.conf = None, None, 0.0
            self.info.configure(text=f"Failed: {e}", foreground="#a33")
            self.conf_lbl.configure(text="")
        self.update_view()

    def _show_conf(self, tw, th):
        c = self.conf
        if c >= UG_CONF_OK:
            txt, col = f"Clear block grid (strength {c:.1f}).", "#282"
        elif c >= UG_CONF_MIN:
            txt, col = f"Weak block grid (strength {c:.1f}). Check it with View: Grid.", "#b70"
        else:
            txt, col = (f"No clear pixel grid (strength {c:.1f}). This image doesn't look block-based; "
                        f"use Scale / the title resize instead, or set the tile size by hand."), "#c22"
        if max(tw, th) / min(tw, th) > UG_RATIO_WARN:
            txt += f"  Tile W and H differ a lot ({tw:.2f} x {th:.2f}); blocks are normally square."
            col = "#c22"
        self.conf_lbl.configure(text=txt, foreground=col)

    def update_view(self):
        if self.v["view"].get() == "Grid" and self.cuts:
            self.app.show_step_preview(None, grid=(self.base, self.cuts))
        else:
            self.app.show_step_preview(self.result)

    def apply(self):
        if self.after:
            self.rebuild()
        if self.result is None:
            messagebox.showerror(self.name, "There is no usable grid to apply.", parent=self.top)
            return
        if self.conf < UG_CONF_MIN and not messagebox.askyesno(
                self.name, "No clear pixel grid was found, so the result may just be noise.\n\nApply anyway?",
                parent=self.top):
            return
        V = self.app.v
        V["w_square"].set(self.v["square"].get())
        V["w_refine"].set(self.v["refine"].get())
        V["w_area"].set(self.v["area"].get())
        V["w_pick"].set(self.v["pick"].get())
        tw, th, ox, oy = self.tile()
        cols, rows = self.cuts
        step = {"op": "snap" if self.snap else "ungrid", "tile": [tw, th, ox, oy],
                "square": self.v["square"].get(), "refine": self.v["refine"].get(),
                "area": self.v["area"].get() / 100.0, "pick": self.v["pick"].get(),
                "grid": [len(cols) - 1, len(rows) - 1],
                "in_size": list(self.base.size), "out_size": list(self.result.size)}
        img = self.result
        self._finish()
        self.app.add_step(step, img)

    def close(self):
        if self.result is not None and not messagebox.askyesno(
                self.name, f"Close without applying the {self.name} step?", parent=self.top):
            return
        self._finish()

    def _finish(self):
        if self.after:
            self.top.after_cancel(self.after)
        self.app.step_win = None
        self.top.destroy()
        self.app.clear_step_preview()


class ScaleWindow:
    """Scale step: resize the current image. Opens at 1:1. Apply adds the step."""

    def __init__(self, app):
        self.app = app
        V = app.v
        self.base = app.cur
        self.bw, self.bh = self.base.size
        self.result = self.base
        self.after = None
        self._linking = False
        self.top = tk.Toplevel(app.root)
        self.top.title("Scale")
        self.top.transient(app.root)
        self.top.protocol("WM_DELETE_WINDOW", self.close)
        self.top.bind("<Escape>", lambda e: self.close())
        self.top.bind("<Return>", lambda e: self.apply())
        f = ttk.Frame(self.top, padding=S(10))
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        self.v = {"w": tk.IntVar(value=self.bw), "h": tk.IntVar(value=self.bh),
                  "link": tk.BooleanVar(value=V["w_link"].get()),
                  "doom": tk.BooleanVar(value=V["w_doom"].get()),
                  "filter": tk.StringVar(value=V["w_filter"].get()),
                  "linear": tk.BooleanVar(value=V["w_linear"].get())}
        r = 0
        ttk.Label(f, text=f"Working on the current image, {self.bw}x{self.bh}",
                  foreground="#666", font=SMALL).grid(row=r, column=0, columnspan=3, sticky="w", pady=(0, S(6)))
        r += 1
        for label, key in (("Width", "w"), ("Height", "h")):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(2))
            sp = ttk.Spinbox(f, textvariable=self.v[key], from_=1, to=4096, increment=1, width=8)
            sp.grid(row=r, column=1, sticky="w", pady=S(2))
            sp.bind("<MouseWheel>", lambda e: "break")
            r += 1
        ttk.Button(f, text="1:1", command=self.one_to_one, width=5).grid(row=1, column=2, rowspan=2,
                                                                         padx=(S(8), 0))
        ttk.Checkbutton(f, text="  Linked (lock aspect ratio)", variable=self.v["link"],
                        style="Big.TCheckbutton").grid(row=r, column=0, columnspan=3, sticky="w", pady=S(2))
        r += 1
        self.doom_cb = ttk.Checkbutton(f, text="  Doom aspect (height \u00f7 1.2)", variable=self.v["doom"],
                                       style="Big.TCheckbutton")
        self.doom_cb.grid(row=r, column=0, columnspan=3, sticky="w", pady=S(2))
        r += 1
        ttk.Label(f, text="Filter").grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(2))
        cb = ttk.Combobox(f, textvariable=self.v["filter"], values=FILTERS, state="readonly")
        cb.grid(row=r, column=1, columnspan=2, sticky="ew", pady=S(2))
        cb.bind("<MouseWheel>", lambda e: "break")
        r += 1
        ttk.Checkbutton(f, text="  Linear light (gamma-correct averaging)", variable=self.v["linear"],
                        style="Big.TCheckbutton").grid(row=r, column=0, columnspan=3, sticky="w", pady=S(2))
        r += 1
        self.info = ttk.Label(f, text="", wraplength=S(360), font=SMALL)
        self.info.grid(row=r, column=0, columnspan=3, sticky="w", pady=S(4))
        r += 1
        bf = ttk.Frame(f)
        bf.grid(row=r, column=0, columnspan=3, sticky="ew", pady=(S(6), 0))
        ttk.Button(bf, text="Apply", command=self.apply).pack(side="left")
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")
        for k, var in self.v.items():
            var.trace_add("write", lambda *a, k=k: self.on_change(k))
        self.refresh()

    def size(self):
        try:
            w, h = int(self.v["w"].get()), int(self.v["h"].get())
        except (tk.TclError, ValueError):
            return None
        return (w, h) if 1 <= w <= 4096 and 1 <= h <= 4096 else None

    def one_to_one(self):
        self._linking = True
        try:
            self.v["w"].set(self.bw)
            self.v["h"].set(self.bh)
        finally:
            self._linking = False
        self.refresh()

    def on_change(self, key):
        if self._linking:
            return
        V = self.v
        if V["link"].get() and key in ("w", "h", "link", "doom"):
            d = DOOM_ASPECT if V["doom"].get() else 1.0
            self._linking = True
            try:
                if key == "h":
                    try:
                        h = int(V["h"].get())
                        V["w"].set(max(1, int(round(h * self.bw / self.bh * d))))
                    except (tk.TclError, ValueError):
                        pass
                else:
                    try:
                        w = int(V["w"].get())
                        V["h"].set(max(1, int(round(w * self.bh / self.bw / d))))
                    except (tk.TclError, ValueError):
                        pass
            finally:
                self._linking = False
        self.refresh()

    def refresh(self):
        try:
            self.doom_cb.state(["!disabled"] if self.v["link"].get() else ["disabled"])
        except tk.TclError:
            pass
        sz = self.size()
        if sz is None:
            self.info.configure(text="Width and Height must be 1 - 4096.", foreground="#a33")
            return
        w, h = sz
        txt = f"{self.bw}x{self.bh}  ->  {w}x{h}   ({w / self.bw * 100:.1f}% x {h / self.bh * 100:.1f}%)"
        up = w > self.bw or h > self.bh
        if (w, h) == (self.bw, self.bh):
            txt += "   1:1, no change"
        elif up:
            txt += "   UPSCALING"
        self.info.configure(text=txt, foreground="#c22" if up else "#246")
        if self.after:
            self.top.after_cancel(self.after)
        self.after = self.top.after(120, self.render)

    def render(self):
        self.after = None
        sz = self.size()
        if sz is None:
            return
        if sz == (self.bw, self.bh):
            self.result = self.base
        else:
            self.result = scale_image(self.base, sz, self.v["filter"].get(), self.v["linear"].get(),
                                      self.app._acut() / 255.0)
        self.app.show_step_preview(self.result)

    def apply(self):
        sz = self.size()
        if sz is None:
            messagebox.showerror("Scale", "Width and Height must be 1 - 4096.", parent=self.top)
            return
        if self.after or self.result.size != sz:
            self.render()
        V = self.app.v
        for k in ("link", "doom", "filter", "linear"):
            V["w_" + k].set(self.v[k].get())
        img = self.result
        w, h = sz
        link = self.v["link"].get()
        doom = link and self.v["doom"].get()
        nh = max(1, int(round(w * self.bh / self.bw))) if doom else h     # height without the squash
        step = {"op": "scale", "w": w, "h": h, "link": link, "doom": doom,
                "filter": self.v["filter"].get(), "linear": self.v["linear"].get(),
                "fx": w / self.bw, "fy": h / self.bh, "n_size": [w, nh], "nfy": nh / self.bh,
                "in_size": [self.bw, self.bh], "out_size": [w, h]}
        self._finish()
        if (w, h) == (self.bw, self.bh):
            return                                     # 1:1 adds nothing
        self.app.add_step(step, img)

    def close(self):
        self._finish()

    def _finish(self):
        if self.after:
            self.top.after_cancel(self.after)
            self.after = None
        self.app.step_win = None
        self.top.destroy()
        self.app.clear_step_preview()
