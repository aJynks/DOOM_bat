"""titlepic - Tweak Image window."""
import numpy as np
import tkinter as tk
from tkinter import colorchooser
from tkinter import messagebox
from tkinter import ttk

from .tweaks import TOOLS, TOOL_NAMES, monotone_lut, tool_defaults
from .gui_base import S, SMALL


# ======================================================================
#  Tweak Image window
# ======================================================================
class TweakWindow:
    """Tool palette. Picking another tool carries the current look forward
    (the tool's effect is committed and the next tool starts from it).
    Apply accepts the look and closes; closing otherwise asks to discard."""

    def __init__(self, app):
        self.app = app
        self.start_ops = [dict(op) for op in app.tweaks]
        self.ops = [dict(op) for op in app.tweaks]     # working look for this session
        self.top = tk.Toplevel(app.root)
        self.top.title("Tweak Image")
        self.top.transient(app.root)
        self.top.protocol("WM_DELETE_WINDOW", self.close)
        self.top.geometry(f"{S(480)}x{S(680)}")
        self.hist = None
        self.points = None
        self.curve_drag = None
        self.vars = {}
        self._building = False
        self.tool = TOOL_NAMES[0]

        head = ttk.Frame(self.top, padding=S(8))
        head.pack(fill="x")
        ttk.Label(head, text="Tool").pack(side="left", padx=(0, S(6)))
        self.tool_var = tk.StringVar(value=self.tool)
        cb = ttk.Combobox(head, textvariable=self.tool_var, values=TOOL_NAMES, state="readonly",
                          height=len(TOOL_NAMES))
        cb.pack(side="left", fill="x", expand=True)
        cb.bind("<MouseWheel>", lambda e: "break")
        ttk.Button(head, text="Reset tool", command=self.reset_tool).pack(side="left", padx=(S(6), 0))
        self.tool_var.trace_add("write", lambda *a: self.switch_tool())

        bot = ttk.Frame(self.top, padding=S(8))
        bot.pack(side="bottom", fill="x")
        self.applied = ttk.Label(bot, text="", wraplength=S(450), foreground="#246")
        self.applied.pack(fill="x", pady=(0, S(6)))
        bf = ttk.Frame(bot)
        bf.pack(fill="x")
        ttk.Button(bf, text="Apply", command=self.apply).pack(side="left", padx=(0, S(4)))
        ttk.Button(bf, text="Undo", command=self.undo).pack(side="left", padx=S(4))
        ttk.Button(bf, text="Reset", command=self.reset_image).pack(side="left", padx=S(4))
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")

        self.ctrl = ttk.Frame(self.top, padding=(S(8), 0))
        self.ctrl.pack(fill="both", expand=True)
        self.load_tool(self.tool)

    # -- session state ---------------------------------------------------
    def load_tool(self, name):
        """Show a tool with its default settings (no effect yet)."""
        self.tool = name
        self._building = True
        self.build_panel()
        self._building = False
        self.push_pending()
        self.draw_graphs()
        self.refresh_label()

    def params(self):
        p = {}
        for k, v in self.vars.items():
            try:
                p[k] = v.get()
            except tk.TclError:
                p[k] = tool_defaults(self.tool)[k]
        if self.points is not None and self.curve_canvas is not None:
            p["points"] = [list(pt) for pt in self.points]
        return p

    def modified(self):
        d = tool_defaults(self.tool)
        for k, v in self.params().items():
            dv = d.get(k)
            if isinstance(dv, float) or isinstance(v, float):
                if abs(float(v) - float(dv)) > 1e-9:
                    return True
            elif v != dv:
                return True
        return False

    def current_op(self):
        return {"tool": self.tool, "params": self.params()} if self.modified() else None

    def push_pending(self):
        self.app.pending = self.current_op()
        self.app.schedule(60)
        self.refresh_label()

    def commit_current(self):
        op = self.current_op()
        if op:
            self.ops.append(op)
        self.app.pending = None

    def switch_tool(self):
        name = self.tool_var.get()
        if name == self.tool:
            return
        self.commit_current()
        self.load_tool(name)

    def reset_tool(self):
        self.load_tool(self.tool)

    def reset_image(self):
        if not self.ops and not self.modified():
            return
        if messagebox.askyesno("Tweak Image", "Reset the image back to the source?", parent=self.top):
            self.ops = []
            self.load_tool(self.tool)

    def undo(self):
        if self.modified():
            self.load_tool(self.tool)          # first undo clears the tool being edited
        elif self.ops:
            self.ops.pop()
            self.load_tool(self.tool)

    def changed(self):
        return self.modified() or self.ops != self.start_ops

    def apply(self):
        self.commit_current()
        self.app.tweaks = self.ops
        self._finish()

    def close(self):
        if self.changed() and not messagebox.askyesno(
                "Tweak Image", "Changes not applied.\n\nDiscard them?", parent=self.top):
            return
        self._finish()

    def _finish(self):
        self.app.pending = None
        self.app.tweak_win = None
        self.top.destroy()
        self.app.update_tweak_summary()
        self.app.schedule()

    def refresh_label(self):
        names = [op["tool"] for op in self.ops]
        txt = " \u2192 ".join(names) if names else "(source)"
        if self.modified():
            txt += f"  \u2192 [{self.tool}]"
        self.applied.configure(text="Look: " + txt)

    def want_hist(self):
        return self.tool in ("Levels", "Curves")

    def build_panel(self):
        for w in self.ctrl.winfo_children():
            w.destroy()
        self.vars = {}
        self.hist_canvas = None
        self.curve_canvas = None
        name = self.tool_var.get()
        self.tool = name
        d = tool_defaults(name)
        f = self.ctrl
        f.columnconfigure(1, weight=1)
        row = 0
        if name == "Levels":
            self.hist_canvas = tk.Canvas(f, width=S(300), height=S(90), bg="#fafafa",
                                         highlightthickness=1, highlightbackground="#999")
            self.hist_canvas.grid(row=row, column=0, columnspan=2, pady=S(4))
            row += 1
        for spec in TOOLS[name][1]:
            kind, key = spec[0], spec[1]
            if kind == "s":
                _, _, label, lo, hi, res, dv = spec
                var = tk.DoubleVar(value=dv) if isinstance(res, float) else tk.IntVar(value=dv)
                lab = ttk.Label(f, text=label)
                lab.grid(row=row, column=0, sticky="sw", padx=(0, S(6)))
                sc = tk.Scale(f, from_=lo, to=hi, resolution=res, orient="horizontal", variable=var,
                              showvalue=True, highlightthickness=0, length=S(220),
                              sliderlength=S(22), width=S(14), font=SMALL)
                sc.grid(row=row, column=1, sticky="ew")
                lab.bind("<Double-Button-1>", lambda e, v=var, dv=dv: v.set(dv))
            elif kind == "c":
                _, _, label, values, dv = spec
                var = tk.StringVar(value=dv)
                ttk.Label(f, text=label).grid(row=row, column=0, sticky="w", padx=(0, S(6)), pady=S(3))
                c = ttk.Combobox(f, textvariable=var, values=values, state="readonly")
                c.grid(row=row, column=1, sticky="ew", pady=S(3))
                c.bind("<MouseWheel>", lambda e: "break")
            elif kind == "b":
                _, _, label, dv = spec
                var = tk.BooleanVar(value=dv)
                ttk.Checkbutton(f, text="  " + label, variable=var, style="Big.TCheckbutton").grid(
                    row=row, column=0, columnspan=2, sticky="w", pady=S(3))
            elif kind == "col":
                _, _, label, dv = spec
                var = tk.StringVar(value=dv)
                ttk.Label(f, text=label).grid(row=row, column=0, sticky="w", padx=(0, S(6)), pady=S(3))
                btn = tk.Button(f, bg=dv, activebackground=dv, width=8, relief="raised")
                btn.configure(command=lambda v=var, b=btn: self.pick_colour(v, b))
                btn.grid(row=row, column=1, sticky="w", pady=S(3))
            elif kind == "curve":
                self.points = [list(pt) for pt in d[key]]
                self.curve_canvas = tk.Canvas(f, width=S(300), height=S(300), bg="#fafafa",
                                              highlightthickness=1, highlightbackground="#999")
                self.curve_canvas.grid(row=row, column=0, columnspan=2, pady=S(6))
                self.curve_canvas.bind("<ButtonPress-1>", self.curve_press)
                self.curve_canvas.bind("<B1-Motion>", self.curve_move)
                self.curve_canvas.bind("<ButtonRelease-1>", lambda e: setattr(self, "curve_drag", None))
                self.curve_canvas.bind("<Button-3>", self.curve_delete)
                row += 1
                ttk.Label(f, text="Click to add a point, drag to move, right-click to delete.",
                          foreground="#666", font=SMALL).grid(row=row, column=0, columnspan=2, sticky="w")
                row += 1
                continue
            self.vars[key] = var
            var.trace_add("write", lambda *a, k=key: self.on_change(k))
            row += 1

    def pick_colour(self, var, btn):
        res = colorchooser.askcolor(color=var.get(), parent=self.top)
        if res and res[1]:
            var.set(res[1])
            btn.configure(bg=res[1], activebackground=res[1])

    def on_change(self, key):
        if self._building:
            return
        if self.tool == "Channel Mixer" and key == "output":
            ident = {"Red": (100, 0, 0), "Green": (0, 100, 0), "Blue": (0, 0, 100)}[self.vars["output"].get()]
            self._building = True
            for k, v in zip(("red", "green", "blue"), ident):
                self.vars[k].set(v)
            self._building = False
        self.push_pending()
        self.draw_graphs()

    # -- histogram / curve drawing ---------------------------------------
    def set_hist(self, hist):
        self.hist = hist
        self.draw_graphs()

    def _hist_for_channel(self):
        if self.hist is None:
            return None
        ch = self.vars.get("channel")
        name = ch.get() if ch else "RGB"
        return self.hist[{"RGB": 0, "Red": 1, "Green": 2, "Blue": 3}[name]]

    def _draw_hist(self, c, w, h, colour):
        hist = self._hist_for_channel()
        if hist is None:
            return
        m = max(1.0, float(np.percentile(hist, 99.5)))
        for i in range(256):
            v = min(1.0, hist[i] / m)
            x = i * w / 256.0
            c.create_rectangle(x, h - v * h, x + w / 256.0 + 1, h, fill=colour, outline="")

    def draw_graphs(self):
        if self.hist_canvas is not None:
            c = self.hist_canvas
            c.delete("all")
            w, h = int(c.cget("width")), int(c.cget("height"))
            self._draw_hist(c, w, h, "#888")
            p = self.params()
            for key, col in (("in_black", "#000"), ("in_white", "#fff")):
                if key in p:
                    x = p[key] * w / 255.0
                    c.create_line(x, 0, x, h, fill="#c00", width=S(1))
        if self.curve_canvas is not None:
            c = self.curve_canvas
            c.delete("all")
            n = int(c.cget("width"))
            self._draw_hist(c, n, n, "#ddd")
            for i in range(1, 4):
                c.create_line(i * n / 4, 0, i * n / 4, n, fill="#ccc")
                c.create_line(0, i * n / 4, n, i * n / 4, fill="#ccc")
            c.create_line(0, n, n, 0, fill="#bbb", dash=(3, 3))
            lut = monotone_lut(self.points, 256)
            coords = []
            for i in range(256):
                coords += [i * n / 255.0, n - lut[i] * n]
            c.create_line(*coords, fill="#222", width=S(2))
            r = S(5)
            for px, py in self.points:
                X, Y = px * n, n - py * n
                c.create_oval(X - r, Y - r, X + r, Y + r, fill="#fff", outline="#000", width=S(1))

    def _curve_xy(self, e):
        n = int(self.curve_canvas.cget("width"))
        return min(max(e.x / n, 0.0), 1.0), min(max(1.0 - e.y / n, 0.0), 1.0), n

    def curve_press(self, e):
        x, y, n = self._curve_xy(e)
        tol = S(9) / n
        for i, (px, py) in enumerate(self.points):
            if abs(px - x) <= tol and abs(py - y) <= tol:
                self.curve_drag = i
                return
        self.points.append([x, y])
        self.points.sort(key=lambda pt: pt[0])
        self.curve_drag = next(i for i, pt in enumerate(self.points) if pt[0] == x and pt[1] == y)
        self.on_change("points")

    def curve_move(self, e):
        if self.curve_drag is None:
            return
        x, y, n = self._curve_xy(e)
        i = self.curve_drag
        eps = 1.0 / 255.0
        lo = self.points[i - 1][0] + eps if i > 0 else 0.0
        hi = self.points[i + 1][0] - eps if i < len(self.points) - 1 else 1.0
        self.points[i] = [min(max(x, lo), hi), y]
        self.on_change("points")

    def curve_delete(self, e):
        if len(self.points) <= 2:
            return
        x, y, n = self._curve_xy(e)
        tol = S(9) / n
        for i, (px, py) in enumerate(self.points):
            if abs(px - x) <= tol and abs(py - y) <= tol:
                del self.points[i]
                self.on_change("points")
                return

# ======================================================================
#  Process Folder dialog
# ======================================================================
