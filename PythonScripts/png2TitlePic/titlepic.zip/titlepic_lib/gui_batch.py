"""titlepic - Process Folder dialog."""
import os

import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk

from .steps import has_doom, step_label
from .gui_export import export_items
from .gui_base import S, SMALL


class BatchDialog:
    def __init__(self, app):
        self.app = app
        V = app.v
        self.sprite = app._sprite()
        self.top = tk.Toplevel(app.root)
        self.top.title("Process Folder" + (" (Sprite)" if self.sprite else " (Title screen)"))
        self.top.transient(app.root)
        self.top.protocol("WM_DELETE_WINDOW", self.close)
        f = ttk.Frame(self.top, padding=S(10))
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)
        for r, (label, key) in enumerate((("Input folder", "b_in"), ("Output folder", "b_out"))):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", padx=(0, S(6)), pady=S(4))
            ttk.Entry(f, textvariable=V[key], width=50).grid(row=r, column=1, sticky="ew", pady=S(4))
            ttk.Button(f, text="Browse...", command=lambda k=key: self.browse(k)).grid(
                row=r, column=2, padx=(S(6), 0), pady=S(4))
        for r, (label, key) in enumerate((("Apply image tweaks", "b_tweaks"),
                                          ("Apply sharpen", "b_sharpen")), start=2):
            ttk.Checkbutton(f, text="  " + label, variable=V[key], style="Big.TCheckbutton").grid(
                row=r, column=0, columnspan=3, sticky="w", pady=S(2))
        r = 4
        self.note = ttk.Label(f, text="", foreground="#666", wraplength=S(520), font=SMALL)
        self.note.grid(row=r, column=0, columnspan=3, sticky="w", pady=(S(6), S(4)))
        bf = ttk.Frame(f)
        bf.grid(row=r + 1, column=0, columnspan=3, sticky="ew", pady=(S(6), 0))
        self.run_btn = ttk.Button(bf, text="Run", command=self.run)
        self.run_btn.pack(side="left")
        ttk.Button(bf, text="Close", command=self.close).pack(side="right")
        self.prog = ttk.Label(f, text="")
        self.prog.grid(row=r + 2, column=0, columnspan=3, sticky="w", pady=(S(6), 0))
        self.refresh_note()

    def refresh_note(self):
        sprite = self.sprite
        items = export_items(sprite, sprite and has_doom(self.app.steps))
        files = ", ".join("<name>" + suf for _, key, _, suf in items if self.app.v[key].get())
        files = ("Writes the files ticked in Export: " + files + ". ") if files else \
            "Nothing is ticked in Export, so nothing would be written. "
        self.note.configure(text=files + self._note_text())

    def _note_text(self):
        if not self.sprite:
            if self.app.steps:
                return ("Every image is processed: " + " -> ".join(step_label(st) for st in self.app.steps)
                        + " (Snap detects each image's own grid), then the centred 426:240 crop and the "
                          "426x200 resize. Uses the current palette, dither and resize filter.")
            return ("426x200 processed as-is, 426x240 squashed to 200, anything else is skipped "
                    "and reported. Uses the current palette, dither and resize filter.")
        else:
            steps = self.app.steps
            t = ("Every image is processed with the current step list"
                 + (": " + " -> ".join(step_label(st) for st in steps) if steps else " (no steps: 1:1)")
                 + ". Mosaic / Snap detect each image's own grid, a Linked Scale uses the same percentage, "
                   "an Unlinked Scale its exact size, and Crop steps are skipped. "
                   "Uses the current transparency, palette and dither.")
        return t

    def browse(self, key):
        d = filedialog.askdirectory(parent=self.top, initialdir=self.app.v[key].get() or None)
        if d:
            self.app.v[key].set(os.path.normpath(d))
            if key == "b_in" and not self.app.v["b_out"].get():
                self.app.v["b_out"].set(os.path.join(os.path.normpath(d),
                                                     "spritepic_out" if self.sprite else "titlepic_out"))

    def run(self):
        indir, outdir = self.app.v["b_in"].get().strip(), self.app.v["b_out"].get().strip()
        if not indir or not os.path.isdir(indir):
            messagebox.showerror("Process Folder", "Pick an existing input folder.", parent=self.top)
            return
        if not outdir:
            messagebox.showerror("Process Folder", "Pick an output folder.", parent=self.top)
            return
        if not self.app.start_batch(indir, outdir, self.top):
            return
        self.run_btn.state(["disabled"])
        self.prog.configure(text="Starting...")

    def progress(self, n, total, name):
        self.prog.configure(text=f"{n} / {total}   {name}")

    def done(self):
        self.run_btn.state(["!disabled"])
        self.prog.configure(text="Done.")

    def close(self):
        self.app.batch_dlg = None
        self.top.destroy()
