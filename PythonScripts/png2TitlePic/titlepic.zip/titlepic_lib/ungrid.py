"""titlepic - Ungrid: rebuild AI tile-mosaic 'pixel art' with one pixel per tile."""
import math

import numpy as np
from PIL import Image


# --------------------------------------------------------------------------
#  Ungrid (rebuild AI mosaic "pixel art" with one pixel per tile)
#  Grid-line walker adapted from Sprite Fusion Pixel Snapper (Hugo Duprez, MIT).
# --------------------------------------------------------------------------
UG_PICKS = ["Grouped vote", "Median"]
UG_CONF_OK = 2.5        # grid strength at or above this: a clear block grid
UG_CONF_MIN = 1.5       # below this: no real grid (texture / noise)
UG_RATIO_WARN = 1.3     # tile W and H further apart than this look wrong
UG_MIN_TILE = 4.0
UG_MAX_CELLS = 512 * 512


def ug_profiles(a, acut):
    """Colour + alpha edge strength per column and per row (transparent = black)."""
    al = (a[..., 3] >= acut).astype(np.float32)
    rgb = a[..., :3].astype(np.float32) * al[..., None]
    dx = np.abs(rgb[:, 2:] - rgb[:, :-2]).sum(2) + 255.0 * np.abs(al[:, 2:] - al[:, :-2])
    dy = np.abs(rgb[2:] - rgb[:-2]).sum(2) + 255.0 * np.abs(al[2:] - al[:-2])
    px = np.zeros(a.shape[1], dtype=np.float64)
    py = np.zeros(a.shape[0], dtype=np.float64)
    px[1:-1] = dx.sum(0)
    py[1:-1] = dy.sum(1)
    return px, py


def ug_estimate(p):
    """-> (tile size, offset) for one axis, or None. Autocorrelation finds the
    rough period, then a comb fit refines size (0.02 px) and offset (0.5 px)."""
    n = len(p)
    lo, hi = int(UG_MIN_TILE), max(int(UG_MIN_TILE) + 2, n // 4)
    if n < lo * 4 or p.max() <= 0:
        return None
    q = p - p.mean()
    ac = np.correlate(q, q, "full")[n - 1:]
    k = lo + int(np.argmax(ac[lo:hi]))
    best = None
    for st in np.arange(k * 0.9, k * 1.1 + 0.01, 0.02):
        for ph in np.arange(0.0, st, 0.5):
            pos = np.round(np.arange(ph, n - 1, st)).astype(np.int64)
            v = p[pos].mean()
            if best is None or v > best[0]:
                best = (v, st, ph)
    return float(best[1]), float(best[2])


def _comb(p, st, phase_step=0.5):
    """-> (strength, phase): mean edge strength on a grid of pitch st / overall mean.
    About 1.0 means the grid lines are no stronger than anywhere else."""
    mean = p.mean()
    n = len(p)
    if mean <= 0 or n < st * 3:
        return 0.0, 0.0
    best = (0.0, 0.0)
    for ph in np.arange(0.0, st, phase_step):
        pos = np.round(np.arange(ph, n - 1, st)).astype(np.int64)
        v = p[pos].mean() / mean
        if v > best[0]:
            best = (float(v), float(ph))
    return best


def ug_confidence(prof, tw, th, ox, oy):
    """Grid strength of a given grid (min of both axes)."""
    out = []
    for p, st, ph in ((prof[0], tw, ox), (prof[1], th, oy)):
        mean = p.mean()
        if mean <= 0:
            return 0.0
        pos = np.round(np.arange(ph - st * math.floor(ph / st), len(p) - 1, st)).astype(np.int64)
        out.append(float(p[pos].mean() / mean) if len(pos) else 0.0)
    return min(out)


def ug_detect(prof, square=True):
    """-> (tw, th, ox, oy, strength) or None.
    square: one tile size for both axes, searched jointly so the ratio can't be
    mangled; the smallest size that explains the grid wins (not a multiple of it)."""
    px, py = prof
    if not square:
        ex, ey = ug_estimate(px), ug_estimate(py)
        if ex is None and ey is None:
            return None
        ex, ey = ex or ey, ey or ex
        return ex[0], ey[0], ex[1], ey[1], ug_confidence(prof, ex[0], ey[0], ex[1], ey[1])
    n = min(len(px), len(py))
    lo, hi = int(UG_MIN_TILE), max(int(UG_MIN_TILE) + 2, n // 4)
    if n < lo * 4 or px.max() <= 0 or py.max() <= 0:
        return None
    # rough pitch: autocorrelation of both axes added together (one pitch for both)
    acs = np.zeros(hi + 1)
    for p in (px, py):
        q = p - p.mean()
        ac = np.correlate(q, q, "full")[len(q) - 1:]
        if ac[0] > 0:
            acs += ac[:hi + 1] / ac[0]
    k = lo + int(np.argmax(acs[lo:hi]))
    # refine size (0.02 px) and offsets (0.5 px) jointly on both axes
    top = (-1.0, float(k), 0.0, 0.0)
    for st in np.arange(max(UG_MIN_TILE, k * 0.9), k * 1.1 + 1e-6, 0.02):
        sx, ox = _comb(px, float(st), 0.5)
        sy, oy = _comb(py, float(st), 0.5)
        if sx + sy > top[0]:
            top = (sx + sy, float(st), ox, oy)
    _, st, ox, oy = top
    return st, st, ox, oy, ug_confidence(prof, st, st, ox, oy)


def _ug_first(step, phase):
    pos = phase - step * math.floor(phase / step)
    return pos if pos > 0.5 else pos + step


def _ug_trim(cuts, step):
    """Drop slivers under half a tile at the image edges."""
    if len(cuts) > 2 and cuts[1] - cuts[0] < step * 0.5:
        cuts.pop(1)
    if len(cuts) > 2 and cuts[-1] - cuts[-2] < step * 0.5:
        cuts.pop(-2)
    return cuts


def ug_uniform(n, step, phase):
    cuts = [0]
    t = _ug_first(step, phase)
    while t < n - 1:
        c = int(round(t))
        if c > cuts[-1]:
            cuts.append(c)
        t += step
    cuts.append(n)
    return _ug_trim(cuts, step)


def ug_walk(p, step, phase, win=0.35, strength=0.5):
    """Elastic cuts: step forward one tile, then snap to the strongest edge within
    +-35% of a tile if it is strong enough, else keep the plain step."""
    n = len(p)
    mean = p.mean()
    w = max(2.0, step * win)
    cuts = [0]
    cur = _ug_first(step, phase) - step
    while True:
        target = cur + step
        if target >= n - 1:
            break
        s0 = int(max(cuts[-1] + 1, target - w))
        s1 = int(min(n - 1, target + w + 1))
        if s1 <= s0:
            break
        i = s0 + int(np.argmax(p[s0:s1]))
        if p[i] > mean * strength:
            cuts.append(i)
            cur = float(i)
        else:
            c = int(round(target))
            if c > cuts[-1]:
                cuts.append(c)
            cur = target
    cuts.append(n)
    return _ug_trim(cuts, step)


def ug_sample(a, cols, rows, area, acut, pick, k=6, qbits=4):
    """One RGBA pixel per cell, read from a k x k point grid over the cell's centre
    area. Grouped vote: colours are grouped coarsely, the biggest group wins and
    its members' real colours are averaged. A cell is solid if at least half of
    its samples are."""
    a = np.asarray(a)
    cols = np.asarray(cols, dtype=np.float64)
    rows = np.asarray(rows, dtype=np.float64)
    W, H = len(cols) - 1, len(rows) - 1
    t = ((np.arange(k) + 0.5) / k) * 2.0 - 1.0
    cx, hx = (cols[:-1] + cols[1:]) / 2.0, (cols[1:] - cols[:-1]) * area / 2.0
    cy, hy = (rows[:-1] + rows[1:]) / 2.0, (rows[1:] - rows[:-1]) * area / 2.0
    xs = np.clip(np.floor(cx[:, None] + t[None, :] * hx[:, None]), 0, a.shape[1] - 1).astype(np.int64)
    ys = np.clip(np.floor(cy[:, None] + t[None, :] * hy[:, None]), 0, a.shape[0] - 1).astype(np.int64)
    n = k * k
    sh = 8 - qbits
    out = np.zeros((H, W, 4), dtype=np.uint8)
    step = max(1, int(3000000 // max(1, W * n * n)))
    for r0 in range(0, H, step):
        r1 = min(H, r0 + step)
        smp = a[ys[r0:r1][:, None, :, None], xs[None, :, None, :]].reshape(r1 - r0, W, n, 4)
        op = smp[..., 3] >= acut
        solid = op.sum(-1) * 2 >= n
        rgb = smp[..., :3].astype(np.float32)
        if pick == "Median":
            masked = np.where(op[..., None], rgb, np.nan)
            with np.errstate(all="ignore"):
                import warnings
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    col = np.nanmedian(masked, axis=2)
            col = np.nan_to_num(col)
        else:
            s8 = smp.astype(np.int32)
            key = ((s8[..., 0] >> sh) << (2 * qbits)) | ((s8[..., 1] >> sh) << qbits) | (s8[..., 2] >> sh)
            key = np.where(op, key, -1)
            counts = (key[..., :, None] == key[..., None, :]).sum(-1)
            counts = np.where(op, counts, -1)
            best = np.argmax(counts, axis=-1)
            win = np.take_along_axis(key, best[..., None], axis=-1)
            sel = (key == win) & op
            col = (rgb * sel[..., None]).sum(2) / np.maximum(sel.sum(-1), 1)[..., None]
        out[r0:r1, :, :3] = np.clip(np.round(col), 0, 255).astype(np.uint8)
        out[r0:r1, :, 3] = np.where(solid, 255, 0)
    out[out[..., 3] == 0, :3] = 0
    return out


def ug_build(prof, size, tw, th, ox, oy, refine):
    """Grid cuts from tile size + offset. -> (cols, rows)."""
    px, py = prof
    W, H = size
    if refine:
        return ug_walk(px, tw, ox), ug_walk(py, th, oy)
    return ug_uniform(W, tw, ox), ug_uniform(H, th, oy)


def ungrid_image(img, acut, area, pick, refine, tile=None, square=True, keep_size=False):
    """PIL image -> (rebuilt PIL image, cols, rows, (tw, th, ox, oy), strength).
    keep_size False: one pixel per block (Mosaic -> Pixels, the image shrinks).
    keep_size True:  every block redrawn as one flat colour in place, same size
                     (Snap Pixels); with refine off the grid is perfectly even. tile None = auto-detect. Raises ValueError if no
                     usable grid is found."""
    a = np.asarray(img.convert("RGBA"))
    prof = ug_profiles(a, acut)
    if tile is None:
        det = ug_detect(prof, square)
        if det is None:
            raise ValueError("no tile grid found")
        tile, conf = det[:4], det[4]
    else:
        conf = ug_confidence(prof, *tile)
    tw, th, ox, oy = tile
    cols, rows = ug_build(prof, img.size, tw, th, ox, oy, refine)
    out = ug_image(a, cols, rows, area, acut, pick, size=img.size if keep_size else None)
    return out, cols, rows, tile, conf


def ug_image(a, cols, rows, area, acut, pick, size=None):
    """One pixel per cell; with size, each cell drawn back flat in place (same size)."""
    if len(cols) < 2 or len(rows) < 2 or (len(cols) - 1) * (len(rows) - 1) > UG_MAX_CELLS:
        raise ValueError("tile size too small for this image")
    out = ug_sample(a, cols, rows, area, acut, pick)
    if size is not None:
        # Snap: every block drawn back flat, in place, at the grid's own cell positions
        W, H = size
        ci = np.clip(np.searchsorted(np.asarray(cols), np.arange(W), side="right") - 1, 0, out.shape[1] - 1)
        ri = np.clip(np.searchsorted(np.asarray(rows), np.arange(H), side="right") - 1, 0, out.shape[0] - 1)
        out = np.ascontiguousarray(out[ri[:, None], ci[None, :]])
    im = Image.fromarray(out, "RGBA")
    return im if (out[..., 3] == 0).any() else im.convert("RGB")
