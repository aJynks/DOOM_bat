"""titlepic - Main window."""
import json
import math
import os
import queue
import sys
import threading
import time
import traceback

import numpy as np
import tkinter as tk
from PIL import Image
from PIL import ImageDraw
from PIL import ImageTk
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk

from .const import (
    CROP_RATIO, DEFAULT_TIDX, DISP_H, IMAGE_EXTS, MODES, MODE_SPRITE, MODE_TITLE, OUT_H, OUT_W,
    PROJECT_EXT)
from .colour import DITHER_MODES, ED_KERNELS, Palette, format_indices, load_palette, parse_indices
from .tweaks import TOOLS, luma
from .imaging import FILTERS, load_source, max_crop, rgba_u8, save_paletted, snap_crop, to_u8
from .ungrid import UG_PICKS
from .steps import has_doom, normal_image, run_step, step_label
from .pipeline import Pipeline, process_folder
from .gui_base import BG, F, FONT, MAX_ZOOM, METRIC_CODE, METRIC_NAME, METRIC_NAMES, S, SMALL, ZOOM_STEPS
from .gui_tweak import TweakWindow
from .gui_export import ExportDialog, export_items
from .gui_steps import GridWindow, ScaleWindow
from .gui_batch import BatchDialog
from . import gui_base


HANDLE = 10   # crop handle size in pixels, set from the DPI in run_gui()


# ======================================================================
#  Main app
# ======================================================================
class App:
    def __init__(self, root, args):
        self.args = args
        self.root = root
        root.geometry(f"{S(1400)}x{S(860)}")
        root.minsize(S(900), S(600))

        self.pipe = Pipeline()
        self.pipe_n = Pipeline()         # Sprite export: the normal-aspect version
        self._n_key = 0
        self.palette = Palette.doom2()
        self.src = None
        self.src_path = None
        self.src_key = 0
        self.crop = None
        self.mode = "preview"
        self.tmp_crop = None
        self.drag = None
        self.outdir = self.args.outdir
        self.project_path = None
        self.tweaks = []
        self.pending = None
        self.tweak_win = None
        self.batch_dlg = None
        self._loading = False
        self.raw_src = None          # the image as loaded
        # one step list per mode: steps, cached result after each, current image,
        # and project steps waiting for an image to be opened
        self._st = {k: {"steps": [], "imgs": [], "cur": None, "pending": False} for k in ("sprite", "title")}
        self.step_win = None         # open Ungrid / Scale window
        self.grid_view = None        # (image, (cols, rows)) while showing an Ungrid grid
        self.grid_disp = None
        self.preview_tag = ""

        self.cv = threading.Condition()
        self.pending_preview = None
        self.pending_save = None
        self.pending_batch = None
        self.gen = 0
        self.results = queue.Queue()
        self.after_id = None
        self.preview_img = None
        self.photo = None
        self.crop_disp = None
        self.zoom = None
        self.pan = [0.0, 0.0]
        self.pan_drag = None

        self._vars()
        self._build()
        self._title()
        threading.Thread(target=self._worker, daemon=True).start()
        root.after(30, self._poll)

        if self.args.project:
            self._load_project(self.args.project)
        if self.args.palette:
            self._load_palette(self.args.palette)
        if self.args.image:
            root.after(50, lambda: self._open(self.args.image))
        else:
            self._redraw()

    def _title(self):
        t = ("titlepic - sprite reducer" if self._sprite()
             else "titlepic - 426x200 Doom title screen reducer")
        if self.project_path:
            t += f"  [{os.path.basename(self.project_path)}]"
        self.root.title(t)

    # ---------------- variables ----------------
    def _vars(self):
        V = self.v = {}
        V["mode"] = tk.StringVar(value=MODE_SPRITE if self.args.sprite else MODE_TITLE)
        V["filter"] = tk.StringVar(value="Lanczos")
        V["linear"] = tk.BooleanVar(value=True)
        V["sharpen"] = tk.IntVar(value=0)
        V["radius"] = tk.DoubleVar(value=0.8)
        V["pal_on"] = tk.BooleanVar(value=False)
        V["metric"] = tk.StringVar(value=METRIC_NAMES[0])
        V["kL"] = tk.DoubleVar(value=1.0)
        V["protect"] = tk.IntVar(value=0)
        V["exclude"] = tk.StringVar(value="")
        V["dither"] = tk.StringVar(value="None")
        V["strength"] = tk.IntVar(value=75)
        V["clamp"] = tk.IntVar(value=96)
        V["serpentine"] = tk.BooleanVar(value=True)
        V["raw"] = tk.BooleanVar(value=False)
        # sprite mode
        V["alpha_thr"] = tk.IntVar(value=50)
        V["tidx"] = tk.IntVar(value=DEFAULT_TIDX)
        # step window defaults (remembered, saved in the project, never trigger renders)
        V["w_link"] = tk.BooleanVar(value=True)
        V["w_doom"] = tk.BooleanVar(value=True)
        V["w_filter"] = tk.StringVar(value="Lanczos")
        V["w_linear"] = tk.BooleanVar(value=True)
        V["w_square"] = tk.BooleanVar(value=True)
        V["w_refine"] = tk.BooleanVar(value=True)
        V["w_area"] = tk.IntVar(value=60)
        V["w_pick"] = tk.StringVar(value=UG_PICKS[0])
        # process folder settings (saved in the project, never trigger renders)
        V["b_in"] = tk.StringVar(value="")
        V["b_out"] = tk.StringVar(value="")
        V["b_tweaks"] = tk.BooleanVar(value=True)
        V["b_sharpen"] = tk.BooleanVar(value=True)
        # export ticks (saved in the project, never trigger renders)
        for k in ("x_doom_pal", "x_doom_tc", "x_pal", "x_tc", "x_t_pal", "x_t_tc", "x_t_tc200"):
            V[k] = tk.BooleanVar(value=True)
        self.defaults = {k: var.get() for k, var in V.items()}
        for k, var in V.items():
            if not k.startswith(("b_", "w_", "x_")):
                var.trace_add("write", lambda *a, k=k: self._changed(k))

    # ---------------- layout ----------------
    def _big_check_style(self, style):
        """Image-based checkbox indicator, so its size follows the DPI."""
        n = S(16)
        imgs = {}
        for name, checked, dis in (("off", False, False), ("on", True, False),
                                   ("doff", False, True), ("don", True, True)):
            im = Image.new("RGBA", (n, n), (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            d.rectangle((0, 0, n - 1, n - 1), fill="#f0f0f0" if dis else "#ffffff",
                        outline="#a0a0a0" if dis else "#404040", width=max(1, n // 12))
            if checked:
                col = "#a0a0a0" if dis else "#1f8a4c"
                d.line([(n * 0.2, n * 0.52), (n * 0.42, n * 0.74), (n * 0.80, n * 0.26)],
                       fill=col, width=max(2, n // 6), joint="curve")
            imgs[name] = ImageTk.PhotoImage(im)
        self._chk_imgs = imgs
        style.element_create("Big.Checkbutton.indicator", "image", imgs["off"],
                             ("disabled", "selected", imgs["don"]),
                             ("disabled", imgs["doff"]),
                             ("selected", imgs["on"]))
        style.layout("Big.TCheckbutton", [
            ("Checkbutton.padding", {"sticky": "nswe", "children": [
                ("Big.Checkbutton.indicator", {"side": "left", "sticky": ""}),
                ("Checkbutton.focus", {"side": "left", "sticky": "w", "children": [
                    ("Checkbutton.label", {"sticky": "nswe"})]})]})])
        style.configure("Big.TCheckbutton", padding=(S(2), S(3)))

    def _build(self):
        root = self.root
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", font=FONT)
        style.configure("TButton", padding=(S(6), S(3)))
        style.configure("Vertical.TScrollbar", arrowsize=S(16), width=S(16))
        style.configure("Horizontal.TScrollbar", arrowsize=S(16), width=S(16))
        style.configure("TCombobox", arrowsize=S(14), padding=S(2))
        style.configure("TSpinbox", arrowsize=S(14), padding=S(2))
        root.option_add("*TCombobox*Listbox.font", FONT)
        self._big_check_style(style)

        bar = ttk.Frame(root, padding=(S(4), S(3)))
        bar.pack(side="top", fill="x")

        def btn(text, cmd):
            b = ttk.Button(bar, text=text, command=cmd)
            b.pack(side="left", padx=S(2))
            return b

        def sep():
            ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=S(6))

        btn("Open...", self._open_dialog)
        self.btn_crop = btn("Crop", self._enter_crop)
        self.btn_mosaic = btn("Mosaic \u2192 Pixels...", lambda: self._open_step(lambda a: GridWindow(a, "mosaic")))
        self.btn_snap = btn("Snap Pixels...", lambda: self._open_step(lambda a: GridWindow(a, "snap")))
        self.btn_scale = btn("Scale...", lambda: self._open_step(ScaleWindow))
        btn("Palette...", self._palette_dialog)
        sep()
        self.btn_export = btn("Export", self._export)
        btn("Process Folder...", self._batch_dialog)
        sep()
        btn("Load Project...", self._load_project_dialog)
        btn("Save Project...", self._save_project_dialog)
        sep()
        btn("Fit", self._zoom_fit)
        self.zoom_label = ttk.Label(bar, text="Zoom: fit", width=14)
        self.zoom_label.pack(side="left", padx=S(4))

        self.cropbar = ttk.Frame(bar)
        ttk.Separator(self.cropbar, orient="vertical").pack(side="left", fill="y", padx=S(6))
        ttk.Button(self.cropbar, text="OK", command=self._crop_ok).pack(side="left", padx=S(2))
        ttk.Button(self.cropbar, text="Cancel", command=self._crop_cancel).pack(side="left", padx=S(2))
        ttk.Button(self.cropbar, text="Max", command=self._crop_max).pack(side="left", padx=S(2))
        self.crop_info = ttk.Label(self.cropbar, text="")
        self.crop_info.pack(side="left", padx=S(8))

        self.status = ttk.Label(root, text="Open an image to start.", anchor="w", padding=(S(6), S(3)))
        self.status.pack(side="bottom", fill="x")

        main = tk.PanedWindow(root, orient="horizontal", sashwidth=S(6), sashrelief="raised",
                              bg="#6a6a6a", bd=0, opaqueresize=True)
        main.pack(side="top", fill="both", expand=True)

        self.canvas = tk.Canvas(main, bg=BG, highlightthickness=0)
        main.add(self.canvas, minsize=S(300), stretch="always")

        side = ttk.Frame(main)
        main.add(side, minsize=S(280), width=S(380), stretch="never")
        self.side = side
        self.opt_canvas = tk.Canvas(side, highlightthickness=0)
        sb = ttk.Scrollbar(side, orient="vertical", command=self.opt_canvas.yview)
        self.opt_canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.opt_canvas.pack(side="left", fill="both", expand=True)
        self.opt = ttk.Frame(self.opt_canvas, padding=S(6))
        self.opt_win = self.opt_canvas.create_window((0, 0), window=self.opt, anchor="nw")
        self.opt.bind("<Configure>", lambda e: self.opt_canvas.configure(
            scrollregion=self.opt_canvas.bbox("all")))
        self.opt_canvas.bind("<Configure>", lambda e: self.opt_canvas.itemconfigure(
            self.opt_win, width=e.width))
        root.bind_all("<MouseWheel>", self._wheel_dispatch)

        self.canvas.bind("<Configure>", lambda e: self._redraw())
        self.canvas.bind("<ButtonPress-1>", self._c_press)
        self.canvas.bind("<B1-Motion>", self._c_drag)
        self.canvas.bind("<ButtonRelease-1>", self._c_release)
        self.canvas.bind("<Motion>", self._c_motion)
        self.canvas.bind("<Double-Button-1>", self._c_double)
        self.canvas.bind("<ButtonPress-2>", self._pan_start)
        self.canvas.bind("<B2-Motion>", self._pan_move)
        self.canvas.bind("<ButtonRelease-2>", self._pan_end)
        root.bind("<Return>", lambda e: self._crop_ok() if self.mode == "crop" else None)
        root.bind("<Escape>", lambda e: self._leave_special())

        self._build_options()

    def _wheel_dispatch(self, e):
        w = self.root.winfo_containing(e.x_root, e.y_root)
        if w is None:
            return
        if w is self.canvas:
            self._c_wheel(e)
            return "break"
        p = w
        while p is not None:
            if p is self.side:
                self._panel_wheel(e)
                return "break"
            p = p.master

    def _panel_wheel(self, e):
        self.opt_canvas.yview_scroll(int(-e.delta / 120), "units")
        return "break"

    def _section(self, title):
        f = ttk.LabelFrame(self.opt, text=title, padding=(S(6), S(4)))
        f.pack(fill="x", pady=S(4))
        f.columnconfigure(1, weight=1)
        f._row = 0
        return f

    def _slider(self, f, label, key, lo, hi, res=1):
        lab = ttk.Label(f, text=label)
        lab.grid(row=f._row, column=0, sticky="sw", padx=(0, S(6)))
        sc = tk.Scale(f, from_=lo, to=hi, resolution=res, orient="horizontal",
                      variable=self.v[key], showvalue=True, highlightthickness=0,
                      length=S(200), sliderlength=S(22), width=S(14), font=SMALL)
        sc.grid(row=f._row, column=1, sticky="ew")
        lab.bind("<Double-Button-1>", lambda e: self.v[key].set(self.defaults[key]))
        f._row += 1
        return sc

    def _combo(self, f, label, key, values):
        ttk.Label(f, text=label).grid(row=f._row, column=0, sticky="w", padx=(0, S(6)), pady=S(2))
        cb = ttk.Combobox(f, textvariable=self.v[key], values=values, state="readonly")
        cb.grid(row=f._row, column=1, sticky="ew", pady=S(2))
        cb.bind("<MouseWheel>", self._panel_wheel)
        f._row += 1
        return cb

    def _check(self, f, label, key):
        cb = ttk.Checkbutton(f, text="  " + label, variable=self.v[key], style="Big.TCheckbutton")
        cb.grid(row=f._row, column=0, columnspan=2, sticky="w", pady=S(2))
        f._row += 1
        return cb

    def _build_options(self):
        f = self._section("Mode")
        self._combo(f, "Mode", "mode", MODES)
        ttk.Label(f, text="Steps").grid(row=f._row, column=0, sticky="nw", padx=(0, S(6)), pady=S(2))
        self.steps_label = ttk.Label(f, text="", foreground="#246", wraplength=S(260))
        self.steps_label.grid(row=f._row, column=1, sticky="w", pady=S(2))
        f._row += 1
        bf = ttk.Frame(f)
        bf.grid(row=f._row, column=0, columnspan=2, sticky="ew", pady=S(2))
        self.btn_undo = ttk.Button(bf, text="Undo step", command=self.undo_step)
        self.btn_undo.pack(side="left", padx=(0, S(4)))
        self.btn_reset = ttk.Button(bf, text="Reset to source", command=self.reset_steps)
        self.btn_reset.pack(side="left")
        f._row += 1
        self.steps_note = ttk.Label(f, text="", foreground="#666", wraplength=S(320), font=SMALL)
        self.steps_note.grid(row=f._row, column=0, columnspan=2, sticky="w", pady=(0, S(4)))
        f._row += 1
        tf = ttk.Frame(f)
        tf.grid(row=f._row, column=0, columnspan=2, sticky="ew")
        tf.columnconfigure(1, weight=1)
        tf._row = 0
        f._row += 1
        self.title_frame = tf
        self._combo(tf, "Filter", "filter", FILTERS)
        self._check(tf, "Linear light (gamma-correct averaging)", "linear")
        ttk.Label(tf, text="Output fixed at 426x200, crop locked to 426:240 "
                           "(16:9 once Doom stretches it by 1.2).",
                  foreground="#666", wraplength=S(320), font=SMALL).grid(
            row=tf._row, column=0, columnspan=2, sticky="w", pady=(S(2), 0))
        tf._row += 1
        sf = ttk.Frame(f)
        sf.grid(row=f._row, column=0, columnspan=2, sticky="ew")
        sf.columnconfigure(1, weight=1)
        sf._row = 0
        f._row += 1
        self.sprite_frame = sf
        self._slider(sf, "Alpha cutoff %", "alpha_thr", 1, 100)
        ttk.Label(sf, text="Transparent index").grid(row=sf._row, column=0, sticky="w",
                                                     padx=(0, S(6)), pady=S(2))
        sp = ttk.Spinbox(sf, textvariable=self.v["tidx"], from_=0, to=255, increment=1, width=6)
        sp.grid(row=sf._row, column=1, sticky="w", pady=S(2))
        sp.bind("<MouseWheel>", self._panel_wheel)
        sf._row += 1
        ttk.Label(sf, text="Source pixels under the alpha cutoff become transparent. The transparent "
                           "index is kept out of palette matching (cyan box on the swatch).",
                  foreground="#666", wraplength=S(320), font=SMALL).grid(
            row=sf._row, column=0, columnspan=2, sticky="w")
        sf._row += 1

        f = self._section("Image tweaks")
        ttk.Button(f, text="Tweak Image...", command=self._tweak_window).grid(
            row=f._row, column=0, columnspan=2, sticky="ew", pady=S(2))
        f._row += 1
        self.tweak_summary = ttk.Label(f, text="", foreground="#246", wraplength=S(320))
        self.tweak_summary.grid(row=f._row, column=0, columnspan=2, sticky="w", pady=S(2))
        f._row += 1

        f = self._section("Sharpen (after downscale)")
        self._slider(f, "Amount", "sharpen", 0, 300)
        self._slider(f, "Radius", "radius", 0.3, 3.0, 0.05)
        ttk.Button(f, text="Reset sharpen", command=self._reset_sharpen).grid(
            row=f._row, column=0, columnspan=2, sticky="ew", pady=(S(4), S(2)))
        f._row += 1

        f = self._section("Palette")
        self._check(f, "Palette match (preview)", "pal_on")
        self.pal_label = ttk.Label(f, text=self.palette.name, foreground="#2a6")
        self.pal_label.grid(row=f._row, column=0, columnspan=2, sticky="w")
        f._row += 1
        bf = ttk.Frame(f)
        bf.grid(row=f._row, column=0, columnspan=2, sticky="ew", pady=S(2))
        ttk.Button(bf, text="Load...", command=self._palette_dialog).pack(side="left", padx=(0, S(4)))
        ttk.Button(bf, text="Doom 2", command=self._palette_doom2).pack(side="left")
        f._row += 1
        self.sw_cell = S(13)
        self.swatch = tk.Canvas(f, width=16 * self.sw_cell + 1, height=16 * self.sw_cell + 1,
                                bg="#000", highlightthickness=0)
        self.swatch.grid(row=f._row, column=0, columnspan=2, pady=S(4))
        self.swatch.bind("<Button-1>", self._swatch_click)
        self.swatch.bind("<Motion>", self._swatch_motion)
        f._row += 1
        ttk.Label(f, text="Exclude").grid(row=f._row, column=0, sticky="w")
        self.ex_entry = ttk.Entry(f, textvariable=self.v["exclude"])
        self.ex_entry.grid(row=f._row, column=1, sticky="ew", pady=S(2))
        f._row += 1
        self.pal_widgets = []
        self.pal_widgets.append(self._combo(f, "Metric", "metric", METRIC_NAMES))
        self.lab_widgets = [self._slider(f, "Lightness wt", "kL", 0.1, 3.0, 0.05),
                            self._slider(f, "Chroma protect", "protect", 0, 300)]
        self.pal_widgets += self.lab_widgets + [self.ex_entry]

        f = self._section("Dither")
        self.pal_widgets.append(self._combo(f, "Method", "dither", DITHER_MODES))
        self.dither_strength = self._slider(f, "Strength", "strength", 0, 100)
        self.dither_clamp = self._slider(f, "Error clamp", "clamp", 4, 255)
        self.dither_serp = self._check(f, "Serpentine scan", "serpentine")
        self.pal_widgets += [self.dither_strength, self.dither_clamp, self.dither_serp]

        f = self._section("Preview")
        self.raw_check = self._check(f, "Raw 426x200 pixels (no 1.2 aspect stretch)", "raw")

        ttk.Label(f, text="Mouse wheel zooms, drag pans, double-click or Fit to fit.",
                  foreground="#666", wraplength=S(320), font=SMALL).grid(
            row=f._row, column=0, columnspan=2, sticky="w")
        f._row += 1

        self._draw_swatch()
        self._update_states()
        self.update_tweak_summary()

    # ---------------- state ----------------
    def _set_state(self, w, on):
        try:
            if isinstance(w, tk.Scale):
                w.configure(state="normal" if on else "disabled", fg="#000" if on else "#999")
            elif isinstance(w, ttk.Combobox):
                w.configure(state="readonly" if on else "disabled")
            else:
                w.state(["!disabled"] if on else ["disabled"])
        except tk.TclError:
            pass

    def _sk(self):
        return "sprite" if self._sprite() else "title"

    @property
    def steps(self):
        return self._st[self._sk()]["steps"]

    @steps.setter
    def steps(self, v):
        self._st[self._sk()]["steps"] = v

    @property
    def step_imgs(self):
        return self._st[self._sk()]["imgs"]

    @step_imgs.setter
    def step_imgs(self, v):
        self._st[self._sk()]["imgs"] = v

    @property
    def cur(self):
        return self._st[self._sk()]["cur"]

    @cur.setter
    def cur(self, v):
        self._st[self._sk()]["cur"] = v

    @property
    def _replay_pending(self):
        return self._st[self._sk()]["pending"]

    @_replay_pending.setter
    def _replay_pending(self, v):
        self._st[self._sk()]["pending"] = v

    def _update_states(self):
        sprite = self._sprite()
        if sprite:
            self.title_frame.grid_remove()
            self.sprite_frame.grid()
            self.raw_check.grid_remove()
        else:
            self.sprite_frame.grid_remove()
            self.title_frame.grid()
            self.raw_check.grid()
        has = self.raw_src is not None
        free = has and self.step_win is None and self.mode == "preview"
        self.btn_crop.state(["!disabled"] if free else ["disabled"])
        for b in (self.btn_mosaic, self.btn_scale):
            b.state(["!disabled"] if free and sprite else ["disabled"])
        self.btn_snap.state(["!disabled"] if free else ["disabled"])
        self.steps_note.configure(text=(
            "Crop, Mosaic \u2192 Pixels..., Snap Pixels... and Scale... on the toolbar each add a step, in any "
            "order. Each step works on the result of the steps before it." if sprite else
            "Snap Pixels... adds a step (Title mode keeps its own step list). The title crop and the "
            "426x200 output work on the result."))
        steps_ok = bool(self.steps) and self.step_win is None and self.mode == "preview"
        self.btn_undo.state(["!disabled"] if steps_ok else ["disabled"])
        self.btn_reset.state(["!disabled"] if steps_ok else ["disabled"])
        on = self.v["pal_on"].get()
        for w in self.pal_widgets:
            self._set_state(w, on)
        if on:
            lab = METRIC_CODE[self.v["metric"].get()] in ("oklab", "cielab")
            for w in self.lab_widgets:
                self._set_state(w, lab)
            d = self.v["dither"].get()
            self._set_state(self.dither_strength, d != "None")
            self._set_state(self.dither_clamp, d in ED_KERNELS)
            self._set_state(self.dither_serp, d in ED_KERNELS)

    def _changed(self, key):
        if key == "mode":
            self._mode_changed()
        if key in ("pal_on", "metric", "dither", "mode"):
            self._update_states()
        if key in ("exclude", "tidx", "mode"):
            self._draw_swatch()
        self.schedule()

    # ---------------- mode / sprite size ----------------
    def _sprite(self):
        return self.v["mode"].get() == MODE_SPRITE

    def _ratio(self):
        return None if self._sprite() else CROP_RATIO

    def _tidx(self):
        try:
            return min(255, max(0, int(self.v["tidx"].get())))
        except (tk.TclError, ValueError):
            return DEFAULT_TIDX

    def _acut(self):
        return max(1, int(round(self.v["alpha_thr"].get() / 100.0 * 255)))

    def _out_sizes(self):
        """-> (tc_size, pl_size), or None with no image."""
        if not self._sprite():
            return (OUT_W, DISP_H), (OUT_W, OUT_H)
        if self.src is None:
            return None
        return tuple(self.src.size), tuple(self.src.size)

    def _mode_changed(self):
        self._title()
        if self._loading:
            return
        if self.mode == "crop":
            self._crop_cancel()
        if self.step_win:
            self.step_win._finish()
        if self.batch_dlg:
            self.batch_dlg.close()
        self._show(reset=True)

    # ---------------- sprite steps ----------------
    def _show(self, img=None, reset=False):
        """Feed the pipeline: Sprite = img (a step preview) or the current image,
        Title = the source with its 426:240 crop."""
        if self.raw_src is None:
            self._update_steps_label()
            self._redraw()
            return
        if self._sprite():
            img = img if img is not None else self.cur
            crop = (0.0, 0.0, float(img.width), float(img.height))
        else:
            img = img if img is not None else self.cur
            keep = (not reset and self.crop is not None and self.src is not None
                    and self.src.size == img.size)
            crop = self.crop if keep else max_crop(img.width, img.height, CROP_RATIO)
        if reset or self.src is None:
            self.preview_img = None          # new image / mode: back to Fit
            self.zoom = None
            self.pan = [0.0, 0.0]
        elif self.src.size != img.size:
            # same zoom, same part of the image: scale the pan offset with the image
            ow, oh = self.src.size
            self.pan = [self.pan[0] * img.width / ow, self.pan[1] * img.height / oh]
        self.src = img
        self.crop = crop
        self.src_key += 1
        self.crop_disp = None
        self._update_steps_label()
        self.status.configure(text=self._src_text())
        self._redraw()
        self.schedule(10)

    def _update_steps_label(self):
        if self._replay_pending and self.steps:
            txt = "From project, applied when an image is opened: " + \
                  " \u2192 ".join(step_label(st) for st in self.steps)
        elif self.steps:
            txt = " \u2192 ".join(step_label(st) for st in self.steps)
        else:
            txt = "none (the source as loaded)"
        self.steps_label.configure(text=txt)
        if self.batch_dlg:
            self.batch_dlg.refresh_note()

    def _open_step(self, cls):
        if self.raw_src is None:
            return
        if self.step_win:
            self.step_win.top.lift()
            return
        if self.mode == "crop":
            self._crop_cancel()
        self.step_win = cls(self)
        self._update_states()

    def add_step(self, step, img):
        self.steps.append(step)
        self.step_imgs.append(img)
        self.cur = img
        self._show()
        self._update_states()
        self.status.configure(text=self._src_text() + f"  |  added {step_label(step)}")

    def undo_step(self):
        if not self.steps or self.step_win:
            return
        st = self.steps.pop()
        self.step_imgs.pop()
        self.cur = self.step_imgs[-1] if self.step_imgs else self.raw_src
        self._show()
        self._update_states()
        self.status.configure(text=self._src_text() + f"  |  undid {step_label(st)}")

    def reset_steps(self):
        if not self.steps or self.step_win:
            return
        if not messagebox.askyesno("titlepic", "Remove all steps and go back to the source image?"):
            return
        self.steps, self.step_imgs = [], []
        self.cur = self.raw_src
        self._show()
        self._update_states()

    def _replay(self, steps, key=None):
        """Run a step list on the source for one mode (project load / open). -> notes."""
        st = self._st[key or self._sk()]
        acut = self._acut()
        img = self.raw_src
        st["steps"], st["imgs"], notes = [], [], []
        for s in steps:
            try:
                out, note, done = run_step(img, s, acut)
            except Exception as e:
                notes.append(f"{s.get('op', '?')} failed: {e}")
                continue
            if out is None:
                notes.append(note)
                continue
            st["steps"].append(done)
            st["imgs"].append(out)
            img = out
        st["cur"] = img
        return notes

    def show_step_preview(self, img, grid=None):
        """Called by the step windows: show a pending result, or a grid over an image."""
        self.grid_view = grid
        if grid:
            self.mode = "grid"
            self._redraw()
            return
        if self.mode == "grid":
            self.mode = "preview"
        self._show(img)

    def clear_step_preview(self):
        self.grid_view = None
        if self.mode == "grid":
            self.mode = "preview"
        self._show()
        self._update_states()

    def _leave_special(self):
        if self.mode == "crop":
            self._crop_cancel()
        elif self.mode == "grid":
            if isinstance(self.step_win, GridWindow):
                self.step_win.v["view"].set("Result")
            else:
                self.mode = "preview"
                self._redraw()

    def _draw_grid(self, cw, ch):
        c = self.canvas
        img, (cols, rows) = self.grid_view
        sw, sh = img.size
        pad = S(16)
        sc = max(0.01, min((cw - pad * 2) / sw, (ch - pad * 2) / sh))
        dw, dh = max(1, int(sw * sc)), max(1, int(sh * sc))
        ox, oy = (cw - dw) // 2, (ch - dh) // 2
        key = (id(img), dw, dh)
        if self.grid_disp is None or self.grid_disp[0] != key:
            im = img.resize((dw, dh), Image.Resampling.LANCZOS if sc < 1 else Image.Resampling.NEAREST)
            if im.mode == "RGBA":
                im = self._on_checker(im)
            self.grid_disp = (key, ImageTk.PhotoImage(im))
        c.create_image(ox, oy, image=self.grid_disp[1], anchor="nw")
        for x in cols:
            X = ox + x * sc
            c.create_line(X, oy, X, oy + dh, fill="#ff00ff")
        for y in rows:
            Y = oy + y * sc
            c.create_line(ox, Y, ox + dw, Y, fill="#ff00ff")
        c.create_text(S(8), S(8), anchor="nw", fill="#ff80ff", font=("Segoe UI", F(10)),
                      text=f"Grid view: {len(cols) - 1} x {len(rows) - 1} tiles   "
                           f"(View: Result or Esc shows the rebuilt image)")

    def _reset_sharpen(self):
        for k in ("sharpen", "radius"):
            self.v[k].set(self.defaults[k])

    def update_tweak_summary(self):
        n = len(self.tweaks)
        if n == 0:
            txt = "No tweaks applied."
        else:
            txt = f"{n} tweak{'s' if n != 1 else ''}: " + " \u2192 ".join(op["tool"] for op in self.tweaks)
        self.tweak_summary.configure(text=txt)

    def set_pending(self, op):
        self.pending = op
        self.schedule(60)

    def _excluded(self):
        try:
            return parse_indices(self.v["exclude"].get())
        except ValueError:
            return set()

    def _params(self, committed=False):
        V = self.v
        if self.tweak_win and not committed:
            tweaks, pending = [dict(op) for op in self.tweak_win.ops], self.pending
        else:
            tweaks, pending = [dict(op) for op in self.tweaks], None
        sizes = self._out_sizes()
        sprite = self._sprite()
        tidx = self._tidx() if sprite else None
        excluded = self._excluded()
        if sprite:
            excluded = excluded | {tidx}
        return {
            "mode": MODE_SPRITE if sprite else MODE_TITLE,
            "tc_size": sizes[0] if sizes else None,
            "pl_size": sizes[1] if sizes else None,
            "alpha_thr": V["alpha_thr"].get() / 100.0,
            "tidx": tidx,
            "steps": [dict(st) for st in self.steps],
            "has_doom": sprite and has_doom(self.steps),
            "export": {k: V[k].get() for k in V if k.startswith("x_")},
            "crop": (None if sprite else (tuple(round(c, 3) for c in self.crop) if self.crop else None)),
            "filter": V["filter"].get(),
            "linear": V["linear"].get(),
            "tweaks": tweaks,
            "pending": pending,
            "sharpen": V["sharpen"].get(),
            "radius": round(V["radius"].get(), 3),
            "pal_on": V["pal_on"].get(),
            "palette": self.palette,
            "excluded": frozenset(excluded),
            "metric": METRIC_CODE[V["metric"].get()],
            "kL": round(V["kL"].get(), 3),
            "protect": V["protect"].get() / 100.0,
            "dither": V["dither"].get(),
            "strength": V["strength"].get(),
            "clamp": V["clamp"].get(),
            "serpentine": V["serpentine"].get(),
            "raw": V["raw"].get(),
            "src": (self.src_key, self.src),
            "want_hist": bool(self.tweak_win and self.tweak_win.want_hist()),
        }

    # ---------------- worker ----------------
    def schedule(self, delay=120):
        if self.src is None or self.crop is None or self._out_sizes() is None:
            return
        if self.after_id:
            self.root.after_cancel(self.after_id)
        self.after_id = self.root.after(delay, self._submit)

    def _submit(self):
        self.after_id = None
        self.gen += 1
        with self.cv:
            self.pending_preview = {"gen": self.gen, "params": self._params()}
            self.cv.notify()
        self.status.configure(text=self.status.cget("text").split("  |  ")[0] + "  |  rendering...")

    def _worker(self):
        while True:
            with self.cv:
                while self.pending_preview is None and self.pending_save is None and self.pending_batch is None:
                    self.cv.wait()
                if self.pending_save is not None:
                    req, kind = self.pending_save, "save"
                    self.pending_save = None
                elif self.pending_batch is not None:
                    req, kind = self.pending_batch, "batch"
                    self.pending_batch = None
                else:
                    req, kind = self.pending_preview, "preview"
                    self.pending_preview = None
            try:
                if kind == "batch":
                    self._do_batch(req)
                    continue
                p = req["params"]
                self.pipe.set_source(*p["src"])
                if kind == "preview":
                    self._do_preview(req)
                else:
                    self._do_save(req)
            except Exception:
                self.results.put(("error", traceback.format_exc()))

    def _do_preview(self, req):
        p = req["params"]
        t0 = time.perf_counter()
        cancel = lambda: self.pending_preview is not None  # noqa: E731
        sprite = p["mode"] == MODE_SPRITE
        hist = None
        if p["want_hist"]:
            _, (btc, _, bm) = self.pipe.base(p)
            px = btc[bm] if bm is not None and bm.any() else btc.reshape(-1, 3)
            u = to_u8(px)
            hist = [np.bincount(to_u8(luma(px)).ravel(), minlength=256)] + \
                   [np.bincount(u[..., c].ravel(), minlength=256) for c in range(3)]
        _, (tc, pl, m) = self.pipe.adjusted(p)
        if p["pal_on"]:
            idx = self.pipe.paletted(p, cancel)
            if idx is None:
                return
            rgb = p["palette"].rgb[idx]
            if m is not None:
                im = Image.fromarray(np.dstack([rgb, np.where(m, 255, 0).astype(np.uint8)]), "RGBA")
                used = idx[m]
            else:
                im = Image.fromarray(rgb, "RGB")
                used = idx
            info = f"paletted, {len(np.unique(used)) if used.size else 0} colours"
            if not sprite and not p["raw"]:
                im = im.resize((OUT_W, DISP_H), Image.Resampling.NEAREST)
        elif sprite:
            im = Image.fromarray(rgba_u8(pl, m), "RGBA")
            info = "true colour"
        else:
            im = Image.fromarray(to_u8(pl if p["raw"] else tc), "RGB")
            info = "true colour"
        tag = ""
        if sprite:
            w, h = p["pl_size"]
            info = f"{w}x{h} {info}" + ("" if m.all() else f", {int((~m).sum())} transparent px")
        dt = (time.perf_counter() - t0) * 1000.0
        self.results.put(("preview", req["gen"], im, f"{info}  |  {dt:.0f} ms", hist, tag))

    def _do_save(self, req):
        p = req["params"]
        jobs = req["jobs"]                  # kind -> path
        _, (tc, pl, m) = self.pipe.adjusted(p)
        if p["mode"] == MODE_SPRITE:
            tidx = p["tidx"]
            if p["has_doom"]:
                if "doom_pal" in jobs:
                    save_paletted(self.pipe.paletted(p, None), p["palette"], jobs["doom_pal"],
                                  None if m.all() else tidx)
                if "doom_tc" in jobs:
                    Image.fromarray(rgba_u8(pl, m), "RGBA").save(jobs["doom_tc"], optimize=True)
                if "pal" in jobs or "tc" in jobs:
                    nimg = normal_image(req["raw"], p["steps"], req["acut"])
                    self._n_key += 1
                    self.pipe_n.set_source(("normal", self._n_key), nimg)
                    p2 = dict(p, pl_size=tuple(nimg.size), tc_size=tuple(nimg.size))
                    _, (_, npl, nm) = self.pipe_n.adjusted(p2)
                    if "pal" in jobs:
                        save_paletted(self.pipe_n.paletted(p2, None), p["palette"], jobs["pal"],
                                      None if nm.all() else tidx)
                    if "tc" in jobs:
                        Image.fromarray(rgba_u8(npl, nm), "RGBA").save(jobs["tc"], optimize=True)
            else:
                if "pal" in jobs:
                    save_paletted(self.pipe.paletted(p, None), p["palette"], jobs["pal"],
                                  None if m.all() else tidx)
                if "tc" in jobs:
                    Image.fromarray(rgba_u8(pl, m), "RGBA").save(jobs["tc"], optimize=True)
        else:
            if "t_pal" in jobs:
                save_paletted(self.pipe.paletted(p, None), p["palette"], jobs["t_pal"])
            if "t_tc" in jobs:
                Image.fromarray(to_u8(tc), "RGB").save(jobs["t_tc"], optimize=True)
            if "t_tc200" in jobs:
                Image.fromarray(to_u8(pl), "RGB").save(jobs["t_tc200"], optimize=True)
        self.results.put(("saved",) + tuple(jobs.values()))

    def _do_batch(self, req):
        p = req["params"]
        _, matcher = self.pipe.matcher(p)
        res = process_folder(p, matcher, req["indir"], req["outdir"], req["tweaks"], req["sharpen"],
                             progress=lambda n, t, name: self.results.put(
                                 ("batch_progress", n, t, name)))
        self.results.put(("batch_done", req["indir"], req["outdir"]) + res)

    def _poll(self):
        try:
            while True:
                msg = self.results.get_nowait()
                kind = msg[0]
                if kind == "preview":
                    _, gen, im, info, hist, tag = msg
                    if gen == self.gen:
                        self.preview_img = im
                        self.preview_tag = tag
                        self.status.configure(text=self._src_text() + "  |  " + info)
                        if self.mode == "preview":
                            self._redraw()
                        if hist is not None and self.tweak_win:
                            self.tweak_win.set_hist(hist)
                elif kind == "saved":
                    self.root.configure(cursor="")
                    self.btn_export.state(["!disabled"])
                    self.status.configure(text="Exported " + ", ".join(os.path.basename(q) for q in msg[1:])
                                               + f"  ->  {os.path.dirname(msg[1])}")
                elif kind == "batch_progress":
                    if self.batch_dlg:
                        self.batch_dlg.progress(*msg[1:])
                elif kind == "batch_done":
                    if self.batch_dlg:
                        self.batch_dlg.done()
                    self._batch_report(*msg[1:])
                elif kind == "error":
                    self.root.configure(cursor="")
                    self.btn_export.state(["!disabled"])
                    if self.batch_dlg:
                        self.batch_dlg.done()
                    print(msg[1], file=sys.stderr)
                    messagebox.showerror("titlepic", msg[1].strip().splitlines()[-1])
        except queue.Empty:
            pass
        self.root.after(30, self._poll)

    def _src_text(self):
        if self.src is None or self.raw_src is None:
            return ""
        raw = self.raw_src
        t = (f"{os.path.basename(self.src_path)} {raw.width}x{raw.height}"
             + (" (alpha)" if raw.mode == "RGBA" else ""))
        if self._sprite():
            if self.steps:
                t += f"  |  {len(self.steps)} step{'s' if len(self.steps) != 1 else ''} -> " \
                     f"{self.cur.width}x{self.cur.height}"
            if self.src is not self.cur:
                t += f"  |  previewing {self.src.width}x{self.src.height}"
            return t
        if self.steps:
            t += f"  |  {len(self.steps)} step{'s' if len(self.steps) != 1 else ''}"
        x0, y0, x1, y1 = self.crop
        t += f"  |  crop {x1 - x0:.0f}x{y1 - y0:.0f}"
        if (y1 - y0) < DISP_H - 0.5:
            t += " (UPSCALING)"
        return t

    # ---------------- file ops ----------------
    def _open_dialog(self):
        path = filedialog.askopenfilename(
            title="Open source image",
            filetypes=[("Images", " ".join("*" + e for e in IMAGE_EXTS)), ("All files", "*.*")])
        if path:
            self._open(path)

    def _open(self, path):
        try:
            img = load_source(path)
        except Exception as e:
            messagebox.showerror("titlepic", f"Could not open image:\n{e}")
            return
        if self.mode == "crop":
            self._crop_cancel()
        if self.step_win:
            self.step_win._finish()
        self.raw_src = img
        self.src = None
        self.src_path = os.path.abspath(path)
        self.preview_img = None
        notes = []
        for key, st in self._st.items():
            st["cur"] = img
            if st["pending"]:
                st["pending"] = False
                notes += self._replay(st["steps"], key)
            else:
                st["steps"], st["imgs"] = [], []
        self._show(reset=True)
        self._update_states()
        if notes:
            self.status.configure(text=self._src_text() + "  |  " + "; ".join(notes))

    def _palette_dialog(self):
        path = filedialog.askopenfilename(
            title="Load palette",
            filetypes=[("Palettes", "*.png *.wad *.pal *.lmp *.gpl *.act *.bmp *.gif"), ("All files", "*.*")])
        if path:
            self._load_palette(path)

    def _load_palette(self, path):
        try:
            self.palette = load_palette(path)
        except Exception as e:
            messagebox.showerror("titlepic", f"Could not load palette:\n{e}")
            return
        self._palette_changed()

    def _palette_doom2(self):
        self.palette = Palette.doom2()
        self._palette_changed()

    def _palette_changed(self):
        self.pal_label.configure(text=self.palette.name)
        self._draw_swatch()
        self.schedule()

    def _export(self):
        if self.src is None:
            return
        if self.mode == "crop":
            self._crop_ok()
        if self.step_win:
            messagebox.showerror("titlepic", "Apply or close the open step window first.")
            return
        ExportDialog(self)

    def start_export(self, jobs):
        self.root.configure(cursor="watch")
        self.btn_export.state(["disabled"])
        self.status.configure(text="Exporting...")
        p = self._params(committed=True)     # unapplied tweak-window changes are not exported
        with self.cv:
            self.pending_save = {"params": p, "jobs": jobs, "raw": self.raw_src, "acut": self._acut()}
            self.cv.notify()

    # ---------------- process folder ----------------
    def _batch_dialog(self):
        if self.batch_dlg:
            self.batch_dlg.top.lift()
            return
        self.batch_dlg = BatchDialog(self)

    def start_batch(self, indir, outdir, parent=None):
        p = self._params(committed=True)
        items = export_items(self._sprite(), p["has_doom"])
        if not any(self.v[key].get() for _, key, _, _ in items):
            messagebox.showerror("Process Folder", "Nothing is ticked in the Export dialog.", parent=parent)
            return False
        with self.cv:
            self.pending_batch = {"params": p, "indir": indir, "outdir": outdir,
                                  "tweaks": self.v["b_tweaks"].get(),
                                  "sharpen": self.v["b_sharpen"].get()}
            self.cv.notify()
        return True

    def _batch_report(self, indir, outdir, processed, skipped, errors):
        lines = [f"Input:   {indir}", f"Output:  {outdir}", "",
                 f"Processed: {len(processed)}"]
        lines += [f"   {x}" for x in processed if "   (" in x]
        if skipped:
            lines += ["", f"Skipped (not 426x200 or 426x240): {len(skipped)}"]
            lines += [f"   {name}   ({w}x{h})" for name, (w, h) in skipped]
        if errors:
            lines += ["", f"Errors: {len(errors)}"]
            lines += [f"   {name}   {msg}" for name, msg in errors]
        if not processed and not skipped and not errors:
            lines += ["", "No images found."]
        text = "\n".join(lines)
        print("\n[titlepic] Process Folder report\n" + text + "\n")
        top = tk.Toplevel(self.root)
        top.title("Process Folder - report")
        top.transient(self.root)
        frm = ttk.Frame(top, padding=S(8))
        frm.pack(fill="both", expand=True)
        t = tk.Text(frm, width=80, height=min(30, len(lines) + 2), font=("Consolas", F(10)), wrap="none")
        sb = ttk.Scrollbar(frm, orient="vertical", command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(side="left", fill="both", expand=True)
        t.insert("1.0", text)
        t.configure(state="disabled")
        ttk.Button(top, text="Close", command=top.destroy).pack(pady=(0, S(8)))

    # ---------------- projects ----------------
    def _project_dict(self):
        V = self.v
        settings = {k: V[k].get() for k in V if not k.startswith("b_")}
        settings["metric"] = METRIC_CODE[V["metric"].get()]
        return {
            "titlepic_project": 1,
            "settings": settings,
            "tweaks": self.tweaks,
            "palette": {"name": self.palette.name, "rgb": self.palette.rgb.tobytes().hex()},
            "process_folder": {k[2:]: V[k].get() for k in V if k.startswith("b_")},
            "steps": self._st["sprite"]["steps"],
            "title_steps": self._st["title"]["steps"],
        }

    def _save_project_dialog(self):
        init = self.project_path or (os.path.splitext(self.src_path)[0] + PROJECT_EXT if self.src_path else None)
        path = filedialog.asksaveasfilename(
            title="Save project", defaultextension=PROJECT_EXT,
            initialdir=os.path.dirname(init) if init else None,
            initialfile=os.path.basename(init) if init else None,
            filetypes=[("titlepic project", "*" + PROJECT_EXT), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(self._project_dict(), fh, indent=2)
        except Exception as e:
            messagebox.showerror("titlepic", f"Could not save project:\n{e}")
            return
        self.project_path = os.path.abspath(path)
        self._title()
        self.status.configure(text=f"Project saved: {path}")

    def _load_project_dialog(self):
        path = filedialog.askopenfilename(
            title="Load project",
            filetypes=[("titlepic project", "*" + PROJECT_EXT), ("All files", "*.*")])
        if path:
            self._load_project(path)

    def _load_project(self, path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if "titlepic_project" not in data:
                raise ValueError("not a titlepic project file")
        except Exception as e:
            messagebox.showerror("titlepic", f"Could not load project:\n{e}")
            return
        V = self.v
        settings = data.get("settings", {})
        self._loading = True
        try:
            V["mode"].set(settings.get("mode") if settings.get("mode") in MODES else MODE_TITLE)
            for k, val in settings.items():
                if k == "mode":
                    continue
                if k == "metric":
                    val = METRIC_NAME.get(val, METRIC_NAMES[0])
                if k in V and not k.startswith("b_"):
                    try:
                        V[k].set(val)
                    except tk.TclError:
                        pass
        finally:
            self._loading = False
        lists = {"sprite": [st for st in data.get("steps", []) if isinstance(st, dict)
                            and st.get("op") in ("crop", "ungrid", "snap", "scale")],
                 "title": [st for st in data.get("title_steps", []) if isinstance(st, dict)
                           and st.get("op") == "snap"]}
        if self.mode == "crop":
            self._crop_cancel()
        if self.step_win:
            self.step_win._finish()
        notes = []
        for key, steps in lists.items():
            st = self._st[key]
            if self.raw_src is not None:
                notes += self._replay(steps, key)
                st["pending"] = False
            else:
                st["steps"], st["imgs"], st["pending"] = steps, [], bool(steps)
        if self.raw_src is not None:
            self._show(reset=True)
        else:
            self._update_steps_label()
        for k, val in data.get("process_folder", {}).items():
            if "b_" + k in V:
                try:
                    V["b_" + k].set(val)
                except tk.TclError:
                    pass
        pal = data.get("palette")
        if pal and pal.get("rgb"):
            try:
                self.palette = Palette(np.frombuffer(bytes.fromhex(pal["rgb"]), dtype=np.uint8)[:768],
                                       pal.get("name", "project palette"))
            except Exception:
                self.palette = Palette.doom2()
        self.tweaks = [op for op in data.get("tweaks", []) if op.get("tool") in TOOLS]
        if self.tweak_win:                    # an open session is replaced by the project's look
            self.tweak_win._finish()
        self.pending = None
        self.update_tweak_summary()
        self.project_path = os.path.abspath(path)
        self._title()
        self._palette_changed()
        self._update_states()
        self.status.configure(text=f"Project loaded: {path}" + ("  |  " + "; ".join(notes) if notes else ""))

    # ---------------- tweak window ----------------
    def _tweak_window(self):
        if self.tweak_win:
            self.tweak_win.top.lift()
            return
        self.tweak_win = TweakWindow(self)

    # ---------------- swatch ----------------
    def _draw_swatch(self):
        c = self.swatch
        c.delete("all")
        ex = self._excluded()
        tidx = self._tidx() if self._sprite() else None
        s = self.sw_cell
        for i in range(256):
            x, y = (i % 16) * s, (i // 16) * s
            r, g, b = self.palette.rgb[i]
            c.create_rectangle(x, y, x + s, y + s, fill=f"#{r:02x}{g:02x}{b:02x}", outline="#000")
            if i == tidx:
                c.create_rectangle(x + 1, y + 1, x + s - 1, y + s - 1, outline="#0ff", width=max(2, s // 5))
            elif i in ex:
                c.create_line(x + 1, y + 1, x + s - 1, y + s - 1, fill="#f0f", width=max(1, s // 6))
                c.create_line(x + s - 1, y + 1, x + 1, y + s - 1, fill="#f0f", width=max(1, s // 6))

    def _swatch_index(self, e):
        gx, gy = e.x // self.sw_cell, e.y // self.sw_cell
        if 0 <= gx < 16 and 0 <= gy < 16:
            return gy * 16 + gx
        return None

    def _swatch_click(self, e):
        if not self.v["pal_on"].get():
            return
        i = self._swatch_index(e)
        if i is None:
            return
        ex = self._excluded()
        ex ^= {i}
        self.v["exclude"].set(format_indices(ex))

    def _swatch_motion(self, e):
        i = self._swatch_index(e)
        if i is not None:
            r, g, b = self.palette.rgb[i]
            tag = ""
            if self._sprite() and i == self._tidx():
                tag = "  [transparent]"
            elif i in self._excluded():
                tag = "  [excluded]"
            self.status.configure(text=f"index {i}: ({r}, {g}, {b})" + tag)

    # ---------------- canvas drawing ----------------
    def _redraw(self):
        c = self.canvas
        c.delete("all")
        cw, ch = max(1, c.winfo_width()), max(1, c.winfo_height())
        if self.src is None:
            c.create_text(cw // 2, ch // 2, text="Open an image  (any size)", fill="#888",
                          font=("Segoe UI", F(14)))
            return
        if self.mode == "crop":
            self._draw_crop(cw, ch)
            return
        if self.mode == "grid":
            self._draw_grid(cw, ch)
            return
        im = self.preview_img
        if im is None:
            c.create_text(cw // 2, ch // 2, text="rendering...", fill="#888", font=("Segoe UI", F(12)))
            return
        k = self._zoom_k()
        w, h = im.width * k, im.height * k
        self._clamp_pan(w, h, cw, ch)
        X0 = cw / 2 + self.pan[0] - w / 2
        Y0 = ch / 2 + self.pan[1] - h / 2
        if k >= 1:
            u0 = max(0, int(math.floor(-X0 / k)))
            v0 = max(0, int(math.floor(-Y0 / k)))
            u1 = min(im.width, int(math.ceil((cw - X0) / k)))
            v1 = min(im.height, int(math.ceil((ch - Y0) / k)))
            if u1 <= u0 or v1 <= v0:
                return
            part = im.crop((u0, v0, u1, v1)).resize(((u1 - u0) * k, (v1 - v0) * k),
                                                    Image.Resampling.NEAREST)
            px, py = X0 + u0 * k, Y0 + v0 * k
        else:
            part = im.resize((max(1, int(w)), max(1, int(h))), Image.Resampling.NEAREST)
            px, py = X0, Y0
        if part.mode == "RGBA":
            part = self._on_checker(part)
        self.photo = ImageTk.PhotoImage(part)
        c.create_image(int(round(px)), int(round(py)), image=self.photo, anchor="nw")
        c.create_rectangle(int(X0) - 1, int(Y0) - 1, int(X0 + w), int(Y0 + h), outline="#444")
        if self.preview_tag:
            c.create_text(S(8), S(8), anchor="nw", fill="#ffd000", font=("Segoe UI", F(10)),
                          text=self.preview_tag)
        self.zoom_label.configure(text=f"Zoom: {k}x" if self.zoom else
                                  (f"Zoom: fit ({k}x)" if k >= 1 else "Zoom: fit"))

    def _on_checker(self, im):
        n = S(8)
        w, h = im.size
        yy, xx = np.mgrid[0:h, 0:w]
        chk = ((xx // n + yy // n) & 1).astype(bool)
        bg = np.where(chk[..., None], np.uint8(102), np.uint8(70))
        bg = np.repeat(bg, 3, axis=2).astype(np.uint8)
        base = Image.fromarray(bg, "RGB").convert("RGBA")
        return Image.alpha_composite(base, im).convert("RGB")

    # ---------------- zoom / pan ----------------
    def _fit_k(self):
        im = self.preview_img
        cw, ch = max(1, self.canvas.winfo_width()), max(1, self.canvas.winfo_height())
        k = min(cw / im.width, ch / im.height)
        return max(1, int(k)) if k >= 1 else k

    def _zoom_k(self):
        return self.zoom if self.zoom else self._fit_k()

    def _clamp_pan(self, w, h, cw, ch):
        mx = max(0.0, (w - cw) / 2)
        my = max(0.0, (h - ch) / 2)
        self.pan[0] = min(max(self.pan[0], -mx), mx)
        self.pan[1] = min(max(self.pan[1], -my), my)

    def _zoom_fit(self):
        self.zoom = None
        self.pan = [0.0, 0.0]
        self._redraw()

    def _zoom_step(self, e, up, steps=1):
        if self.preview_img is None:
            return
        old = self._zoom_k()
        if up:
            cap = max(MAX_ZOOM, int(old))          # tiny sprites can fit above MAX_ZOOM
            new = min(cap, int(old) + steps if old >= 1 else 1)
        else:
            new = int(old) - steps if old >= 1 else old
            if new < 1:
                return self._zoom_fit()
        if new == old:
            return
        cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
        ux = (e.x - cw / 2 - self.pan[0]) / old
        uy = (e.y - ch / 2 - self.pan[1]) / old
        self.zoom = new
        self.pan = [e.x - cw / 2 - ux * new, e.y - ch / 2 - uy * new]
        self._redraw()

    def _c_double(self, e):
        if self.mode == "preview":
            self._zoom_fit()

    def _pan_start(self, e):
        if self.mode == "preview" and self.preview_img is not None:
            self.pan_drag = (e.x, e.y, self.pan[0], self.pan[1])
            self.canvas.configure(cursor="fleur")

    def _pan_move(self, e):
        if self.pan_drag:
            sx, sy, px, py = self.pan_drag
            self.pan = [px + e.x - sx, py + e.y - sy]
            self._redraw()

    def _pan_end(self, e):
        self.pan_drag = None
        if self.mode == "preview":
            self.canvas.configure(cursor="")

    # ---------------- crop mode ----------------
    def _crop_geom(self, cw, ch):
        sw, sh = self.src.size
        pad = S(16)
        s = min((cw - pad * 2) / sw, (ch - pad * 2) / sh)
        s = max(s, 0.01)
        dw, dh = int(sw * s), int(sh * s)
        ox, oy = (cw - dw) // 2, (ch - dh) // 2
        return s, ox, oy, dw, dh

    def _draw_crop(self, cw, ch):
        c = self.canvas
        s, ox, oy, dw, dh = self._crop_geom(cw, ch)
        if self.crop_disp is None or self.crop_disp[0] != (dw, dh):
            resample_f = Image.Resampling.LANCZOS if s < 1 else Image.Resampling.NEAREST
            dim = self.src.resize((max(1, dw), max(1, dh)), resample_f, reducing_gap=3.0 if s < 1 else None)
            self.crop_disp = ((dw, dh), ImageTk.PhotoImage(dim))
        c.create_image(ox, oy, image=self.crop_disp[1], anchor="nw")
        x0, y0, x1, y1 = self.tmp_crop
        X0, Y0, X1, Y1 = ox + x0 * s, oy + y0 * s, ox + x1 * s, oy + y1 * s
        for r in ((ox, oy, ox + dw, Y0), (ox, Y1, ox + dw, oy + dh), (ox, Y0, X0, Y1), (X1, Y0, ox + dw, Y1)):
            if r[2] > r[0] and r[3] > r[1]:
                c.create_rectangle(*r, fill="#000", stipple="gray50", outline="")
        for i in (1, 2):
            xx = X0 + (X1 - X0) * i / 3
            yy = Y0 + (Y1 - Y0) * i / 3
            c.create_line(xx, Y0, xx, Y1, fill="#ffffff", dash=(3, 4))
            c.create_line(X0, yy, X1, yy, fill="#ffffff", dash=(3, 4))
        c.create_rectangle(X0, Y0, X1, Y1, outline="#ffd000", width=S(2))
        Xm, Ym = (X0 + X1) / 2, (Y0 + Y1) / 2
        for hx, hy in ((X0, Y0), (X1, Y0), (X0, Y1), (X1, Y1)):
            c.create_rectangle(hx - HANDLE / 2, hy - HANDLE / 2, hx + HANDLE / 2, hy + HANDLE / 2,
                               fill="#ffd000", outline="#000")
        e = HANDLE * 0.4                      # smaller handles mid-edge
        for hx, hy in ((Xm, Y0), (Xm, Y1), (X0, Ym), (X1, Ym)):
            c.create_rectangle(hx - e, hy - e, hx + e, hy + e, fill="#ffd000", outline="#000")
        w, h = x1 - x0, y1 - y0
        if self._sprite():
            txt = f"{w:.0f}x{h:.0f} at ({x0:.0f}, {y0:.0f})   (OK adds a Crop step)"
        else:
            txt = f"{w:.0f}x{h:.0f} at ({x0:.0f}, {y0:.0f})  ->  {OUT_W}x{OUT_H}  ({DISP_H / h:.3f}x)"
            if h < DISP_H:
                txt += "   UPSCALING"
        self.crop_info.configure(text=txt)

    def _enter_crop(self):
        if self.src is None or self.mode != "preview" or self.step_win:
            return
        self.mode = "crop"
        self.tmp_crop = self.crop
        self.cropbar.pack(side="left")
        self.btn_crop.state(["disabled"])
        self._redraw()

    def _leave_crop(self):
        self.mode = "preview"
        self.cropbar.pack_forget()
        self.btn_crop.state(["!disabled"])
        self.canvas.configure(cursor="")
        self._redraw()

    def _crop_ok(self):
        if self.mode != "crop":
            return
        if self._sprite():
            box = tuple(int(v) for v in snap_crop(self.tmp_crop, *self.cur.size))
            self._leave_crop()
            if box == (0, 0, self.cur.width, self.cur.height):
                return                                  # whole image: nothing to add
            img = self.cur.crop(box)
            self.add_step({"op": "crop", "box": list(box), "in_size": list(self.cur.size),
                           "out_size": list(img.size)}, img)
            return
        self.crop = self.tmp_crop
        self._leave_crop()
        self.status.configure(text=self._src_text())
        self.schedule(10)

    def _crop_cancel(self):
        if self.mode != "crop":
            return
        self._leave_crop()

    def _crop_max(self):
        if self.mode == "crop":
            self.tmp_crop = max_crop(*self.src.size, self._ratio())
            self._redraw()

    def _to_src(self, e):
        s, ox, oy, _, _ = self._crop_geom(self.canvas.winfo_width(), self.canvas.winfo_height())
        return (e.x - ox) / s, (e.y - oy) / s, s

    def _hit(self, e):
        mx, my, s = self._to_src(e)
        x0, y0, x1, y1 = self.tmp_crop
        tol = (HANDLE + S(4)) / s
        for name, hx, hy in (("tl", x0, y0), ("tr", x1, y0), ("bl", x0, y1), ("br", x1, y1)):
            if abs(mx - hx) <= tol and abs(my - hy) <= tol:
                return name
        etol = S(6) / s                       # the whole length of each edge is grabbable
        inx, iny = x0 - etol <= mx <= x1 + etol, y0 - etol <= my <= y1 + etol
        if iny and abs(mx - x0) <= etol:
            return "l"
        if iny and abs(mx - x1) <= etol:
            return "r"
        if inx and abs(my - y0) <= etol:
            return "t"
        if inx and abs(my - y1) <= etol:
            return "b"
        if x0 <= mx <= x1 and y0 <= my <= y1:
            return "move"
        return None

    def _c_motion(self, e):
        if self.mode != "crop" or self.drag:
            return
        h = self._hit(e)
        cur = {"tl": "size_nw_se", "br": "size_nw_se", "tr": "size_ne_sw", "bl": "size_ne_sw",
               "l": "sb_h_double_arrow", "r": "sb_h_double_arrow",
               "t": "sb_v_double_arrow", "b": "sb_v_double_arrow",
               "move": "fleur"}.get(h, "")
        try:
            self.canvas.configure(cursor=cur)
        except tk.TclError:
            self.canvas.configure(cursor="sizing" if h and h != "move" else ("fleur" if h else ""))

    def _c_press(self, e):
        if self.mode != "crop":
            self._pan_start(e)
            return
        h = self._hit(e)
        if not h:
            self.drag = None
            return
        mx, my, _ = self._to_src(e)
        self.drag = (h, mx, my, self.tmp_crop)

    def _c_drag(self, e):
        if self.mode != "crop":
            self._pan_move(e)
            return
        if not self.drag:
            return
        h, sx, sy, (x0, y0, x1, y1) = self.drag
        mx, my, _ = self._to_src(e)
        sw, sh = self.src.size
        sprite = self._sprite()
        if h == "move":
            w, hh = x1 - x0, y1 - y0
            nx = min(max(0.0, x0 + mx - sx), sw - w)
            ny = min(max(0.0, y0 + my - sy), sh - hh)
            if sprite:
                nx, ny = float(round(nx)), float(round(ny))
            self.tmp_crop = (nx, ny, nx + w, ny + hh)
        elif sprite:
            # free: each grabbed side follows the mouse, the others stay put
            nx0, ny0, nx1, ny1 = x0, y0, x1, y1
            if "l" in h:
                nx0 = min(max(0.0, mx), x1 - 1.0)
            if "r" in h:
                nx1 = max(min(float(sw), mx), x0 + 1.0)
            if "t" in h:
                ny0 = min(max(0.0, my), y1 - 1.0)
            if "b" in h:
                ny1 = max(min(float(sh), my), y0 + 1.0)
            self.tmp_crop = snap_crop((nx0, ny0, nx1, ny1), sw, sh)
        elif h in ("l", "r", "t", "b"):
            # title: one side moves, the other axis follows to keep 426:240, centred
            cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
            if h in ("l", "r"):
                ax = x1 if h == "l" else x0
                w = max((ax - mx) if h == "l" else (mx - ax), 0.0)
                maxw = ax if h == "l" else sw - ax
                maxh = 2.0 * min(cy, sh - cy)
                w = min(w, maxw, maxh * CROP_RATIO)
                w = max(w, min(16.0, maxw, maxh * CROP_RATIO))
                hh = w / CROP_RATIO
                nx0 = ax - w if h == "l" else ax
                self.tmp_crop = (nx0, cy - hh / 2, nx0 + w, cy + hh / 2)
            else:
                ay = y1 if h == "t" else y0
                hh = max((ay - my) if h == "t" else (my - ay), 0.0)
                maxh = ay if h == "t" else sh - ay
                maxw = 2.0 * min(cx, sw - cx)
                hh = min(hh, maxh, maxw / CROP_RATIO)
                hh = max(hh, min(16.0 / CROP_RATIO, maxh, maxw / CROP_RATIO))
                w = hh * CROP_RATIO
                ny0 = ay - hh if h == "t" else ay
                self.tmp_crop = (cx - w / 2, ny0, cx + w / 2, ny0 + hh)
        else:
            ax = x1 if "l" in h else x0
            ay = y1 if "t" in h else y0
            dx = -1 if "l" in h else 1
            dy = -1 if "t" in h else 1
            w = max((mx - ax) * dx, 0.0)
            hh = max((my - ay) * dy, 0.0)
            w = max(w, hh * CROP_RATIO)
            maxw = ax if dx < 0 else sw - ax
            maxh = ay if dy < 0 else sh - ay
            w = min(w, maxw, maxh * CROP_RATIO)
            w = max(w, min(16.0, maxw, maxh * CROP_RATIO))
            hh = w / CROP_RATIO
            nx0 = ax if dx > 0 else ax - w
            ny0 = ay if dy > 0 else ay - hh
            self.tmp_crop = (nx0, ny0, nx0 + w, ny0 + hh)
        self._redraw()

    def _c_release(self, e):
        self.drag = None
        if self.mode != "crop":
            self._pan_end(e)

    def _c_wheel(self, e):
        if self.mode == "grid":
            return
        if self.mode != "crop":
            self._zoom_step(e, e.delta > 0, 1 if (e.state & 0x0001) else ZOOM_STEPS)
            return
        f = 0.95 if e.delta > 0 else 1.0 / 0.95
        x0, y0, x1, y1 = self.tmp_crop
        sw, sh = self.src.size
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        if self._sprite():
            ow, oh = int(round(x1 - x0)), int(round(y1 - y0))
            w, h = max(1, int(round(ow * f))), max(1, int(round(oh * f)))
            if w == ow and h == oh:              # tiny boxes still move a pixel per notch
                step = -1 if f < 1 else 1
                w, h = max(1, w + step), max(1, h + step)
            if w > sw or h > sh:
                g = min(sw / w, sh / h)
                w, h = max(1, int(w * g)), max(1, int(h * g))
            nx = min(max(0.0, cx - w / 2), sw - w)
            ny = min(max(0.0, cy - h / 2), sh - h)
            self.tmp_crop = snap_crop((nx, ny, nx + w, ny + h), sw, sh)
            self._redraw()
            return
        w = (x1 - x0) * f
        w = min(max(w, 16.0), sw, sh * CROP_RATIO)
        h = w / CROP_RATIO
        nx = min(max(0.0, cx - w / 2), sw - w)
        ny = min(max(0.0, cy - h / 2), sh - h)
        self.tmp_crop = (nx, ny, nx + w, ny + h)
        self._redraw()


def run_gui(args):
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    gui_base.init(root)
    global HANDLE
    HANDLE = S(10)
    App(root, args)
    root.mainloop()
