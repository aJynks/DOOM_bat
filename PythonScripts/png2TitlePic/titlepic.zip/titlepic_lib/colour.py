"""titlepic - Colour math, palettes, the palette matcher and dithering."""
import os

import numpy as np
from PIL import Image

from .const import DOOM2_PAL0_HEX


# --------------------------------------------------------------------------
#  Colour math
# --------------------------------------------------------------------------
def srgb_to_linear(x):
    x = np.asarray(x, dtype=np.float32)
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4).astype(np.float32)


def linear_to_srgb(x):
    x = np.clip(np.asarray(x, dtype=np.float32), 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1.0 / 2.4) - 0.055).astype(np.float32)


def linear_to_oklab(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l, m, s = np.cbrt(l), np.cbrt(m), np.cbrt(s)
    L = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
    A = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
    B = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
    return np.stack([L, A, B], axis=-1).astype(np.float32)


def oklab_to_linear(lab):
    L, A, B = lab[..., 0], lab[..., 1], lab[..., 2]
    l = L + 0.3963377774 * A + 0.2158037573 * B
    m = L - 0.1055613458 * A - 0.0638541728 * B
    s = L - 0.0894841775 * A - 1.2914855480 * B
    l, m, s = l ** 3, m ** 3, s ** 3
    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    b = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    return np.stack([r, g, b], axis=-1).astype(np.float32)


def linear_to_cielab(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    X = (0.4124564 * r + 0.3575761 * g + 0.1804375 * b) / 0.95047
    Y = (0.2126729 * r + 0.7151522 * g + 0.0721750 * b)
    Z = (0.0193339 * r + 0.1191920 * g + 0.9503041 * b) / 1.08883

    def f(t):
        return np.where(t > 0.008856, np.cbrt(t), 7.787 * t + 16.0 / 116.0)
    fx, fy, fz = f(X), f(Y), f(Z)
    return np.stack([116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz)], axis=-1).astype(np.float32)


def features(rgb01, metric):
    """rgb01: (N,3) sRGB 0..1 -> (features (N,3), chroma (N,) or None)."""
    if metric in ("rgb", "redmean"):
        return (rgb01 * 255.0).astype(np.float32), None
    lin = srgb_to_linear(rgb01)
    if metric == "oklab":
        lab = linear_to_oklab(lin) * 100.0      # L 0..100, a/b roughly -40..40
    else:
        lab = linear_to_cielab(lin)
    chroma = np.hypot(lab[:, 1], lab[:, 2]).astype(np.float32)
    return lab.astype(np.float32), chroma


# --------------------------------------------------------------------------
#  Palette
# --------------------------------------------------------------------------
class Palette:
    _uid = 0

    def __init__(self, rgb, name):
        Palette._uid += 1
        self.uid = Palette._uid
        self.rgb = np.asarray(rgb, dtype=np.uint8).reshape(256, 3)
        self.name = name

    @classmethod
    def doom2(cls):
        data = bytes.fromhex("".join(DOOM2_PAL0_HEX))
        return cls(np.frombuffer(data, dtype=np.uint8), "Doom 2 (PLAYPAL 0)")

    def pil_palette(self):
        return self.rgb.reshape(-1).tolist()


def _pad768(data):
    data = list(data[:768])
    data += [0] * (768 - len(data))
    return data


def load_palette(path):
    name = os.path.basename(path)
    with open(path, "rb") as fh:
        raw = fh.read()

    # WAD
    if raw[:4] in (b"IWAD", b"PWAD"):
        import struct
        numlumps, diroff = struct.unpack_from("<ii", raw, 4)
        found = None
        for i in range(numlumps):
            pos, size, lname = struct.unpack_from("<ii8s", raw, diroff + i * 16)
            if lname.rstrip(b"\0").upper() == b"PLAYPAL":
                found = (pos, size)          # last one wins, like the engine
        if not found:
            raise ValueError("no PLAYPAL lump in WAD")
        pos, size = found
        if size < 768:
            raise ValueError("PLAYPAL lump is too small")
        return Palette(np.frombuffer(raw[pos:pos + 768], dtype=np.uint8), f"{name} PLAYPAL")

    # Text palettes
    head = raw[:16]
    if head.startswith(b"JASC-PAL"):
        lines = raw.decode("ascii", "ignore").split()
        count = int(lines[2])
        vals = [int(v) for v in lines[3:3 + count * 3]]
        return Palette(_pad768(vals), name)
    if head.startswith(b"GIMP Palette"):
        vals = []
        for line in raw.decode("utf-8", "ignore").splitlines()[1:]:
            line = line.strip()
            if not line or line.startswith("#") or ":" in line.split()[0]:
                continue
            parts = line.split()
            try:
                vals += [int(parts[0]), int(parts[1]), int(parts[2])]
            except (ValueError, IndexError):
                continue
        return Palette(_pad768(vals), name)

    # Images
    try:
        im = Image.open(path)
        im.load()
    except Exception:
        im = None
    if im is not None:
        w, h = im.size
        if w % 16 == 0 and h % 16 == 0:
            rgbim = im.convert("RGB")
            cw, ch = w // 16, h // 16
            vals = []
            for gy in range(16):
                for gx in range(16):
                    vals += list(rgbim.getpixel((gx * cw + cw // 2, gy * ch + ch // 2)))
            return Palette(vals, name)
        if im.mode == "P" and im.getpalette():
            return Palette(_pad768(im.getpalette()), name)
        raise ValueError("image is not a 16x16 swatch grid or an indexed image")

    # Raw
    if len(raw) >= 768:
        return Palette(np.frombuffer(raw[:768], dtype=np.uint8), name)
    raise ValueError("unrecognised palette format")


def parse_indices(text):
    out = set()
    for part in text.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a, b = int(a), int(b)
            if a > b:
                a, b = b, a
            for i in range(a, b + 1):
                if 0 <= i <= 255:
                    out.add(i)
        else:
            i = int(part)
            if 0 <= i <= 255:
                out.add(i)
    return out


def format_indices(s):
    s = sorted(s)
    parts = []
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[j + 1] == s[j] + 1:
            j += 1
        parts.append(str(s[i]) if i == j else f"{s[i]}-{s[j]}")
        i = j + 1
    return ", ".join(parts)


# --------------------------------------------------------------------------
#  Palette matcher
# --------------------------------------------------------------------------
LUT_BITS = 6
LUT_N = 1 << LUT_BITS
LUT_SHIFT = 8 - LUT_BITS


class Matcher:
    CHUNK = 8192

    def __init__(self, pal, excluded, metric, kL, protect):
        active = np.array([i for i in range(256) if i not in excluded], dtype=np.int32)
        if active.size == 0:
            active = np.arange(256, dtype=np.int32)
        self.active = active
        self.metric = metric
        self.kL = float(kL)
        self.protect = float(protect)
        prgb = pal.rgb[active].astype(np.float32) / 255.0
        self.pfeat, self.pchroma = features(prgb, metric)
        self._lut = None

    def _dist(self, f, c):
        pf = self.pfeat
        if self.metric == "rgb":
            d = f[:, None, :] - pf[None, :, :]
            return np.einsum("npk,npk->np", d, d)
        if self.metric == "redmean":
            rm = (f[:, None, 0] + pf[None, :, 0]) * 0.5
            dr = f[:, None, 0] - pf[None, :, 0]
            dg = f[:, None, 1] - pf[None, :, 1]
            db = f[:, None, 2] - pf[None, :, 2]
            return (2.0 + rm / 256.0) * dr * dr + 4.0 * dg * dg + (2.0 + (255.0 - rm) / 256.0) * db * db
        dL = f[:, None, 0] - pf[None, :, 0]
        da = f[:, None, 1] - pf[None, :, 1]
        db = f[:, None, 2] - pf[None, :, 2]
        d = self.kL * dL * dL + da * da + db * db
        if self.protect > 0.0:
            loss = np.maximum(c[:, None] - self.pchroma[None, :], 0.0)
            d += self.protect * loss * loss
        return d

    def match(self, rgb01, cancel=None):
        """rgb01 (N,3) sRGB 0..1 -> palette indices (N,) int32, or None if cancelled."""
        f, c = features(rgb01.astype(np.float32), self.metric)
        n = f.shape[0]
        out = np.empty(n, dtype=np.int32)
        for s in range(0, n, self.CHUNK):
            if cancel and cancel():
                return None
            e = min(n, s + self.CHUNK)
            out[s:e] = np.argmin(self._dist(f[s:e], None if c is None else c[s:e]), axis=1)
        return self.active[out]

    def lut(self, cancel=None):
        if self._lut is None:
            v = ((np.arange(LUT_N, dtype=np.float32) * (1 << LUT_SHIFT)) + ((1 << LUT_SHIFT) - 1) / 2.0) / 255.0
            r, g, b = np.meshgrid(v, v, v, indexing="ij")
            grid = np.stack([r.ravel(), g.ravel(), b.ravel()], axis=1)
            res = self.match(grid, cancel)
            if res is None:
                return None
            self._lut = res.astype(np.int32)
        return self._lut


# --------------------------------------------------------------------------
#  Dithering
# --------------------------------------------------------------------------
ED_KERNELS = {
    "Floyd-Steinberg": ([(1, 0, 7), (-1, 1, 3), (0, 1, 5), (1, 1, 1)], 16),
    "Atkinson": ([(1, 0, 1), (2, 0, 1), (-1, 1, 1), (0, 1, 1), (1, 1, 1), (0, 2, 1)], 8),
    "Sierra Lite": ([(1, 0, 2), (-1, 1, 1), (0, 1, 1)], 4),
    "Sierra": ([(1, 0, 5), (2, 0, 3), (-2, 1, 2), (-1, 1, 4), (0, 1, 5), (1, 1, 4), (2, 1, 2),
                (-1, 2, 2), (0, 2, 3), (1, 2, 2)], 32),
    "Jarvis-Judice-Ninke": ([(1, 0, 7), (2, 0, 5), (-2, 1, 3), (-1, 1, 5), (0, 1, 7), (1, 1, 5), (2, 1, 3),
                             (-2, 2, 1), (-1, 2, 3), (0, 2, 5), (1, 2, 3), (2, 2, 1)], 48),
    "Stucki": ([(1, 0, 8), (2, 0, 4), (-2, 1, 2), (-1, 1, 4), (0, 1, 8), (1, 1, 4), (2, 1, 2),
                (-2, 2, 1), (-1, 2, 2), (0, 2, 4), (1, 2, 2), (2, 2, 1)], 42),
    "Burkes": ([(1, 0, 8), (2, 0, 4), (-2, 1, 2), (-1, 1, 4), (0, 1, 8), (1, 1, 4), (2, 1, 2)], 32),
}
ORDERED = ("Bayer 2x2", "Bayer 4x4", "Bayer 8x8", "Noise (IGN)")
DITHER_MODES = ["None"] + list(ED_KERNELS.keys()) + list(ORDERED)


def bayer(n):
    m = np.array([[0]], dtype=np.float32)
    while m.shape[0] < n:
        k = m.shape[0]
        m = np.block([[4 * m, 4 * m + 2], [4 * m + 3, 4 * m + 1]])
    return (m + 0.5) / (n * n) - 0.5


def ordered_offsets(mode, h, w):
    if mode == "Noise (IGN)":
        y, x = np.mgrid[0:h, 0:w].astype(np.float32)
        t = np.mod(0.06711056 * x + 0.00583715 * y, 1.0)
        return (np.mod(52.9829189 * t, 1.0) - 0.5).astype(np.float32)
    n = {"Bayer 2x2": 2, "Bayer 4x4": 4, "Bayer 8x8": 8}[mode]
    m = bayer(n)
    return np.tile(m, (h // n + 1, w // n + 1))[:h, :w]


def error_diffuse(img255, lut, pal_rgb, mode, strength, clamp, serpentine, cancel, mask=None):
    """Error diffusion in sRGB space, nearest lookups through the LUT.
    mask (H,W) bool: False pixels are skipped (no error taken or given)."""
    taps, div = ED_KERNELS[mode]
    taps = [(dx, dy, wt / div) for dx, dy, wt in taps]
    maxdy = max(t[1] for t in taps)
    H, W, _ = img255.shape
    rows = img255.reshape(H, W * 3).tolist()
    pal = pal_rgb.astype(np.float64).tolist()
    lutl = lut.tolist()
    S = LUT_SHIFT
    B2 = LUT_BITS * 2
    B1 = LUT_BITS
    buf = [[0.0] * (W * 3) for _ in range(maxdy + 1)]
    mrows = mask.tolist() if mask is not None else None
    out = np.empty((H, W), dtype=np.int32)
    for y in range(H):
        if cancel and (y & 7) == 0 and cancel():
            return None
        cur = buf[0]
        row = rows[y]
        orow = [0] * W
        mrow = mrows[y] if mrows is not None else None
        rev = serpentine and (y & 1)
        xs = range(W - 1, -1, -1) if rev else range(W)
        for x in xs:
            if mrow is not None and not mrow[x]:
                continue
            i3 = x * 3
            r = row[i3] + cur[i3]
            g = row[i3 + 1] + cur[i3 + 1]
            b = row[i3 + 2] + cur[i3 + 2]
            r = 0.0 if r < 0.0 else (255.0 if r > 255.0 else r)
            g = 0.0 if g < 0.0 else (255.0 if g > 255.0 else g)
            b = 0.0 if b < 0.0 else (255.0 if b > 255.0 else b)
            idx = lutl[((int(r) >> S) << B2) | ((int(g) >> S) << B1) | (int(b) >> S)]
            orow[x] = idx
            p = pal[idx]
            er = (r - p[0]) * strength
            eg = (g - p[1]) * strength
            eb = (b - p[2]) * strength
            if er > clamp: er = clamp
            elif er < -clamp: er = -clamp
            if eg > clamp: eg = clamp
            elif eg < -clamp: eg = -clamp
            if eb > clamp: eb = clamp
            elif eb < -clamp: eb = -clamp
            for dx, dy, wt in taps:
                xx = x - dx if rev else x + dx
                if 0 <= xx < W:
                    tb = buf[dy]
                    j = xx * 3
                    tb[j] += er * wt
                    tb[j + 1] += eg * wt
                    tb[j + 2] += eb * wt
        out[y] = orow
        buf.pop(0)
        buf.append([0.0] * (W * 3))
    return out
