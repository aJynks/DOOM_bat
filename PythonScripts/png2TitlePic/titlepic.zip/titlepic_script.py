#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
titlepic_script.py  -  crop + reduce any image into a 426x200 widescreen Doom
                       title screen, or (Sprite mode) into a sprite / patch of
                       any size, with a realtime preview.

Modes
    Title screen  crop box locked to 426:240 (true 16:9 display aspect),
                  output fixed at 426x200
    Sprite        a list of steps, each added from the toolbar and working on
                  the result of the steps before it, in any order:
                    Crop     free box, whole pixels
                    Mosaic -> Pixels   rebuild AI mosaic art with one pixel per block (shrinks)
                    Snap Pixels        redraw the blocks flat on a perfect grid (same size)
                    Scale    W x H, Linked / Unlinked, Doom aspect (height / 1.2)
                  source transparency is kept (alpha cutoff + transparent index)

Pipeline
    Title:   source -> crop (426:240) -> high quality resize
               (true-colour branch 426x240, paletted branch 426x200)
    Sprite:  source -> steps (Crop / Ungrid / Scale, any order) -> current image
      -> image tweaks (Tweak Image window: each tool is applied in turn)
      -> unsharp mask
      -> palette match (OKLab / CIELAB / redmean / RGB) + optional dither
      -> Export (Title):   <n>-paletted.png       426x200 indexed
                           <n>-truecolour.png     426x240 RGB, before palette matching
                           <n>-truecolour-200.png 426x200 RGB, before palette matching
         Export (Sprite):  <n>-paletted.png       W x H indexed, transparent index via tRNS
                           <n>-truecolour.png     W x H RGBA, before palette matching
                           with a Doom-aspect Scale step also
                           <n>-doom-paletted.png / <n>-doom-truecolour.png (the squashed lump)
         Export opens a dialog with tick boxes for which files to write

    Projects (.titlepic, JSON) store the mode, every setting, the applied tweaks
    and the palette, so a look can be reused on new images or a whole folder.

    Mosaic -> Pixels / Snap Pixels: for AI "fake pixel art" (an image drawn as a
    mosaic of large solid-colour blocks) the block grid is detected; Mosaic ->
    Pixels rebuilds it with one real pixel per block (Sprite mode), Snap Pixels
    redraws every block flat on a perfect grid at the same size (both modes). Grid lines are found
    with an elastic walker that re-snaps every line to the nearest strong colour
    edge, so drifting tile sizes are followed. The walker approach is adapted from
    Sprite Fusion Pixel Snapper by Hugo Duprez (MIT licence),
    https://github.com/Hugo-Dz/spritefusion-pixel-snapper

    spritepic.bat starts the same script in Sprite mode (--sprite).

Files
    titlepic_script.py   this entry script (help, arguments, dependency check)
    titlepic_lib/        the program, split by job:
        const.py      constants + embedded Doom 2 palette
        colour.py     colour math, palettes, matcher, dithering
        tweaks.py     Tweak Image tools, sharpen
        imaging.py    loading, resampling (incl. Majority), transparency, palettising
        ungrid.py     tile-grid detection and rebuild
        steps.py      Sprite steps (Crop / Ungrid / Scale)
        pipeline.py   stage-cached pipeline, Process Folder
        gui_*.py      main window, Tweak / Ungrid / Scale windows, Process Folder dialog
    Keep titlepic_lib next to this script (titlepic.bat / spritepic.bat beside them).

Run with -h for the command line help.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from titlepic_lib.const import PROJECT_EXT, DEFAULT_TIDX, MODE_TITLE, MODE_SPRITE  # noqa: E402,F401


# --------------------------------------------------------------------------
#  Help (house style)
# --------------------------------------------------------------------------
def _enable_ansi():
    if os.name == "nt":
        os.system("")


C_H = "\033[1;96m"
C_O = "\033[93m"
C_D = "\033[37m"
C_E = "\033[92m"
C_R = "\033[0m"
C_T = "\033[1;97m"


def print_help():
    _enable_ansi()
    print(f"""
{C_T}titlepic{C_R} {C_D}- crop and reduce an image to a Doom title screen or sprite{C_R}

{C_H}USAGE{C_R}
  titlepic  [image] [-project FILE] [-pal PALETTE] [-o OUTDIR]
  spritepic [image] [-project FILE] [-pal PALETTE] [-o OUTDIR]
  titlepic  --sprite ...          (same as spritepic)

{C_H}ARGUMENTS{C_R}
  {C_O}image{C_R}              Image to open on startup (any size, any format Pillow reads).

{C_H}OPTIONS{C_R}
  {C_O}--sprite{C_R}           Start in Sprite mode (a project's own mode still wins).
  {C_O}-project{C_R}           Load a {PROJECT_EXT} project (mode, all settings, tweaks and palette).
  {C_O}-pal, --palette{C_R}    Palette to match against. Default: Doom 2 PLAYPAL palette 0
                     (embedded). Accepts:
                       SLADE pal0.png / doomtools-playpal.png (16x16 swatch grid)
                       any indexed (P mode) image's palette
                       a WAD containing PLAYPAL (palette 0)
                       raw .pal / .lmp / PLAYPAL (first 768 bytes)
                       JASC-PAL text, GIMP .gpl
  {C_O}-o, --outdir{C_R}       Folder Export writes into. Default: next to the source image.
  {C_O}-h, --help{C_R}         Show this help.

{C_H}MODES{C_R}
  Title screen   crop locked to 426:240, output fixed 426x200
  Sprite         work is a list of STEPS, added from the toolbar in any order and
                 any number of times; each step works on the result so far:
                   Crop       drag a free box (whole pixels), OK adds the step
                   Mosaic -> Pixels...  rebuild AI mosaic art with one pixel per block
                   Snap Pixels...       redraw the blocks flat on a perfect grid, same size
                   Scale...   resize the current image
                 Undo step removes the last one, Reset to source clears them all.
                 With no steps the source is used at its own size.
                 Transparency from the source alpha: pixels under the alpha cutoff
                 are transparent, kept out of matching / dithering, and written
                 with the transparent index (default {DEFAULT_TIDX}, excluded from matching).

{C_H}MOSAIC -> PIXELS / SNAP PIXELS{C_R}
  For AI "pixel art" drawn as a mosaic of big solid blocks. The block grid is
  detected when the window opens.
    Mosaic -> Pixels  one pixel per block: the image shrinks (Sprite mode)
    Snap Pixels       every block redrawn flat on a perfect grid: same size
                      (both modes; Title mode keeps its own step list)
    Square tiles    one tile size for both axes (default on), so the ratio holds
    Tile W / H      tile size in pixels (decimals allowed)
    Offset X / Y    where the first grid line sits
    Re-detect       detect tile size and offset again
    Refine lines    snap every grid line to the nearest strong edge (follows drift)
    Sample area     centre part of each tile that is read (edges are blurry)
    Pick            Grouped vote (most common colour group, averaged) or Median
    View            Result (the rebuilt pixels) or Grid (lines over the image)
  The window rates the grid: clear, weak, or "no clear pixel grid" (the image
  isn't block-based: use Scale / the title resize instead).

{C_H}SCALE WINDOW{C_R}
  Opens at 1:1 (no change) on the current image.
    Width / Height  output size; 1:1 button returns to the current size
    Linked          typing one size sets the other from the current aspect
    Doom aspect     (Linked) height is divided by 1.2 so it looks right after
                    Doom's 1.2 vertical stretch; done in the same resample as
                    the size change, so the pixels are only resampled once
    Filter          resize filter (Majority for pixel art), Linear light averaging

{C_H}FILTERS{C_R}
  Lanczos / Box / Bicubic / Hamming / Bilinear / Nearest, plus
  Majority (pixel art)  each output pixel takes the most common source colour
                        in its footprint; keeps pixel art crisp

{C_H}EXPORT{C_R}
  Title:   <name>-paletted.png        426x200  indexed PNG, uses the active palette
           <name>-truecolour.png      426x240  RGB, after tweaks + sharpen, before palette match
           <name>-truecolour-200.png  426x200  RGB, same but at lump size (squashed)
  Sprite:  <name>-paletted.png        W x H    indexed PNG, tRNS on the transparent index
           <name>-truecolour.png      W x H    RGBA, before palette match
           When a Scale step used Doom aspect there are two sets:
           <name>-doom-paletted.png / -doom-truecolour.png   squashed, the lump for the WAD
           <name>-paletted.png / -truecolour.png             normal aspect, rebuilt from the
                                                             steps with the squash off (each
                                                             Scale still resamples only once)
  Export opens a dialog: folder, name, and a tick box per file. Process Folder
  writes the same ticked files.

{C_H}PROCESS FOLDER{C_R}
  Runs the current settings over every image in a folder (no crop).
  Title:   with Snap steps: every image is snapped, then centre-cropped to 426:240
           and resized; without steps:
           426x200  processed as-is (truecolour written as *-truecolour-200)
           426x240  squashed to 426x200 first (current filter / linear light)
           other    skipped and listed by name and size in the report
  Sprite:  every image is processed; the step list is replayed on each one
           Ungrid    detects each image's own grid
           Scale     Linked: the same percentage of whatever size reaches it,
                     Unlinked: exactly Width x Height
           Crop      skipped (crops belong to one image)
  Files already named *-paletted / *-truecolour / *-truecolour-200 are ignored.
  Tick boxes (default on): apply tweaks, apply sharpen. Files: as ticked in Export.

{C_H}GUI{C_R}
  Preview     mouse wheel zooms (4 steps a notch, Shift+wheel 1 step), drag pans,
              double-click / Fit fits. Zoom and position are kept through
              adjustments; only opening an image, switching mode or Fit resets.
              Sprite mode always shows the raw pixel data at its real size,
              exactly what is saved (a Doom-squashed sprite looks squat)
  Divider     drag the bar between image and controls to resize the panel
  Crop        drag inside the box to move, an edge to move that side, a corner
              to move two sides (Sprite mode: free; Title mode: the 426:240 ratio
              is kept, an edge drag grows the box centred), mouse wheel to scale,
              Enter = OK, Esc = cancel, Max = largest box / whole image.
              In Sprite mode OK adds a Crop step
  Tweak       pick a tool and adjust; picking another tool carries the look forward.
              Reset tool = tool defaults, Reset = back to source, Undo = step back,
              Apply = accept + close (closing otherwise asks to discard)
  Sliders     double-click a slider's label to reset it
  Palette     click swatches to exclude/include indices (cyan box = transparent index)

{C_H}EXAMPLES{C_R}
  {C_E}titlepic{C_R}
  {C_E}titlepic art\\title_source.jpg{C_R}
  {C_E}titlepic art\\title_source.jpg -project looks\\hellish.titlepic{C_R}
  {C_E}titlepic render.png -pal pal0.png -o graphics{C_R}
  {C_E}spritepic face.png -o sprites{C_R}
""")


# --------------------------------------------------------------------------
#  Dependency check
# --------------------------------------------------------------------------
def check_deps(need_tk=True):
    missing = []
    try:
        import PIL  # noqa: F401
    except ImportError:
        missing.append("pillow")
    try:
        import numpy  # noqa: F401
    except ImportError:
        missing.append("numpy")
    if missing:
        _enable_ansi()
        print(f"\n{C_O}titlepic: missing dependencies:{C_R} {', '.join(missing)}")
        print(f"  install with:  {C_E}pip install {' '.join(missing)}{C_R}\n")
        sys.exit(1)
    if need_tk:
        try:
            import tkinter  # noqa: F401
        except ImportError:
            print("\ntitlepic: tkinter is not available. Reinstall Python from python.org "
                  "with the 'tcl/tk and IDLE' option ticked.\n")
            sys.exit(1)


# Imports that need the deps. Done lazily so -h works without them.


# --------------------------------------------------------------------------
#  Entry
# --------------------------------------------------------------------------
class _Args:
    sprite = False
    image = None
    palette = None
    outdir = None
    project = None


def parse_args(argv):
    a = _Args()
    i = 0
    while i < len(argv):
        t = argv[i]
        if t in ("-h", "--help", "/?"):
            print_help()
            sys.exit(0)
        elif t in ("-sprite", "--sprite"):
            a.sprite = True
        elif t in ("-pal", "--palette"):
            i += 1
            a.palette = argv[i] if i < len(argv) else None
        elif t in ("-o", "--outdir"):
            i += 1
            a.outdir = argv[i] if i < len(argv) else None
        elif t in ("-project", "--project"):
            i += 1
            a.project = argv[i] if i < len(argv) else None
        elif t.startswith("-"):
            _enable_ansi()
            print(f"{C_O}titlepic: unknown option {t}{C_R}  (titlepic -h for help)")
            sys.exit(2)
        else:
            a.image = t
        i += 1
    return a


def main():
    args = parse_args(sys.argv[1:])
    check_deps(need_tk=True)
    from titlepic_lib.gui_app import run_gui
    run_gui(args)


if __name__ == "__main__":
    main()
