#!/usr/bin/env python3
"""
colourRemap_script.py - standalone clone of SLADE's Colour Remap tool.

Launched by colourRemap.bat. Engine lives in colourRemap_lib/ beside this file.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


# ----------------------------------------------------------------------------
# Dependency check
# ----------------------------------------------------------------------------
def check_deps():
    missing = []
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("tkinter is missing - re-run the Python installer and tick 'tcl/tk and IDLE'.")
        sys.exit(1)
    try:
        import PIL  # noqa: F401
    except ImportError:
        missing.append("Pillow")
    if missing:
        print(f"Missing: {', '.join(missing)}")
        print(f"  pip install {' '.join(missing)}")
        sys.exit(1)


# ----------------------------------------------------------------------------
# Help (house style: ANSI sections, EXAMPLES last)
# ----------------------------------------------------------------------------
def _ansi_ok():
    if not sys.stdout.isatty():
        return False
    if os.name == "nt":
        os.system("")
    return True


def print_help():
    from colourRemap_lib import VERSION
    c = _ansi_ok()
    H = "\033[1;36m" if c else ""
    C = "\033[1;33m" if c else ""
    D = "\033[90m" if c else ""
    R = "\033[0m" if c else ""
    print(f"""
{H}colourRemap {VERSION}{R} - SLADE-style Colour Remap (palette translation) tool

{H}USAGE{R}
  colourRemap {C}[SOURCE]{R} {C}[-pal PALETTE]{R}

{H}ARGUMENTS{R}
  {C}SOURCE{R}             What to open:
                       a PNG or Doom-format .lmp graphic
                       a folder (every .png / .lmp in it)
                       a WAD (sprites, patches, flats, graphics, textures)
  {C}-pal, --pal FILE{R}   Palette to load as pal0. Accepts:
                       WAD (PLAYPAL), SLADE playpal.pal / pal0.pal,
                       SLADE 16x16 grid png, DoomTools playpal png,
                       COLORMAP png (row 0), JASC-PAL, GIMP .gpl
                     {D}Without it: last used palette, else built-in Doom II pal0{R}
  {C}-h, --help{R}         This screen

{H}IN THE WINDOW{R}
  Sprite window      wheel = zoom to cursor
                     middle-drag or Space+left-drag = pan (view only)
                     click / drag a box = pick indices (Shift add, Alt subtract)
  Image dropdown     type to filter by name, Up/Down or the arrow buttons step
  Save Sprite        writes the image you're looking at
  Export             filtered, multi-select list of the whole source; each
                     selected graphic is written as NAME.png (offsets in grAb)
  Mode: Paint        touch up single images: brush / rectangle select pixels,
                     the translation previews on the selection only, Apply
                     (Enter) bakes it, Ctrl+Z / Ctrl+Y undo / redo; frames
                     start from the Batch result (or Original); edited frames
                     show * until saved; Save All Changed writes them all

{H}NOTES{R}
  Paletted sources are read through the LOADED pal0 (indices are kept).
  Truecolour sources are converted to pal0 on load (nearest colour, optional
  dither); alpha below 128 becomes transparent.
  Settings, panel sizes and folders are remembered on close.

{H}EXAMPLES{R}
  colourRemap
  colourRemap D:\\doom\\iwads\\doom2.wad
  colourRemap TROOA1.png -pal D:\\doom\\iwads\\doom2.wad
  colourRemap D:\\work\\sprites\\imp
""")


def parse_args(argv):
    source = pal = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help", "/?"):
            print_help()
            sys.exit(0)
        if a.lower() in ("-pal", "--pal"):
            if i + 1 >= len(argv):
                print("-pal needs a file.")
                sys.exit(1)
            pal = argv[i + 1]
            i += 2
            continue
        if a.startswith("-"):
            print(f"Unknown option: {a}  (colourRemap -h for help)")
            sys.exit(1)
        if source is None:
            source = a
        i += 1
    if source and not os.path.exists(source):
        print(f"Source not found: {source}")
        sys.exit(1)
    if pal and not os.path.isfile(pal):
        print(f"Palette not found: {pal}")
        sys.exit(1)
    return source, pal


def main():
    check_deps()
    source, pal = parse_args(sys.argv[1:])
    from colourRemap_lib.gui.app import run
    run(source, pal)


if __name__ == "__main__":
    main()
