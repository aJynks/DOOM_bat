@echo off
python "%~dp0colourRemap_script.py" %*
