"""
trnslate_text.py - ZDoom TRNSLATE string <-> Translation.

Accepts:  "0:16=32:48", "0:16=[255,0,0]:[0,0,0]", "0:255=%[0,0,0]:[2,2,2]",
          "64:79=#[255,128,0]", "64:79=@50[255,0,0]", "0:255=$ice"
          comma-separated, quoted or not; built-ins (Inverse, Gold, Red,
          Green, Blue, Ice, "Desaturate, N"); SLADE's predefined names
          (doom0..6, heretic0..8, strife0..6, chex0..6, tomato, dirt, sea,
          black, purple, vomit, pink, cream, white, blue, gold, stealth).
"""

import re

from .ranges import (PaletteRange, ColourRange, DesatRange, BlendRange,
                     TintRange, SpecialRange)
from .translation import Translation


class TranslationParseError(Exception):
    pass


PREDEFINED = {
    "doom0": '"112:127=96:111"', "doom1": '"112:127=64:79"', "doom2": '"112:127=32:47"',
    "doom3": '"112:127=88:103"', "doom4": '"112:127=56:71"', "doom5": '"112:127=176:191"',
    "doom6": '"112:127=192:207"',
    "heretic0": '"225:240=114:129"', "heretic1": '"225:240=145:160"', "heretic2": '"225:240=190:205"',
    "heretic3": '"225:240=67:82"', "heretic4": '"225:240=9:24"', "heretic5": '"225:240=74:89"',
    "heretic6": '"225:240=150:165"', "heretic7": '"225:240=192:207"', "heretic8": '"225:240=95:110"',
    "strife0": '"32:63=0:31", "128:143=64:79", "241:246=224:229", "247:251=241:245"',
    "strife1": '"32:63=0:31", "128:143=176:191"',
    "strife2": '"32:47=208:223", "48:63=208:223", "128:143=16:31"',
    "strife3": '"32:47=208:223", "48:63=208:223", "128:143=48:63"',
    "strife4": '"32:63=0:31", "80:95=128:143", "128:143=80:95", "192:223=160:191"',
    "strife5": '"32:63=0:31", "80:95=16:31", "128:143=96:111", "192:223=32:63"',
    "strife6": '"32:63=0:31", "80:95=64:79", "128:143=144:159", "192=1", "193:223=1:31"',
    "chex0": '"192:207=112:127"', "chex1": '"192:207=96:111"', "chex2": '"192:207=64:79"',
    "chex3": '"192:207=32:47"', "chex4": '"192:207=88:103"', "chex5": '"192:207=56:71"',
    "chex6": '"192:207=176:191"',
    "tomato": '"112:113=171:171", "114:114=172:172", "115:122=173:187", "123:124=188:189", "125:126=45:47", "127:127=1:1"',
    "dirt": '"112:117=128:133", "118:120=135:137", "121:123=139:143", "124:125=237:239", "126:127=1:2"',
    "blue": '"112:121=197:206", "122:127=240:245"',
    "gold": '"112:113=160:160", "114:119=161:166", "120:123=236:239", "124:125=1:2", "126:127=7:8"',
    "sea": '"112:112=91:91", "113:114=94:95", "115:122=152:159", "123:126=9:12", "127:127=8:8"',
    "black": '"112:112=101:101", "113:121=103:111", "122:125=5:8", "126:127=0:0"',
    "purple": '"112:113=4:4", "114:115=170:170", "116:125=250:254", "126:127=46:46"',
    "vomit": '"112:119=209:216", "120:121=218:220", "122:124=69:75", "125:127=237:239"',
    "pink": '"112:113=16:17", "114:117=19:25", "118:119=27:28", "120:124=30:38", "125:126=41:43", "127:127=46:46"',
    "cream": '"112:112=4:4", "113:118=48:63", "119:119=65:65", "120:124=68:76", "125:126=77:79", "127:127=1:1"',
    "white": '"112:112=4:4", "113:115=80:82", "116:117=84:86", "118:120=89:93", "121:127=96:108"',
    "stealth": '"0:255=%[0.00,0.00,0.00]:[1.31,0.84,0.84]"',
}

_NUM = r"\s*(-?\d+)\s*"
_FLT = r"\s*(-?\d+(?:\.\d*)?|-?\.\d+)\s*"
_RGB_I = r"\[" + _NUM + "," + _NUM + "," + _NUM + r"\]"
_RGB_F = r"\[" + _FLT + "," + _FLT + "," + _FLT + r"\]"
_RE_LHS = re.compile(r"^\s*(\d+)\s*(?::\s*(\d+)\s*)?=\s*(.*?)\s*$", re.S)
_RE_PAL = re.compile(r"^(\d+)\s*(?::\s*(\d+))?$")
_RE_COL = re.compile(r"^" + _RGB_I + r"\s*:\s*" + _RGB_I + "$")
_RE_DES = re.compile(r"^%\s*" + _RGB_F + r"\s*:\s*" + _RGB_F + "$")
_RE_BLD = re.compile(r"^#\s*" + _RGB_I + "$")
_RE_TNT = re.compile(r"^@" + _NUM + _RGB_I + "$")
_RE_SPC = re.compile(r"^\$\s*([A-Za-z0-9_]+)$")


def _c8(v):
    v = int(v)
    return max(0, min(255, v))


def _split_top(text):
    """Split on commas that aren't inside [ ]."""
    parts, depth, cur = [], 0, []
    for ch in text:
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]


def parse_range(text):
    m = _RE_LHS.match(text)
    if not m:
        raise TranslationParseError(f"Bad range '{text}' (expected start:end=target).")
    o1 = _c8(m.group(1))
    o2 = _c8(m.group(2)) if m.group(2) is not None else o1
    rhs = m.group(3)
    rev = o1 > o2
    lo, hi = min(o1, o2), max(o1, o2)

    if (mm := _RE_COL.match(rhs)):
        v = [_c8(x) for x in mm.groups()]
        a, b = tuple(v[:3]), tuple(v[3:])
        return ColourRange(lo, hi, b, a) if rev else ColourRange(lo, hi, a, b)
    if (mm := _RE_DES.match(rhs)):
        v = [float(x) for x in mm.groups()]
        a, b = tuple(v[:3]), tuple(v[3:])
        return DesatRange(lo, hi, b, a) if rev else DesatRange(lo, hi, a, b)
    if (mm := _RE_BLD.match(rhs)):
        return BlendRange(lo, hi, tuple(_c8(x) for x in mm.groups()))
    if (mm := _RE_TNT.match(rhs)):
        v = mm.groups()
        return TintRange(lo, hi, tuple(_c8(x) for x in v[1:]), _c8(v[0]))
    if (mm := _RE_SPC.match(rhs)):
        return SpecialRange(lo, hi, mm.group(1))
    if (mm := _RE_PAL.match(rhs)):
        d1 = _c8(mm.group(1))
        d2 = _c8(mm.group(2)) if mm.group(2) is not None else d1
        return PaletteRange(lo, hi, d2, d1) if rev else PaletteRange(lo, hi, d1, d2)
    raise TranslationParseError(f"Bad target in '{text}'.")


def parse(text):
    """Parse a translation string into a Translation (raises TranslationParseError)."""
    s = text.strip()
    # Allow a TRNSLATE lump line:  Name = "..." , "..."
    m = re.match(r'^[A-Za-z_][A-Za-z0-9_]*\s*=\s*(".*)$', s, re.S)
    if m:
        s = m.group(1).strip()

    t = Translation()
    low = s.lower()
    # Unquoted names are ZDoom built-ins (like SLADE)...
    for name in ("Inverse", "Gold", "Red", "Green", "Blue", "Ice"):
        if low == name.lower():
            t.builtin = name
            return t
    m = re.match(r"^desaturate\s*,\s*(\d+)$", low)
    if m:
        t.builtin = "Desaturate"
        t.desat_amount = max(1, min(31, int(m.group(1))))
        return t
    if low.startswith('"$@'):
        raise TranslationParseError("Hexen translation-table references (\"$@LUMP\") aren't supported.")
    # ...quoted single names are SLADE's predefined translations ("doom0", "blue")
    m = re.match(r'^"([a-z0-9_]+)"$', low)
    if m and m.group(1) in PREDEFINED:
        s = PREDEFINED[m.group(1)]

    if not s:
        return t

    if '"' in s:
        segs = [x.strip() for x in re.findall(r'"([^"]*)"', s)]
        segs = [x for x in segs if x]
        if not segs:
            raise TranslationParseError("Unbalanced quotes in translation string.")
    else:
        segs = _split_top(s)

    t.ranges = [parse_range(x) for x in segs]
    return t


def to_text(t, palette=None):
    """SLADE-style string: "a:b=c:d", "..." or a built-in name.
    Pick groups are written out as the ordinary ranges they expand to
    (brightness order needs [palette]; without it index order is used)."""
    if t.builtin:
        if t.builtin == "Desaturate":
            return f"Desaturate, {t.desat_amount}"
        return t.builtin
    if palette is None:
        palette = [(i, i, i) for i in range(256)]
    return ", ".join(f'"{r.to_text()}"' for r in t.flat_ranges(palette))


# ----------------------------------------------------------------------------
# Palette-translation-only: exact index-to-index string from a LUT
# ----------------------------------------------------------------------------
def _pal_formula(s, e, ds, de, i):
    span = e - s
    frac = (i - s) / span if span else 0.0
    return max(0, min(255, int(ds + frac * (de - ds))))


def palette_only_text(lut):
    """Build a palette-range-only string that reproduces [lut]'s indices exactly.
    Unlike SLADE's run detection this handles reversed and flat runs and is
    verified against the palette-range formula, so it's never lossy."""
    idx = [e[0] for e in lut]
    out = []
    i = 0
    while i < 256:
        if idx[i] == i:
            i += 1
            continue
        j, step = i, None
        while j + 1 < 256 and idx[j + 1] != j + 1:
            d = idx[j + 1] - idx[j]
            if d not in (-1, 0, 1) or (step is not None and d != step):
                break
            step = d
            j += 1
        s, e, ds, de = i, j, idx[i], idx[j]
        if all(_pal_formula(s, e, ds, de, k) == idx[k] for k in range(s, e + 1)):
            out.append(f"{s}:{e}={ds}:{de}")
        else:
            out.extend(f"{k}:{k}={idx[k]}:{idx[k]}" for k in range(s, e + 1))
        i = j + 1
    return ", ".join(f'"{x}"' for x in out)
