"""
settings.py - last-used settings, stored beside colourRemap_script.py
(so the same tools folder carries them), falling back to %APPDATA%.
"""

import json
import os

_FILE = "colourRemap_settings.json"

DEFAULTS = {
    "palette_path": "",
    "source_dir": "",
    "export_dir": "",
    "trans_dir": "",
    "dither": False,
    "sashes": {},
    "translation": "",
    "match": "ciede2000",
    "truecolor": False,
    "palette_only": False,
    "geometry": "",
}


def _paths():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    yield os.path.join(here, _FILE)
    appdata = os.environ.get("APPDATA")
    if appdata:
        yield os.path.join(appdata, "colourRemap", _FILE)


def load():
    s = dict(DEFAULTS)
    for p in _paths():
        if os.path.isfile(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    s.update(json.load(f))
                break
            except (OSError, ValueError):
                pass
    return s


def save(s):
    for p in _paths():
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                json.dump(s, f, indent=2)
            return True
        except OSError:
            continue
    return False
