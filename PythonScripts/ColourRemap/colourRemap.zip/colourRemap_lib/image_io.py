"""
image_io.py - the working image, truecolour -> pal0 conversion, rendering
and PNG output.

Every GfxImage is paletted once loaded. Truecolour sources are converted to
the current input pal0 (nearest colour via the Matcher, optional
Floyd-Steinberg dither; alpha < 128 = transparent). The original RGBA is kept
so a palette or dither change re-converts from source, never twice.
"""

import io
import struct
import zlib

from PIL import Image


class ImageError(Exception):
    pass


# ----------------------------------------------------------------------------
# grAb chunk helpers
# ----------------------------------------------------------------------------
def _make_chunk(ctype, body):
    crc = zlib.crc32(ctype + body) & 0xFFFFFFFF
    return struct.pack(">I", len(body)) + ctype + body + struct.pack(">I", crc)


def insert_grab(png_bytes, offsets):
    """Insert a grAb chunk (x, y offsets) straight after IHDR."""
    if not offsets:
        return png_bytes
    ihdr_len, = struct.unpack(">I", png_bytes[8:12])
    cut = 8 + 12 + ihdr_len
    body = struct.pack(">ii", int(offsets[0]), int(offsets[1]))
    return png_bytes[:cut] + _make_chunk(b"grAb", body) + png_bytes[cut:]


# ----------------------------------------------------------------------------
# Truecolour -> pal0
# ----------------------------------------------------------------------------
def convert_rgba(rgba, w, h, matcher, dither=False):
    """Returns (indices, alpha) bytes."""
    n = w * h
    alpha = bytes(255 if rgba[p * 4 + 3] >= 128 else 0 for p in range(n))
    idx = bytearray(n)
    near = matcher.nearest_fast
    pal = matcher.palette

    if not dither:
        for p in range(n):
            if alpha[p]:
                q = p * 4
                idx[p] = near((rgba[q], rgba[q + 1], rgba[q + 2]))
        return bytes(idx), alpha

    # Floyd-Steinberg; error only spreads between opaque pixels
    er = [float(rgba[p * 4]) for p in range(n)]
    eg = [float(rgba[p * 4 + 1]) for p in range(n)]
    eb = [float(rgba[p * 4 + 2]) for p in range(n)]
    for y in range(h):
        for x in range(w):
            p = y * w + x
            if not alpha[p]:
                continue
            r = min(255, max(0, int(er[p] + 0.5)))
            g = min(255, max(0, int(eg[p] + 0.5)))
            b = min(255, max(0, int(eb[p] + 0.5)))
            i = near((r, g, b))
            idx[p] = i
            pr, pg, pb = pal[i]
            dr, dg, db = er[p] - pr, eg[p] - pg, eb[p] - pb
            for dx, dy, f in ((1, 0, 7 / 16), (-1, 1, 3 / 16), (0, 1, 5 / 16), (1, 1, 1 / 16)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and ny < h:
                    k = ny * w + nx
                    if alpha[k]:
                        er[k] += dr * f
                        eg[k] += dg * f
                        eb[k] += db * f
    return bytes(idx), alpha


# ----------------------------------------------------------------------------
# Working image
# ----------------------------------------------------------------------------
class GfxImage:
    def __init__(self, entry, raw):
        self.entry = entry
        self.name = entry.name if entry else "image"
        self.kind = entry.kind if entry else ""
        self.width = raw["w"]
        self.height = raw["h"]
        self.offsets = raw.get("offsets")
        self.png_trans = raw.get("png_trans")
        self.src_rgba = raw.get("rgba") if raw["mode"] == "rgba" else None
        self.indices = raw.get("indices")
        self.alpha = raw.get("alpha")

    @property
    def truecolour(self):
        return self.src_rgba is not None

    def convert(self, matcher, dither):
        """(Re)convert a truecolour source to pal0. No-op for paletted sources."""
        if self.src_rgba is not None:
            self.indices, self.alpha = convert_rgba(self.src_rgba, self.width, self.height,
                                                    matcher, dither)

    def describe(self):
        o = f", offsets {self.offsets[0]},{self.offsets[1]}" if self.offsets else ""
        src = "truecolour->pal0" if self.truecolour else "paletted"
        return f"{self.name}  ({self.kind}, {self.width}x{self.height}, {src}{o})"


def build_image(entry, matcher, dither):
    try:
        raw = entry.load()
    except Exception as e:
        raise ImageError(f"{entry.name}: {e}")
    img = GfxImage(entry, raw)
    img.convert(matcher, dither)
    return img


# ----------------------------------------------------------------------------
# Rendering / saving
# ----------------------------------------------------------------------------
def render(img, lut, palette, truecolor=False, original=False):
    """PIL RGBA of the result (or the pre-remap paletted image)."""
    if original or lut is None:
        table = list(palette)
    elif truecolor:
        table = [lut[i][1] for i in range(256)]
    else:
        table = [palette[lut[i][0]] for i in range(256)]
    w, h = img.width, img.height
    p = Image.frombytes("P", (w, h), img.indices)
    p.putpalette([v for c in table for v in c])
    out = p.convert("RGBA")
    out.putalpha(Image.frombytes("L", (w, h), img.alpha))
    return out


def save_image(img, lut, palette, truecolor, path):
    """Write the remapped image as PNG. Returns a list of warning strings.

    Paletted output: transparent pixels use an index no visible pixel uses
    (the source PNG's own transparent index if still free, else the highest
    free index), written as tRNS - the same approach SLADE uses.
    """
    warnings = []
    w, h = img.width, img.height
    kw = {}
    if not truecolor:
        new = [e[0] for e in lut]
        src, alpha = img.indices, img.alpha
        out = bytearray(w * h)
        used = set()
        has_trans = False
        for p in range(w * h):
            if alpha[p]:
                d = new[src[p]]
                out[p] = d
                used.add(d)
            else:
                has_trans = True
        if has_trans:
            t = img.png_trans if (img.png_trans is not None and img.png_trans not in used) else None
            if t is None:
                free = [i for i in range(255, -1, -1) if i not in used]
                t = free[0] if free else None
            if t is None:
                warnings.append(f"{img.name}: all 256 indices used, saved as RGBA to keep transparency.")
                im = render(img, lut, palette, False)
            else:
                for p in range(w * h):
                    if not alpha[p]:
                        out[p] = t
                kw["transparency"] = t
                im = Image.frombytes("P", (w, h), bytes(out))
                im.putpalette([v for c in palette for v in c])
        else:
            im = Image.frombytes("P", (w, h), bytes(out))
            im.putpalette([v for c in palette for v in c])
    else:
        im = render(img, lut, palette, True)

    buf = io.BytesIO()
    im.save(buf, "PNG", **kw)
    with open(path, "wb") as f:
        f.write(insert_grab(buf.getvalue(), img.offsets))
    return warnings
