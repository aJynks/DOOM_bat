"""
palette_io.py - pal0 loading for colourRemap.

Every loader returns exactly 256 (r, g, b) tuples: pal0 of whatever was given.

Accepted sources
  * WAD (IWAD/PWAD)          - last PLAYPAL lump in the directory, pal0
  * raw .pal / .lmp          - SLADE playpal.pal (N x 768 bytes) or pal0.pal (768)
  * JASC-PAL / GIMP .gpl     - text palettes (first 256 entries)
  * PNG, square, /16         - SLADE-style 16x16 grid (any cell size), cell centres
  * PNG, 256 wide            - DoomTools playpal.png strip(s) or COLORMAP png, row 0
  * PNG, other paletted      - the PNG's own embedded palette (fallback)
"""

import base64
import os
import struct

PAL_BYTES = 768


class PaletteError(Exception):
    """Raised when a file can't be read as a palette."""


# Doom / Doom II pal0 (PLAYPAL palette 0), used until something is loaded.
_DOOM2_PAL0 = base64.b64decode(
    "AAAAHxcLFw8HS0tL////GxsbExMTCwsLBwcHLzcfIysPFx8HDxcATzsrRzMjPysb/7e396ur86Oj"
    "65eX54+P34eH23t703Nzy2trx2Njv1tbu1dXs09Pr0dHpz8/ozs7mzMzly8vjysriyMjgx8ffxsb"
    "dxcXcxMTaw8PZwsLXwcHWwcHUwcHTwAARwAAQwAA/+vf/+PT/9vH/9O7/8+z/8en/7+b/7uT/7OD"
    "96t776Nz55tr35Nj14tbz4NTy39Pv3tLs3NHq29Do2s/m2M7j183h1czf1Mvd08ra0cnX0MjUz8f"
    "SzcbPy8XMysTKyMP7+/v5+fn39/f29vb09PTy8vLx8fHv7+/t7e3s7Ozq6urp6enn5+fl5eXk5OT"
    "i4uLg4ODf39/d3d3b29va2trY2NjW1tbV1dXT09PR0dHQ0NDOzs7Nzc3Ly8vJycnIyMjd/9vb+9n"
    "Z99fX89XW79PU69HS58/Q5M3P4MvN3MrL2MjJ1MbH0MXFzMPEyMLCxcHv6ePt5+Hr5d/p493n4dv"
    "m39rk3tji3Nbg2tXe2NPd19Lb1dDZ1M/X0s3V0MzUz8vn4Njj3dTg2tLd18/Z1MzW0crTzsjQzMb"
    "e39jb3NXZ2tPW2NHU1c7R08zP0crNz8n//9z69tX17tDw5svr3sfm1sTh0MHcysA/////9vb/7u7"
    "/5ub/3t7/19f/z8//x8f/wAA7wAA4wAA1wAAywAAvwAAswAApwAAmwAAiwAAfwAAcwAAZwAAWwAA"
    "TwAAQwAA5+f/x8f/q6v/j4//c3P/U1P/Nzf/Gxv/AAD/AADjAADLAACzAACbAACDAABrAABT////"
    "/+vb/9e7/8eb/7N7/6Nb/487/38b83MX628P32cP118Ly1cHw08At0cAr0MA///////X//+z//+P"
    "//9r//9H//8j//8Apz8AnzcAky8AhyMATzsnQy8bNyMTLxsLAABTAABHAAA7AAAvAAAjAAAXAAAL"
    "AAAA/59D/+dL/3v//wD/zwDPnwCbbwBrp2tr"
)


def default_palette():
    """Built-in Doom II pal0."""
    return _bytes_to_pal(_DOOM2_PAL0)


def _bytes_to_pal(data):
    return [tuple(data[i * 3:i * 3 + 3]) for i in range(256)]


def _pad(colours):
    colours = [tuple(int(v) & 255 for v in c[:3]) for c in colours[:256]]
    while len(colours) < 256:
        colours.append((0, 0, 0))
    return colours


# ----------------------------------------------------------------------------
# Public entry point
# ----------------------------------------------------------------------------
def load_palette(path):
    """Load pal0 from [path]. Returns (colours, description)."""
    if not os.path.isfile(path):
        raise PaletteError(f"File not found: {path}")
    with open(path, "rb") as f:
        data = f.read()

    name = os.path.basename(path)
    if data[:4] in (b"IWAD", b"PWAD"):
        return _from_wad(data, name)
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return _from_png(path, name)
    if data[:8] == b"JASC-PAL":
        return _from_jasc(data, name)
    if data[:12] == b"GIMP Palette":
        return _from_gpl(data, name)
    if len(data) >= PAL_BYTES and len(data) % PAL_BYTES == 0:
        count = len(data) // PAL_BYTES
        kind = "pal0.pal" if count == 1 else f"playpal.pal, {count} palettes"
        return _bytes_to_pal(data[:PAL_BYTES]), f"{name}  (raw {kind}, pal0)"
    if len(data) in (8704, 8448, 8960):
        raise PaletteError(
            f"{name} looks like a raw COLORMAP lump. COLORMAP stores palette "
            "indices, not colours - load a PLAYPAL, pal0 or COLORMAP png instead.")
    raise PaletteError(f"{name}: unrecognised palette format ({len(data)} bytes).")


# ----------------------------------------------------------------------------
# Loaders
# ----------------------------------------------------------------------------
def _from_wad(data, name):
    try:
        numlumps, diroffs = struct.unpack_from("<ii", data, 4)
    except struct.error:
        raise PaletteError(f"{name}: truncated WAD header.")
    found = None
    for n in range(numlumps):
        pos = diroffs + n * 16
        if pos + 16 > len(data):
            raise PaletteError(f"{name}: WAD directory runs past end of file.")
        offs, size = struct.unpack_from("<ii", data, pos)
        lname = data[pos + 8:pos + 16].split(b"\0", 1)[0].decode("ascii", "replace").upper()
        if lname == "PLAYPAL":
            found = (offs, size)          # keep going: last one wins (PWAD override)
    if not found:
        raise PaletteError(f"{name}: no PLAYPAL lump in this WAD.")
    offs, size = found
    if size < PAL_BYTES or offs + PAL_BYTES > len(data):
        raise PaletteError(f"{name}: PLAYPAL lump is too small ({size} bytes).")
    count = size // PAL_BYTES
    return _bytes_to_pal(data[offs:offs + PAL_BYTES]), f"{name}  (WAD PLAYPAL, {count} palettes, pal0)"


def _from_png(path, name):
    from PIL import Image
    try:
        im = Image.open(path)
        im.load()
    except Exception as e:
        raise PaletteError(f"{name}: can't read PNG ({e}).")
    w, h = im.size
    rgba = im.convert("RGBA")
    px = rgba.load()

    # SLADE-style 16x16 grid (any cell size, borders or not) - sample cell
    # centres. Cells must be solid colour, so a 64x64 flat isn't mistaken for one.
    if w == h and w % 16 == 0 and _looks_like_grid(px, w // 16):
        cell = w // 16
        cols = []
        for i in range(256):
            cx = (i % 16) * cell + cell // 2
            cy = (i // 16) * cell + cell // 2
            cols.append(px[cx, cy][:3])
        return cols, f"{name}  (16x16 grid png, cell {cell}px)"

    # DoomTools playpal strip / COLORMAP png - row 0
    if w == 256:
        what = "COLORMAP png" if h in (32, 33, 34) else (
            "pal0 strip png" if h == 1 else f"playpal png, {h} rows")
        return [px[x, 0][:3] for x in range(256)], f"{name}  ({what}, row 0)"

    # Any other paletted PNG - use its embedded palette
    if im.mode == "P":
        raw = im.getpalette() or []
        cols = [tuple(raw[i:i + 3]) for i in range(0, len(raw) - 2, 3)]
        if cols:
            return _pad(cols), f"{name}  (embedded PNG palette, {len(cols)} colours)"

    raise PaletteError(
        f"{name}: {w}x{h} PNG isn't a palette layout (need a square 16x16 grid, "
        "a 256-wide strip, or a paletted PNG).")


def _looks_like_grid(px, cell):
    if cell == 1:
        return True
    lo, hi = cell // 4, cell - 1 - cell // 4
    good = 0
    for i in range(256):
        x0, y0 = (i % 16) * cell, (i // 16) * cell
        c = px[x0 + cell // 2, y0 + cell // 2]
        if all(px[x0 + dx, y0 + dy] == c for dx in (lo, hi) for dy in (lo, hi)):
            good += 1
    return good >= 243   # ~95% solid cells


def _from_jasc(data, name):
    lines = data.decode("ascii", "replace").splitlines()
    cols = []
    for line in lines[3:]:
        parts = line.split()
        if len(parts) >= 3:
            try:
                cols.append(tuple(int(p) for p in parts[:3]))
            except ValueError:
                pass
    if not cols:
        raise PaletteError(f"{name}: JASC-PAL file has no colours.")
    return _pad(cols), f"{name}  (JASC-PAL, {len(cols)} colours)"


def _from_gpl(data, name):
    cols = []
    for line in data.decode("utf-8", "replace").splitlines()[1:]:
        s = line.strip()
        if not s or s.startswith("#") or ":" in s.split()[0]:
            continue
        parts = s.split()
        try:
            cols.append(tuple(int(p) for p in parts[:3]))
        except ValueError:
            pass
    if not cols:
        raise PaletteError(f"{name}: GIMP palette has no colours.")
    return _pad(cols), f"{name}  (GIMP palette, {len(cols)} colours)"
