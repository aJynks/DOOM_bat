"""
export_dialog.py - batch export: apply the current translation to many
graphics from the open source and write each as its own PNG.

Filter box narrows the list (name substring); Select All / None / Invert act
on the rows currently shown only. Selections survive filter changes.
"""

import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .dpi import S


class ExportDialog(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.entries = app.source.entries
        self.title(f"Export - {os.path.basename(app.source.path.rstrip(os.sep)) or app.source.path}")
        self.transient(app.root)
        self.selected = set()
        if app.entry is not None and app.entry in self.entries:
            self.selected.add(self.entries.index(app.entry))
        self.visible = []
        self._quiet = False
        self._job = None
        pad = S(6)

        top = ttk.Frame(self, padding=pad)
        top.pack(fill="x")
        ttk.Label(top, text="Filter:").pack(side="left")
        self.var_filter = tk.StringVar()
        ent = ttk.Entry(top, textvariable=self.var_filter, width=24)
        ent.pack(side="left", padx=(S(4), S(12)))
        self.var_filter.trace_add("write", lambda *a: self._rebuild())
        for txt, cb in (("Select All", self._all), ("Select None", self._none), ("Invert", self._invert)):
            ttk.Button(top, text=txt, command=cb).pack(side="left", padx=(0, S(4)))

        mid = ttk.Frame(self, padding=(pad, 0))
        mid.pack(fill="both", expand=True)
        cols = ("type", "size", "offsets", "note")
        self.tree = ttk.Treeview(mid, columns=cols, selectmode="extended", height=18)
        self.tree.heading("#0", text="Name")
        self.tree.column("#0", width=S(120), stretch=False)
        for c, wdt in zip(cols, (80, 80, 80, 200)):
            self.tree.heading(c, text=c.capitalize())
            self.tree.column(c, width=S(wdt), stretch=(c == "note"))
        ys = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=ys.set)
        self.tree.pack(side="left", fill="both", expand=True)
        ys.pack(side="left", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._tree_sel)

        out = ttk.Frame(self, padding=pad)
        out.pack(fill="x")
        ttk.Label(out, text="Output folder:").pack(side="left")
        self.var_dir = tk.StringVar(value=app.default_export_dir())
        ttk.Entry(out, textvariable=self.var_dir).pack(side="left", fill="x", expand=True, padx=(S(4), S(4)))
        ttk.Button(out, text="Browse…", command=self._browse).pack(side="left")

        info = ttk.Frame(self, padding=(pad, 0, pad, 0))
        info.pack(fill="x")
        mode = "truecolour RGBA" if app.var_truecolor.get() else "paletted"
        ttk.Label(info, text=f"Each graphic is written as NAME.png ({mode}, offsets kept in grAb).",
                  foreground="#808080").pack(side="left")
        self.lbl_count = ttk.Label(info, text="")
        self.lbl_count.pack(side="right")

        bot = ttk.Frame(self, padding=pad)
        bot.pack(fill="x")
        self.progress = ttk.Progressbar(bot, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True, padx=(0, S(8)))
        self.btn_export = ttk.Button(bot, text="Export", command=self._export)
        self.btn_export.pack(side="left")
        ttk.Button(bot, text="Close", command=self._close).pack(side="left", padx=(S(4), 0))
        self.lbl_status = ttk.Label(self, text="", padding=(pad, 0, pad, pad), anchor="w")
        self.lbl_status.pack(fill="x")

        self.protocol("WM_DELETE_WINDOW", self._close)
        self.geometry(f"{S(700)}x{S(600)}")
        self._rebuild()
        ent.focus_set()

    # ------------------------------------------------------------ list/sel
    def _rebuild(self):
        ft = self.var_filter.get().strip().lower()
        self.visible = [i for i, e in enumerate(self.entries) if ft in e.name.lower()]
        self._quiet = True
        self.tree.delete(*self.tree.get_children())
        for i in self.visible:
            e = self.entries[i]
            self.tree.insert("", "end", iid=str(i), text=e.name,
                             values=(e.kind, e.size_text(), e.offs_text(), e.note))
        self.tree.selection_set([str(i) for i in self.visible if i in self.selected])
        self.after_idle(self._unquiet)
        self._update_count()

    def _unquiet(self):
        self._quiet = False

    def _tree_sel(self, _e):
        if self._quiet:
            return
        now = {int(x) for x in self.tree.selection()}
        self.selected = (self.selected - set(self.visible)) | now
        self._update_count()

    def _set_visible_sel(self, ids):
        self.selected = (self.selected - set(self.visible)) | set(ids)
        self._quiet = True
        self.tree.selection_set([str(i) for i in self.visible if i in self.selected])
        self.after_idle(self._unquiet)
        self._update_count()

    def _all(self):
        self._set_visible_sel(self.visible)

    def _none(self):
        self._set_visible_sel([])

    def _invert(self):
        self._set_visible_sel([i for i in self.visible if i not in self.selected])

    def _update_count(self):
        shown = len(self.visible)
        self.lbl_count.configure(
            text=f"{len(self.selected)} of {len(self.entries)} selected   ({shown} shown)")

    def _browse(self):
        d = filedialog.askdirectory(parent=self, initialdir=self.var_dir.get() or None,
                                    title="Export to folder")
        if d:
            self.var_dir.set(d)

    # --------------------------------------------------------------- export
    def _export(self):
        if self._job:
            return
        out = self.var_dir.get().strip()
        if not self.selected:
            self.lbl_status.configure(text="Nothing selected.")
            return
        if not out:
            self.lbl_status.configure(text="Choose an output folder.")
            return
        src = os.path.abspath(self.app.source.path)
        if os.path.isdir(src) and os.path.normcase(os.path.abspath(out)) == os.path.normcase(src):
            if not messagebox.askyesno("Export", "The output folder is the source folder.\n"
                                       "Files with the same names will be replaced. Continue?",
                                       parent=self):
                return
        try:
            os.makedirs(out, exist_ok=True)
        except OSError as e:
            messagebox.showerror("Export", str(e), parent=self)
            return

        # build the job list, de-duplicating names (e.g. a texture and patch both called SKY1)
        used, jobs = set(), []
        for i in sorted(self.selected):
            e = self.entries[i]
            fn = f"{e.name}.png"
            if fn.lower() in used:
                fn = f"{e.name}_{e.kind.lower()}.png"
            n = 2
            while fn.lower() in used:
                fn = f"{e.name}_{e.kind.lower()}{n}.png"
                n += 1
            used.add(fn.lower())
            jobs.append((e, os.path.join(out, fn)))

        existing = [p for _, p in jobs if os.path.exists(p)]
        skip_existing = False
        if existing:
            ans = messagebox.askyesnocancel(
                "Export", f"{len(existing)} of {len(jobs)} files already exist in the output folder.\n\n"
                          "Yes = overwrite them\nNo = skip them\nCancel = stop", parent=self)
            if ans is None:
                return
            skip_existing = not ans

        self.app.cfg["export_dir"] = out
        self.btn_export.configure(state="disabled")
        self.progress.configure(maximum=len(jobs), value=0)
        self._state = {"jobs": jobs, "pos": 0, "written": 0, "skipped": 0, "failed": [],
                       "warnings": [], "skip": skip_existing}
        self._job = self.after(1, self._step)

    def _step(self):
        st = self._state
        end = min(len(st["jobs"]), st["pos"] + 4)
        for k in range(st["pos"], end):
            e, path = st["jobs"][k]
            if st["skip"] and os.path.exists(path):
                st["skipped"] += 1
                continue
            try:
                st["warnings"] += self.app.export_entry(e, path)
                st["written"] += 1
            except Exception as ex:
                st["failed"].append(f"{e.name}: {ex}")
        st["pos"] = end
        self.progress.configure(value=end)
        self.lbl_status.configure(text=f"Exporting {end}/{len(st['jobs'])}…")
        if end < len(st["jobs"]):
            self._job = self.after(1, self._step)
            return
        self._job = None
        self.btn_export.configure(state="normal")
        msg = f"Done: {st['written']} written, {st['skipped']} skipped, {len(st['failed'])} failed."
        self.lbl_status.configure(text=msg)
        self.app.status(msg)
        extra = st["failed"] + st["warnings"]
        if extra:
            more = f"\n… and {len(extra) - 20} more" if len(extra) > 20 else ""
            messagebox.showwarning("Export", msg + "\n\n" + "\n".join(extra[:20]) + more, parent=self)

    def _close(self):
        if self._job:
            self.after_cancel(self._job)
            self._job = None
        self.destroy()
