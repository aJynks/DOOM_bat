"""
paint_strip.py - Paint mode controls, shown above the sprite in Paint mode.

  Tool: (Brush) (Rectangle)   Shape [Circle]   Size [===]  5      Start from [Batch result]
  [Apply] [Undo] [Redo] [Clear selection] [Pick from selection]       [Save All Changed]
"""

import tkinter as tk
from tkinter import ttk

from ..paint import SHAPES
from .dpi import S


class PaintStrip(ttk.Frame):
    def __init__(self, master, on_change, on_apply, on_undo, on_redo, on_clear,
                 on_pick=None, on_start=None, on_save_all=None):
        super().__init__(master)
        self.on_change = on_change
        self.start = tk.StringVar(value="Batch result")
        self.tool = tk.StringVar(value="brush")
        self.shape = tk.StringVar(value="Circle")
        self.size = tk.IntVar(value=5)

        row1 = ttk.Frame(self)
        row1.pack(fill="x")
        row2 = ttk.Frame(self)
        row2.pack(fill="x", pady=(S(3), 0))

        ttk.Label(row1, text="Tool:").pack(side="left")
        for val, txt in (("brush", "Brush"), ("rect", "Rectangle")):
            ttk.Radiobutton(row1, text=txt, value=val, variable=self.tool,
                            command=on_change).pack(side="left", padx=(S(4), 0))
        ttk.Label(row1, text="Shape:").pack(side="left", padx=(S(12), S(4)))
        cb = ttk.Combobox(row1, textvariable=self.shape, values=SHAPES, state="readonly", width=8)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: on_change())
        ttk.Label(row1, text="Size:").pack(side="left", padx=(S(12), S(4)))
        self.scale = ttk.Scale(row1, from_=1, to=32, orient="horizontal", length=S(110),
                               command=self._size_moved)
        self.scale.set(5)
        self.scale.pack(side="left")
        self.size_lbl = ttk.Label(row1, text="5", width=3)
        self.size_lbl.pack(side="left", padx=(S(4), 0))
        sc = ttk.Combobox(row1, textvariable=self.start, state="readonly", width=12,
                          values=("Batch result", "Original"))
        sc.pack(side="right")
        sc.bind("<<ComboboxSelected>>", lambda e: on_start and on_start(self.start.get()))
        ttk.Label(row1, text="Start from:").pack(side="right", padx=(0, S(4)))

        ttk.Button(row2, text="Apply", command=on_apply).pack(side="left")
        ttk.Button(row2, text="Undo", command=on_undo).pack(side="left", padx=(S(4), 0))
        ttk.Button(row2, text="Redo", command=on_redo).pack(side="left", padx=(S(4), 0))
        ttk.Button(row2, text="Clear selection", command=on_clear).pack(side="left", padx=(S(4), 0))
        ttk.Button(row2, text="Pick from selection", command=on_pick).pack(side="left", padx=(S(4), 0))
        ttk.Button(row2, text="Save All Changed", command=on_save_all).pack(side="right")
        ttk.Label(self, text="Enter apply \u00b7 Ctrl+Z / Ctrl+Y \u00b7 Esc clear \u00b7 "
                             "brush adds, Alt erases \u00b7 rectangle replaces, Shift adds",
                  foreground="#808080").pack(anchor="w", pady=(S(2), 0))

    def _size_moved(self, v):
        n = max(1, int(round(float(v))))
        if n != self.size.get():
            self.size.set(n)
            self.size_lbl.configure(text=str(n))
            self.on_change()

    def set_values(self, tool, shape, size):
        self.tool.set(tool if tool in ("brush", "rect") else "brush")
        self.shape.set(shape if shape in SHAPES else "Circle")
        self.size.set(max(1, min(32, int(size))))
        self.scale.set(self.size.get())
        self.size_lbl.configure(text=str(self.size.get()))
