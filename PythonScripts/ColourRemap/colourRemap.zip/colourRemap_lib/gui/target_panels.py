"""
target_panels.py - the "Target Range" panels that swap with the range type:
  GradientTarget - From/To colours + gradient strip (colour and desat ranges)
  TintTarget     - colour + amount slider (colourise hides the slider)
"""

import tkinter as tk
from tkinter import ttk, colorchooser

from .dpi import S, hexcol


class ColourSwatch(tk.Canvas):
    """Click to pick a colour; on_change(rgb) fires after picking."""

    def __init__(self, master, colour=(0, 0, 0), on_change=None, size=40):
        w, h = S(size), S(22)
        super().__init__(master, width=w, height=h, highlightthickness=1,
                         highlightbackground="#808080", cursor="hand2")
        self.colour = tuple(colour)
        self.on_change = on_change
        self._rect = self.create_rectangle(0, 0, w + 2, h + 2, outline="")
        self.set(colour)
        self.bind("<Button-1>", self._pick)

    def set(self, rgb):
        self.colour = tuple(int(v) for v in rgb[:3])
        self.itemconfigure(self._rect, fill=hexcol(self.colour))

    def _pick(self, _e):
        res = colorchooser.askcolor(color=hexcol(self.colour), parent=self)
        if res and res[0]:
            self.set(tuple(int(v) for v in res[0]))
            if self.on_change:
                self.on_change(self.colour)


class GradientTarget(ttk.Frame):
    def __init__(self, master, on_change):
        super().__init__(master)
        self.on_change = on_change
        row = ttk.Frame(self)
        row.grid(row=0, column=0, sticky="ew")
        ttk.Label(row, text="From").grid(row=0, column=0, padx=(0, S(4)))
        self.c1 = ColourSwatch(row, (0, 0, 0), self._changed)
        self.c1.grid(row=0, column=1)
        ttk.Label(row, text="To").grid(row=0, column=2, padx=(S(10), S(4)))
        self.c2 = ColourSwatch(row, (255, 255, 255), self._changed)
        self.c2.grid(row=0, column=3)

        self.strip = tk.Canvas(self, width=S(210), height=S(20), highlightthickness=1,
                               highlightbackground="#808080")
        self.strip.grid(row=1, column=0, sticky="ew", pady=(S(6), 0))
        self.note = ttk.Label(self, text="", foreground="#808080")
        self.note.grid(row=2, column=0, sticky="w", pady=(S(4), 0))
        self.steps = 0

    def set(self, c1, c2, steps=0, note=""):
        self.c1.set(c1)
        self.c2.set(c2)
        self.steps = steps
        self.note.configure(text=note)
        self._draw()

    def _changed(self, _c):
        self._draw()
        self.on_change(self.c1.colour, self.c2.colour)

    def _draw(self):
        self.strip.delete("all")
        w = int(self.strip.cget("width"))
        h = int(self.strip.cget("height"))
        a, b = self.c1.colour, self.c2.colour
        n = self.steps if self.steps > 1 else w
        for k in range(n):
            f = k / (n - 1) if n > 1 else 0
            col = tuple(int(a[i] + f * (b[i] - a[i])) for i in range(3))
            x0 = k * w / n
            self.strip.create_rectangle(x0, 0, (k + 1) * w / n + 1, h + 2, fill=hexcol(col), outline="")


class TintTarget(ttk.Frame):
    def __init__(self, master, on_colour, on_amount):
        super().__init__(master)
        self.on_amount = on_amount
        ttk.Label(self, text="Colour").grid(row=0, column=0, sticky="w")
        self.col = ColourSwatch(self, (255, 0, 0), on_colour)
        self.col.grid(row=0, column=1, sticky="w", padx=(S(6), 0))
        self.amount_lbl = ttk.Label(self, text="Amount")
        self.amount = tk.IntVar(value=50)
        self.slider = ttk.Scale(self, from_=0, to=100, orient="horizontal",
                                length=S(160), command=self._slide)
        self.value_lbl = ttk.Label(self, text="50%", width=5)
        self.amount_lbl.grid(row=1, column=0, sticky="w", pady=(S(6), 0))
        self.slider.grid(row=1, column=1, sticky="w", padx=(S(6), 0), pady=(S(6), 0))
        self.value_lbl.grid(row=1, column=2, sticky="w", pady=(S(6), 0))
        self._quiet = True
        self.slider.set(50)
        self._quiet = False

    def show_amount(self, show):
        for w in (self.amount_lbl, self.slider, self.value_lbl):
            if show:
                w.grid()
            else:
                w.grid_remove()

    def set(self, colour, amount=None):
        self.col.set(colour)
        if amount is not None:
            self._quiet = True
            self.slider.set(amount)
            self.value_lbl.configure(text=f"{int(amount)}%")
            self._quiet = False

    def _slide(self, v):
        a = int(float(v))
        self.value_lbl.configure(text=f"{a}%")
        if not self._quiet:
            self.on_amount(a)
