"""Tk GUI for colourRemap. Only this package imports tkinter."""
