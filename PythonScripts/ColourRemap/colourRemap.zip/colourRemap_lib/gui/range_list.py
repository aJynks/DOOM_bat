"""
range_list.py - "Translation Ranges" list with a column of + / - / up / down
buttons beside it (SLADE layout).
"""

import tkinter as tk
from tkinter import ttk

from .dpi import S


class RangeList(ttk.Frame):
    def __init__(self, master, on_select, on_add, on_remove, on_up, on_down):
        super().__init__(master)
        self.on_select = on_select
        self.listbox = tk.Listbox(self, height=6, width=26, exportselection=False,
                                  activestyle="none", font=("Consolas", 9))
        sb = ttk.Scrollbar(self, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=sb.set)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        btns = ttk.Frame(self)
        btns.grid(row=0, column=2, sticky="n", padx=(S(6), 0))
        for n, (txt, cb, tip) in enumerate((("+", on_add, "Add"), ("\u2212", on_remove, "Remove"),
                                            ("\u25b2", on_up, "Up"), ("\u25bc", on_down, "Down"))):
            ttk.Button(btns, text=txt, command=cb, width=3).grid(row=n, column=0, pady=(0, S(3)))
        self.listbox.bind("<<ListboxSelect>>", self._sel)

    def set_items(self, labels, selected):
        self.listbox.delete(0, "end")
        for l in labels:
            self.listbox.insert("end", l)
        if labels:
            selected = max(0, min(selected, len(labels) - 1))
            self.listbox.selection_set(selected)
            self.listbox.see(selected)

    def update_item(self, index, label):
        if 0 <= index < self.listbox.size():
            self.listbox.delete(index)
            self.listbox.insert(index, label)
            self.listbox.selection_set(index)

    def selected(self):
        s = self.listbox.curselection()
        return s[0] if s else -1

    def _sel(self, _e):
        i = self.selected()
        if i >= 0:
            self.on_select(i)
