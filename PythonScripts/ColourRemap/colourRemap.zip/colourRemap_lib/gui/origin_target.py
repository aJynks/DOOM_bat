"""
origin_target.py - the Origin -> Target panel.

Both halves sit in one panel and scale as one: the two halves are equal-width
columns, and the row under the grids is shared, so the origin and target
grids always get the same cell size.

  Palette Range:  [origin 32x8]  ▶  [target 32x8]
                  origin info         Reverse Selection
  other types:    [origin 32x8]  ▶  [mode controls in the right half]

When the current range is a pick group (indices picked from the sprite) the
row under the origin shows the picks and an Order dropdown.
"""

import tkinter as tk
from tkinter import ttk

from .dpi import S
from .palette_grid import PaletteGrid


ORDERS = [("bright", "Brightness"), ("index", "Index")]


class OriginTarget(ttk.Frame):
    def __init__(self, master, on_origin_select, on_target_select, on_reverse, on_hover,
                 on_order=None):
        super().__init__(master)
        self.columnconfigure(0, weight=1, uniform="half")
        self.columnconfigure(2, weight=1, uniform="half")

        ttk.Label(self, text="Origin", style="Half.TLabel").grid(row=0, column=0, sticky="nw")
        self.grid_origin = PaletteGrid(self, cols=32, on_select=on_origin_select,
                                       on_hover=lambda i: on_hover(i))
        self.grid_origin.grid(row=1, column=0, sticky="nsew")
        info = ttk.Frame(self)
        info.grid(row=2, column=0, sticky="ew", pady=(S(4), 0))
        info.columnconfigure(0, weight=1)
        self.origin_info = ttk.Label(info, text="", foreground="#808080", anchor="w", width=10)
        self.origin_info.grid(row=0, column=0, sticky="ew")
        self.on_order = on_order
        self.order_var = tk.StringVar(value=ORDERS[0][1])
        self.order_lbl = ttk.Label(info, text="Order:")
        self.order_cb = ttk.Combobox(info, textvariable=self.order_var, state="readonly",
                                     width=11, values=[l for _, l in ORDERS])
        self.order_cb.bind("<<ComboboxSelected>>", self._order_changed)

        sep = ttk.Frame(self)
        sep.grid(row=0, column=1, rowspan=3, sticky="ns", padx=S(6))
        ttk.Separator(sep, orient="vertical").pack(side="left", fill="y")
        ttk.Label(sep, text="\u25b6", font=("Segoe UI", 12)).pack(side="left", padx=S(4))
        ttk.Separator(sep, orient="vertical").pack(side="left", fill="y")

        self.target_title = ttk.Label(self, text="Target", style="Half.TLabel")
        self.target_title.grid(row=0, column=2, sticky="nw")
        self.grid_target = PaletteGrid(self, cols=32, on_select=on_target_select,
                                       on_hover=lambda i: on_hover(i))
        self.reverse = tk.BooleanVar(value=False)
        self.cb_reverse = ttk.Checkbutton(self, text="Reverse Selection", variable=self.reverse,
                                          command=on_reverse)
        # holder for gradient / tint / info controls (replaces the target grid)
        self.controls = ttk.Frame(self)
        self.rowconfigure(1, weight=1)
        self._mode = None
        self.show_target()

    def show_target(self):
        if self._mode == "target":
            return
        self.controls.grid_remove()
        self.grid_target.grid(row=1, column=2, sticky="nsew")
        self.cb_reverse.grid(row=2, column=2, sticky="w", pady=(S(4), 0))
        self.target_title.configure(text="Target")
        self._mode = "target"

    def show_controls(self, title):
        self.target_title.configure(text=title)
        if self._mode == "controls":
            return
        self.grid_target.grid_remove()
        self.cb_reverse.grid_remove()
        self.controls.grid(row=1, column=2, rowspan=2, sticky="nsew")
        self._mode = "controls"

    def set_colours(self, colours):
        self.grid_origin.set_colours(colours)
        self.grid_target.set_colours(colours)

    def set_origin_info(self, start, end):
        n = end - start + 1
        self.origin_info.configure(text=f"{start}:{end}  ({n} colour{'s' if n != 1 else ''})")
        self.order_lbl.grid_remove()
        self.order_cb.grid_remove()

    def set_picks_info(self, indices, order):
        n = len(indices)
        if n:
            shown = " ".join(str(i) for i in sorted(indices)[:12]) + (" …" if n > 12 else "")
            self.origin_info.configure(text=f"Picks ({n}): {shown}")
        else:
            self.origin_info.configure(text="Picks: none - click or drag on the sprite")
        self.order_var.set(dict(ORDERS).get(order, ORDERS[0][1]))
        self.order_lbl.grid(row=0, column=1, padx=(S(6), S(4)))
        self.order_cb.grid(row=0, column=2)

    def _order_changed(self, _e):
        key = next((k for k, l in ORDERS if l == self.order_var.get()), "bright")
        if self.on_order:
            self.on_order(key)
