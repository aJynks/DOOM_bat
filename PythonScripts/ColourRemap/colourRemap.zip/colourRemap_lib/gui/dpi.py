"""
dpi.py - Windows DPI awareness and pixel scaling helpers.

Call enable() BEFORE creating the Tk root, then init(root) once.
S(px) converts a 96-dpi design size to real screen pixels.
"""

import sys

_scale = 1.0


def enable():
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)   # per-monitor
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def init(root):
    global _scale
    try:
        _scale = max(1.0, root.winfo_fpixels("1i") / 96.0)
    except Exception:
        _scale = 1.0
    return _scale


def S(px):
    return max(1, int(round(px * _scale)))


def scale():
    return _scale


def hexcol(rgb):
    return "#%02x%02x%02x" % tuple(int(v) for v in rgb[:3])
