"""
palette_grid.py - reusable palette grid widget (16x16 or 32x8, etc).

Resizes with its panel: cells stay square, as large as fits, centred.
selectable=True: press-drag-release selects a linear index span (like
SLADE); on_select(start, end) fires on release.
set_picks(indices) shows an arbitrary set of indices instead of a span.
set_marker(index or None) draws the hover marker (sprite hover).
on_hover(index or None) fires as the mouse moves.
"""

import tkinter as tk

from .dpi import S, hexcol

SEL_COLOUR = "#ffffff"
SEL_SHADOW = "#000000"
MARK_COLOUR = "#ffe000"
GRID_LINE = "#1a1a1a"


class PaletteGrid(tk.Canvas):
    def __init__(self, master, cols=16, cell=12, selectable=True, on_select=None,
                 on_hover=None, bg="#202020", **kw):
        self.cols = cols
        self.rows = 256 // cols
        self.cell = S(cell)
        self.x0 = self.y0 = 0
        super().__init__(master, width=self.cell * self.cols + S(4),
                         height=self.cell * self.rows + S(4),
                         highlightthickness=0, bg=bg, **kw)
        self.selectable = selectable
        self.on_select = on_select
        self.on_hover = on_hover
        self.colours = [(0, 0, 0)] * 256
        self.sel = None
        self.picks = None
        self.marker = None
        self._anchor = None
        self._cells = [self.create_rectangle(0, 0, 1, 1, fill="#000000", outline=GRID_LINE)
                       for _ in range(256)]
        self._sel_items = []
        self._mark_items = []

        self.bind("<Configure>", self._on_resize)
        self.bind("<Motion>", self._motion)
        self.bind("<Leave>", lambda e: self.on_hover and self.on_hover(None))
        if selectable:
            self.bind("<ButtonPress-1>", self._press)
            self.bind("<B1-Motion>", self._drag)
            self.bind("<ButtonRelease-1>", self._release)

    # ------------------------------------------------------------------ api
    def set_colours(self, colours):
        self.colours = list(colours)
        for i, c in enumerate(self.colours):
            self.itemconfigure(self._cells[i], fill=hexcol(c))

    def set_selection(self, start, end=None):
        self.picks = None
        if start is None:
            self.sel = None
        else:
            end = start if end is None else end
            self.sel = (min(start, end), max(start, end))
        self._draw_sel()

    def set_picks(self, indices):
        """Show an arbitrary set of indices as selected."""
        self.sel = None
        self.picks = sorted(set(indices))
        self._draw_sel()

    def set_marker(self, index):
        if index == self.marker:
            return
        self.marker = index
        self._draw_marker()

    # ------------------------------------------------------------- geometry
    def _on_resize(self, e):
        pad = S(2)
        cell = max(3, min((e.width - pad * 2) // self.cols, (e.height - pad * 2) // self.rows))
        self.cell = cell
        self.x0 = (e.width - cell * self.cols) // 2
        self.y0 = (e.height - cell * self.rows) // 2
        for i in range(256):
            x, y = self._cell_xy(i)
            self.coords(self._cells[i], x, y, x + cell, y + cell)
        self._draw_sel()
        self._draw_marker()

    def _cell_xy(self, i):
        return self.x0 + (i % self.cols) * self.cell, self.y0 + (i // self.cols) * self.cell

    def index_at(self, x, y):
        cx = (x - self.x0) // self.cell
        cy = (y - self.y0) // self.cell
        if 0 <= cx < self.cols and 0 <= cy < self.rows:
            return int(cy * self.cols + cx)
        return None

    def _draw_sel(self):
        for it in self._sel_items:
            self.delete(it)
        self._sel_items = []
        if self.picks is not None:
            cells = self.picks
        elif self.sel:
            cells = range(self.sel[0], self.sel[1] + 1)
        else:
            cells = ()
        w = max(1, S(1))
        c = self.cell
        for i in cells:
            x, y = self._cell_xy(i)
            self._sel_items.append(self.create_rectangle(
                x + w, y + w, x + c - w, y + c - w, outline=SEL_SHADOW, width=w))
            self._sel_items.append(self.create_rectangle(
                x, y, x + c, y + c, outline=SEL_COLOUR, width=w))
        for it in self._mark_items:
            self.tag_raise(it)

    def _draw_marker(self):
        for it in self._mark_items:
            self.delete(it)
        self._mark_items = []
        if self.marker is None:
            return
        x, y = self._cell_xy(self.marker)
        c = self.cell
        w = max(2, S(2))
        o = w + max(1, S(1))
        self._mark_items.append(self.create_rectangle(
            x - o, y - o, x + c + o, y + c + o, outline=SEL_SHADOW, width=w + 2))
        self._mark_items.append(self.create_rectangle(
            x - o, y - o, x + c + o, y + c + o, outline=MARK_COLOUR, width=w))

    # ---------------------------------------------------------------- mouse
    def _motion(self, e):
        if self.on_hover:
            self.on_hover(self.index_at(e.x, e.y))

    def _press(self, e):
        i = self.index_at(e.x, e.y)
        if i is None:
            return
        self._anchor = i
        self.set_selection(i, i)

    def _drag(self, e):
        self._motion(e)
        if self._anchor is None:
            return
        x = min(max(e.x, self.x0), self.x0 + self.cell * self.cols - 1)
        y = min(max(e.y, self.y0), self.y0 + self.cell * self.rows - 1)
        i = self.index_at(x, y)
        if i is not None:
            self.set_selection(self._anchor, i)

    def _release(self, e):
        if self._anchor is None:
            return
        self._anchor = None
        if self.sel and self.on_select:
            self.on_select(*self.sel)
