"""
image_picker.py - the image dropdown above the preview.

Type in the box to filter by name (case-insensitive substring), pick from the
dropdown, or step with the up/down buttons / Up and Down keys. Stepping stays
inside the current filter and wraps at the ends. mark(entry) -> True puts a
"*" in front of that entry (Paint mode: unsaved changes).
"""

import tkinter as tk
from tkinter import ttk

from .dpi import S

_IGNORE_KEYS = {"Up", "Down", "Return", "KP_Enter", "Escape", "Tab", "Shift_L", "Shift_R",
                "Control_L", "Control_R", "Alt_L", "Alt_R", "Left", "Right", "Home", "End"}


class ImagePicker(ttk.Frame):
    def __init__(self, master, on_pick):
        super().__init__(master)
        self.on_pick = on_pick
        self.mark = lambda e: False
        self.entries = []
        self.filtered = []
        self.current = -1
        self.var = tk.StringVar()
        self.combo = ttk.Combobox(self, textvariable=self.var, font=("Consolas", 9), height=24)
        self.combo.grid(row=0, column=0, sticky="ew")
        ttk.Button(self, text="\u25b2", width=3, command=lambda: self.step(-1)).grid(row=0, column=1, padx=(S(4), 0))
        ttk.Button(self, text="\u25bc", width=3, command=lambda: self.step(1)).grid(row=0, column=2, padx=(S(2), 0))
        self.count = ttk.Label(self, text="", width=14, anchor="e")
        self.count.grid(row=0, column=3, padx=(S(6), 0))
        self.columnconfigure(0, weight=1)

        c = self.combo
        c.bind("<<ComboboxSelected>>", self._selected)
        c.bind("<KeyRelease>", self._typed)
        c.bind("<Up>", lambda e: (self.step(-1), "break")[1])
        c.bind("<Down>", lambda e: (self.step(1), "break")[1])
        c.bind("<Return>", self._enter)
        c.bind("<FocusIn>", lambda e: c.select_range(0, "end"))

    # ------------------------------------------------------------------ api
    def set_entries(self, entries, pick_index=0):
        self.entries = entries
        self.var.set("")
        self._apply_filter("")
        if entries:
            self.pick(max(0, min(pick_index, len(entries) - 1)))
        else:
            self.current = -1

    def step(self, d):
        if not self.filtered:
            return
        if self.current in self.filtered:
            pos = (self.filtered.index(self.current) + d) % len(self.filtered)
        else:
            pos = 0 if d > 0 else len(self.filtered) - 1
        self.pick(self.filtered[pos])

    def pick(self, i):
        self.current = i
        self.var.set(self._label(self.entries[i]))
        self._update_count()
        self.on_pick(self.entries[i])

    # ------------------------------------------------------------- internal
    def _apply_filter(self, text):
        ft = text.strip().lower()
        self.filtered = [i for i, e in enumerate(self.entries) if ft in e.name.lower()]
        self.combo.configure(values=[self._label(self.entries[i]) for i in self.filtered])
        self._update_count()

    def _label(self, e):
        return ("* " if self.mark(e) else "  ") + e.label()

    def refresh_labels(self):
        """Redraw labels after unsaved markers change."""
        self.combo.configure(values=[self._label(self.entries[i]) for i in self.filtered])
        if 0 <= self.current < len(self.entries):
            self.var.set(self._label(self.entries[self.current]))

    def _update_count(self):
        n, t = len(self.filtered), len(self.entries)
        if self.current in self.filtered:
            self.count.configure(text=f"{self.filtered.index(self.current) + 1} / {n}" +
                                 (f"  ({t})" if n != t else ""))
        else:
            self.count.configure(text=f"{n} match{'es' if n != 1 else ''}")

    def _typed(self, e):
        if e.keysym in _IGNORE_KEYS:
            return
        self._apply_filter(self.var.get())

    def _selected(self, _e):
        k = self.combo.current()
        if 0 <= k < len(self.filtered):
            self.pick(self.filtered[k])

    def _enter(self, _e):
        if self.filtered:
            if self.current not in self.filtered:
                self.pick(self.filtered[0])
        return "break"
