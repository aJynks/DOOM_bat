"""
preview.py - the sprite window.

Mouse in this window:
  wheel        zoom toward the cursor
  middle-drag  pan (purely visual, never touches offsets)
  Space+left-drag  pan as well (cursor turns to a move cursor while Space is held)
  left-click   pick the pixel under the cursor
  left-drag    marquee: pick every pixel in the box
  Shift = add to the picks, Alt = subtract (Photoshop style)
The canvas takes keyboard focus when the mouse enters it, unless a text box
has focus - so Space never pans while you're typing a filter or string.
on_pick(x0, y0, x1, y1, mode) gets the inclusive image rect, mode is
"replace" / "add" / "subtract".
Paint mode: set tool = "brush" and left-drag calls on_brush(phase, x, y, mode)
with phase "start" / "move" / "end"; tool = "rect" uses the marquee/on_pick. set_outline(mask) outlines picked pixels.
on_hover(x, y) reports image pixels.
"""

import sys
import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageChops, ImageFilter, ImageTk

from .dpi import S

CHECK_A = (52, 52, 64)
CHECK_B = (68, 68, 82)
ZOOMS = [0.125, 0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32]
FULL_RENDER_LIMIT = 6_000_000   # scaled pixels; above this only the visible area is drawn
OUTLINE_RGB = (0, 255, 255)
MARQUEE = "#ffe000"
DRAG_PX = 3                     # movement before a click becomes a marquee


class Preview(ttk.Frame):
    def __init__(self, master, on_hover=None, on_zoom=None, on_pick=None):
        super().__init__(master)
        self.on_hover = on_hover
        self.on_zoom = on_zoom
        self.on_pick = on_pick
        self.outline = None            # L-mode mask (image size) of picked pixels
        self._sel = None               # (x0, y0, mode) of a left drag in progress
        self._marquee = None
        self.tool = "pick"             # "pick" (Batch), "brush" or "rect" (Paint)
        self.on_brush = None
        self.brush_size = 1
        self._brush_item = None
        self._brushing = False
        self._space = False            # Space held: left-drag pans
        self._lpan = False             # current left drag is a pan
        self.canvas = tk.Canvas(self, width=S(360), height=S(260), highlightthickness=0,
                                bg="#343442")
        self.canvas.pack(fill="both", expand=True)
        self.image = None
        self.zoom = 1
        self.ox = self.oy = 0          # canvas position of the image's top-left
        self._bg_photo = None
        self._photo = None
        self._bg_item = None
        self._img_item = None
        self._full = False             # whole scaled image rendered (pan = move only)
        self._drag = None
        self._pending = None

        c = self.canvas
        c.bind("<Configure>", self._on_resize)
        c.bind("<Motion>", self._motion)
        c.bind("<Leave>", self._leave)
        c.bind("<MouseWheel>", self._wheel)                       # Windows / mac
        c.bind("<Button-4>", lambda e: self._wheel(e, 120))       # X11
        c.bind("<Button-5>", lambda e: self._wheel(e, -120))
        c.bind("<ButtonPress-2>", self._pan_start)
        c.bind("<B2-Motion>", self._pan_move)
        c.bind("<ButtonRelease-2>", lambda e: setattr(self, "_drag", None))
        c.bind("<ButtonPress-1>", self._sel_start)
        c.bind("<B1-Motion>", self._sel_move)
        c.bind("<ButtonRelease-1>", self._sel_end)
        c.bind("<Enter>", self._enter)
        c.bind("<KeyPress-space>", self._space_down)
        c.bind("<KeyRelease-space>", self._space_up)
        c.bind("<FocusOut>", lambda e: self._space_up(None))

    # ------------------------------------------------------------------ api
    def set_image(self, pil_rgba, keep_view=True):
        """keep_view=False refits; True keeps zoom and position."""
        first = self.image is None
        same_size = self.image is not None and self.image.size == pil_rgba.size
        self.image = pil_rgba
        if first:
            self.fit()
            return
        if not keep_view:
            self.fit()
        elif not same_size:
            self.centre()
        else:
            self._render()

    def set_outline(self, mask):
        """mask: L image the size of the sprite (255 = picked) or None."""
        self.outline = mask
        self._render()

    def clear(self):
        self.image = None
        self.outline = None
        if self._img_item:
            self.canvas.delete(self._img_item)
            self._img_item = None

    def fit(self):
        if not self.image:
            return
        cw, ch = self._csize()
        w, h = self.image.size
        best = ZOOMS[0]
        for z in ZOOMS:
            if w * z <= cw * 0.95 and h * z <= ch * 0.95:
                best = z
        self.zoom = best
        self.centre()

    def centre(self):
        if not self.image:
            return
        cw, ch = self._csize()
        w, h = self.image.size
        self.ox = int((cw - w * self.zoom) / 2)
        self.oy = int((ch - h * self.zoom) / 2)
        self._render()

    def step_zoom(self, d, anchor=None):
        if not self.image:
            return
        i = min(range(len(ZOOMS)), key=lambda k: abs(ZOOMS[k] - self.zoom))
        j = max(0, min(len(ZOOMS) - 1, i + d))
        if j == i:
            return
        if anchor is None:
            cw, ch = self._csize()
            anchor = (cw / 2, ch / 2)
        ax, ay = anchor
        f = ZOOMS[j] / self.zoom
        self.ox = int(ax - (ax - self.ox) * f)
        self.oy = int(ay - (ay - self.oy) * f)
        self.zoom = ZOOMS[j]
        self._render()

    # ------------------------------------------------------------- internal
    def _csize(self):
        return max(1, self.canvas.winfo_width()), max(1, self.canvas.winfo_height())

    def _on_resize(self, e):
        sq = S(8)
        cw, ch = -(-e.width // sq), -(-e.height // sq)
        small = Image.new("RGB", (cw, ch), CHECK_A)
        px = small.load()
        for y in range(ch):
            for x in range(cw):
                if (x + y) & 1:
                    px[x, y] = CHECK_B
        bg = small.resize((cw * sq, ch * sq), Image.NEAREST)
        self._bg_photo = ImageTk.PhotoImage(bg)
        if self._bg_item:
            self.canvas.itemconfigure(self._bg_item, image=self._bg_photo)
        else:
            self._bg_item = self.canvas.create_image(0, 0, image=self._bg_photo, anchor="nw")
            self.canvas.tag_lower(self._bg_item)
        if self.image and self._img_item is None:
            self.fit()
        else:
            self._render()

    def _with_outline(self, scaled, box, size):
        """Draw a 1-screen-pixel outline around picked pixels."""
        if self.outline is None:
            return scaled
        m = self.outline.crop(box) if box else self.outline
        m = m.resize(size, Image.NEAREST)
        edge = ImageChops.subtract(m.filter(ImageFilter.MaxFilter(3)), m)
        if not edge.getbbox():
            return scaled
        out = scaled.copy()
        out.paste(Image.new("RGBA", size, OUTLINE_RGB + (255,)), (0, 0), edge)
        return out

    def _render(self):
        if self._pending:
            self.after_cancel(self._pending)
            self._pending = None
        if not self.image:
            return
        w, h = self.image.size
        z = self.zoom
        sw, sh = max(1, int(w * z)), max(1, int(h * z))
        if sw * sh <= FULL_RENDER_LIMIT:
            scaled = self.image.resize((sw, sh), Image.NEAREST if z >= 1 else Image.BOX)
            scaled = self._with_outline(scaled, None, (sw, sh))
            self._photo = ImageTk.PhotoImage(scaled)
            self._full = True
            x, y = self.ox, self.oy
        else:
            cw, ch = self._csize()
            x0 = max(0, int(-self.ox / z))
            y0 = max(0, int(-self.oy / z))
            x1 = min(w, int((cw - self.ox) / z) + 2)
            y1 = min(h, int((ch - self.oy) / z) + 2)
            if x1 <= x0 or y1 <= y0:
                if self._img_item:
                    self.canvas.delete(self._img_item)
                    self._img_item = None
                return
            crop = self.image.crop((x0, y0, x1, y1))
            size = (int((x1 - x0) * z), int((y1 - y0) * z))
            scaled = crop.resize(size, Image.NEAREST)
            scaled = self._with_outline(scaled, (x0, y0, x1, y1), size)
            self._photo = ImageTk.PhotoImage(scaled)
            self._full = False
            x, y = self.ox + int(x0 * z), self.oy + int(y0 * z)
        if self._img_item:
            self.canvas.itemconfigure(self._img_item, image=self._photo)
            self.canvas.coords(self._img_item, x, y)
        else:
            self._img_item = self.canvas.create_image(x, y, image=self._photo, anchor="nw")
        if self._marquee:
            self.canvas.tag_raise(self._marquee)
        if self.on_zoom:
            self.on_zoom(self.zoom)

    def _leave(self, _e):
        if self._brush_item:
            self.canvas.delete(self._brush_item)
            self._brush_item = None
        if self.on_hover:
            self.on_hover(None)

    def _draw_brush_cursor(self, e):
        if self.tool != "brush" or not self.image:
            if self._brush_item:
                self.canvas.delete(self._brush_item)
                self._brush_item = None
            return
        z = self.zoom
        ix = (e.x - self.ox) // z
        iy = (e.y - self.oy) // z
        n = self.brush_size
        x0 = self.ox + (ix - n // 2) * z
        y0 = self.oy + (iy - n // 2) * z
        coords = (x0, y0, x0 + n * z, y0 + n * z)
        if self._brush_item:
            self.canvas.coords(self._brush_item, *coords)
            self.canvas.tag_raise(self._brush_item)
        else:
            self._brush_item = self.canvas.create_rectangle(*coords, outline=MARQUEE,
                                                            width=max(1, S(1)))

    def _img_xy(self, e):
        return int((e.x - self.ox) // self.zoom), int((e.y - self.oy) // self.zoom)

    def _motion(self, e):
        self._draw_brush_cursor(e)
        if not self.on_hover:
            return
        if not self.image:
            self.on_hover(None)
            return
        x = int((e.x - self.ox) // self.zoom)
        y = int((e.y - self.oy) // self.zoom)
        w, h = self.image.size
        self.on_hover((x, y) if 0 <= x < w and 0 <= y < h else None)

    def _wheel(self, e, delta=None):
        d = delta if delta is not None else e.delta
        self.step_zoom(1 if d > 0 else -1, (e.x, e.y))

    def _pan_start(self, e):
        self._drag = (e.x, e.y)

    def _pan_move(self, e):
        if not self._drag or not self.image:
            return
        dx, dy = e.x - self._drag[0], e.y - self._drag[1]
        self._drag = (e.x, e.y)
        self.ox += dx
        self.oy += dy
        if self._full and self._img_item:
            self.canvas.move(self._img_item, dx, dy)
        elif not self._pending:
            self._pending = self.after(16, self._render)

    # ------------------------------------------------------------- picking
    @staticmethod
    def _mode(e):
        if e.state & 0x0001:                       # Shift
            return "add"
        # Alt: 0x20000 on Windows (0x0008 there is NumLock); Mod1 0x0008 elsewhere
        if e.state & (0x20000 if sys.platform == "win32" else 0x0008):
            return "subtract"
        return "replace"

    _TEXT_CLASSES = {"Entry", "TEntry", "TCombobox", "Text", "Spinbox", "TSpinbox"}

    def _enter(self, _e):
        try:
            f = self.focus_get()
        except (KeyError, tk.TclError):
            f = None
        if f is None or f.winfo_class() not in self._TEXT_CLASSES:
            self.canvas.focus_set()

    def _space_down(self, _e):
        if not self._space:
            self._space = True
            self.canvas.configure(cursor="fleur")
        return "break"

    def _space_up(self, _e):
        self._space = False
        if not self._lpan:
            self.canvas.configure(cursor="")
        return "break"

    def _sel_start(self, e):
        self.canvas.focus_set()
        if self._space:
            self._lpan = True
            self._pan_start(e)
            return
        if self.tool == "brush" and self.image and self.on_brush:
            self._brushing = True
            self.on_brush("start", *self._img_xy(e), self._mode(e))
            return
        self._sel = (e.x, e.y, self._mode(e))

    def _sel_move(self, e):
        if self._lpan:
            self._pan_move(e)
            return
        if self._brushing:
            self._draw_brush_cursor(e)
            self.on_brush("move", *self._img_xy(e), None)
            return
        if not self._sel:
            return
        x0, y0, _ = self._sel
        if abs(e.x - x0) < DRAG_PX and abs(e.y - y0) < DRAG_PX and not self._marquee:
            return
        if self._marquee:
            self.canvas.coords(self._marquee, x0, y0, e.x, e.y)
        else:
            self._marquee = self.canvas.create_rectangle(x0, y0, e.x, e.y, outline=MARQUEE,
                                                         dash=(4, 3), width=max(1, S(1)))
        self._motion(e)

    def _sel_end(self, e):
        if self._lpan:
            self._lpan = False
            self._drag = None
            if not self._space:
                self.canvas.configure(cursor="")
            return
        if self._brushing:
            self._brushing = False
            self.on_brush("end", *self._img_xy(e), None)
            return
        if not self._sel:
            return
        x0, y0, mode = self._sel
        self._sel = None
        dragged = self._marquee is not None
        if self._marquee:
            self.canvas.delete(self._marquee)
            self._marquee = None
        if not self.image or not self.on_pick:
            return
        z = self.zoom
        if dragged:
            ax, bx = sorted((x0, e.x))
            ay, by = sorted((y0, e.y))
        else:
            ax = bx = e.x
            ay = by = e.y
        w, h = self.image.size
        ix0 = int((ax - self.ox) // z)
        iy0 = int((ay - self.oy) // z)
        ix1 = int((bx - self.ox) // z)
        iy1 = int((by - self.oy) // z)
        ix0, iy0 = max(0, ix0), max(0, iy0)
        ix1, iy1 = min(w - 1, ix1), min(h - 1, iy1)
        if ix1 < ix0 or iy1 < iy0:
            self.on_pick(None, None, None, None, mode)     # outside the sprite
            return
        self.on_pick(ix0, iy0, ix1, iy1, mode)
