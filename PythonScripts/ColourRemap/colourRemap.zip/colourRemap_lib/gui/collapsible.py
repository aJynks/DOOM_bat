"""
collapsible.py - foldable panels and the fold logic for two-pane dividers.

Collapsible: a panel with a title bar holding a fold arrow.
  unfolded: [▾ Title] + body
  folded:   [▸ Title] only - a thin bar

FoldGroup: wraps one two-pane ttk.PanedWindow. When a member folds, the
divider moves so that member shrinks to its bar and its neighbour takes the
space. Members can be Collapsible panels or nested FoldGroups (a nested group
counts as folded when both of its members are). The divider position from
before the fold is kept and put back on unfold.
"""

import tkinter as tk
from tkinter import ttk

from .dpi import S


class Collapsible(ttk.Frame):
    def __init__(self, master, title, name, on_toggle=None, padding=None):
        super().__init__(master, relief="groove", borderwidth=1)
        self.name = name
        self.title = title
        self.folded = False
        self.on_toggle = on_toggle
        self.header = ttk.Frame(self)
        self.header.pack(fill="x")
        self.btn = ttk.Button(self.header, text="\u25be", width=2, style="Fold.TButton",
                              command=self.toggle, takefocus=False)
        self.btn.pack(side="left")
        self.lbl = ttk.Label(self.header, text=title, style="FoldTitle.TLabel")
        self.lbl.pack(side="left", padx=(S(4), 0))
        self.lbl.bind("<Double-Button-1>", lambda e: self.toggle())
        self.body = ttk.Frame(self, padding=padding if padding is not None else S(5))
        self.body.pack(fill="both", expand=True)

    def set_folded(self, folded):
        self.folded = bool(folded)
        if self.folded:
            self.body.pack_forget()
            self.btn.configure(text="\u25b8")
        else:
            self.body.pack(fill="both", expand=True)
            self.btn.configure(text="\u25be")

    def toggle(self):
        self.set_folded(not self.folded)
        if self.on_toggle:
            self.on_toggle(self)

    def bar(self, orient):
        """Thickness of this panel when folded, along [orient]."""
        self.update_idletasks()
        if orient == "vertical":
            return self.header.winfo_reqheight() + 4
        return self.btn.winfo_reqwidth() + 4


class FoldGroup:
    def __init__(self, paned, orient, first, second):
        self.paned = paned
        self.orient = orient
        self.members = [first, second]
        self.saved = None            # divider position from before folding
        paned.bind("<Configure>", lambda e: self.apply(), add="+")

    # a nested group is "folded" when everything in it is
    @property
    def folded(self):
        return all(m.folded for m in self.members)

    def bar(self, orient):
        if orient == self.orient:
            return sum(m.bar(orient) for m in self.members) + S(6)
        return max(m.bar(orient) for m in self.members)

    def _size(self):
        return self.paned.winfo_height() if self.orient == "vertical" else self.paned.winfo_width()

    def sash(self):
        """Divider position to save: the unfolded one if currently folded."""
        if self.saved is not None:
            return self.saved
        try:
            return self.paned.sashpos(0)
        except tk.TclError:
            return None

    def _set(self, pos):
        try:
            self.paned.sashpos(0, pos)
        except tk.TclError:
            pass

    def apply(self):
        a, b = self.members
        try:
            if not a.folded and not b.folded:
                if self.saved is not None:
                    pos, self.saved = self.saved, None
                    self.paned.sashpos(0, pos)
                    # outer panes may still be growing; set it again once they settle
                    self.paned.after(80, lambda: self._set(pos))
                return
            if self.saved is None:
                self.saved = self.paned.sashpos(0)
            if a.folded:
                pos = a.bar(self.orient)
            else:
                pos = self._size() - b.bar(self.orient) - S(6)
            self.paned.sashpos(0, max(0, pos))
        except tk.TclError:
            pass
