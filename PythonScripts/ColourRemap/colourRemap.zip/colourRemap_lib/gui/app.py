"""
app.py - colourRemap main window. Wires the panels to the engine.

Layout (every divider draggable, every panel foldable, both remembered):
  row 1 - [Translation Ranges / Target Range Type] | Origin -> Target
  row 2 - Resulting Palette                        | Preview
  then the translation string, the two button rows and the status bar.
"""

import copy
import os
import tkinter as tk

from PIL import Image, ImageChops
from tkinter import ttk, filedialog, messagebox

from .. import VERSION
from .. import colour_math as cm
from .. import image_io
from .. import palette_io
from ..paint import PaintFrame, brush_offsets
from .. import settings as settings_mod
from .. import sources
from .. import trnslate_text as tt
from ..ranges import (PaletteRange, ColourRange, DesatRange, BlendRange, TintRange,
                      PickGroup, copy_range)
from ..translation import Translation
from . import dpi
from .dpi import S
from .export_dialog import ExportDialog
from .image_picker import ImagePicker
from .collapsible import Collapsible, FoldGroup
from .origin_target import OriginTarget
from .paint_strip import PaintStrip
from .palette_grid import PaletteGrid
from .preview import Preview
from .range_list import RangeList
from .target_panels import GradientTarget, TintTarget

TYPE_LABELS = [
    ("palette", "Palette Range"),
    ("colour", "Colour Gradient"),
    ("desat", "Desaturated Colour Gradient"),
    ("blend", "Colourise Range"),
    ("tint", "Tint Range"),
]
KIND_SHORT = {"palette": "Palette", "colour": "Gradient", "desat": "Desat",
              "blend": "Colourise", "tint": "Tint", "special": "Special"}

PAL_TYPES = [("Palettes", "*.wad *.pal *.lmp *.png *.gpl *.txt"),
             ("WAD", "*.wad"), ("Raw palette", "*.pal *.lmp"), ("PNG", "*.png"),
             ("All files", "*.*")]
SRC_TYPES = [("Images and WADs", "*.png *.wad *.lmp"), ("WAD", "*.wad"),
             ("PNG", "*.png"), ("Doom graphic lump", "*.lmp"), ("All files", "*.*")]


def _desat_to_rgb(f):
    return tuple(max(0, min(255, int(v * 128))) for v in f)


def _rgb_to_desat(c):
    return tuple(max(0.0, min(2.0, v / 127.0)) for v in c)


class App:
    def __init__(self, root, source_path=None, palette_path=None):
        self.root = root
        self.cfg = settings_mod.load()
        root.title(f"colourRemap {VERSION}")

        self.palette = palette_io.default_palette()
        self.pal_desc = "Doom II pal0 (built-in)"
        self.pal_path = ""
        self.matcher = cm.Matcher(self.palette, self.cfg.get("match", cm.DEFAULT_METHOD))
        self.trans = Translation.default()
        self.cur = 0
        self.source = None
        self.entry = None
        self.img = None
        self.lut = None
        self._pending = None

        self.var_truecolor = tk.BooleanVar(value=bool(self.cfg.get("truecolor")))
        self.var_palonly = tk.BooleanVar(value=bool(self.cfg.get("palette_only")))
        self.var_dither = tk.BooleanVar(value=bool(self.cfg.get("dither")))
        self.var_original = tk.BooleanVar(value=False)
        self.var_outline = tk.BooleanVar(value=bool(self.cfg.get("show_outline", True)))
        self.var_mode = tk.StringVar(value="batch")
        self.frames = {}            # id(entry) -> PaintFrame (Paint mode edits)
        self.frame_entries = {}     # id(entry) -> entry
        self.frame = None
        self._brush_last = None
        self._brush_val = 1
        self._paint_job = None
        self.var_type = tk.StringVar(value="palette")
        self.var_string = tk.StringVar()
        self.var_match = tk.StringVar(value=cm.METHODS[self.matcher.method])

        self._build()
        self._initial_geometry()

        start_pal = palette_path or self.cfg.get("palette_path")
        if start_pal:
            if os.path.isfile(start_pal):
                self.load_palette_path(start_pal, quiet=not palette_path)
            else:
                self.status(f"Last palette not found ({start_pal}) - using built-in Doom II pal0.", err=True)

        if self.cfg.get("translation"):
            try:
                self.trans = tt.parse(self.cfg["translation"])
                if self.trans.is_empty():
                    self.trans = Translation.default()
            except tt.TranslationParseError:
                self.trans = Translation.default()

        self.refresh_list()
        self.open_range(0)
        self.schedule()
        if source_path:
            self.root.after(80, lambda: self.open_source_path(source_path))
        self.root.after(150, self._restore_sashes)
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # =================================================================== UI
    def _build(self):
        r = self.root
        pad = S(5)
        r.columnconfigure(0, weight=1)
        r.rowconfigure(1, weight=1)

        mbar = ttk.Frame(r, padding=(pad, pad, pad, 0))
        mbar.grid(row=0, column=0, sticky="ew")
        ttk.Label(mbar, text="Mode:").pack(side="left")
        for val, txt in (("batch", "Batch"), ("paint", "Paint")):
            ttk.Radiobutton(mbar, text=txt, value=val, variable=self.var_mode, style="Toolbutton",
                            command=self.on_mode_changed).pack(side="left", padx=(S(4), 0))
        self.lbl_mode = ttk.Label(mbar, text="", foreground="#808080")
        self.lbl_mode.pack(side="left", padx=(S(12), 0))

        style = ttk.Style(r)
        style.configure("Fold.TButton", padding=0)
        style.configure("FoldTitle.TLabel", font=("Segoe UI", 9, "bold"))
        style.configure("Half.TLabel", foreground="#707070")

        self.vpane = ttk.PanedWindow(r, orient="vertical")
        self.vpane.grid(row=1, column=0, sticky="nsew", padx=pad, pady=(pad, 0))
        self.row0 = ttk.PanedWindow(self.vpane, orient="horizontal")
        self.row1 = ttk.PanedWindow(self.vpane, orient="horizontal")
        self.vpane.add(self.row0, weight=1)
        self.vpane.add(self.row1, weight=3)
        self.leftcol = ttk.PanedWindow(self.row0, orient="vertical")
        self.row0.add(self.leftcol, weight=0)

        fold = self._on_fold
        # ---- row 1, left column
        self.c_ranges = Collapsible(self.leftcol, "Translation Ranges", "ranges", fold)
        self.leftcol.add(self.c_ranges, weight=1)
        self.ranges_w = RangeList(self.c_ranges.body, self.on_range_selected, self.cmd_add,
                                  self.cmd_remove, self.cmd_up, self.cmd_down)
        self.ranges_w.pack(fill="both", expand=True)
        self.c_types = Collapsible(self.leftcol, "Target Range Type", "types", fold)
        self.leftcol.add(self.c_types, weight=0)
        for key, label in TYPE_LABELS:
            ttk.Radiobutton(self.c_types.body, text=label, value=key, variable=self.var_type,
                            command=self.on_type_changed).pack(anchor="w", pady=(0, S(2)))

        # ---- row 1, origin -> target
        self.c_ot = Collapsible(self.row0, "Origin → Target", "origin_target", fold)
        self.row0.add(self.c_ot, weight=1)
        self.ot = OriginTarget(self.c_ot.body, self.on_origin_select, self.on_target_select,
                               self.on_reverse, lambda i: self.hover_index(i, False),
                               on_order=self.on_pick_order)
        self.ot.pack(fill="both", expand=True)
        self.grid_origin = self.ot.grid_origin
        self.p_gradient = GradientTarget(self.ot.controls, self.on_gradient_changed)
        self.p_tint = TintTarget(self.ot.controls, self.on_tint_colour, self.on_tint_amount)
        self.p_info = ttk.Label(self.ot.controls, text="", justify="left", wraplength=S(360))

        # ---- row 2
        self.c_result = Collapsible(self.row1, "Resulting Palette", "result", fold)
        self.row1.add(self.c_result, weight=0)
        self.grid_result = PaletteGrid(self.c_result.body, cols=16, cell=11, selectable=False,
                                       on_hover=lambda i: self.hover_index(i, True))
        self.grid_result.pack(fill="both", expand=True)
        self.c_preview = Collapsible(self.row1, "Preview", "preview", fold)
        self.row1.add(self.c_preview, weight=1)
        f = self.c_preview.body
        self.picker = ImagePicker(f, self.on_pick_entry)
        self.picker.pack(fill="x", pady=(0, S(4)))
        self.paint_strip = PaintStrip(f, self.on_paint_settings, self.cmd_paint_apply,
                                      self.cmd_paint_undo, self.cmd_paint_redo,
                                      self.cmd_paint_clear,
                                      on_pick=self.cmd_pick_from_selection,
                                      on_start=self.on_start_from,
                                      on_save_all=self.cmd_save_all_changed)
        self.picker.mark = lambda e: (id(e) in self.frames and self.frames[id(e)].dirty)
        self.paint_strip.set_values(self.cfg.get("paint_tool", "brush"),
                                    self.cfg.get("paint_shape", "Circle"),
                                    self.cfg.get("paint_size", 5))
        self.preview = Preview(f, on_hover=self.hover_pixel, on_zoom=self._zoom_changed,
                               on_pick=self.on_sprite_pick)
        self.preview.on_brush = self.on_brush
        self.preview.pack(fill="both", expand=True)
        zb = ttk.Frame(f)
        zb.pack(fill="x", pady=(S(4), 0))
        ttk.Button(zb, text="\u2212", width=3, command=lambda: self.preview.step_zoom(-1)).pack(side="left")
        ttk.Button(zb, text="+", width=3, command=lambda: self.preview.step_zoom(1)).pack(side="left", padx=(S(3), 0))
        ttk.Button(zb, text="Fit", width=4, command=self.preview.fit).pack(side="left", padx=(S(3), 0))
        self.lbl_zoom = ttk.Label(zb, text="", width=7)
        self.lbl_zoom.pack(side="left", padx=(S(6), 0))
        ttk.Checkbutton(zb, text="Show original", variable=self.var_original,
                        command=self.schedule).pack(side="left", padx=(S(10), 0))
        ttk.Checkbutton(zb, text="Show pick outline", variable=self.var_outline,
                        command=self._update_outline_and_preview).pack(side="left", padx=(S(10), 0))
        ttk.Label(f, text="wheel zoom  \u00b7  middle or Space+drag pan  \u00b7  click/drag pick (Shift add, Alt subtract)",
                  foreground="#808080").pack(anchor="e", pady=(S(2), 0))

        self.panels = [self.c_ranges, self.c_types, self.c_ot, self.c_result, self.c_preview]
        g_left = FoldGroup(self.leftcol, "vertical", self.c_ranges, self.c_types)
        g_row0 = FoldGroup(self.row0, "horizontal", g_left, self.c_ot)
        g_row1 = FoldGroup(self.row1, "horizontal", self.c_result, self.c_preview)
        g_v = FoldGroup(self.vpane, "vertical", g_row0, g_row1)
        self.groups = {"lc": g_left, "r0": g_row0, "r1": g_row1, "v": g_v}

        # ---- translation string
        srow = ttk.Frame(r, padding=(pad, pad, pad, 0))
        srow.grid(row=2, column=0, sticky="ew")
        srow.columnconfigure(1, weight=1)
        ttk.Label(srow, text="Translation String:").grid(row=0, column=0, padx=(0, S(6)))
        ent = ttk.Entry(srow, textvariable=self.var_string, font=("Consolas", 9))
        ent.grid(row=0, column=1, sticky="ew")
        ent.bind("<Return>", lambda e: self.cmd_apply_string())
        ttk.Button(srow, text="Apply", command=self.cmd_apply_string).grid(row=0, column=2, padx=(S(4), 0))

        # ---- button rows
        # row A: SLADE's own row (translation file + output options)
        brow = ttk.Frame(r, padding=(pad, pad, pad, 0))
        brow.grid(row=3, column=0, sticky="ew")
        ttk.Button(brow, text="Load from File", command=self.cmd_load_txt).pack(side="left")
        ttk.Button(brow, text="Save to File", command=self.cmd_save_txt).pack(side="left", padx=(S(4), 0))
        self.var_recent = tk.StringVar()
        self.recent_cb = ttk.Combobox(brow, textvariable=self.var_recent, state="readonly", width=18)
        self.recent_cb.pack(side="left", padx=(S(4), 0))
        self.recent_cb.bind("<<ComboboxSelected>>", self._recent_picked)
        self._refresh_recent()
        ttk.Checkbutton(brow, text="Truecolor", variable=self.var_truecolor,
                        command=self.schedule).pack(side="left", padx=(S(12), 0))
        ttk.Checkbutton(brow, text="Palette Translation Only", variable=self.var_palonly,
                        command=self.schedule).pack(side="left", padx=(S(8), 0))
        self.btn_export = ttk.Button(brow, text="Export…", command=self.cmd_export)
        self.btn_export.pack(side="right")
        ttk.Button(brow, text="Save Sprite…", command=self.cmd_save_sprite).pack(side="right", padx=(0, S(4)))
        self.btn_open = ttk.Button(brow, text="Open…", command=self.cmd_open_menu)
        self.btn_open.pack(side="right", padx=(0, S(4)))

        # row B: palette + truecolour conversion
        prow = ttk.Frame(r, padding=pad)
        prow.grid(row=4, column=0, sticky="ew")
        ttk.Button(prow, text="Load Palette…", command=self.cmd_load_palette).pack(side="left")
        ttk.Label(prow, text="Match:").pack(side="left", padx=(S(12), S(4)))
        cb = ttk.Combobox(prow, textvariable=self.var_match, state="readonly", width=24,
                          values=list(cm.METHODS.values()))
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.on_match_changed())
        ttk.Checkbutton(prow, text="Dither truecolour", variable=self.var_dither,
                        command=self.on_dither_changed).pack(side="left", padx=(S(12), 0))

        self.open_menu = tk.Menu(r, tearoff=0)
        self.open_menu.add_command(label="Image, graphic or WAD…", command=self.cmd_open_file)
        self.open_menu.add_command(label="Folder of images…", command=self.cmd_open_folder)

        # ---- status bar
        sb = ttk.Frame(r)
        sb.grid(row=5, column=0, sticky="ew")
        sb.columnconfigure(0, weight=3)
        sb.columnconfigure(1, weight=2)
        sb.columnconfigure(2, weight=2)
        self.lbl_status = ttk.Label(sb, text="", padding=(pad, S(2)), relief="sunken", anchor="w", width=10)
        self.lbl_status.grid(row=0, column=0, sticky="ew")
        self.lbl_src = ttk.Label(sb, text="no source", padding=(pad, S(2)), relief="sunken", anchor="w", width=10)
        self.lbl_src.grid(row=0, column=1, sticky="ew")
        self.lbl_pal = ttk.Label(sb, text=self.pal_desc, padding=(pad, S(2)), relief="sunken", anchor="w", width=10)
        self.lbl_pal.grid(row=0, column=2, sticky="ew")

        r.bind("<Control-o>", lambda e: self.cmd_open_file())
        r.bind("<Control-s>", lambda e: self.cmd_save_sprite())
        r.bind("<Control-e>", lambda e: self.cmd_export())
        r.bind("<Control-p>", lambda e: self.cmd_load_palette())
        r.bind("<Control-z>", lambda e: self._paint_key(self.cmd_paint_undo))
        r.bind("<Control-y>", lambda e: self._paint_key(self.cmd_paint_redo))
        r.bind("<Return>", lambda e: self._paint_key(self.cmd_paint_apply), add="+")
        r.bind("<KP_Enter>", lambda e: self._paint_key(self.cmd_paint_apply), add="+")
        r.bind("<Escape>", lambda e: self._paint_key(self.cmd_paint_clear))

        self.ot.set_colours(self.palette)

    def _initial_geometry(self):
        geo = self.cfg.get("geometry")
        if geo:
            try:
                self.root.geometry(geo)
                return
            except tk.TclError:
                pass
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        w, h = min(S(1060), int(sw * 0.9)), min(S(980), int(sh * 0.88))
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{max(0, (sh - h) // 3)}")

    def _restore_sashes(self):
        s = self.cfg.get("sashes") or {}
        for key, g in self.groups.items():
            pos = s.get(key)
            if isinstance(pos, int):
                try:
                    g.paned.sashpos(0, pos)
                except tk.TclError:
                    pass
        folded = self.cfg.get("folded") or {}
        for p in self.panels:
            p.set_folded(folded.get(p.name, False))
        # a folded group restores to the divider position saved last session
        for key, g in self.groups.items():
            pos = s.get(key)
            if isinstance(pos, int) and any(m.folded for m in g.members):
                g.saved = pos
        self._apply_folds()

    def _save_sashes(self):
        return {k: g.sash() for k, g in self.groups.items()}

    def _on_fold(self, panel):
        self.root.after_idle(self._apply_folds)

    def _apply_folds(self):
        # outer dividers first, so inner panes have their final size
        for key in ("v", "r0", "r1", "lc"):
            self.root.update_idletasks()
            self.groups[key].apply()

    def status(self, msg, err=False):
        self.lbl_status.configure(text=msg, foreground="#c03030" if err else "")

    def _zoom_changed(self, z):
        self.lbl_zoom.configure(text=f"{int(z * 100)}%")

    # ============================================================ ranges list
    def _label(self, r):
        if r.kind == "picks":
            return self._label_picks(r)
        return f"{KIND_SHORT[r.kind]:<10}{r.to_text()}"

    def _label_picks(self, r):
        t = r.inner
        desc = {"palette": f"{t.dstart}:{t.dend}" if t.kind == "palette" else "",
                "colour": "Gradient", "desat": "Desat gradient", "blend": "Colourise",
                "tint": f"Tint {getattr(t, 'amount', 0)}%"}.get(t.kind, t.kind)
        if not r.ready:
            desc = "drag a target"
        return f"Picks ({len(r.indices)}) \u2192 {desc}"

    @staticmethod
    def target_of(r):
        """The range whose TARGET fields are edited (a pick group's inner range)."""
        return r.inner if r is not None and r.kind == "picks" else r

    def refresh_list(self):
        if self.trans.builtin:
            self.ranges_w.set_items([f"Built-in  {tt.to_text(self.trans)}"], 0)
        else:
            self.ranges_w.set_items([self._label(r) for r in self.trans.ranges], self.cur)

    def current(self):
        if self.trans.builtin or not self.trans.ranges:
            return None
        self.cur = max(0, min(self.cur, len(self.trans.ranges) - 1))
        return self.trans.ranges[self.cur]

    def _show_panel(self, panel, title=""):
        for p in (self.p_gradient, self.p_tint, self.p_info):
            p.pack_forget()
        if panel is None:
            self.ot.show_target()
        else:
            self.ot.show_controls(title)
            panel.pack(anchor="nw", fill="x")

    def open_range(self, index):
        self.cur = index
        if self.trans.builtin:
            self.var_type.set("")
            self.grid_origin.set_selection(0, 255)
            self.ot.set_origin_info(0, 255)
            self.p_info.configure(text=f"Built-in translation: {tt.to_text(self.trans)}\n\n"
                                       "Applies to all 256 colours. Pick a range type or "
                                       "add a range to replace it with normal ranges.")
            self._show_panel(self.p_info, "Built-in")
            return
        r = self.current()
        if r is None:
            return
        if r.kind == "picks":
            self.grid_origin.set_picks(r.indices)
            self.ot.set_picks_info(r.indices, r.order)
            steps = max(1, len(set(r.indices)))
        else:
            self.grid_origin.set_selection(r.start, r.end)
            self.ot.set_origin_info(r.start, r.end)
            steps = r.end - r.start + 1
        t = self.target_of(r)
        if t.kind == "palette":
            self.var_type.set("palette")
            self.ot.reverse.set(t.dstart > t.dend)
            self.ot.grid_target.set_selection(t.dstart, t.dend)
            self._show_panel(None)
        elif t.kind == "colour":
            self.var_type.set("colour")
            self.p_gradient.set(t.c1, t.c2, steps)
            self._show_panel(self.p_gradient, "Colour Gradient")
        elif t.kind == "desat":
            self.var_type.set("desat")
            self.p_gradient.set(_desat_to_rgb(t.f1), _desat_to_rgb(t.f2), steps,
                                f"%[{t.f1[0]:.2f},{t.f1[1]:.2f},{t.f1[2]:.2f}]:"
                                f"[{t.f2[0]:.2f},{t.f2[1]:.2f},{t.f2[2]:.2f}]")
            self._show_panel(self.p_gradient, "Desaturated Colour Gradient")
        elif t.kind == "blend":
            self.var_type.set("blend")
            self.p_tint.set(t.colour)
            self.p_tint.show_amount(False)
            self._show_panel(self.p_tint, "Colourise")
        elif t.kind == "tint":
            self.var_type.set("tint")
            self.p_tint.set(t.colour, t.amount)
            self.p_tint.show_amount(True)
            self._show_panel(self.p_tint, "Tint")
        else:
            self.var_type.set("")
            self.p_info.configure(text=f"Special range: ${t.name}\n\nEdit it through the "
                                       "translation string, or pick a range type to replace it.")
            self._show_panel(self.p_info, "Special")

    def _range_changed(self):
        r = self.current()
        if r is not None:
            self.ranges_w.update_item(self.cur, self._label(r))
        self.schedule()

    def _clear_builtin(self):
        if self.trans.builtin:
            self.trans = Translation.default()
            self.cur = 0
            return True
        return False

    def on_range_selected(self, i):
        self.open_range(i)
        self._update_outline_and_preview()

    def cmd_add(self):
        if self._clear_builtin():
            self.status("Built-in translation replaced with a normal range.")
        else:
            self.trans.ranges.insert(self.cur + 1, PaletteRange())
            self.cur += 1
        self.refresh_list()
        self.open_range(self.cur)
        self.schedule()

    def cmd_remove(self):
        if self.trans.builtin:
            self._clear_builtin()
        elif len(self.trans.ranges) > 1:
            del self.trans.ranges[self.cur]
            self.cur = min(self.cur, len(self.trans.ranges) - 1)
        else:
            self.trans.ranges = [PaletteRange()]
            self.cur = 0
        self.refresh_list()
        self.open_range(self.cur)
        self.schedule()

    def _move(self, d):
        rs = self.trans.ranges
        j = self.cur + d
        if self.trans.builtin or not 0 <= j < len(rs):
            return
        rs[self.cur], rs[j] = rs[j], rs[self.cur]
        self.cur = j
        self.refresh_list()
        self.schedule()

    def cmd_up(self):
        self._move(-1)

    def cmd_down(self):
        self._move(1)

    # ========================================================= range editing
    def on_origin_select(self, a, b):
        if self.trans.builtin:
            self._clear_builtin()
            self.trans.ranges[0] = PaletteRange(a, b, a, b)
            self.refresh_list()
            self.open_range(0)
            self.schedule()
            return
        r = self.current()
        if r is None:
            return
        if r.kind == "picks":
            # dragging the origin grid turns picks back into one ordinary range
            inner = copy_range(r.inner)
            inner.start, inner.end = a, b
            self.trans.ranges[self.cur] = inner
            self.refresh_list()
            self.open_range(self.cur)
            self._update_outline_and_preview()
            self.schedule()
            return
        r.start, r.end = a, b
        self.ot.set_origin_info(a, b)
        if r.kind in ("colour", "desat"):
            self.p_gradient.steps = b - a + 1
            self.p_gradient._draw()
        self._range_changed()

    def _target_span(self):
        sel = self.ot.grid_target.sel
        if not sel:
            return None
        a, b = sel
        return (b, a) if self.ot.reverse.get() else (a, b)

    def on_target_select(self, a=0, b=0):
        cur = self.current()
        r = self.target_of(cur)
        if r is None or r.kind != "palette":
            return
        span = self._target_span()
        if span is None:
            return
        r.dstart, r.dend = span
        if cur.kind == "picks":
            cur.ready = True
        self._range_changed()

    def on_reverse(self):
        self.on_target_select()

    def on_gradient_changed(self, c1, c2):
        r = self.target_of(self.current())
        if r is None:
            return
        if r.kind == "colour":
            r.c1, r.c2 = c1, c2
        elif r.kind == "desat":
            r.f1, r.f2 = _rgb_to_desat(c1), _rgb_to_desat(c2)
            self.p_gradient.note.configure(
                text=f"%[{r.f1[0]:.2f},{r.f1[1]:.2f},{r.f1[2]:.2f}]:[{r.f2[0]:.2f},{r.f2[1]:.2f},{r.f2[2]:.2f}]")
        self._range_changed()

    def on_tint_colour(self, c):
        r = self.target_of(self.current())
        if r is not None and r.kind in ("blend", "tint"):
            r.colour = c
            self._range_changed()

    def on_tint_amount(self, a):
        r = self.target_of(self.current())
        if r is not None and r.kind == "tint":
            r.amount = a
            self._range_changed()

    def on_type_changed(self):
        kind = self.var_type.get()
        if self.trans.builtin:
            self._clear_builtin()
            start, end = 0, 255
        else:
            r = self.current()
            start, end = (r.start, r.end) if r and r.kind != "picks" else (0, 0)
        if not self.trans.ranges:
            self.trans.ranges.append(PaletteRange())
            self.cur = 0
        if kind == "palette":
            span = self._target_span() or (start, end)
            new = PaletteRange(start, end, span[0], span[1])
        elif kind == "colour":
            new = ColourRange(start, end, self.p_gradient.c1.colour, self.p_gradient.c2.colour)
        elif kind == "desat":
            new = DesatRange(start, end, _rgb_to_desat(self.p_gradient.c1.colour),
                             _rgb_to_desat(self.p_gradient.c2.colour))
        elif kind == "blend":
            new = BlendRange(start, end, self.p_tint.col.colour)
        elif kind == "tint":
            new = TintRange(start, end, self.p_tint.col.colour, int(float(self.p_tint.slider.get())))
        else:
            return
        cur = self.trans.ranges[self.cur]
        if cur.kind == "picks":
            cur.inner = new
            cur.ready = kind != "palette"
        else:
            self.trans.ranges[self.cur] = new
        self.refresh_list()
        self.open_range(self.cur)
        self.schedule()

    # ============================================================ recompute
    def schedule(self):
        if self._pending:
            self.root.after_cancel(self._pending)
        self._pending = self.root.after(15, self._recompute)

    def _recompute(self):
        self._pending = None
        self.lut = self.trans.build_lut(self.palette, self.matcher)
        tc = self.var_truecolor.get()
        self.grid_result.set_colours([e[1] if tc else self.palette[e[0]] for e in self.lut])
        self._update_preview()
        if self.var_palonly.get():
            self.var_string.set(tt.palette_only_text(self.lut))
        else:
            self.var_string.set(tt.to_text(self.trans, self.palette))

    def _pick_mask(self):
        """L mask of sprite pixels whose index is in the current pick group."""
        r = self.current()
        if (not self.var_outline.get() or not self.img or r is None
                or r.kind != "picks" or not r.indices):
            return None
        picked = set(r.indices)
        table = bytes(255 if i in picked else 0 for i in range(256))
        size = (self.img.width, self.img.height)
        m = Image.frombytes("L", size, self.img.indices.translate(table))
        return ImageChops.darker(m, Image.frombytes("L", size, self.img.alpha))

    def _update_preview(self, keep_view=True):
        if self.painting() and self.lut:
            f = self.frame
            pil = f.render(self.lut, self.palette, self.var_truecolor.get(),
                           preview=not self.var_original.get())
            self.preview.outline = (f.selection_mask() if self.var_outline.get()
                                    and f.has_selection() else None)
            self.preview.set_image(pil, keep_view=keep_view)
            return
        if self.img and self.lut:
            pil = image_io.render(self.img, self.lut, self.palette, self.var_truecolor.get(),
                                  self.var_original.get())
            self.preview.outline = self._pick_mask()
            self.preview.set_image(pil, keep_view=keep_view)

    def _update_outline_and_preview(self):
        if self.painting():
            self._update_preview()
            return
        self.preview.set_outline(self._pick_mask())

    # =============================================================== hovers
    def hover_index(self, i, result):
        if i is None:
            return
        c = self.palette[i]
        if result and self.lut:
            d, rgb = self.lut[i]
            tc = rgb if self.var_truecolor.get() else self.palette[d]
            self.status(f"Index {i} {c}  \u2192  {d} {tc}")
        else:
            self.status(f"Index {i}  rgb {c}")

    def _set_markers(self, i=None, d=None):
        self.grid_origin.set_marker(i)
        self.grid_result.set_marker(i)
        self.ot.grid_target.set_marker(d)

    def hover_pixel(self, xy):
        if xy is None or not self.img or not self.lut:
            self._set_markers()
            return
        x, y = xy
        p = y * self.img.width + x
        if not self.img.alpha[p]:
            self._set_markers()
            self.status(f"{x},{y}  transparent")
            return
        i = self.frame.work[p] if self.painting() else self.img.indices[p]
        d = self.lut[i][0]
        self._set_markers(i, d)
        self.status(f"{x},{y}  index {i}  \u2192  {d}")

    # ============================================================ picking
    def on_sprite_pick(self, x0, y0, x1, y1, mode):
        if not self.img:
            return
        if self.painting():
            f = self.frame
            if mode == "replace":
                f.clear_selection()
            if x0 is not None:
                f.rect(x0, y0, x1, y1, 0 if mode == "subtract" else 1)
            self._update_preview()
            self._paint_status()
            return
        found = set()
        if x0 is not None:
            w = self.img.width
            ind, alpha = self.img.indices, self.img.alpha
            for y in range(y0, y1 + 1):
                row = y * w
                for x in range(x0, x1 + 1):
                    if alpha[row + x]:
                        found.add(ind[row + x])
        self._set_picks(found, mode)

    def _set_picks(self, found, mode):
        """Replace / add / subtract [found] indices on the current range,
        turning it into a pick group if it isn't one."""
        r = self.current()
        is_group = r is not None and r.kind == "picks"
        base = set(r.indices) if is_group else set()
        if mode == "add":
            new = base | found
        elif mode == "subtract":
            new = base - found
        else:
            new = found
        if not is_group:
            if not new:
                return                      # nothing picked, nothing to change
            if self.trans.builtin:
                self._clear_builtin()
                r = self.current()
            inner = copy_range(r) if r is not None and r.kind in (
                "palette", "colour", "desat", "blend", "tint") else PaletteRange()
            # a palette target must be chosen first; other types already have settings
            group = PickGroup(sorted(new), inner, self.cfg.get("pick_order", "bright"),
                              ready=inner.kind != "palette")
            self.trans.ranges[self.cur] = group
        else:
            r.indices = sorted(new)
        self.refresh_list()
        self.open_range(self.cur)
        self._update_outline_and_preview()
        self.schedule()
        n = len(new)
        self.status(f"Picked {n} ind{'ex' if n == 1 else 'ices'}" +
                    (": " + " ".join(str(i) for i in sorted(new)[:16]) if n else "") +
                    (" …" if n > 16 else ""))

    def on_pick_order(self, key):
        r = self.current()
        if r is None or r.kind != "picks":
            return
        r.order = key
        self.cfg["pick_order"] = key
        self._range_changed()

    # ============================================================== palette
    def cmd_load_palette(self):
        start = os.path.dirname(self.pal_path) if self.pal_path else self.cfg.get("source_dir", "")
        path = filedialog.askopenfilename(parent=self.root, title="Load palette (pal0)",
                                          initialdir=start or None, filetypes=PAL_TYPES)
        if path:
            self.load_palette_path(path)

    def load_palette_path(self, path, quiet=False):
        try:
            cols, desc = palette_io.load_palette(path)
        except palette_io.PaletteError as e:
            if quiet:
                self.status(str(e), err=True)
            else:
                messagebox.showerror("Load palette", str(e), parent=self.root)
            return False
        self.palette = cols
        self.pal_desc = desc
        self.pal_path = os.path.abspath(path)
        self.matcher = cm.Matcher(self.palette, self.matcher.method)
        self.lbl_pal.configure(text=desc)
        self.ot.set_colours(self.palette)
        self._reconvert()
        self.status(f"Palette loaded: {desc}")
        self.schedule()
        return True

    def _reconvert(self):
        if self.img and self.img.truecolour:
            self.img.convert(self.matcher, self.var_dither.get())

    def on_match_changed(self):
        label = self.var_match.get()
        key = next((k for k, v in cm.METHODS.items() if v == label), cm.DEFAULT_METHOD)
        self.matcher = cm.Matcher(self.palette, key)
        self._reconvert()
        self.status(f"Colour matching: {label}")
        self.schedule()

    def on_dither_changed(self):
        self._reconvert()
        self.schedule()

    # =============================================================== source
    def cmd_open_menu(self):
        b = self.btn_open
        self.open_menu.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())

    def cmd_open_file(self):
        path = filedialog.askopenfilename(parent=self.root, title="Open image, graphic or WAD",
                                          initialdir=self.cfg.get("source_dir") or None,
                                          filetypes=SRC_TYPES)
        if path:
            self.open_source_path(path)

    def cmd_open_folder(self):
        path = filedialog.askdirectory(parent=self.root, title="Open folder of images",
                                       initialdir=self.cfg.get("source_dir") or None)
        if path:
            self.open_source_path(path)

    def open_source_path(self, path):
        if not self._confirm_unsaved():
            return
        try:
            src = sources.open_source(path)
        except sources.SourceError as e:
            messagebox.showerror("Open", str(e), parent=self.root)
            return
        self.source = src
        self.cfg["source_dir"] = path if os.path.isdir(path) else os.path.dirname(os.path.abspath(path))
        self.lbl_src.configure(text=src.desc)
        # keep the same graphic selected if the new source has it
        pick = 0
        if self.entry is not None:
            for i, e in enumerate(src.entries):
                if e.name == self.entry.name and e.kind == self.entry.kind:
                    pick = i
                    break
        self.img = None
        self.frames = {}
        self.frame_entries = {}
        self.frame = None
        self.preview.clear()
        self.picker.set_entries(src.entries, pick)

    def on_pick_entry(self, entry):
        try:
            img = image_io.build_image(entry, self.matcher, self.var_dither.get())
        except image_io.ImageError as e:
            self.status(str(e), err=True)
            return
        first = self.img is None
        self.entry = entry
        self.img = img
        if self.lut is None:
            self.lut = self.trans.build_lut(self.palette, self.matcher)
        if self.var_mode.get() == "paint":
            self.frame = self._frame_for(entry)
        self._update_preview(keep_view=not first)
        note = f"  [{entry.note}]" if entry.note else ""
        self.status(img.describe() + note)

    # ================================================================= save
    def default_export_dir(self):
        d = self.cfg.get("export_dir")
        if d and os.path.isdir(d):
            return d
        return self.cfg.get("source_dir", "")

    def cmd_save_sprite(self):
        if not self.img:
            self.status("Nothing open.", err=True)
            return
        path = filedialog.asksaveasfilename(parent=self.root, title="Save sprite",
                                            initialdir=self.default_export_dir() or None,
                                            initialfile=f"{self.img.name}.png",
                                            defaultextension=".png", filetypes=[("PNG", "*.png")])
        if not path:
            return
        if self.lut is None:
            self._recompute()
        try:
            if self.painting():
                warns = self._save_frame(path)
            else:
                warns = image_io.save_image(self.img, self.lut, self.palette,
                                            self.var_truecolor.get(), path)
        except Exception as e:
            messagebox.showerror("Save sprite", str(e), parent=self.root)
            return
        self.cfg["export_dir"] = os.path.dirname(path)
        kind = "truecolour" if self.var_truecolor.get() else "paletted"
        self.status(f"Saved {os.path.basename(path)} ({kind}"
                    f"{', offsets kept' if self.img.offsets else ''})")
        if warns:
            messagebox.showwarning("Save sprite", "\n".join(warns), parent=self.root)

    def cmd_export(self):
        if not self.source:
            self.status("Open a PNG, folder or WAD first.", err=True)
            return
        if self.lut is None:
            self._recompute()
        ExportDialog(self)

    def export_entry(self, entry, path):
        """Used by the export window: remap one entry and write it."""
        if entry is self.entry and self.img is not None:
            img = self.img
        else:
            img = image_io.build_image(entry, self.matcher, self.var_dither.get())
        return image_io.save_image(img, self.lut, self.palette, self.var_truecolor.get(), path)

    # ================================================================ paint
    def painting(self):
        return self.var_mode.get() == "paint" and self.frame is not None

    def _frame_for(self, entry):
        """This image's PaintFrame; a new one starts from its Batch result."""
        key = id(entry)
        f = self.frames.get(key)
        if f is None:
            f = PaintFrame(self.img.width, self.img.height,
                           self._start_indices(self.paint_strip.start.get()), self.img.alpha)
            self.frames[key] = f
            self.frame_entries[key] = entry
        return f

    def _start_indices(self, start):
        """Starting pixels for a Paint frame: the Batch result or the original."""
        if start == "Original":
            return self.img.indices
        if self.lut is None:
            self.lut = self.trans.build_lut(self.palette, self.matcher)
        return self.img.indices.translate(bytes(e[0] for e in self.lut))

    def on_start_from(self, start):
        if not self.painting():
            return
        if self.frame.reset(self._start_indices(start)):
            self.status(f"Frame reset to the {start.lower()} (Ctrl+Z to undo).")
        self._after_paint_edit()

    def _after_paint_edit(self):
        self._update_preview()
        self._paint_status()
        self.picker.refresh_labels()

    def cmd_pick_from_selection(self):
        if not self.painting():
            return
        found = self.frame.selected_indices()
        if not found:
            self.status("Pick from selection: nothing selected.", err=True)
            return
        self._set_picks(found, "replace")
        self._paint_status()

    def on_mode_changed(self):
        paint = self.var_mode.get() == "paint"
        if paint:
            self.paint_strip.pack(fill="x", pady=(0, S(4)), before=self.preview)
            self.btn_export.state(["disabled"])
            self.frame = self._frame_for(self.entry) if (self.img and self.entry) else None
            self.lbl_mode.configure(text="Paint: select pixels, the translation previews on the "
                                         "selection only - Apply (Enter) bakes it in")
        else:
            self.paint_strip.pack_forget()
            self.btn_export.state(["!disabled"])
            self.lbl_mode.configure(text="")
        self.on_paint_settings()
        self._update_preview()
        self._paint_status()

    def on_paint_settings(self):
        tool = self.paint_strip.tool.get() if self.var_mode.get() == "paint" else "pick"
        self.preview.tool = tool
        self.preview.brush_size = self.paint_strip.size.get()

    def _paint_key(self, fn):
        if self.var_mode.get() != "paint":
            return
        try:
            cls = self.root.focus_get().winfo_class()
        except (AttributeError, KeyError, tk.TclError):
            cls = ""
        if cls in ("Entry", "TEntry", "TCombobox", "Text"):
            return
        fn()
        return "break"

    def on_brush(self, phase, x, y, mode):
        if not self.painting():
            return
        f = self.frame
        if phase == "start":
            # brush strokes add (Shift too); Alt erases from the selection
            self._brush_val = 0 if mode == "subtract" else 1
            self._brush_last = None
        if phase in ("start", "move"):
            offs = brush_offsets(self.paint_strip.shape.get(), self.paint_strip.size.get())
            lx, ly = self._brush_last if self._brush_last else (x, y)
            steps = max(abs(x - lx), abs(y - ly), 1)
            for k in range(1, steps + 1):          # fill gaps between mouse events
                f.stamp(lx + (x - lx) * k // steps, ly + (y - ly) * k // steps,
                        offs, self._brush_val)
            if phase == "start":
                f.stamp(x, y, offs, self._brush_val)
            self._brush_last = (x, y)
            if not self._paint_job:
                self._paint_job = self.root.after(30, self._paint_refresh)
        else:
            self._brush_last = None
            self._paint_refresh()

    def _paint_refresh(self):
        self._paint_job = None
        self._update_preview()
        self._paint_status()

    def _paint_status(self):
        if not self.painting():
            return
        f = self.frame
        n = sum(1 for s, a in zip(f.sel, f.alpha) if s and a)
        self.status(f"Paint: {n} pixel{'s' if n != 1 else ''} selected   "
                    f"undo {len(f.undo)} / redo {len(f.redo)}"
                    f"{'   (unsaved changes)' if f.dirty else ''}")

    def cmd_paint_apply(self):
        if not self.painting():
            return
        if self.lut is None:
            self._recompute()
        n = self.frame.apply(self.lut)
        self.frame.clear_selection()
        self._after_paint_edit()
        if not n:
            self.status("Apply: no selected pixel changed colour.")

    def cmd_paint_undo(self):
        if self.painting() and self.frame.undo_step():
            self._after_paint_edit()

    def cmd_paint_redo(self):
        if self.painting() and self.frame.redo_step():
            self._after_paint_edit()

    def cmd_paint_clear(self):
        if self.painting():
            self.frame.clear_selection()
            self._update_preview()
            self._paint_status()

    def _save_frame(self, path):
        """Save the Paint working image (already remapped) as paletted PNG."""
        out = copy.copy(self.img)
        out.indices = bytes(self.frame.work)
        identity = [(i, self.palette[i]) for i in range(256)]
        warns = image_io.save_image(out, identity, self.palette, False, path)
        self.frame.dirty = False
        self.picker.refresh_labels()
        return warns

    def _dirty_frames(self):
        return [(self.frame_entries[k], f) for k, f in self.frames.items() if f.dirty]

    def cmd_save_all_changed(self):
        """Write every painted frame with unsaved changes. False if cancelled."""
        dirty = self._dirty_frames()
        if not dirty:
            self.status("No painted frames with unsaved changes.")
            return True
        out_dir = filedialog.askdirectory(parent=self.root, title=f"Save {len(dirty)} changed frame(s) to",
                                          initialdir=self.default_export_dir() or None)
        if not out_dir:
            return False
        used, jobs = set(), []
        for e, f in dirty:
            fn = f"{e.name}.png"
            if fn.lower() in used:
                fn = f"{e.name}_{e.kind.lower()}.png"
            used.add(fn.lower())
            jobs.append((e, f, os.path.join(out_dir, fn)))
        existing = [j for j in jobs if os.path.exists(j[2])]
        skip = False
        if existing:
            ans = messagebox.askyesnocancel(
                "Save All Changed", f"{len(existing)} of {len(jobs)} files already exist.\n\n"
                "Yes = overwrite them\nNo = skip them\nCancel = stop", parent=self.root)
            if ans is None:
                return False
            skip = not ans
        identity = [(i, self.palette[i]) for i in range(256)]
        written, failed = 0, []
        for e, f, path in jobs:
            if skip and os.path.exists(path):
                continue
            try:
                img = self.img if e is self.entry else image_io.build_image(
                    e, self.matcher, self.var_dither.get())
                out = copy.copy(img)
                out.indices = bytes(f.work)
                image_io.save_image(out, identity, self.palette, False, path)
                f.dirty = False
                written += 1
            except Exception as ex:
                failed.append(f"{e.name}: {ex}")
        self.cfg["export_dir"] = out_dir
        self.picker.refresh_labels()
        msg = f"Saved {written} painted frame(s)" + (f", {len(failed)} failed" if failed else "") + "."
        self.status(msg, err=bool(failed))
        if failed:
            messagebox.showwarning("Save All Changed", msg + "\n\n" + "\n".join(failed[:20]),
                                   parent=self.root)
            return False
        return True

    def _confirm_unsaved(self):
        """Ask before throwing away painted frames. True = go ahead."""
        dirty = self._dirty_frames()
        if not dirty:
            return True
        ans = messagebox.askyesnocancel(
            "Unsaved paint changes",
            f"{len(dirty)} painted frame(s) have unsaved changes.\n\n"
            "Yes = save them first\nNo = discard them\nCancel = go back", parent=self.root)
        if ans is None:
            return False
        if ans:
            return self.cmd_save_all_changed()
        return True

    # ==================================================== translation string
    def cmd_apply_string(self):
        try:
            t = tt.parse(self.var_string.get())
        except tt.TranslationParseError as e:
            self.status(str(e), err=True)
            return
        self.trans = t if not t.is_empty() else Translation.default()
        self.cur = 0
        self.refresh_list()
        self.open_range(0)
        self.status("Translation string applied.")
        self.schedule()

    def cmd_load_txt(self):
        path = filedialog.askopenfilename(parent=self.root, title="Load translation from file",
                                          initialdir=self.cfg.get("trans_dir") or None,
                                          filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            self.load_translation_path(path)

    def load_translation_path(self, path):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                text = " ".join(l.strip() for l in f if l.strip() and not l.strip().startswith("//"))
            t = tt.parse(text)
        except (OSError, tt.TranslationParseError) as e:
            messagebox.showerror("Load translation", f"Not a valid translation file:\n{e}", parent=self.root)
            return
        self.cfg["trans_dir"] = os.path.dirname(path)
        self._add_recent(path)
        self.trans = t if not t.is_empty() else Translation.default()
        self.cur = 0
        self.refresh_list()
        self.open_range(0)
        self.schedule()
        self.status(f"Loaded translation from {os.path.basename(path)}")

    def cmd_save_txt(self):
        path = filedialog.asksaveasfilename(parent=self.root, title="Save translation to file",
                                            initialdir=self.cfg.get("trans_dir") or None,
                                            defaultextension=".txt",
                                            filetypes=[("Text file", "*.txt")])
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.var_string.get() + "\n")
        self.cfg["trans_dir"] = os.path.dirname(path)
        self._add_recent(path)
        self.status(f"Saved translation to {os.path.basename(path)}")

    def _add_recent(self, path):
        path = os.path.abspath(path)
        rec = [p for p in self.cfg.get("recent_trans", []) if os.path.normcase(p) != os.path.normcase(path)]
        self.cfg["recent_trans"] = ([path] + rec)[:12]
        self._refresh_recent()

    def _refresh_recent(self):
        rec = [p for p in self.cfg.get("recent_trans", []) if os.path.isfile(p)]
        self.cfg["recent_trans"] = rec
        self.recent_cb.configure(values=[os.path.basename(p) for p in rec])
        self.var_recent.set("Recent stacks\u2026" if rec else "no recent stacks")

    def _recent_picked(self, _e):
        k = self.recent_cb.current()
        rec = self.cfg.get("recent_trans", [])
        if 0 <= k < len(rec):
            self.load_translation_path(rec[k])

    # ================================================================ close
    def on_close(self):
        if not self._confirm_unsaved():
            return
        self.cfg.update({
            "palette_path": self.pal_path,
            "translation": tt.to_text(self.trans, self.palette),
            "match": self.matcher.method,
            "truecolor": self.var_truecolor.get(),
            "palette_only": self.var_palonly.get(),
            "dither": self.var_dither.get(),
            "show_outline": self.var_outline.get(),
            "paint_tool": self.paint_strip.tool.get(),
            "paint_shape": self.paint_strip.shape.get(),
            "paint_size": self.paint_strip.size.get(),
            "geometry": self.root.geometry(),
            "sashes": self._save_sashes(),
            "folded": {p.name: p.folded for p in self.panels},
        })
        settings_mod.save(self.cfg)
        self.root.destroy()


def run(source_path=None, palette_path=None):
    dpi.enable()
    root = tk.Tk()
    dpi.init(root)
    try:
        style = ttk.Style(root)
        style.theme_use("vista" if "vista" in style.theme_names() else "clam")
    except tk.TclError:
        pass
    App(root, source_path, palette_path)
    root.mainloop()
