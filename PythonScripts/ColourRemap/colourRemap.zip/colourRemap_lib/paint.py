"""
paint.py - Paint mode engine (no tkinter).

A PaintFrame is one image being touched up. It holds the working indices
(starting from the Batch result), a pixel selection mask, and undo/redo.
The current translation previews on selected pixels only; apply() bakes it.
"""

from PIL import Image

SHAPES = ("Square", "Circle", "Diamond")


def brush_offsets(shape, size):
    """(dx, dy) offsets covered by a brush of [size] pixels across."""
    size = max(1, int(size))
    r0 = -(size // 2)
    r1 = r0 + size - 1
    c = (size - 1) / 2.0
    out = []
    for dy in range(r0, r1 + 1):
        for dx in range(r0, r1 + 1):
            if shape == "Circle":
                ax, ay = dx - r0 - c, dy - r0 - c
                if ax * ax + ay * ay > (c + 0.5) ** 2:
                    continue
            elif shape == "Diamond":
                if abs(dx - r0 - c) + abs(dy - r0 - c) > c + 0.5:
                    continue
            out.append((dx, dy))
    return out


class PaintFrame:
    def __init__(self, width, height, indices, alpha):
        self.w = width
        self.h = height
        self.alpha = alpha
        self.work = bytearray(indices)
        self.sel = bytearray(width * height)
        self.undo = []
        self.redo = []
        self.dirty = False

    # ------------------------------------------------------------ selection
    def stamp(self, x, y, offsets, value):
        w, h, sel = self.w, self.h, self.sel
        for dx, dy in offsets:
            px, py = x + dx, y + dy
            if 0 <= px < w and 0 <= py < h:
                sel[py * w + px] = value

    def rect(self, x0, y0, x1, y1, value):
        for y in range(max(0, y0), min(self.h - 1, y1) + 1):
            row = y * self.w
            for x in range(max(0, x0), min(self.w - 1, x1) + 1):
                self.sel[row + x] = value

    def clear_selection(self):
        self.sel = bytearray(self.w * self.h)

    def has_selection(self):
        return any(self.sel)

    def selection_mask(self):
        """L image, 255 where selected AND visible."""
        m = bytes(255 if (s and a) else 0 for s, a in zip(self.sel, self.alpha))
        return Image.frombytes("L", (self.w, self.h), m)

    # ---------------------------------------------------------------- apply
    def apply(self, lut):
        """Bake [lut] into selected visible pixels. Returns pixels changed."""
        new = [e[0] for e in lut]
        before = bytes(self.work)
        changed = 0
        for p in range(self.w * self.h):
            if self.sel[p] and self.alpha[p]:
                d = new[self.work[p]]
                if d != self.work[p]:
                    self.work[p] = d
                    changed += 1
        if changed:
            self.undo.append(before)
            self.redo.clear()
            self.dirty = True
        return changed

    def reset(self, indices):
        """Start over from [indices] (Start from: Batch / Original). Undoable."""
        new = bytearray(indices)
        if new == self.work:
            return False
        self.undo.append(bytes(self.work))
        self.redo.clear()
        self.work = new
        self.dirty = True
        return True

    def selected_indices(self):
        """Distinct working indices under the selection (visible pixels only)."""
        return {self.work[p] for p in range(self.w * self.h) if self.sel[p] and self.alpha[p]}

    def undo_step(self):
        if not self.undo:
            return False
        self.redo.append(bytes(self.work))
        self.work = bytearray(self.undo.pop())
        self.dirty = True
        return True

    def redo_step(self):
        if not self.redo:
            return False
        self.undo.append(bytes(self.work))
        self.work = bytearray(self.redo.pop())
        self.dirty = True
        return True

    # --------------------------------------------------------------- render
    def render(self, lut, palette, truecolor=False, preview=True):
        """RGBA: working image, with [lut] previewed on the selection only."""
        size = (self.w, self.h)
        flat = [v for c in palette for v in c]
        base = Image.frombytes("P", size, bytes(self.work))
        base.putpalette(flat)
        base = base.convert("RGBA")
        alpha = Image.frombytes("L", size, self.alpha)
        base.putalpha(alpha)
        if not preview or lut is None or not self.has_selection():
            return base
        if truecolor:
            table = [lut[i][1] for i in range(256)]
        else:
            table = [palette[lut[i][0]] for i in range(256)]
        tr = Image.frombytes("P", size, bytes(self.work))
        tr.putpalette([v for c in table for v in c])
        tr = tr.convert("RGBA")
        tr.putalpha(alpha)
        return Image.composite(tr, base, self.selection_mask())
