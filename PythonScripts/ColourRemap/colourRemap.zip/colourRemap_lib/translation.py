"""
translation.py - a Translation (list of ranges or a built-in) and its LUT.

The LUT is 256 entries of (index, (r, g, b)):
  index - the pal0 index the source index ends up as
  rgb   - the exact colour before snapping (what Truecolor output uses)

Behaviour matches SLADE's Translation::translate():
  * every range tests the ORIGINAL index; ranges never chain
  * the loop doesn't stop, so the LAST matching range wins
  * palette ranges truncate (no rounding), reverse via negative delta
  * gradient/desat/colourise/tint results snap via nearest colour
Deliberate fix: Inverse is computed as 255 - grey instead of relying on
SLADE's uint8 wraparound (results are near-identical).
"""

from . import colour_math as cm
from .ranges import PaletteRange, ColourRange, DesatRange, BlendRange, TintRange

# Ice colours (from the Hexen palette), as in SLADE/ZDoom
ICE_RANGE = [
    (10, 8, 18), (15, 15, 26), (20, 16, 36), (30, 26, 46),
    (40, 36, 57), (50, 46, 67), (59, 57, 78), (69, 67, 88),
    (79, 77, 99), (89, 87, 109), (99, 97, 120), (109, 107, 130),
    (118, 118, 141), (128, 128, 151), (138, 138, 162), (148, 148, 172),
]

BUILTINS = ("Inverse", "Gold", "Red", "Green", "Blue", "Ice", "Desaturate")

# start/end float multipliers for the preset desaturated blends
_PRESETS = {
    "inverse": ((1.0, 1.0, 1.0), (0.0, 0.0, 0.0)),   # Doom invuln, Strife sigil
    "gold":    ((0.0, 0.0, 0.0), (1.5, 0.75, 0.0)),  # Heretic invuln
    "red":     ((0.0, 0.0, 0.0), (1.5, 0.0, 0.0)),   # Skulltag doomsphere
    "green":   ((0.0, 0.0, 0.0), (1.25, 1.5, 1.0)),  # Skulltag guardsphere
    "blue":    ((0.0, 0.0, 0.0), (0.0, 0.0, 1.5)),   # Hacx invuln
}


def _clamp(v):
    v = int(v)
    return 0 if v < 0 else 255 if v > 255 else v


def special_blend(rgb, name, matcher):
    """ZDoom special blends. [name] is ice/inverse/red/green/blue/gold or
    desatN (N 1..31). Returns (index, rgb) or None if the name is invalid."""
    name = name.lower()
    grey = cm.grey_zdoom(rgb)

    if name == "ice":
        col = ICE_RANGE[min(int(grey) >> 4, 15)]
        return matcher.nearest(col), col

    if name.startswith("desat"):
        try:
            amt = int(name[-2:])
        except ValueError:
            return None
        if not 1 <= amt <= 31:
            return None
        a = amt - 1  # 0..30
        col = tuple(min(255, int((c * (31 - a) + grey * a) / 31)) for c in rgb)
        return matcher.nearest(col), col

    preset = _PRESETS.get(name)
    if preset is None:
        return None
    s, e = preset
    g = grey / 255.0
    col = tuple(_clamp((s[k] + g * (e[k] - s[k])) * 255.0) for k in range(3))
    return matcher.nearest(col), col


def _lum(rgb):
    return rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114


def _pal_formula(s, e, ds, de, i):
    span = e - s
    frac = (i - s) / span if span else 0.0
    return _clamp(ds + frac * (de - ds))


def _runs(indices):
    """Sorted unique indices -> list of (start, end) unbroken runs."""
    out = []
    for i in sorted(set(indices)):
        if out and i == out[-1][1] + 1:
            out[-1][1] = i
        else:
            out.append([i, i])
    return [tuple(r) for r in out]


def _merge_pairs(pairs):
    """{src: dst} -> fewest PaletteRanges that reproduce it exactly."""
    src = sorted(pairs)
    out, k = [], 0
    while k < len(src):
        j, step = k, None
        while j + 1 < len(src) and src[j + 1] == src[j] + 1:
            d = pairs[src[j + 1]] - pairs[src[j]]
            if d not in (-1, 0, 1) or (step is not None and d != step):
                break
            step = d
            j += 1
        s, e = src[k], src[j]
        ds, de = pairs[s], pairs[e]
        if all(_pal_formula(s, e, ds, de, i) == pairs[i] for i in range(s, e + 1)):
            out.append(PaletteRange(s, e, ds, de))
        else:
            out.extend(PaletteRange(i, i, pairs[i], pairs[i]) for i in range(s, e + 1))
        k = j + 1
    return out


def pick_order(group, palette):
    """The picked indices in the order they're laid onto the target."""
    idx = sorted(set(group.indices))
    if group.order == "bright":
        idx.sort(key=lambda i: (-_lum(palette[i]), i))
    return idx


def expand_picks(group, palette):
    """PickGroup -> ordinary ranges (exact)."""
    if not group.ready:
        return []
    order = pick_order(group, palette)
    n = len(order)
    if not n:
        return []
    t = group.inner
    k = t.kind
    if k == "palette":
        pairs = {}
        for pos, i in enumerate(order):
            frac = pos / (n - 1) if n > 1 else 0.0
            pairs[i] = _clamp(t.dstart + frac * (t.dend - t.dstart))
        return _merge_pairs(pairs)
    if k == "colour":
        out = []
        for pos, i in enumerate(order):
            frac = pos / (n - 1) if n > 1 else 0.0
            col = tuple(_clamp(t.c1[c] + frac * (t.c2[c] - t.c1[c])) for c in range(3))
            out.append(ColourRange(i, i, col, col))
        return sorted(out, key=lambda r: r.start)
    runs = _runs(order)
    if k == "desat":
        return [DesatRange(a, b, t.f1, t.f2) for a, b in runs]
    if k == "blend":
        return [BlendRange(a, b, t.colour) for a, b in runs]
    if k == "tint":
        return [TintRange(a, b, t.colour, t.amount) for a, b in runs]
    return []


class Translation:
    def __init__(self):
        self.ranges = []
        self.builtin = ""        # "" or one of BUILTINS
        self.desat_amount = 1    # used when builtin == "Desaturate"

    # ---------------------------------------------------------------- basics
    def is_empty(self):
        return not self.builtin and not self.ranges

    def copy(self):
        t = Translation()
        from .ranges import copy_range
        t.ranges = [copy_range(r) for r in self.ranges]
        t.builtin = self.builtin
        t.desat_amount = self.desat_amount
        return t

    @staticmethod
    def default():
        """What SLADE's dialog opens with: one 0:0=0:0 palette range."""
        t = Translation()
        t.ranges.append(PaletteRange())
        return t

    # ---------------------------------------------------------------- mapping
    def flat_ranges(self, palette):
        """Ranges with every PickGroup expanded in place (order kept)."""
        out = []
        for r in self.ranges:
            if r.kind == "picks":
                out.extend(expand_picks(r, palette))
            else:
                out.append(r)
        return out

    def translate_index(self, i, palette, matcher, ranges=None):
        """Translate source index [i]. Returns (index, rgb)."""
        if ranges is None:
            ranges = self.flat_ranges(palette)
        src = palette[i]

        if self.builtin:
            name = self.builtin.lower()
            if name == "desaturate":
                name = f"desat{max(1, min(31, self.desat_amount)):02d}"
            res = special_blend(src, name, matcher)
            return res if res else (i, src)

        out = (i, src)
        for r in ranges:
            if i < r.start or i > r.end:
                continue
            span = r.end - r.start
            frac = (i - r.start) / span if span else 0.0
            k = r.kind

            if k == "palette":
                di = _clamp(r.dstart + frac * (r.dend - r.dstart))
                out = (di, palette[di])

            elif k == "colour":
                col = tuple(_clamp(r.c1[n] + frac * (r.c2[n] - r.c1[n])) for n in range(3))
                out = (matcher.nearest(col), col)

            elif k == "desat":
                g = cm.grey_desat(src)
                col = tuple(_clamp((r.f1[n] + g * (r.f2[n] - r.f1[n])) * 255.0) for n in range(3))
                out = (matcher.nearest(col), col)

            elif k == "blend":
                g = cm.grey_blend(src)
                col = tuple(_clamp(r.colour[n] * g) for n in range(3))
                out = (matcher.nearest(col), col)

            elif k == "tint":
                amt = r.amount * 0.01
                inv = 1.0 - amt
                col = tuple(_clamp(src[n] * inv + r.colour[n] * amt) for n in range(3))
                out = (matcher.nearest(col), col)

            elif k == "special":
                res = special_blend(src, r.name, matcher)
                # SLADE returns straight away from a special range
                return res if res else (i, src)
        return out

    def build_lut(self, palette, matcher):
        flat = self.flat_ranges(palette)
        return [self.translate_index(i, palette, matcher, flat) for i in range(256)]
