"""
ranges.py - the six translation range types (data only).

Each range maps an origin index span [start..end] to some target.
to_text() gives the ZDoom TRNSLATE form, formatted exactly like SLADE.
"""

from dataclasses import dataclass, replace


@dataclass
class PaletteRange:
    start: int = 0
    end: int = 0
    dstart: int = 0
    dend: int = 0
    kind = "palette"

    def to_text(self):
        return f"{self.start}:{self.end}={self.dstart}:{self.dend}"


@dataclass
class ColourRange:
    start: int = 0
    end: int = 0
    c1: tuple = (0, 0, 0)
    c2: tuple = (255, 255, 255)
    kind = "colour"

    def to_text(self):
        return f"{self.start}:{self.end}=[{self.c1[0]},{self.c1[1]},{self.c1[2]}]:[{self.c2[0]},{self.c2[1]},{self.c2[2]}]"


@dataclass
class DesatRange:
    start: int = 0
    end: int = 0
    f1: tuple = (0.0, 0.0, 0.0)
    f2: tuple = (2.0, 2.0, 2.0)
    kind = "desat"

    def to_text(self):
        a, b = self.f1, self.f2
        return (f"{self.start}:{self.end}=%[{a[0]:1.2f},{a[1]:1.2f},{a[2]:1.2f}]"
                f":[{b[0]:1.2f},{b[1]:1.2f},{b[2]:1.2f}]")


@dataclass
class BlendRange:
    start: int = 0
    end: int = 0
    colour: tuple = (255, 0, 0)
    kind = "blend"

    def to_text(self):
        c = self.colour
        return f"{self.start}:{self.end}=#[{c[0]},{c[1]},{c[2]}]"


@dataclass
class TintRange:
    start: int = 0
    end: int = 0
    colour: tuple = (255, 0, 0)
    amount: int = 50
    kind = "tint"

    def to_text(self):
        c = self.colour
        return f"{self.start}:{self.end}=@{self.amount}[{c[0]},{c[1]},{c[2]}]"


@dataclass
class SpecialRange:
    start: int = 0
    end: int = 0
    name: str = ""
    kind = "special"

    def to_text(self):
        return f"{self.start}:{self.end}=${self.name}"


KINDS = {
    "palette": PaletteRange,
    "colour": ColourRange,
    "desat": DesatRange,
    "blend": BlendRange,
    "tint": TintRange,
    "special": SpecialRange,
}


def copy_range(r):
    if r.kind == "picks":
        return PickGroup(list(r.indices), replace(r.inner), r.order, r.ready)
    return replace(r)


@dataclass
class PickGroup:
    """Origin indices picked from the sprite (any set, not one unbroken span),
    plus a target. [inner] is an ordinary range whose TARGET fields are used
    (its start/end are ignored). Expanded into ordinary ranges by
    translation.expand_picks() when the LUT or string is built.

    order: "bright" - picks laid onto the target lightest first
           "index"  - picks laid onto the target in palette-index order
    ready: False until a palette target has been chosen - an unready group
           changes nothing, so picking never blacks out the sprite.
    """
    indices: list = None
    inner: object = None
    order: str = "bright"
    ready: bool = True
    kind = "picks"

    def __post_init__(self):
        if self.indices is None:
            self.indices = []
        if self.inner is None:
            self.inner = PaletteRange()

    @property
    def start(self):
        return min(self.indices) if self.indices else 0

    @property
    def end(self):
        return max(self.indices) if self.indices else 0


KINDS["picks"] = PickGroup
