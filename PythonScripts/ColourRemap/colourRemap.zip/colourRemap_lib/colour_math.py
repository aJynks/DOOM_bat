"""
colour_math.py - greyscale formulas and nearest-palette-colour matching.

SLADE uses three different greyscale formulas depending on the range type;
they're kept separate here so results match SLADE exactly.
"""

import heapq
import math

# ----------------------------------------------------------------------------
# Greyscale
# ----------------------------------------------------------------------------
# Blend ("Colourise") ranges: SLADE's col_greyscale_* cvar defaults
BLEND_GREY = (0.299, 0.587, 0.114)


def grey_desat(rgb):
    """Desaturated gradient ranges: 0.30/0.59/0.11, normalised 0..1."""
    r, g, b = rgb
    return (r * 0.3 + g * 0.59 + b * 0.11) / 255.0


def grey_blend(rgb):
    """Colourise ranges: col_greyscale weights, normalised 0..1, capped at 1."""
    r, g, b = rgb
    return min(1.0, (r * BLEND_GREY[0] + g * BLEND_GREY[1] + b * BLEND_GREY[2]) / 255.0)


def grey_zdoom(rgb):
    """Special blends (ice/inverse/gold/...): ZDoom formula, 0..255 scale."""
    r, g, b = rgb
    return (r * 77 + g * 143 + b * 37) / 256.0


# ----------------------------------------------------------------------------
# CIE Lab / CIEDE2000
# ----------------------------------------------------------------------------
def _lin(c):
    c /= 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def rgb_to_lab(rgb):
    r, g, b = (_lin(v) for v in rgb)
    x = (r * 0.4124564 + g * 0.3575761 + b * 0.1804375) / 0.95047
    y = (r * 0.2126729 + g * 0.7151522 + b * 0.0721750)
    z = (r * 0.0193339 + g * 0.1191920 + b * 0.9503041) / 1.08883

    def f(t):
        return t ** (1.0 / 3.0) if t > 216.0 / 24389.0 else (24389.0 / 27.0 * t + 16.0) / 116.0

    fx, fy, fz = f(x), f(y), f(z)
    return (116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz))


def cie76(l1, l2):
    return (l1[0] - l2[0]) ** 2 + (l1[1] - l2[1]) ** 2 + (l1[2] - l2[2]) ** 2


def ciede2000(l1, l2):
    L1, a1, b1 = l1
    L2, a2, b2 = l2
    c1 = math.hypot(a1, b1)
    c2 = math.hypot(a2, b2)
    cbar7 = ((c1 + c2) / 2.0) ** 7
    g = 0.5 * (1.0 - math.sqrt(cbar7 / (cbar7 + 6103515625.0)))  # 25^7
    a1p, a2p = a1 * (1.0 + g), a2 * (1.0 + g)
    c1p, c2p = math.hypot(a1p, b1), math.hypot(a2p, b2)
    h1p = math.degrees(math.atan2(b1, a1p)) % 360.0 if c1p else 0.0
    h2p = math.degrees(math.atan2(b2, a2p)) % 360.0 if c2p else 0.0

    dL = L2 - L1
    dC = c2p - c1p
    if c1p * c2p == 0:
        dh = 0.0
    else:
        dh = h2p - h1p
        if dh > 180.0:
            dh -= 360.0
        elif dh < -180.0:
            dh += 360.0
    dH = 2.0 * math.sqrt(c1p * c2p) * math.sin(math.radians(dh / 2.0))

    Lbar = (L1 + L2) / 2.0
    Cbar = (c1p + c2p) / 2.0
    if c1p * c2p == 0:
        hbar = h1p + h2p
    elif abs(h1p - h2p) <= 180.0:
        hbar = (h1p + h2p) / 2.0
    elif h1p + h2p < 360.0:
        hbar = (h1p + h2p + 360.0) / 2.0
    else:
        hbar = (h1p + h2p - 360.0) / 2.0

    t = (1.0 - 0.17 * math.cos(math.radians(hbar - 30.0))
         + 0.24 * math.cos(math.radians(2.0 * hbar))
         + 0.32 * math.cos(math.radians(3.0 * hbar + 6.0))
         - 0.20 * math.cos(math.radians(4.0 * hbar - 63.0)))
    lb50 = (Lbar - 50.0) ** 2
    sl = 1.0 + 0.015 * lb50 / math.sqrt(20.0 + lb50)
    sc = 1.0 + 0.045 * Cbar
    sh = 1.0 + 0.015 * Cbar * t
    cbar7 = Cbar ** 7
    rt = (-2.0 * math.sqrt(cbar7 / (cbar7 + 6103515625.0))
          * math.sin(math.radians(60.0 * math.exp(-(((hbar - 275.0) / 25.0) ** 2)))))
    return math.sqrt((dL / sl) ** 2 + (dC / sc) ** 2 + (dH / sh) ** 2
                     + rt * (dC / sc) * (dH / sh))


# ----------------------------------------------------------------------------
# Nearest-colour matching
# ----------------------------------------------------------------------------
# key -> label (dropdown order)
METHODS = {
    "ciede2000": "CIEDE2000",
    "cie76": "CIE76 (Lab)",
    "redmean": "Weighted RGB (redmean)",
    "rgb": "Plain RGB (SLADE default)",
}
DEFAULT_METHOD = "ciede2000"


class Matcher:
    """Finds the nearest pal0 index for an RGB colour.

    Like SLADE: an exact match always wins (lowest index on duplicates),
    and ties go to the lowest index. Results are cached per colour.
    """

    def __init__(self, palette, method=DEFAULT_METHOD):
        self.palette = [tuple(c) for c in palette]
        self.method = method if method in METHODS else DEFAULT_METHOD
        self.exact = {}
        for i, c in enumerate(self.palette):
            self.exact.setdefault(c, i)
        self._labs = [rgb_to_lab(c) for c in self.palette] if self.method in ("ciede2000", "cie76") else None
        self._cache = {}
        self._fast = {}

    def nearest(self, rgb):
        rgb = (int(rgb[0]), int(rgb[1]), int(rgb[2]))
        hit = self.exact.get(rgb)
        if hit is not None:
            return hit
        hit = self._cache.get(rgb)
        if hit is not None:
            return hit

        best, best_d = 0, float("inf")
        if self.method == "ciede2000":
            lab = rgb_to_lab(rgb)
            for i, pl in enumerate(self._labs):
                d = ciede2000(lab, pl)
                if d < best_d:
                    best, best_d = i, d
        elif self.method == "cie76":
            lab = rgb_to_lab(rgb)
            for i, pl in enumerate(self._labs):
                d = cie76(lab, pl)
                if d < best_d:
                    best, best_d = i, d
        elif self.method == "redmean":
            r, g, b = rgb
            for i, (pr, pg, pb) in enumerate(self.palette):
                rm = (r + pr) / 2.0
                dr, dg, db = r - pr, g - pg, b - pb
                d = (2 + rm / 256.0) * dr * dr + 4 * dg * dg + (2 + (255 - rm) / 256.0) * db * db
                if d < best_d:
                    best, best_d = i, d
        else:  # plain RGB, SLADE's "Old" default
            r, g, b = rgb
            for i, (pr, pg, pb) in enumerate(self.palette):
                d = (r - pr) ** 2 + (g - pg) ** 2 + (b - pb) ** 2
                if d < best_d:
                    best, best_d = i, d

        self._cache[rgb] = best
        return best

    def nearest_fast(self, rgb):
        """For bulk truecolour conversion. Lab methods search only the 12
        closest CIE76 candidates (the CIEDE2000 winner is practically always
        among them); RGB methods are already quick and use the full search."""
        if self.method != "ciede2000":
            return self.nearest(rgb)
        rgb = (int(rgb[0]), int(rgb[1]), int(rgb[2]))
        hit = self.exact.get(rgb)
        if hit is not None:
            return hit
        hit = self._fast.get(rgb)
        if hit is not None:
            return hit
        lab = rgb_to_lab(rgb)
        labs = self._labs
        cands = heapq.nsmallest(12, range(256), key=lambda i: cie76(lab, labs[i]))
        best, best_d = cands[0], float("inf")
        for i in sorted(cands):
            d = ciede2000(lab, labs[i])
            if d < best_d:
                best, best_d = i, d
        self._fast[rgb] = best
        return best
