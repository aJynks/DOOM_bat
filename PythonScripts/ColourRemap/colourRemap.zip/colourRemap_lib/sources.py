"""
sources.py - everything colourRemap can open, as a flat list of graphics.

open_source(path) accepts:
  * a PNG file          -> one entry
  * a folder            -> every .png (and Doom-format .lmp) in it, not subfolders
  * a WAD (IWAD/PWAD)   -> sprites (S_), patches (P_), flats (F_), PNG lumps
                           (any namespace, TX_ included), other Doom-format
                           graphics (TITLEPIC, M_*, STBAR...), and textures
                           composited from TEXTURE1/2 + PNAMES

Entries are listed cheaply (headers only); pixel data is decoded on demand
by entry.load(), which returns a raw dict for image_io.raw_to_image().
"""

import io
import os
import struct

from . import doom_gfx as dg

PNG_SIG = b"\x89PNG\r\n\x1a\n"

# lumps that are never graphics, even if their bytes happen to parse as one
NON_GFX = {
    "PLAYPAL", "COLORMAP", "ENDOOM", "ENDTEXT", "ENDSTRF", "PNAMES", "TEXTURE1", "TEXTURE2",
    "GENMIDI", "DMXGUS", "DMXGUSC", "TINTTAB", "XLATAB", "AUTOPAGE", "SNDCURVE", "SNDINFO",
    "THINGS", "LINEDEFS", "SIDEDEFS", "VERTEXES", "SEGS", "SSECTORS", "NODES", "SECTORS",
    "REJECT", "BLOCKMAP", "BEHAVIOR", "SCRIPTS", "TEXTMAP", "ZNODES", "ENDMAP", "DIALOGUE",
    "LEAFS", "LIGHTS", "MACROS", "ANIMATED", "SWITCHES", "DEHACKED", "MAPINFO", "UMAPINFO",
    "DECORATE", "TRNSLATE", "LOCKDEFS", "SNDSEQ", "LANGUAGE", "GAMEINFO", "KEYCONF",
}

NS_SPRITE = {"S", "SS"}
NS_PATCH = {"P", "PP", "P1", "P2", "P3"}
NS_FLAT = {"F", "FF", "F1", "F2", "F3"}
NS_TX = {"TX"}


class Entry:
    def __init__(self, name, kind, w, h, offsets, loader, note=""):
        self.name = name
        self.kind = kind          # Sprite / Patch / Flat / Graphic / Texture / PNG / Picture
        self.w = w
        self.h = h
        self.offsets = offsets    # (x, y) or None
        self.loader = loader
        self.note = note

    def load(self):
        return self.loader()

    def size_text(self):
        return f"{self.w}x{self.h}"

    def offs_text(self):
        return f"{self.offsets[0]},{self.offsets[1]}" if self.offsets else ""

    def label(self):
        s = f"{self.name:<12} {self.kind:<8} {self.size_text():>9}"
        if self.offsets:
            s += f"  ({self.offs_text()})"
        if self.note:
            s += f"  [{self.note}]"
        return s


class Source:
    def __init__(self, path, desc, entries):
        self.path = path
        self.desc = desc
        self.entries = entries


class SourceError(Exception):
    pass


# ----------------------------------------------------------------------------
# PNG helpers
# ----------------------------------------------------------------------------
def png_info(data):
    """(w, h, grab_offsets_or_None) from PNG bytes, header-only."""
    if data[:8] != PNG_SIG or len(data) < 24:
        return None
    w, h = struct.unpack(">II", data[16:24])
    offs = None
    pos = 8
    while pos + 8 <= len(data):
        ln, = struct.unpack(">I", data[pos:pos + 4])
        ctype = data[pos + 4:pos + 8]
        if ctype == b"grAb" and ln >= 8:
            offs = struct.unpack(">ii", data[pos + 8:pos + 16])
        if ctype in (b"IDAT", b"IEND"):
            break
        pos += 12 + ln
    return w, h, offs


def decode_png(data):
    from PIL import Image
    info = png_info(data)
    im = Image.open(io.BytesIO(data))
    im.load()
    offs = info[2] if info else None
    w, h = im.size
    if im.mode == "P":
        trans = im.info.get("transparency")
        table = [255] * 256
        if isinstance(trans, int):
            table[trans] = 0
        elif isinstance(trans, (bytes, bytearray)):
            for i, a in enumerate(trans[:256]):
                table[i] = a
        ind = im.tobytes()
        return {"mode": "indexed", "w": w, "h": h, "indices": ind,
                "alpha": bytes(255 if table[i] >= 128 else 0 for i in ind),
                "offsets": offs, "png_trans": trans if isinstance(trans, int) else None}
    rgba = im.convert("RGBA")
    return {"mode": "rgba", "w": w, "h": h, "rgba": rgba.tobytes(), "offsets": offs}


# ----------------------------------------------------------------------------
# Openers
# ----------------------------------------------------------------------------
def open_source(path):
    if os.path.isdir(path):
        return _open_folder(path)
    if not os.path.isfile(path):
        raise SourceError(f"Not found: {path}")
    with open(path, "rb") as f:
        head = f.read(8)
    if head[:4] in (b"IWAD", b"PWAD"):
        return _open_wad(path)
    if head == PNG_SIG:
        e = _file_entry(path)
        if not e:
            raise SourceError(f"Can't read {os.path.basename(path)}.")
        return Source(path, os.path.basename(path), [e])
    e = _file_entry(path)
    if e:
        return Source(path, os.path.basename(path), [e])
    raise SourceError(f"{os.path.basename(path)}: not a PNG, WAD or Doom-format graphic.")


def _file_entry(path):
    name, ext = os.path.splitext(os.path.basename(path))
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return None

    def reader():
        with open(path, "rb") as fh:
            return fh.read()

    if data[:8] == PNG_SIG:
        info = png_info(data)
        if not info:
            return None
        return Entry(name, "PNG", info[0], info[1], info[2], lambda: decode_png(reader()))
    hdr = dg.validate_picture(data)
    if hdr:
        return Entry(name, "Picture", hdr[0], hdr[1], (hdr[2], hdr[3]),
                     lambda: dg.decode_picture(reader()))
    fs = dg.flat_size(len(data))
    if fs and ext.lower() in (".lmp", ".raw", ".flat", ""):
        return Entry(name, "Flat", fs[0], fs[1], None, lambda: dg.decode_flat(reader()))
    return None


def _open_folder(path):
    entries = []
    for fn in sorted(os.listdir(path), key=str.lower):
        full = os.path.join(path, fn)
        if not os.path.isfile(full) or os.path.splitext(fn)[1].lower() not in (".png", ".lmp"):
            continue
        e = _file_entry(full)
        if e:
            entries.append(e)
    if not entries:
        raise SourceError(f"No PNG or Doom-format graphics in {path}")
    return Source(path, f"{os.path.basename(os.path.normpath(path))}\\  (folder, {len(entries)} images)", entries)


def _open_wad(path):
    with open(path, "rb") as f:
        data = f.read()
    name = os.path.basename(path)
    try:
        numlumps, diroffs = struct.unpack_from("<ii", data, 4)
    except struct.error:
        raise SourceError(f"{name}: truncated WAD header.")

    lumps = []
    for n in range(numlumps):
        pos = diroffs + n * 16
        if pos + 16 > len(data):
            raise SourceError(f"{name}: WAD directory runs past end of file.")
        offs, size = struct.unpack_from("<ii", data, pos)
        lname = dg._name8(data[pos + 8:pos + 16])
        if size < 0 or offs < 0 or offs + size > len(data):
            size = 0
        lumps.append((lname, offs, size))

    def lump(i):
        _, o, s = lumps[i]
        return data[o:o + s]

    found = {}            # (kind, name) -> Entry, last one wins (PWAD rules)
    order = []
    patch_lookup = {}     # name -> lump index, for texture compositing
    stack = []
    pnames_i = tex_i = None
    tex_list = []

    for i, (ln, offs, size) in enumerate(lumps):
        if size == 0 and (ln.endswith("_START") or ln.endswith("_END")):
            ns = ln.rsplit("_", 1)[0]
            if ln.endswith("_START"):
                stack.append(ns)
            elif stack:
                stack.pop()
            continue
        if size == 0:
            continue
        ns = stack[-1] if stack else ""
        if ln == "PNAMES":
            pnames_i = i
        if ln in ("TEXTURE1", "TEXTURE2"):
            tex_list.append(i)
        if ln in NON_GFX:
            continue

        head = data[offs:offs + 8]
        entry = None
        kind = None
        if head == PNG_SIG:
            info = png_info(data[offs:offs + size])
            if info:
                kind = ("Sprite" if ns in NS_SPRITE else "Flat" if ns in NS_FLAT else
                        "Texture" if ns in NS_TX else "Patch" if ns in NS_PATCH else "Graphic")
                entry = Entry(ln, kind, info[0], info[1], info[2],
                              (lambda k=i: decode_png(lump(k))))
        elif ns in NS_FLAT:
            fs = dg.flat_size(size)
            if fs:
                kind = "Flat"
                entry = Entry(ln, kind, fs[0], fs[1], None, (lambda k=i: dg.decode_flat(lump(k))))
        elif ns in NS_SPRITE or ns in NS_PATCH:
            hdr = dg.picture_header(data[offs:offs + size])
            if hdr:
                kind = "Sprite" if ns in NS_SPRITE else "Patch"
                entry = Entry(ln, kind, hdr[0], hdr[1], (hdr[2], hdr[3]),
                              (lambda k=i: dg.decode_picture(lump(k))))
        elif not ns:
            hdr = dg.validate_picture(data[offs:offs + size])
            if hdr:
                kind = "Graphic"
                entry = Entry(ln, kind, hdr[0], hdr[1], (hdr[2], hdr[3]),
                              (lambda k=i: dg.decode_picture(lump(k))))

        if entry:
            key = (kind, ln)
            if key not in found:
                order.append(key)
            found[key] = entry
            if kind in ("Patch", "Graphic", "Sprite") or head == PNG_SIG:
                # patches first, but any picture lump can be a texture patch
                if kind == "Patch" or ln not in patch_lookup:
                    patch_lookup[ln] = i

    entries = [found[k] for k in order]

    # ---- textures
    n_tex = 0
    if pnames_i is not None and tex_list:
        pnames = dg.parse_pnames(lump(pnames_i))
        cache = {}

        def get_patch(pname):
            if pname in cache:
                return cache[pname]
            raw = None
            li = patch_lookup.get(pname)
            if li is not None:
                d = lump(li)
                try:
                    raw = decode_png(d) if d[:8] == PNG_SIG else dg.decode_picture(d)
                    if raw["mode"] != "indexed":
                        raw = None
                except Exception:
                    raw = None
            if len(cache) > 256:
                cache.clear()
            cache[pname] = raw
            return raw

        seen = set()
        for ti in tex_list:
            for tex in dg.parse_texturex(lump(ti)):
                if tex["name"] in seen:
                    continue
                seen.add(tex["name"])
                miss = [pnames[p] if 0 <= p < len(pnames) else f"#{p}"
                        for _, _, p in tex["patches"]
                        if not (0 <= p < len(pnames) and pnames[p] in patch_lookup)]
                note = f"missing {', '.join(sorted(set(miss)))}" if miss else ""
                entries.append(Entry(tex["name"], "Texture", tex["w"], tex["h"], None,
                                     (lambda t=tex: dg.composite_texture(t, pnames, get_patch)[0]),
                                     note))
                n_tex += 1

    if not entries:
        raise SourceError(f"{name}: no graphics found.")
    counts = {}
    for e in entries:
        counts[e.kind] = counts.get(e.kind, 0) + 1
    def plural(k, v):
        return k.lower() if v == 1 else (k.lower() + ("es" if k == "Patch" else "s"))
    summary = ", ".join(f"{v} {plural(k, v)}" for k, v in counts.items())
    return Source(path, f"{name}  ({summary})", entries)
