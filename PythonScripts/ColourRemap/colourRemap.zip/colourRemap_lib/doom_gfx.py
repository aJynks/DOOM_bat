"""
doom_gfx.py - Doom graphic formats: picture (patch) decode, flats,
PNAMES / TEXTURE1/2 parsing and texture compositing.

All decoders return a "raw" dict understood by image_io.raw_to_image():
  {"mode": "indexed", "w", "h", "indices", "alpha", "offsets"}
"""

import struct

MAX_DIM = 4096


# ----------------------------------------------------------------------------
# Doom picture format (sprites, patches, most graphics)
# ----------------------------------------------------------------------------
def picture_header(data):
    """(w, h, xoff, yoff) if [data] looks like a Doom picture, else None.
    Checks the header and that every column offset is in range."""
    n = len(data)
    if n < 12:
        return None
    w, h, xo, yo = struct.unpack_from("<HHhh", data, 0)
    if not (0 < w <= MAX_DIM and 0 < h <= MAX_DIM):
        return None
    table_end = 8 + 4 * w
    if table_end > n:
        return None
    for off in struct.unpack_from(f"<{w}I", data, 8):
        if off < table_end or off >= n:
            return None
    return w, h, xo, yo


def validate_picture(data):
    """Full check: header plus every post chain terminates inside the lump.
    Used for lumps outside S_/P_ namespaces so random data isn't listed."""
    hdr = picture_header(data)
    if not hdr:
        return None
    w, n = hdr[0], len(data)
    for off in struct.unpack_from(f"<{w}I", data, 8):
        steps = 0
        while True:
            if off >= n:
                return None
            if data[off] == 0xFF:
                break
            if off + 1 >= n:
                return None
            off += data[off + 1] + 4
            steps += 1
            if steps > 512:
                return None
    return hdr


def decode_picture(data):
    hdr = picture_header(data)
    if not hdr:
        raise ValueError("not a valid Doom picture")
    w, h, xo, yo = hdr
    n = len(data)
    idx = bytearray(w * h)
    alpha = bytearray(w * h)
    for x, off in enumerate(struct.unpack_from(f"<{w}I", data, 8)):
        top = -1
        guard = 0
        while off < n and data[off] != 0xFF and guard < 512:
            td = data[off]
            top = top + td if td <= top else td     # tall-patch (DeePsea) rule
            if off + 1 >= n:
                break
            ln = data[off + 1]
            px = data[off + 3:off + 3 + ln]
            for i, v in enumerate(px):
                y = top + i
                if 0 <= y < h:
                    p = y * w + x
                    idx[p] = v
                    alpha[p] = 255
            off += ln + 4
            guard += 1
    return {"mode": "indexed", "w": w, "h": h, "indices": bytes(idx),
            "alpha": bytes(alpha), "offsets": (xo, yo)}


# ----------------------------------------------------------------------------
# Flats
# ----------------------------------------------------------------------------
def flat_size(n):
    """Width/height of a raw flat of [n] bytes, or None."""
    if n <= 0:
        return None
    r = int(round(n ** 0.5))
    if r * r == n:
        return r, r
    if n % 64 == 0:               # e.g. Heretic/Hexen 64x65
        return 64, n // 64
    return None


def decode_flat(data):
    size = flat_size(len(data))
    if not size:
        raise ValueError("not a flat")
    w, h = size
    return {"mode": "indexed", "w": w, "h": h, "indices": bytes(data[:w * h]),
            "alpha": b"\xff" * (w * h), "offsets": None}


# ----------------------------------------------------------------------------
# PNAMES / TEXTURE1 / TEXTURE2
# ----------------------------------------------------------------------------
def _name8(b):
    return b.split(b"\0", 1)[0].decode("ascii", "replace").upper()


def parse_pnames(data):
    if len(data) < 4:
        return []
    count, = struct.unpack_from("<i", data, 0)
    count = max(0, min(count, (len(data) - 4) // 8))
    return [_name8(data[4 + i * 8:12 + i * 8]) for i in range(count)]


def _parse_tex(data, strife):
    count, = struct.unpack_from("<i", data, 0)
    if not 0 < count < 32768 or 4 + 4 * count > len(data):
        raise ValueError
    offs = struct.unpack_from(f"<{count}i", data, 4)
    out = []
    for o in offs:
        if o < 0 or o + 22 > len(data):
            raise ValueError
        name = _name8(data[o:o + 8])
        w, h = struct.unpack_from("<hh", data, o + 12)
        if strife:
            npatch, = struct.unpack_from("<h", data, o + 16)
            p, step = o + 18, 6
        else:
            npatch, = struct.unpack_from("<h", data, o + 20)
            p, step = o + 22, 10
        if not (0 < w <= MAX_DIM and 0 < h <= MAX_DIM and 0 <= npatch < 1024):
            raise ValueError
        if p + npatch * step > len(data):
            raise ValueError
        patches = []
        for k in range(npatch):
            ox, oy, pi = struct.unpack_from("<hhh", data, p + k * step)
            patches.append((ox, oy, pi))
        out.append({"name": name, "w": w, "h": h, "patches": patches})
    return out


def parse_texturex(data):
    """List of {name, w, h, patches:[(x, y, pnames_index)]}. Doom or Strife layout."""
    if len(data) < 4:
        return []
    for strife in (False, True):
        try:
            return _parse_tex(data, strife)
        except (ValueError, struct.error):
            continue
    return []


def composite_texture(tex, pnames, get_patch):
    """Build a texture. get_patch(name) -> raw indexed dict or None.
    Uncovered areas are transparent. Returns (raw, missing_patch_names)."""
    w, h = tex["w"], tex["h"]
    idx = bytearray(w * h)
    alpha = bytearray(w * h)
    missing = []
    for ox, oy, pi in tex["patches"]:
        pname = pnames[pi] if 0 <= pi < len(pnames) else f"#{pi}"
        raw = get_patch(pname)
        if raw is None:
            missing.append(pname)
            continue
        pw, ph, pidx, pal = raw["w"], raw["h"], raw["indices"], raw["alpha"]
        for y in range(ph):
            ty = oy + y
            if ty < 0 or ty >= h:
                continue
            row = y * pw
            trow = ty * w
            for x in range(pw):
                if pal[row + x]:
                    tx = ox + x
                    if 0 <= tx < w:
                        idx[trow + tx] = pidx[row + x]
                        alpha[trow + tx] = 255
    return ({"mode": "indexed", "w": w, "h": h, "indices": bytes(idx),
             "alpha": bytes(alpha), "offsets": None}, missing)
