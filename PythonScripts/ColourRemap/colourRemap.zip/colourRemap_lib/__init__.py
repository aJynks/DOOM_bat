"""colourRemap_lib - standalone clone of SLADE's Colour Remap (translation) tool."""

VERSION = "1.6.0"
