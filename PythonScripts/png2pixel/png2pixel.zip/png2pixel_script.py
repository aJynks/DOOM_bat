#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
png2pixel_script.py  -  turn high resolution images into pixel art, with a
                        realtime preview.

Source kinds (tools for each are being built one at a time)
    normal images              photos, renders, paintings
    AI pixel-art-like images   look like pixel art, but no clean grid
    grid images                pixel art drawn as big solid blocks on a grid

Files
    png2pixel.bat              launcher (put this folder on PATH)
    png2pixel_script.py        this entry script (help, arguments, dependency check)
    png2pixel_lib/             every file prefixed lib_ (no __init__.py needed)
        lib_const.py           constants, DPI scaling, colours
        lib_settings.py        remembered window / panel / tool state
        lib_panels.py          top bar, tool strip, status bar, collapse slivers
        lib_viewport.py        image view: zoom, pan, fit, hide-all button, eyedropper
        lib_popups.py          the tool window host (one tool at a time)
        lib_widgets.py         shared widgets: scroll frame, number box, dialogs
        lib_colour.py          colour space maths
        lib_colourpick.py      colour picker with a dropdown of picker styles
        lib_stack.py           snapshot stack, image loading, project files
        lib_batch.py           Process Folder (replays the stack)
        lib_export.py          Export window (true colour / paletted)
        lib_palette.py         palettes, matching, dithering (Pal0)
        lib_paldialog.py       Pal0 options window
        lib_app.py             main window, wiring, hotkeys
        tools/                 every file prefixed tool_
            tool_registry.py   the list of tools by name
            tool_base.py       the tool interface
            tool_force_grid.py Force Grid (tool window)
            tool_force_grid_engine.py  Force Grid image work (also used by batch)
            tool_adjust.py     Adjust (tool window)
            tool_adjust_engine.py      Adjust maths (also used by batch)
            tool_rebuild.py    Rebuild
            tool_gridui.py     grid controls (Raw / Doom Size) for Force Grid + Rebuild
            tool_titlepic.py   titlePic
            tool_scale.py      Scale (tool window)
            tool_scaleui.py    scaling method / options panel (Scale + titlePic)
            tool_scale_engine.py       scaling methods (also used by batch)
            tool_sprite.py     Sprite

Run with -h for the command line help.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

C_H = "\033[1;96m"
C_O = "\033[93m"
C_D = "\033[37m"
C_E = "\033[92m"
C_R = "\033[0m"
C_T = "\033[1;97m"


def _enable_ansi():
    if os.name == "nt":
        os.system("")


# --------------------------------------------------------------------------
#  Help (house style)
# --------------------------------------------------------------------------
def print_help():
    _enable_ansi()
    print(f"""
{C_T}png2pixel{C_R} {C_D}- turn high resolution images into pixel art{C_R}

{C_H}USAGE{C_R}
  png2pixel [image]

{C_H}ARGUMENTS{C_R}
  {C_O}image{C_R}              Image to open on startup (any size, any format Pillow reads).

{C_H}OPTIONS{C_R}
  {C_O}-h, --help{C_R}         Show this help.

{C_H}WINDOW{C_R}
  Top bar      Open, Load / Save Project, Export, Process Folder, Pal0 + Preview,
               Fit, Compare, zoom readout
  Viewport     the result image. Mouse wheel zooms around the cursor,
               double-click fits.
                 100% and up   whole-number zoom so pixels stay exact squares:
                               wheel {ZOOM_STEPS} levels a notch, Ctrl+wheel 1 level
                 below 100%    big sources, smooth steps between fit and 1:1:
                               wheel about 25% a notch, Ctrl+wheel about 5%
                 Shift+wheel works the same as Ctrl+wheel
               Pan: drag with the middle or right button, or hold Space and
               drag with the left button (plain left-drag is kept for tools).
               Works at any zoom; part of the image always stays on screen
  Tool strip   right side; each button opens that tool in its own window.
               Tool windows are detached: drag them anywhere, they stay open.
               One tool at a time: opening another asks Apply / Discard /
               Cancel if the current one has a result. Every tool window has
                 Reset     options back to defaults
                 Discard   close, image unchanged
                 Apply     the result becomes the working image
               Each tool's options and window position are remembered. A window taller
               than the screen scrolls: mouse wheel anywhere in it, or drag the
               scrollbar on its right edge
  Status bar   messages, result size, source size, zoom, pixel under the cursor

{C_H}SNAPSHOTS{C_R}
  Under the tool buttons. Layer 1 is the opened image; every Apply adds a
  layer holding the result plus the tool, its settings and its cell edits.
  The view always shows the top layer, and the next tool works on it.
    Delete top layer      removes it and reopens its tool with the same
                          settings and edits, as a live preview
    Save / Load Project   the whole stack in one .png2pixel file (a zip with
                          the original, every layer image and all settings)
    Export                saves the top layer (true colour and / or paletted)
    Process Folder        replays every layer (settings and cell edits) on each
                          image in a folder; saves -truecolour / -paletted PNGs.
                          Cell edits are skipped, and reported, for an image
                          whose grid has a different number of cells

{C_H}PAL0{C_R}
  Preview (tick box)    shows the view converted to the palette; nothing is
                        baked in, every tool keeps working in true colour, and
                        the eyedropper still picks the true colour
  Pal0 (button)         palette options window: Load... (WAD PLAYPAL, .pal /
                        .lmp, JASC, GIMP .gpl, 16x16 swatch image, indexed
                        image) or Doom 2; click swatches / type ranges to
                        exclude indices; metric (OKLab, CIELAB, redmean, RGB),
                        lightness weight, chroma protect; dither (error
                        diffusion or ordered), strength, error clamp, serpentine
  The palette is Doom 2 at every start; a project remembers a custom one.
  The matching / dither options are remembered.
  Export and Process Folder save <name>-truecolour.png and / or
  <name>-paletted.png (indexed, Pal0 settings; an image with transparency is
  saved as RGBA in the palette's colours).

{C_H}FORCE GRID{C_R}
  Set a grid and every cell is redrawn as one solid colour, at full size.
    Cell width / height   decimals allowed
    Offset X / Y          where the first grid line sits
    Raw Size / Doom Size  the rebuild size with square cells / with cells 1.2x
                          taller (squashed for Doom). Tick one to use it; type
                          W or H into either to set the cells
    Sample area           only the middle of each cell votes (blurry edges don't)
    Colour grouping       near-identical colours counted together (0 = exact)
    Show result           off = the image underneath, for lining up the grid
  Select cells in the view: click, drag a rectangle, Shift adds, Ctrl removes.
    Apply edits to        Selection, or Whole image
    Colour list           flat cell colours: In selection (click to narrow the
                          edits to that colour, Ctrl-click several) or Adjacent
                          (click to paint the targets); Merge similar groups them
    Pick offset           0 = each cell's biggest colour group, 1 = 2nd, ...
    Adjustments           hue / saturation / lightness / contrast, live;
                          Apply to cells bakes them and zeroes the sliders
    Colour picker         HSV square, colour wheel, RGB / HSV / HSL / OKLCH
                          sliders, hex box, Pick from view eyedropper
    Auto                  targets back to their automatic colour
  Changing the grid clears all cell edits. While a tool uses left clicks,
  double-click with the middle button to fit.

{C_H}ADJUST{C_R}
  Whole-image adjustments, one at a time, from a dropdown:
    Basic, Levels, Curves, Brightness / Contrast, Exposure, HSL, Vibrance,
    Colour Balance, White Balance, Shadows / Highlights, Colorize,
    Black & White, Channel Mixer, Gradient Map, Selective Colour, Invert,
    Posterize, Threshold, Sharpen, Blur / Denoise
  Picking another adjustment while the current one changes the image asks
  Apply / Discard / Cancel; Apply adds a layer ("Adjust: Levels") and the next
  adjustment works on that result. Settings are remembered per adjustment.
  Reset adjustment = this one's defaults; double-click a slider's name to
  reset that slider. Levels shows a histogram; Curves: click adds a point,
  drag moves it, right-click deletes it.

{C_H}REBUILD{C_R}
  Every grid cell becomes one pixel of its most common colour (1024 x 768 with
  16 px cells -> 64 x 48). Partial edge cells become pixels too; mostly
  transparent cells become transparent pixels. The grid is copied from the
  nearest Force Grid layer when the tool opens (From Force Grid copies it
  again); type a rebuild size to set it directly. Show result off = the image
  underneath with the grid drawn over it.

{C_H}TITLEPIC{C_R}
  A crop box locked to the title screen's shape: 320 x 200 vanilla,
  426 x 200 widescreen or 560 x 200 ultra wide. Doom squash crops at 240 tall
  and squashes to 200 (off: crops at 200 tall, for already-squashed images).
  Scale off = crop only at the image's own resolution; on = crop and scale to
  the exact size with the Scale tool's methods. Free = any shape, crop only.
  Drag inside the box to move it, drag a corner or an edge to resize (the
  cursor shows what you'll grab); Fit box resets it. The yellow readout shows
  the crop size, and in brackets the size it reduces to.

{C_H}SCALE{C_R}
  Downscale to an exact size: Scale %, Keep aspect, Raw Size / Doom Size
  (height / 1.2 for Doom). Methods: Lanczos 3 / 2, Catmull-Rom, Mitchell,
  Bicubic, Hamming, Bilinear, Box, Nearest (sample point), Majority (pixel art,
  as titlepic), Majority (grouped), Median, DPID (detail preserving),
  Contrast keep, Line keeper (keeps dark outlines), Edge-weighted majority.
  Options: phase search, linear light, pre-flatten (Kuwahara), dark / light
  bias, snap to source colours, despeckle, sharpen after.
  Title screen buttons set exactly 320 / 426 / 560 x 200.

{C_H}SPRITE{C_R}
  Finishes a small image as a Doom graphic (run it last):
    Background    colour key (auto border colour, or picked) to transparency,
                  only the part touching the edges if wanted; Defringe removes
                  or recolours the halo left round a cut-out
    Transparency  hard 1-bit alpha, remove specks, fill pinholes
    Outline       outer / inner, 4- or 8-connected, fixed colour or darkened
                  neighbours
    Trim / offsets  trim to the visible pixels (+ padding); offsets Feet
                  (monsters, items; ground sink), Centre, Custom or None
  Offsets are written into exported PNGs as a grAb chunk (SLADE reads it), and
  kept in projects and Process Folder output.

{C_H}HIDING PANELS{C_R}
  Every panel has a small hide button. A hidden panel collapses to a thin
  sliver along its edge; click the sliver to bring it back.
  {C_O}\u2630{C_R} button       top-left of the viewport: hide / show all panels
  {C_O}Tab{C_R}              hide / show all panels
  {C_O}F1{C_R} / {C_O}F2{C_R} / {C_O}F3{C_R}     top bar / tool strip / status bar
  {C_O}Ctrl+O{C_R}           open an image

{C_H}REMEMBERED{C_R}
  Window size and position, which panels are hidden, each tool window's
  position and the last folder, per machine in:
    %APPDATA%\\png2pixel\\settings.json

{C_H}EXAMPLES{C_R}
  {C_E}png2pixel{C_R}
  {C_E}png2pixel art\\render.png{C_R}
""")


ZOOM_STEPS = 4


# --------------------------------------------------------------------------
#  Dependency check
# --------------------------------------------------------------------------
def check_deps():
    missing = []
    try:
        import PIL  # noqa: F401
    except ImportError:
        missing.append("pillow")
    try:
        import numpy  # noqa: F401
    except ImportError:
        missing.append("numpy")
    if missing:
        _enable_ansi()
        print(f"\n{C_O}png2pixel: missing dependencies:{C_R} {', '.join(missing)}")
        print(f"  install with:  {C_E}pip install {' '.join(missing)}{C_R}\n")
        sys.exit(1)
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("\npng2pixel: tkinter is not available. Reinstall Python from python.org "
              "with the 'tcl/tk and IDLE' option ticked.\n")
        sys.exit(1)


# --------------------------------------------------------------------------
#  Entry
# --------------------------------------------------------------------------
class _Args:
    image = None


def parse_args(argv):
    a = _Args()
    for t in argv:
        if t in ("-h", "--help", "/?"):
            print_help()
            sys.exit(0)
        elif t.startswith("-"):
            _enable_ansi()
            print(f"{C_O}png2pixel: unknown option {t}{C_R}  (png2pixel -h for help)")
            sys.exit(2)
        else:
            a.image = t
    return a


def main():
    args = parse_args(sys.argv[1:])
    check_deps()
    from png2pixel_lib.lib_app import run
    run(args)


if __name__ == "__main__":
    main()
