@echo off
python "%~dp0png2pixel_script.py" %*
