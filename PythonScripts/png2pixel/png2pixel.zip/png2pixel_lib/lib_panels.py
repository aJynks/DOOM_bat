"""png2pixel - the hideable panels: top bar, tool strip and status bar.

Every panel has its own small hide button. A hidden panel collapses to a thin
sliver along its edge; clicking the sliver (or its arrow) brings it back.
"""
import tkinter as tk
from tkinter import ttk

from .lib_const import (
    S, SMALL, HEAD, GLYPH, PANEL_NAMES, PANEL_HOTKEYS, TOOL_NAMES, TOOL_ON,
    SLIVER_BG, SLIVER_HOVER, SLIVER_FG, GLYPH_FG, GLYPH_HOVER)


# ==========================================================================
#  Small helpers
# ==========================================================================
class Tooltip:
    """Hover tooltip; text may be a string or a function returning one."""

    def __init__(self, widget, text, delay=500):
        self.widget, self.text, self.delay = widget, text, delay
        self._job = None
        self._tip = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _e=None):
        self._cancel()
        self._job = self.widget.after(self.delay, self._show)

    def _cancel(self):
        if self._job:
            self.widget.after_cancel(self._job)
            self._job = None

    def _show(self):
        self._job = None
        text = self.text() if callable(self.text) else self.text
        if not text or not self.widget.winfo_ismapped():
            return
        x = self.widget.winfo_pointerx() + S(12)
        y = self.widget.winfo_pointery() + S(16)
        tip = tk.Toplevel(self.widget)
        tip.wm_overrideredirect(True)
        try:
            tip.attributes("-topmost", True)
        except tk.TclError:
            pass
        tk.Label(tip, text=text, font=SMALL, bg="#ffffe1", fg="#000", relief="solid", bd=1,
                 padx=S(5), pady=S(2), justify="left").pack()
        tip.wm_geometry(f"+{x}+{y}")
        self._tip = tip

    def _hide(self, _e=None):
        self._cancel()
        if self._tip is not None:
            self._tip.destroy()
            self._tip = None


class GlyphButton(tk.Label):
    """A small flat clickable glyph (the hide buttons)."""

    def __init__(self, parent, glyph, command, bg=None, fg=GLYPH_FG, hover=GLYPH_HOVER, font=GLYPH, tip=None):
        bg = bg or ttk.Style().lookup("TFrame", "background") or "#dcdad5"
        super().__init__(parent, text=glyph, bg=bg, fg=fg, font=font, cursor="hand2",
                         padx=S(4), pady=0)
        self._bg, self._hover, self._cmd = bg, hover, command
        self.bind("<Enter>", lambda e: self.configure(bg=self._hover))
        self.bind("<Leave>", lambda e: self.configure(bg=self._bg))
        self.bind("<ButtonRelease-1>", self._click)
        if tip:
            Tooltip(self, tip)

    def set_bg(self, bg):
        self._bg = bg
        self.configure(bg=bg)

    def _click(self, e):
        # only fire if the release is still over the button
        if 0 <= e.x < self.winfo_width() and 0 <= e.y < self.winfo_height():
            self._cmd()


# ==========================================================================
#  Panel: content + collapse sliver
# ==========================================================================
HIDE_GLYPH = {"top": "\u25B2", "right": "\u25B6", "bottom": "\u25BC"}   # points at the edge
SHOW_GLYPH = {"top": "\u25BC", "right": "\u25C0", "bottom": "\u25B2"}   # points back in


class Panel(ttk.Frame):
    """A panel that is either open (content) or collapsed (a thin sliver)."""

    def __init__(self, parent, key, side, on_toggle):
        super().__init__(parent)
        self.key, self.side, self.is_open = key, side, True
        self.content = ttk.Frame(self)
        name, hk = PANEL_NAMES[key], PANEL_HOTKEYS[key]

        self.sliver = tk.Frame(self, bg=SLIVER_BG, cursor="hand2")
        self.arrow = tk.Label(self.sliver, text=SHOW_GLYPH[side], bg=SLIVER_BG, fg=SLIVER_FG,
                              font=GLYPH, cursor="hand2", padx=S(3), pady=0)
        if side == "right":
            self.arrow.pack(side="top", pady=(S(4), 0))
        else:
            self.arrow.pack(side="right", padx=(0, S(8)))
        for w in (self.sliver, self.arrow):
            w.bind("<Button-1>", lambda e: on_toggle(key))
            w.bind("<Enter>", lambda e: self._sliver_hover(True))
            w.bind("<Leave>", lambda e: self._sliver_hover(False))
        Tooltip(self.sliver, f"Show {name} ({hk})")
        Tooltip(self.arrow, f"Show {name} ({hk})")

        self.hide_btn_tip = f"Hide {name} ({hk})"
        self.content.pack(fill="both", expand=True)

    def _sliver_hover(self, on):
        c = SLIVER_HOVER if on else SLIVER_BG
        self.sliver.configure(bg=c)
        self.arrow.configure(bg=c)

    def make_hide_button(self, parent, on_toggle):
        return GlyphButton(parent, HIDE_GLYPH[self.side], lambda: on_toggle(self.key), tip=self.hide_btn_tip)

    def set_open(self, is_open):
        if is_open == self.is_open:
            return
        self.is_open = is_open
        if is_open:
            self.sliver.pack_forget()
            self.content.pack(fill="both", expand=True)
        else:
            self.content.pack_forget()
            self.sliver.pack(fill="both", expand=True)


# ==========================================================================
#  Top bar: file and view actions
# ==========================================================================
class TopBar(Panel):
    def __init__(self, parent, on_toggle, cmds):
        super().__init__(parent, "top", "top", on_toggle)
        bar = ttk.Frame(self.content, padding=(S(4), S(3)))
        bar.pack(fill="x")

        self.make_hide_button(bar, on_toggle).pack(side="right", padx=(S(4), 0))

        def btn(text, key, tip=None):
            b = ttk.Button(bar, text=text, command=cmds[key], takefocus=0)
            b.pack(side="left", padx=S(2))
            if tip:
                Tooltip(b, tip)
            return b

        def sep():
            ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=S(6))

        btn("Open...", "open", "Open an image (Ctrl+O)")
        sep()
        btn("Load Project...", "load_project")
        btn("Save Project...", "save_project")
        sep()
        btn("Export...", "export")
        btn("Process Folder...", "process_folder")
        sep()
        btn("Pal0", "pal0", "Palette options: load a palette, exclude indices, metric, dither")
        self.v_pal = tk.BooleanVar(value=False)
        cb = ttk.Checkbutton(bar, text="Preview", variable=self.v_pal, command=cmds["pal_preview"], takefocus=0)
        cb.pack(side="left", padx=(S(2), 0))
        Tooltip(cb, "Show the view converted to the Pal0 palette (nothing is baked in)")
        sep()
        btn("Fit", "fit", "Fit the image to the view (double-click the view)")
        btn("Center", "center", "Put the image in the middle of the view, keeping the zoom")
        self.btn_compare = btn("Compare: Off", "compare")
        self.zoom_label = ttk.Label(bar, text="Zoom: -", width=16)
        self.zoom_label.pack(side="left", padx=S(6))

    def set_zoom_text(self, text):
        self.zoom_label.configure(text=text)


# ==========================================================================
#  Tool strip: one button per tool, each opens its popup
# ==========================================================================
class ToolStrip(Panel):
    def __init__(self, parent, on_toggle, on_tool, on_delete):
        super().__init__(parent, "tools", "right", on_toggle)
        inner = ttk.Frame(self.content, padding=(S(4), S(3), S(4), S(4)))
        inner.pack(fill="both", expand=True)

        head = ttk.Frame(inner)
        head.pack(fill="x", pady=(0, S(4)))
        ttk.Label(head, text="Tools", font=HEAD).pack(side="left")
        self.make_hide_button(head, on_toggle).pack(side="right")

        self.buttons = {}
        for name in TOOL_NAMES:
            b = ttk.Button(inner, text=name, command=lambda n=name: on_tool(n), takefocus=0)
            b.pack(fill="x", pady=S(2))
            self.buttons[name] = b

        # snapshot stack: shows the layers, the top one is what the view shows
        ttk.Separator(inner).pack(fill="x", pady=(S(8), S(4)))
        ttk.Label(inner, text="Snapshots", font=HEAD).pack(anchor="w")
        lf = ttk.Frame(inner)
        lf.pack(fill="both", expand=True, pady=(S(2), S(4)))
        self.snap = tk.Listbox(lf, font=SMALL, width=22, height=8, activestyle="none", exportselection=False,
                               highlightthickness=1, selectbackground="#ffffff", selectforeground="#000000",
                               cursor="arrow")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.snap.yview)
        self.snap.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.snap.pack(side="left", fill="both", expand=True)
        self.snap.bind("<<ListboxSelect>>", lambda e: self.snap.selection_clear(0, "end"))
        self.btn_delete = ttk.Button(inner, text="Delete top layer", command=on_delete, takefocus=0)
        self.btn_delete.pack(fill="x")
        Tooltip(self.btn_delete, "Remove the top layer and reopen its tool with the same settings")
        self.set_snapshots([])

    def set_snapshots(self, rows):
        """rows: [(number, label, (w, h))], bottom (original) first."""
        lb = self.snap
        lb.delete(0, "end")
        for n, label, (w, h) in rows:
            lb.insert("end", f"{n:>2}  {label}   {w}x{h}")
        if rows:
            lb.itemconfigure(len(rows) - 1, background=TOOL_ON, selectbackground=TOOL_ON)
            lb.see("end")
        self.btn_delete.state(["!disabled"] if len(rows) > 1 else ["disabled"])

    def set_tool_open(self, name, is_open):
        b = self.buttons.get(name)
        if b is not None:
            b.configure(style="ToolOn.TButton" if is_open else "TButton")


# ==========================================================================
#  Status bar: message on the left, readouts on the right
# ==========================================================================
class StatusBar(Panel):
    def __init__(self, parent, on_toggle):
        super().__init__(parent, "status", "bottom", on_toggle)
        bar = ttk.Frame(self.content, padding=(S(6), S(2)))
        bar.pack(fill="x")

        self.make_hide_button(bar, on_toggle).pack(side="right", padx=(S(6), 0))

        self.fields = {}
        for key, width in (("pixel", 14), ("zoom", 15), ("source", 17), ("result", 17)):
            ttk.Separator(bar, orient="vertical").pack(side="right", fill="y", padx=S(4))
            lab = ttk.Label(bar, text="", width=width, anchor="w", font=SMALL)
            lab.pack(side="right")
            self.fields[key] = lab
        self.msg = ttk.Label(bar, text="", anchor="w", font=SMALL)
        self.msg.pack(side="left", fill="x", expand=True)
        self.set_info()

    def set_message(self, text):
        self.msg.configure(text=text)

    def set_info(self, result=None, source=None, zoom=None, pixel=None):
        def size(s):
            return f"{s[0]} x {s[1]}" if s else "-"
        self.fields["result"].configure(text=f"Result: {size(result)}")
        self.fields["source"].configure(text=f"Source: {size(source)}")
        self.fields["zoom"].configure(text=f"Zoom: {zoom or '-'}")
        self.fields["pixel"].configure(text=f"Pixel: {pixel[0]}, {pixel[1]}" if pixel else "Pixel: -")
