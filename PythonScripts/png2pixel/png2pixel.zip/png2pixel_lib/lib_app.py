"""png2pixel - main window: layout, panel hiding, hotkeys, image loading."""
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


from . import lib_const as const
from .lib_const import S, FONT, APP, PANEL_KEYS, IMAGE_EXTS, TOOL_ON
from .lib_panels import TopBar, ToolStrip, StatusBar
from .lib_popups import ToolHost
from .lib_settings import Settings, geometry_on_screen
from .lib_viewport import Viewport
from .lib_stack import Stack, load_image, save_project, load_project, PROJECT_EXT
from .lib_batch import ProcessFolderDialog
from .lib_palette import PalSettings
from .lib_paldialog import PalDialog
from .lib_export import ExportDialog

# widgets that keep Tab for moving between fields
_TEXT_CLASSES = {"Entry", "TEntry", "Spinbox", "TSpinbox", "Text", "TCombobox"}


class App:
    def __init__(self, root, args):
        self.root = root
        self.settings = Settings()
        self.stack = Stack()        # original image + one layer per applied tool
        self.pal = PalSettings()    # Pal0: always Doom 2 at start, options remembered
        self.pal.set_options(self.settings["pal_options"])
        self.pal_dialog = None
        self._pal_cache = {}        # (id(image), size, pal key) -> (image, preview)
        self._pal_job = None
        self.src_path = None
        self.project_path = None
        self._normal_geom = None
        self._space_job = None

        self._style()
        root.title(APP)
        root.minsize(S(640), S(400))

        cmds = {
            "open": self.open_dialog,
            "load_project": self.load_project_dialog,
            "save_project": self.save_project_dialog,
            "export": self.export_dialog,
            "pal0": self.open_pal0,
            "pal_preview": self.pal_preview_toggled,
            "process_folder": self.process_folder,
            "fit": lambda: self.view.fit(),
            "compare": lambda: self.stub("Compare"),
        }
        self.top = TopBar(root, self.toggle_panel, cmds)
        self.tools = ToolStrip(root, self.toggle_panel, self.open_tool, self.delete_layer)
        self.status = StatusBar(root, self.toggle_panel)
        self.view = Viewport(root, self._view_changed, self.toggle_all)
        self.panels = {"top": self.top, "tools": self.tools, "status": self.status}
        self.host = ToolHost(self)

        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)
        self.top.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.view.canvas.grid(row=1, column=0, sticky="nsew")
        self.tools.grid(row=1, column=1, sticky="ns")
        self.status.grid(row=2, column=0, columnspan=2, sticky="ew")

        for key in PANEL_KEYS:
            self.panels[key].set_open(bool(self.settings["panels"].get(key, True)))

        self._bind_keys()
        self._restore_window()
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.bind("<Configure>", self._track_geometry, add="+")

        self.status.set_message("Open an image to start.")
        root.after(100, root.focus_force)       # keys go to the window, not a button
        if args.image:
            root.after(50, lambda: self.load(args.image))

    # ------------------------------------------------------------------
    #  Look
    # ------------------------------------------------------------------
    def _style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", font=FONT)
        style.configure("TButton", padding=(S(6), S(3)))
        # Tk doesn't scale these parts itself: size them for the display (300% -> x3)
        style.configure("TSpinbox", arrowsize=S(16))
        style.configure("TCombobox", arrowsize=S(16))
        style.configure("TScrollbar", arrowsize=S(16))
        style.configure("Horizontal.TScale", sliderlength=S(30), arrowsize=S(22))
        style.configure("Vertical.TScale", sliderlength=S(30), arrowsize=S(22))
        style.configure("TCheckbutton", indicatorsize=S(15), indicatormargin=(0, 0, S(5), 0))
        style.configure("TRadiobutton", indicatorsize=S(15), indicatormargin=(0, 0, S(5), 0))
        style.configure("ToolOn.TButton", padding=(S(6), S(3)), background=TOOL_ON)
        style.map("ToolOn.TButton", background=[("active", TOOL_ON), ("pressed", TOOL_ON)])
        self.root.configure(bg=style.lookup("TFrame", "background") or "#dcdad5")

    # ------------------------------------------------------------------
    #  Panels
    # ------------------------------------------------------------------
    def set_panel(self, key, is_open):
        self.panels[key].set_open(is_open)
        self.settings["panels"][key] = is_open
        self.settings.save()
        self.view.redraw_soon()

    def toggle_panel(self, key):
        self.set_panel(key, not self.panels[key].is_open)

    def toggle_all(self):
        show = not any(p.is_open for p in self.panels.values())
        for key in PANEL_KEYS:
            self.panels[key].set_open(show)
            self.settings["panels"][key] = show
        self.settings.save()
        self.view.redraw_soon()

    # ------------------------------------------------------------------
    #  Keys and wheel
    # ------------------------------------------------------------------
    def _bind_keys(self):
        r = self.root
        r.bind_all("<Tab>", self._tab)
        r.bind_all("<F1>", lambda e: self._key_panel("top"))
        r.bind_all("<F2>", lambda e: self._key_panel("tools"))
        r.bind_all("<F3>", lambda e: self._key_panel("status"))
        r.bind_all("<Control-o>", lambda e: self.open_dialog())
        r.bind_all("<Control-O>", lambda e: self.open_dialog())
        r.bind_all("<MouseWheel>", self._wheel)
        # these widgets would otherwise eat the wheel (change their value):
        # let it scroll the window they're in instead, like a web page
        for cls in ("TCombobox", "TSpinbox", "Spinbox", "Scale", "TScale"):
            r.bind_class(cls, "<MouseWheel>", lambda e: None)
        r.bind_all("<KeyPress-space>", self._space_down)
        r.bind_all("<KeyRelease-space>", self._space_up)
        r.bind_all("<FocusOut>", self._focus_out, add="+")
        r.bind("<Escape>", lambda e: self.view.cancel_pick())

    def _key_panel(self, key):
        self.toggle_panel(key)
        return "break"

    def _tab(self, e):
        # bind_all replaces Tk's own Tab handling, so keep focus moving in fields
        if e.widget.winfo_class() in _TEXT_CLASSES:
            nxt = e.widget.tk_focusNext()
            if nxt is not None:
                nxt.focus_set()
            return "break"
        self.toggle_all()
        return "break"

    def _space_down(self, e):
        if e.widget.winfo_class() in _TEXT_CLASSES:
            return None                 # typing a space in a field
        if self._space_job is not None:     # key auto-repeat: still held
            self.root.after_cancel(self._space_job)
            self._space_job = None
        self.view.set_space(True)
        return "break"

    def _space_up(self, e):
        if e.widget.winfo_class() in _TEXT_CLASSES:
            return None
        # auto-repeat can send release+press pairs; only let go if no press follows
        if self._space_job is not None:
            self.root.after_cancel(self._space_job)
        self._space_job = self.root.after(40, self._space_release)
        return "break"

    def _focus_out(self, _e):
        # switching to another program while Space is held never sends the release
        self.root.after(50, lambda: not self.focus_name() and self._space_release())

    def focus_name(self):
        """Path name of the widget with keyboard focus, '' when another program has it.
        (focus_get() fails while a dropdown list is open: its popdown isn't a tkinter widget.)"""
        try:
            return str(self.root.tk.call("focus"))
        except tk.TclError:
            return ""

    def _space_release(self):
        self._space_job = None
        self.view.set_space(False)

    def _wheel(self, e):
        # by path name: winfo_containing() fails over a dropdown's popdown list
        try:
            path = str(self.root.tk.call("winfo", "containing", e.x_root, e.y_root))
        except tk.TclError:
            return
        if not path:
            return
        if path == str(self.view.canvas):
            self.view.wheel(e)
        elif self.host.handle_wheel(path, e):
            pass
        elif self.pal_dialog is not None:
            self.pal_dialog.handle_wheel(path, e)

    # ------------------------------------------------------------------
    #  Image
    # ------------------------------------------------------------------
    def open_dialog(self):
        pats = " ".join(f"*{x}" for x in IMAGE_EXTS)
        path = filedialog.askopenfilename(
            parent=self.root, title="Open image", initialdir=self.settings["last_dir"] or None,
            filetypes=[("Images", pats), ("All files", "*.*")])
        if path:
            self.load(path)

    @property
    def work(self):
        """The top layer of the snapshot stack: what the next tool works on."""
        return self.stack.top()

    def load(self, path):
        if self.stack.layers and not messagebox.askokcancel(
                APP, "Opening an image starts a new snapshot stack.\nThe current layers will be lost "
                     "(save the project first to keep them).", parent=self.root):
            return
        if not self.host.close(ask=True):
            return
        try:
            im = load_image(path)
        except Exception as ex:
            messagebox.showerror(APP, f"Could not open:\n{path}\n\n{ex}", parent=self.root)
            return
        self.src_path = os.path.abspath(path)
        self.project_path = None
        self.settings["last_dir"] = os.path.dirname(self.src_path)
        self.settings.save()
        name = os.path.basename(self.src_path)
        self.stack.reset(im, name)
        self._stack_changed(keep_view=False)
        self.status.set_message(f"Opened {name}")

    def _stack_changed(self, keep_view=True):
        self.tools.set_snapshots(self.stack.rows())
        self.refresh_display(keep_view=keep_view)
        name = os.path.basename(self.project_path) if self.project_path else self.stack.source_name
        self.root.title(f"{APP} - {name}" if name else APP)

    def refresh_display(self, keep_view=True):
        """Show the open tool's live result, or the working image - through the
        Pal0 palette when Preview is ticked (never baked in)."""
        tool = self.host.tool
        img = tool.display() if tool is not None else None
        if img is None:
            img = self.work
        self.view.overlay = tool.overlay if tool is not None else None
        shown = self._pal_view(img) if img is not None and self.top.v_pal.get() else img
        self.view.set_image(shown, keep_view=keep_view, pick=img)

    # ------------------------------------------------------------------
    #  Pal0 preview
    # ------------------------------------------------------------------
    def _pal_view(self, img):
        key = (id(img), img.size, self.pal.key())
        hit = self._pal_cache.get(key)
        if hit is not None and hit[0] is img:
            return hit[1]
        if self.pal.is_slow() and img.width * img.height > 160000:
            # error diffusion is slow on big images: show true colour, convert after a pause
            if self._pal_job is not None:
                self.root.after_cancel(self._pal_job)
            self._pal_job = self.root.after(400, lambda: self._pal_slow(img, key))
            self.status.set_message("Pal0 preview: dithering...")
            return img
        out = self.pal.preview(img)
        self._pal_store(key, img, out)
        return out

    def _pal_store(self, key, img, out):
        if len(self._pal_cache) > 6:
            self._pal_cache.clear()
        self._pal_cache[key] = (img, out)

    def _pal_slow(self, img, key):
        self._pal_job = None
        if not self.top.v_pal.get() or key[2] != self.pal.key():
            return
        self.root.config(cursor="watch")
        self.root.update_idletasks()
        try:
            out = self.pal.preview(img)
        finally:
            self.root.config(cursor="")
        self._pal_store(key, img, out)
        self.status.set_message("Pal0 preview updated.")
        self.refresh_display()

    def pal_preview_toggled(self):
        self.refresh_display()
        on = self.top.v_pal.get()
        self.status.set_message(f"Pal0 preview {'on' if on else 'off'}: {self.pal.palette.name}")

    def pal_changed(self):
        """Pal0 palette or options changed (from the Pal0 window)."""
        self.settings["pal_options"] = self.pal.options()
        self.settings.save()
        if self.top.v_pal.get():
            self.refresh_display()

    def open_pal0(self):
        if self.pal_dialog is not None:
            self.pal_dialog.top.deiconify()
            self.pal_dialog.top.lift()
            return
        self.pal_dialog = PalDialog(self)

    def commit(self, img, what, opts=None, edits=None, label=None):
        """An applied tool result goes on the snapshot stack as a new layer."""
        self.stack.push(what, opts or {}, edits or {}, img, label)
        self._stack_changed()
        self.status.set_message(f"Applied {label or what}  (layer {len(self.stack.layers) + 1}).")

    def delete_layer(self):
        """Remove the top layer and reopen its tool with the same settings and edits."""
        if not self.stack.layers:
            return
        if not self.host.close(ask=True):
            return
        ly = self.stack.pop()
        self._stack_changed()
        self.host.show(ly.tool, opts=ly.opts, edits=ly.edits)
        self.status.set_message(f"Removed the {ly.label} layer; its settings are open again.")

    # ------------------------------------------------------------------
    #  Export / projects / batch
    # ------------------------------------------------------------------
    def _stem(self):
        if self.project_path:
            return os.path.splitext(os.path.basename(self.project_path))[0]
        return os.path.splitext(self.stack.source_name or "image")[0]

    def export_dialog(self):
        if self.stack.original is None:
            self.status.set_message("Export: open an image first.")
            return
        ExportDialog(self, self._stem())

    def save_project_dialog(self):
        if self.stack.original is None:
            self.status.set_message("Save Project: open an image first.")
            return
        path = filedialog.asksaveasfilename(
            parent=self.root, title="Save project", defaultextension=PROJECT_EXT,
            initialdir=self.settings["project_dir"] or self.settings["last_dir"] or None,
            initialfile=f"{self._stem()}{PROJECT_EXT}", filetypes=[("png2pixel project", f"*{PROJECT_EXT}")])
        if not path:
            return
        try:
            save_project(path, self.stack, self.pal.to_dict())
        except Exception as ex:
            messagebox.showerror(APP, f"Could not save the project:\n{path}\n\n{ex}", parent=self.root)
            return
        self.project_path = path
        self.settings["project_dir"] = os.path.dirname(path)
        self.settings.save()
        self._stack_changed()
        extra = "  (the open tool isn't applied, so it isn't saved)" if self.host.tool is not None \
            and self.host.tool.result() is not None else ""
        self.status.set_message(f"Saved {os.path.basename(path)}  ({len(self.stack.layers) + 1} layers){extra}")

    def load_project_dialog(self):
        path = filedialog.askopenfilename(
            parent=self.root, title="Load project",
            initialdir=self.settings["project_dir"] or self.settings["last_dir"] or None,
            filetypes=[("png2pixel project", f"*{PROJECT_EXT}"), ("All files", "*.*")])
        if path:
            self.load_project(path)

    def load_project(self, path):
        if self.stack.layers and not messagebox.askokcancel(
                APP, "Loading a project replaces the current snapshot stack.", parent=self.root):
            return
        if not self.host.close(ask=True):
            return
        try:
            st = load_project(path)
        except Exception as ex:
            messagebox.showerror(APP, f"Could not load the project:\n{path}\n\n{ex}", parent=self.root)
            return
        self.stack = st
        if st.pal0 is not None:     # the project's palette (Doom 2 unless it saved a custom one)
            self.pal.from_dict(st.pal0)
            self._pal_cache.clear()
            if self.pal_dialog is not None:
                self.pal_dialog.sync()
        self.project_path = os.path.abspath(path)
        self.src_path = None
        self.settings["project_dir"] = os.path.dirname(self.project_path)
        self.settings.save()
        self._stack_changed(keep_view=False)
        self.status.set_message(f"Loaded {os.path.basename(path)}  ({len(st.layers) + 1} layers)")

    def process_folder(self):
        if not self.stack.layers:
            self.status.set_message("Process Folder: apply at least one tool first (it replays the snapshot stack).")
            return
        ProcessFolderDialog(self)

    def _view_changed(self):
        zt = self.view.zoom_text()
        self.top.set_zoom_text(f"Zoom: {zt}")
        shown = self.view.img
        self.status.set_info(
            result=shown.size if shown is not None else None,
            source=self.stack.original.size if self.stack.original is not None else None,
            zoom=zt if shown is not None else None,
            pixel=self.view.pixel())

    # ------------------------------------------------------------------
    #  Tools and stubs
    # ------------------------------------------------------------------
    def open_tool(self, name):
        self.host.show(name)

    def tool_opened(self, tool):
        self.view.mouse = tool if tool.uses_mouse else None
        if tool.hint:
            self.status.set_message(tool.hint)
        self.refresh_display()

    def tool_closed(self):
        self.view.overlay = None
        self.view.mouse = None
        self.view._tool_cursor = ""
        self.view._idle_cursor()
        self.refresh_display()

    def stub(self, what):
        self.status.set_message(f"{what}: not built yet")

    # ------------------------------------------------------------------
    #  Window state
    # ------------------------------------------------------------------
    def _restore_window(self):
        r = self.root
        g = geometry_on_screen(r, self.settings["geometry"])
        if g:
            r.geometry(g)
        else:
            sw, sh = r.winfo_screenwidth(), r.winfo_screenheight()
            w, h = min(S(1200), int(sw * 0.9)), min(S(780), int(sh * 0.85))
            r.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 3)}")
        if self.settings["zoomed"]:
            try:
                r.state("zoomed")
            except tk.TclError:
                pass

    def _track_geometry(self, e):
        if e.widget is self.root:
            try:
                if self.root.state() == "normal":
                    self._normal_geom = self.root.geometry()
            except tk.TclError:
                pass

    def on_close(self):
        try:
            zoomed = self.root.state() == "zoomed"
        except tk.TclError:
            zoomed = False
        self.settings["zoomed"] = zoomed
        if self._normal_geom:
            self.settings["geometry"] = self._normal_geom
        elif not zoomed:
            self.settings["geometry"] = self.root.geometry()
        self.host.save_state()
        self.settings.save()
        self.root.destroy()


def run(args):
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    const.init_dpi(root)
    App(root, args)
    root.mainloop()
