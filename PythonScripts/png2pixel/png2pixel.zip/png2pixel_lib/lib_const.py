"""png2pixel - shared constants, DPI scaling (S / F), fonts and colours."""

APP = "png2pixel"
VERSION = "0.1"

# --------------------------------------------------------------------------
#  DPI scaling
#  Fonts are in points, so Tk scales them itself. Anything sized in pixels
#  goes through S() so it follows the display scaling (300% -> x3).
# --------------------------------------------------------------------------
UI_SCALE = 1.0          # extra manual multiplier on top of the DPI factor
DPI_F = 1.0             # real screen DPI / 96, set by init_dpi()


def init_dpi(root):
    global DPI_F
    try:
        DPI_F = max(1.0, root.winfo_fpixels("1i") / 96.0)
    except Exception:
        DPI_F = 1.0


def S(v):
    return max(1, int(round(v * UI_SCALE * DPI_F)))


def F(pt):
    return max(6, int(round(pt * UI_SCALE)))


FONT = ("Segoe UI", F(10))
SMALL = ("Segoe UI", F(9))
HEAD = ("Segoe UI Semibold", F(11))
GLYPH = ("Segoe UI Symbol", F(8))
VIEW_TEXT = ("Segoe UI", F(14))

# --------------------------------------------------------------------------
#  Colours
# --------------------------------------------------------------------------
VIEW_BG = "#1e1e1e"         # viewport background
VIEW_BORDER = "#444444"     # outline drawn round the image
VIEW_HINT = "#888888"       # "Open an image" text
CHECK_A = 70                # transparency checkerboard greys
CHECK_B = 102
SLIVER_BG = "#b9b9b9"       # collapsed panel strip
SLIVER_HOVER = "#a2a2a2"
SLIVER_FG = "#303030"
GLYPH_FG = "#505050"        # small hide buttons on the panels
GLYPH_HOVER = "#d6d6d6"
ALLBTN_BG = "#3a3a3a"       # hide-all button floating on the viewport
ALLBTN_HOVER = "#555555"
ALLBTN_FG = "#e0e0e0"
TOOL_ON = "#a9cdf2"         # tool button while its window is open
GRID_LINE = "#00c8ff"       # tool grid lines drawn over the image
GRID_SEL = "#ffd000"        # selected cell outline

# --------------------------------------------------------------------------
#  Viewport
# --------------------------------------------------------------------------
MAX_ZOOM = 32
ZOOM_STEPS = 4              # whole-number zoom levels per wheel notch above 100%
ZOOM_STEPS_FINE = 1         # ... with Ctrl (or Shift) held
ZOOM_FRAC = 1.25            # zoom factor per wheel notch below 100%
ZOOM_FRAC_FINE = 1.05       # ... with Ctrl (or Shift) held
PAN_KEEP = 48               # pixels of the image always left on screen when panning
MIN_VIEW = 32               # zooming out stops when the image is this many px (scaled) long

# --------------------------------------------------------------------------
#  Panels and tools
# --------------------------------------------------------------------------
PANEL_KEYS = ("top", "tools", "status")
PANEL_NAMES = {"top": "top bar", "tools": "tool strip", "status": "status bar"}
PANEL_HOTKEYS = {"top": "F1", "tools": "F2", "status": "F3"}

TOOL_NAMES = ["Adjust", "Force Grid", "Rebuild", "titlePic", "Scale", "Sprite"]

IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tga", ".tif", ".tiff", ".webp", ".pcx")
