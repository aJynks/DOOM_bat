"""png2pixel - colour picker with a dropdown of picker styles.

    HSV square      saturation / value square + hue bar (Photoshop style)
    Colour wheel    hue ring with a saturation / value square inside (Krita style)
    RGB sliders     R G B 0..255
    HSV sliders     H 0..360, S V 0..100
    HSL sliders     H 0..360, S L 0..100
    OKLCH sliders   perceptual: L 0..100, C 0..37, H 0..360 (out of gamut is clipped)

All styles share a before / after swatch, a hex box and (optionally) a
"Pick from view" eyedropper button. The hue is remembered when a colour has no
hue of its own (greys), so dragging saturation back up keeps the hue you had.
"""
import math
import tkinter as tk
from tkinter import ttk

import numpy as np
from PIL import Image, ImageTk

from .lib_const import S, SMALL
from .lib_colour import (
    hex_to_rgb255, rgb255_to_hex, to01, to255, rgb_to_hsv, hsv_to_rgb, rgb_to_hsl, rgb_to_oklch,
    hsv_to_rgb_np, hsl_to_rgb_np, oklch_to_rgb_np)

MODES = ["HSV square", "Colour wheel", "RGB sliders", "HSV sliders", "HSL sliders", "OKLCH sliders"]


def _photo(arr01):
    a = (np.clip(arr01, 0, 1) * 255 + 0.5).astype(np.uint8)
    return ImageTk.PhotoImage(Image.fromarray(a, "RGB"))


def _frame_bg():
    return ttk.Style().lookup("TFrame", "background") or "#dcdad5"


def _marker(canvas, x, y, r, tag):
    canvas.delete(tag)
    canvas.create_oval(x - r - 1, y - r - 1, x + r + 1, y + r + 1, outline="#000", width=S(1), tags=tag)
    canvas.create_oval(x - r, y - r, x + r, y + r, outline="#fff", width=S(1), tags=tag)


# ==========================================================================
#  Square + wheel styles (both edit H, S, V)
# ==========================================================================
class _HSVBase(ttk.Frame):
    def __init__(self, parent, picker):
        super().__init__(parent)
        self.picker = picker
        self.h, self.s, self.v = picker.hue, 0.0, 1.0
        self._sv_key = None
        self._sv_photo = None
        self._drag = None

    def from_rgb(self, rgb):
        h, s, v = rgb_to_hsv(rgb)
        if v > 1e-4:
            if s > 1e-4:
                self.h = h
            self.s = s
        else:
            self.h = self.picker.hue
        self.v = v
        self.draw()

    def _sv_image(self, size):
        key = (round(self.h, 1), size)
        if self._sv_key != key:
            xs = np.linspace(0, 1, size, dtype=np.float32)
            ys = np.linspace(1, 0, size, dtype=np.float32)
            sv = hsv_to_rgb_np(self.h, xs[None, :], ys[:, None])
            self._sv_photo = _photo(sv)
            self._sv_key = key
        return self._sv_photo

    def _changed(self):
        self.picker.hue = self.h
        self.picker.picked(hsv_to_rgb(self.h, self.s, self.v), self)
        self.draw()


class SquareMode(_HSVBase):
    def __init__(self, parent, picker):
        super().__init__(parent, picker)
        self.size, self.bar, self.gap = S(170), S(18), S(10)
        w = self.size + self.gap + self.bar
        self.c = tk.Canvas(self, width=w, height=self.size, highlightthickness=0, bg=_frame_bg())
        self.c.pack()
        hues = np.linspace(0, 360, self.size, dtype=np.float32)
        bar = hsv_to_rgb_np(hues[:, None], 1.0, 1.0)
        self._bar_photo = _photo(np.repeat(bar, self.bar, axis=1))
        self.c.create_image(0, 0, anchor="nw", tags="sv")
        self.c.create_image(self.size + self.gap, 0, anchor="nw", image=self._bar_photo)
        self.c.bind("<ButtonPress-1>", self._press)
        self.c.bind("<B1-Motion>", self._move)
        self.c.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag", None))

    def draw(self):
        self.c.itemconfigure("sv", image=self._sv_image(self.size))
        n = self.size - 1
        _marker(self.c, self.s * n, (1 - self.v) * n, S(5), "m_sv")
        y = self.h / 360.0 * n
        x0 = self.size + self.gap
        self.c.delete("m_h")
        self.c.create_rectangle(x0 - S(2), y - S(2), x0 + self.bar + S(2), y + S(2),
                                outline="#000", width=S(1), tags="m_h")

    def _press(self, e):
        self._drag = "sv" if e.x < self.size + self.gap // 2 else "h"
        self._move(e)

    def _move(self, e):
        n = self.size - 1
        if self._drag == "sv":
            self.s = min(1.0, max(0.0, e.x / n))
            self.v = min(1.0, max(0.0, 1 - e.y / n))
        elif self._drag == "h":
            self.h = min(359.99, max(0.0, e.y / n * 360.0))
        else:
            return
        self._changed()


class WheelMode(_HSVBase):
    def __init__(self, parent, picker):
        super().__init__(parent, picker)
        d = self.d = S(200)
        self.cx = self.cy = d / 2
        self.r_out = d / 2 - S(2)
        self.r_in = self.r_out * 0.80
        self.sq = int(self.r_in * math.sqrt(2) * 0.92)
        self.sq0 = (d - self.sq) // 2
        bg = _frame_bg()
        self.c = tk.Canvas(self, width=d, height=d, highlightthickness=0, bg=bg)
        self.c.pack()
        # hue ring (drawn once), blended onto the frame colour
        yy, xx = np.mgrid[0:d, 0:d].astype(np.float32)
        dx, dy = xx - self.cx + 0.5, yy - self.cy + 0.5
        r = np.hypot(dx, dy)
        ang = (np.degrees(np.arctan2(-dy, dx)) + 360.0) % 360.0
        ring = hsv_to_rgb_np(ang, 1.0, 1.0)
        a = np.clip(np.minimum(r - self.r_in, self.r_out - r) + 0.5, 0, 1)[..., None]
        rgb_bg = np.array([v / 65535 for v in self.c.winfo_rgb(bg)], np.float32)
        self._ring_photo = _photo(ring * a + rgb_bg * (1 - a))
        self.c.create_image(0, 0, anchor="nw", image=self._ring_photo)
        self.c.create_image(self.sq0, self.sq0, anchor="nw", tags="sv")
        self.c.bind("<ButtonPress-1>", self._press)
        self.c.bind("<B1-Motion>", self._move)
        self.c.bind("<ButtonRelease-1>", lambda e: setattr(self, "_drag", None))

    def draw(self):
        self.c.itemconfigure("sv", image=self._sv_image(self.sq))
        n = self.sq - 1
        _marker(self.c, self.sq0 + self.s * n, self.sq0 + (1 - self.v) * n, S(5), "m_sv")
        rm = (self.r_in + self.r_out) / 2
        t = math.radians(self.h)
        _marker(self.c, self.cx + rm * math.cos(t), self.cy - rm * math.sin(t), S(5), "m_h")

    def _press(self, e):
        r = math.hypot(e.x - self.cx, e.y - self.cy)
        if self.r_in - S(3) <= r <= self.r_out + S(4):
            self._drag = "h"
        elif self.sq0 - S(4) <= e.x <= self.sq0 + self.sq + S(4) and self.sq0 - S(4) <= e.y <= self.sq0 + self.sq + S(4):
            self._drag = "sv"
        else:
            self._drag = None
        self._move(e)

    def _move(self, e):
        if self._drag == "h":
            self.h = (math.degrees(math.atan2(-(e.y - self.cy), e.x - self.cx)) + 360.0) % 360.0
        elif self._drag == "sv":
            n = self.sq - 1
            self.s = min(1.0, max(0.0, (e.x - self.sq0) / n))
            self.v = min(1.0, max(0.0, 1 - (e.y - self.sq0) / n))
        else:
            return
        self._changed()


# ==========================================================================
#  Slider styles
# ==========================================================================
SLIDERS = {
    "RGB sliders": [("R", 0, 255), ("G", 0, 255), ("B", 0, 255)],
    "HSV sliders": [("H", 0, 360), ("S", 0, 100), ("V", 0, 100)],
    "HSL sliders": [("H", 0, 360), ("S", 0, 100), ("L", 0, 100)],
    "OKLCH sliders": [("L", 0, 100), ("C", 0, 37), ("H", 0, 360)],
}


def _to_rgb_np(kind, v):
    """v: (..., 3) slider values -> (..., 3) rgb 0..1"""
    a, b, c = v[..., 0], v[..., 1], v[..., 2]
    if kind == "RGB sliders":
        return v / 255.0
    if kind == "HSV sliders":
        return hsv_to_rgb_np(a, b / 100.0, c / 100.0)
    if kind == "HSL sliders":
        return hsl_to_rgb_np(a, b / 100.0, c / 100.0)
    return oklch_to_rgb_np(a / 100.0, b / 100.0, c)


class SliderMode(ttk.Frame):
    def __init__(self, parent, picker, kind):
        super().__init__(parent)
        self.picker, self.kind = picker, kind
        self.chans = SLIDERS[kind]
        self.vals = [0.0, 0.0, 0.0]
        self.gw, self.gh = S(190), S(16)
        self.canvases, self.boxes, self.photos = [], [], [None] * 3
        self._editing = None
        from .lib_widgets import NumberBox
        bg = _frame_bg()
        for i, (name, lo, hi) in enumerate(self.chans):
            row = ttk.Frame(self)
            row.pack(fill="x", pady=S(2))
            ttk.Label(row, text=name, width=2).pack(side="left")
            c = tk.Canvas(row, width=self.gw, height=self.gh + S(7), highlightthickness=0, bg=bg)
            c.pack(side="left", padx=(S(2), S(6)))
            c.create_image(0, 0, anchor="nw", tags="grad")
            c.bind("<ButtonPress-1>", lambda e, i=i: self._drag(i, e))
            c.bind("<B1-Motion>", lambda e, i=i: self._drag(i, e))
            box = NumberBox(row, 0, lo, hi, step=1, width=5, decimals=0,
                            on_change=lambda v, i=i: self._typed(i, v))
            box.pack(side="left")
            self.canvases.append(c)
            self.boxes.append(box)

    def from_rgb(self, rgb):
        k = self.kind
        if k == "RGB sliders":
            self.vals = [v * 255.0 for v in rgb]
        elif k == "HSV sliders":
            h, s, v = rgb_to_hsv(rgb)
            hold = s < 1e-4 or v < 1e-4
            self.vals = [self.picker.hue if hold else h, s * 100 if v > 1e-4 else self.vals[1], v * 100]
        elif k == "HSL sliders":
            h, s, l = rgb_to_hsl(rgb)
            self.vals = [self.picker.hue if s < 1e-4 else h, s * 100, l * 100]
        else:
            L, C, H = rgb_to_oklch(rgb)
            self.vals = [L * 100, C * 100, self.picker.hue if C < 0.002 else H]
        self.draw()

    def draw(self, skip_box=None):
        for i, (name, lo, hi) in enumerate(self.chans):
            n = self.gw
            v = np.tile(np.array(self.vals, np.float64), (n, 1))
            v[:, i] = np.linspace(lo, hi, n)
            row = _to_rgb_np(self.kind, v)[None, :, :]
            img = Image.fromarray((np.clip(row, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB")
            self.photos[i] = ImageTk.PhotoImage(img.resize((n, self.gh), Image.Resampling.NEAREST))
            c = self.canvases[i]
            c.itemconfigure("grad", image=self.photos[i])
            x = (self.vals[i] - lo) / (hi - lo) * (n - 1)
            c.delete("m")
            t = S(6)
            c.create_polygon(x, self.gh, x - t, self.gh + S(7), x + t, self.gh + S(7),
                             fill="#202020", outline="#ffffff", tags="m")
            if i != skip_box:
                self.boxes[i].set(self.vals[i])

    def _apply(self, i, skip_box=None):
        name = self.chans[i][0]
        if name == "H":
            self.picker.hue = self.vals[i]
        rgb = tuple(float(x) for x in _to_rgb_np(self.kind, np.array(self.vals, np.float64)))
        self.picker.picked(rgb, self)
        self.draw(skip_box)

    def _drag(self, i, e):
        _, lo, hi = self.chans[i]
        t = min(1.0, max(0.0, e.x / (self.gw - 1)))
        self.vals[i] = lo + t * (hi - lo)
        self._apply(i)

    def _typed(self, i, v):
        self.vals[i] = v
        self._apply(i, skip_box=i)


# ==========================================================================
#  The picker
# ==========================================================================
class ColourPicker(ttk.Frame):
    def __init__(self, parent, on_change, mode=MODES[0], on_mode=None, on_eyedrop=None):
        super().__init__(parent)
        self.on_change, self.on_mode = on_change, on_mode
        self.rgb = (1.0, 1.0, 1.0)
        self.before = None              # 0..255 tuple or None
        self.hue = 0.0
        self.mode_widget = None

        top = ttk.Frame(self)
        top.pack(fill="x")
        self.mode_var = tk.StringVar(value=mode if mode in MODES else MODES[0])
        cb = ttk.Combobox(top, textvariable=self.mode_var, values=MODES, state="readonly", width=15)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self._mode_changed())
        if on_eyedrop:
            ttk.Button(top, text="Pick from view", command=on_eyedrop, takefocus=0).pack(side="right")

        self.area = ttk.Frame(self)
        self.area.pack(fill="x", pady=S(6))

        bot = ttk.Frame(self)
        bot.pack(fill="x")
        self.sw = tk.Canvas(bot, width=S(96), height=S(26), highlightthickness=1, highlightbackground="#888")
        self.sw.pack(side="left")
        ttk.Label(bot, text="before | after", font=SMALL, foreground="#666").pack(side="left", padx=S(6))
        self.hex_var = tk.StringVar()
        ent = ttk.Entry(bot, textvariable=self.hex_var, width=9)
        ent.pack(side="right")
        ttk.Label(bot, text="Hex").pack(side="right", padx=(0, S(4)))
        ent.bind("<Return>", lambda e: self._hex_entered())
        ent.bind("<FocusOut>", lambda e: self._hex_entered())

        self._build_mode()

    # ---------------- modes ----------------
    def _build_mode(self):
        if self.mode_widget is not None:
            self.mode_widget.destroy()
        m = self.mode_var.get()
        if m == "HSV square":
            w = SquareMode(self.area, self)
        elif m == "Colour wheel":
            w = WheelMode(self.area, self)
        else:
            w = SliderMode(self.area, self, m)
        w.pack(anchor="w")
        self.mode_widget = w
        w.from_rgb(self.rgb)

    def _mode_changed(self):
        self._build_mode()
        if self.on_mode:
            self.on_mode(self.mode_var.get())

    # ---------------- colour in / out ----------------
    def set_colour(self, rgb255, before=None, notify=False):
        self.rgb = to01(rgb255)
        self.before = tuple(before[:3]) if before is not None else None
        h, s, v = rgb_to_hsv(self.rgb)
        if s > 1e-4 and v > 1e-4:
            self.hue = h
        self.mode_widget.from_rgb(self.rgb)
        self._draw_swatch()
        if notify:
            self.on_change(self.get255())

    def get255(self):
        return to255(self.rgb)

    def picked(self, rgb, source):
        """Called by a picker style when the user changes the colour."""
        self.rgb = tuple(min(1.0, max(0.0, float(v))) for v in rgb)
        if source is not self.mode_widget:
            self.mode_widget.from_rgb(self.rgb)
        self._draw_swatch()
        self.on_change(self.get255())

    def _hex_entered(self):
        c = hex_to_rgb255(self.hex_var.get())
        if c is None:
            self.hex_var.set(rgb255_to_hex(self.get255()))
            return
        if c != self.get255():
            self.rgb = to01(c)
            h, s, v = rgb_to_hsv(self.rgb)
            if s > 1e-4 and v > 1e-4:
                self.hue = h
            self.mode_widget.from_rgb(self.rgb)
            self._draw_swatch()
            self.on_change(self.get255())

    def _draw_swatch(self):
        c = self.sw
        c.delete("all")
        w, h = S(96), S(26)
        if self.before is not None:
            c.create_rectangle(0, 0, w // 2, h, fill=rgb255_to_hex(self.before), width=0)
        else:
            c.create_rectangle(0, 0, w // 2, h, fill="#999", width=0)
            c.create_line(0, h, w // 2, 0, fill="#c00", width=S(1))
        c.create_rectangle(w // 2, 0, w, h, fill=rgb255_to_hex(self.get255()), width=0)
        self.hex_var.set(rgb255_to_hex(self.get255()))
