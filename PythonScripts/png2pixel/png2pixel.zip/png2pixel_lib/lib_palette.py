"""png2pixel - palette matching and dithering (Pal0 preview and paletted export).

Ported from the titlepic tool (same palette loading, metrics and dithers), with
one change: exact nearest-colour matches are cached per colour, so previewing
images with few colours (Force Grid output) or re-previewing after a small
change is fast. Error diffusion still runs pixel by pixel and is slow on big
images.

Palette files: a WAD with PLAYPAL (palette 0), raw 768-byte .pal / .lmp,
JASC-PAL, GIMP .gpl, a 16x16 swatch-grid image (SLADE pal0.png, DoomTools
playpal.png), or any indexed image.
"""
import os

import numpy as np
from PIL import Image

# --------------------------------------------------------------------------
#  Doom 2 PLAYPAL palette 0 (embedded so the default never needs a file)
# --------------------------------------------------------------------------
DOOM2_PAL0_HEX = (
    "0000001f170b170f074b4b4bffffff1b1b1b1313130b0b0b0707072f371f232b0f171f070f17004f3b2b4733233f2b1b"
    "ffb7b7f7ababf3a3a3eb9797e78f8fdf8787db7b7bd37373cb6b6bc76363bf5b5bbb5757b34f4faf4747a73f3fa33b3b"
    "9b3333972f2f8f2b2b8b2323831f1f7f1b1b7717177313136b0f0f670b0b5f07075b07075307074f0000470000430000"
    "ffebdfffe3d3ffdbc7ffd3bbffcfb3ffc7a7ffbf9bffbb93ffb383f7ab7befa373e79b6bdf9363d78b5bcf8353cb7f4f"
    "bf7b4bb37347ab6f43a36b3f9b633b8f5f378757337f532f774f2b6b47275f4323533f1f4b371b3f2f17332b132b230f"
    "efefefe7e7e7dfdfdfdbdbdbd3d3d3cbcbcbc7c7c7bfbfbfb7b7b7b3b3b3abababa7a7a79f9f9f9797979393938b8b8b"
    "8383837f7f7f7777776f6f6f6b6b6b6363635b5b5b5757574f4f4f4747474343433b3b3b3737372f2f2f272727232323"
    "77ff6f6fef6767df5f5fcf575bbf4f53af474b9f3f4393373f832f37732b2f632327531b1f431717330f13230b0b1707"
    "bfa78fb79f87af977fa78f779f876f9b7f6b937b638b735b836b577b634f775f4b6f574367533f5f4b37574333533f2f"
    "9f83638f7753836b4b775f3f6753335b472b4f3b2343331b7b7f636f7357676b4f5b634753573b474f333f472b373f27"
    "ffff73ebdb57d7bb43c39b2faf7b1f9b5b13874307732b00ffffffffdbdbffbbbbff9b9bff7b7bff5f5fff3f3fff1f1f"
    "ff0000ef0000e30000d70000cb0000bf0000b30000a700009b00008b00007f00007300006700005b00004f0000430000"
    "e7e7ffc7c7ffababff8f8fff7373ff5353ff3737ff1b1bff0000ff0000e30000cb0000b300009b00008300006b000053"
    "ffffffffebdbffd7bbffc79bffb37bffa35bff8f3bff7f1bf37317eb6f0fdf670fd75f0bcb5707c34f00b74700af4300"
    "ffffffffffd7ffffb3ffff8fffff6bffff47ffff23ffff00a73f009f3700932f008723004f3b27432f1b3723132f1b0b"
    "00005300004700003b00002f00002300001700000b000000ff9f43ffe74bff7bffff00ffcf00cf9f009b6f006ba76b6b"
)


# --------------------------------------------------------------------------
#  Colour maths
# --------------------------------------------------------------------------
def srgb_to_linear(x):
    x = np.asarray(x, dtype=np.float32)
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4).astype(np.float32)


def linear_to_srgb(x):
    x = np.clip(np.asarray(x, dtype=np.float32), 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1.0 / 2.4) - 0.055).astype(np.float32)


def linear_to_oklab(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l, m, s = np.cbrt(l), np.cbrt(m), np.cbrt(s)
    L = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
    A = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
    B = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
    return np.stack([L, A, B], axis=-1).astype(np.float32)


def linear_to_cielab(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    X = (0.4124564 * r + 0.3575761 * g + 0.1804375 * b) / 0.95047
    Y = (0.2126729 * r + 0.7151522 * g + 0.0721750 * b)
    Z = (0.0193339 * r + 0.1191920 * g + 0.9503041 * b) / 1.08883

    def f(t):
        return np.where(t > 0.008856, np.cbrt(t), 7.787 * t + 16.0 / 116.0)
    fx, fy, fz = f(X), f(Y), f(Z)
    return np.stack([116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz)], axis=-1).astype(np.float32)


def features(rgb01, metric):
    """rgb01: (N,3) sRGB 0..1 -> (features (N,3), chroma (N,) or None)."""
    if metric in ("rgb", "redmean"):
        return (rgb01 * 255.0).astype(np.float32), None
    lin = srgb_to_linear(rgb01)
    if metric == "oklab":
        lab = linear_to_oklab(lin) * 100.0      # L 0..100, a/b roughly -40..40
    else:
        lab = linear_to_cielab(lin)
    chroma = np.hypot(lab[:, 1], lab[:, 2]).astype(np.float32)
    return lab.astype(np.float32), chroma


# --------------------------------------------------------------------------
#  Palette
# --------------------------------------------------------------------------
class Palette:
    _uid = 0

    def __init__(self, rgb, name):
        Palette._uid += 1
        self.uid = Palette._uid
        self.rgb = np.asarray(rgb, dtype=np.uint8).reshape(256, 3)
        self.name = name

    @classmethod
    def doom2(cls):
        data = bytes.fromhex("".join(DOOM2_PAL0_HEX))
        return cls(np.frombuffer(data, dtype=np.uint8), "Doom 2 (PLAYPAL 0)")

    def pil_palette(self):
        return self.rgb.reshape(-1).tolist()

    def to_dict(self):
        return {"name": self.name, "rgb": self.rgb.tobytes().hex()}

    @classmethod
    def from_dict(cls, d):
        return cls(np.frombuffer(bytes.fromhex(d["rgb"]), dtype=np.uint8)[:768], d.get("name", "palette"))

    def is_doom2(self):
        return self.rgb.tobytes() == bytes.fromhex("".join(DOOM2_PAL0_HEX))



def _pad768(data):
    data = list(data[:768])
    data += [0] * (768 - len(data))
    return data


def load_palette(path):
    name = os.path.basename(path)
    with open(path, "rb") as fh:
        raw = fh.read()

    # WAD
    if raw[:4] in (b"IWAD", b"PWAD"):
        import struct
        numlumps, diroff = struct.unpack_from("<ii", raw, 4)
        found = None
        for i in range(numlumps):
            pos, size, lname = struct.unpack_from("<ii8s", raw, diroff + i * 16)
            if lname.rstrip(b"\0").upper() == b"PLAYPAL":
                found = (pos, size)          # last one wins, like the engine
        if not found:
            raise ValueError("no PLAYPAL lump in WAD")
        pos, size = found
        if size < 768:
            raise ValueError("PLAYPAL lump is too small")
        return Palette(np.frombuffer(raw[pos:pos + 768], dtype=np.uint8), f"{name} PLAYPAL")

    # Text palettes
    head = raw[:16]
    if head.startswith(b"JASC-PAL"):
        lines = raw.decode("ascii", "ignore").split()
        count = int(lines[2])
        vals = [int(v) for v in lines[3:3 + count * 3]]
        return Palette(_pad768(vals), name)
    if head.startswith(b"GIMP Palette"):
        vals = []
        for line in raw.decode("utf-8", "ignore").splitlines()[1:]:
            line = line.strip()
            if not line or line.startswith("#") or ":" in line.split()[0]:
                continue
            parts = line.split()
            try:
                vals += [int(parts[0]), int(parts[1]), int(parts[2])]
            except (ValueError, IndexError):
                continue
        return Palette(_pad768(vals), name)

    # Images
    try:
        im = Image.open(path)
        im.load()
    except Exception:
        im = None
    if im is not None:
        w, h = im.size
        if w % 16 == 0 and h % 16 == 0:
            rgbim = im.convert("RGB")
            cw, ch = w // 16, h // 16
            vals = []
            for gy in range(16):
                for gx in range(16):
                    vals += list(rgbim.getpixel((gx * cw + cw // 2, gy * ch + ch // 2)))
            return Palette(vals, name)
        if im.mode == "P" and im.getpalette():
            return Palette(_pad768(im.getpalette()), name)
        raise ValueError("image is not a 16x16 swatch grid or an indexed image")

    # Raw
    if len(raw) >= 768:
        return Palette(np.frombuffer(raw[:768], dtype=np.uint8), name)
    raise ValueError("unrecognised palette format")


def parse_indices(text):
    out = set()
    for part in text.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a, b = int(a), int(b)
            if a > b:
                a, b = b, a
            for i in range(a, b + 1):
                if 0 <= i <= 255:
                    out.add(i)
        else:
            i = int(part)
            if 0 <= i <= 255:
                out.add(i)
    return out


def format_indices(s):
    s = sorted(s)
    parts = []
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[j + 1] == s[j] + 1:
            j += 1
        parts.append(str(s[i]) if i == j else f"{s[i]}-{s[j]}")
        i = j + 1
    return ", ".join(parts)

# --------------------------------------------------------------------------
#  Palette matcher
# --------------------------------------------------------------------------
METRICS = [("OKLab (perceptual)", "oklab"), ("CIELAB", "cielab"),
           ("Redmean RGB", "redmean"), ("RGB (euclidean)", "rgb")]
METRIC_NAMES = [m[0] for m in METRICS]
METRIC_CODE = dict(METRICS)
METRIC_NAME = {v: k for k, v in METRICS}
LUT_BITS = 6
LUT_N = 1 << LUT_BITS
LUT_SHIFT = 8 - LUT_BITS


class Matcher:
    CHUNK = 8192

    def __init__(self, pal, excluded, metric, kL, protect):
        active = np.array([i for i in range(256) if i not in excluded], dtype=np.int32)
        if active.size == 0:
            active = np.arange(256, dtype=np.int32)
        self.active = active
        self.metric = metric
        self.kL = float(kL)
        self.protect = float(protect)
        prgb = pal.rgb[active].astype(np.float32) / 255.0
        self.pfeat, self.pchroma = features(prgb, metric)
        self._lut = None
        self._cache = None          # 2^24 int16: exact match per 24-bit colour, -1 = not yet known

    def _dist(self, f, c):
        pf = self.pfeat
        if self.metric == "rgb":
            d = f[:, None, :] - pf[None, :, :]
            return np.einsum("npk,npk->np", d, d)
        if self.metric == "redmean":
            rm = (f[:, None, 0] + pf[None, :, 0]) * 0.5
            dr = f[:, None, 0] - pf[None, :, 0]
            dg = f[:, None, 1] - pf[None, :, 1]
            db = f[:, None, 2] - pf[None, :, 2]
            return (2.0 + rm / 256.0) * dr * dr + 4.0 * dg * dg + (2.0 + (255.0 - rm) / 256.0) * db * db
        dL = f[:, None, 0] - pf[None, :, 0]
        da = f[:, None, 1] - pf[None, :, 1]
        db = f[:, None, 2] - pf[None, :, 2]
        d = self.kL * dL * dL + da * da + db * db
        if self.protect > 0.0:
            loss = np.maximum(c[:, None] - self.pchroma[None, :], 0.0)
            d += self.protect * loss * loss
        return d

    def match(self, rgb01):
        """rgb01 (N,3) sRGB 0..1 -> palette indices (N,) int32 (brute force)."""
        f, c = features(rgb01.astype(np.float32), self.metric)
        n = f.shape[0]
        out = np.empty(n, dtype=np.int32)
        for s in range(0, n, self.CHUNK):
            e = min(n, s + self.CHUNK)
            out[s:e] = np.argmin(self._dist(f[s:e], None if c is None else c[s:e]), axis=1)
        return self.active[out]

    def match_u8(self, rgb255):
        """rgb255 (N,3) uint8 -> palette indices (N,) int32, exact, cached per colour."""
        if self._cache is None:
            self._cache = np.full(1 << 24, -1, dtype=np.int16)
        p = rgb255.astype(np.int64)
        code = (p[:, 0] << 16) | (p[:, 1] << 8) | p[:, 2]
        got = self._cache[code]
        miss = got < 0
        if miss.any():
            new = np.unique(code[miss])
            cols = np.stack([(new >> 16) & 255, (new >> 8) & 255, new & 255], axis=1).astype(np.float32) / 255.0
            self._cache[new] = self.match(cols).astype(np.int16)
            got = self._cache[code]
        return got.astype(np.int32)

    def lut(self):
        if self._lut is None:
            v = ((np.arange(LUT_N, dtype=np.float32) * (1 << LUT_SHIFT)) + ((1 << LUT_SHIFT) - 1) / 2.0) / 255.0
            r, g, b = np.meshgrid(v, v, v, indexing="ij")
            grid = np.stack([r.ravel(), g.ravel(), b.ravel()], axis=1)
            self._lut = self.match(grid).astype(np.int32)
        return self._lut


# --------------------------------------------------------------------------
#  Dithering
# --------------------------------------------------------------------------
ED_KERNELS = {
    "Floyd-Steinberg": ([(1, 0, 7), (-1, 1, 3), (0, 1, 5), (1, 1, 1)], 16),
    "Atkinson": ([(1, 0, 1), (2, 0, 1), (-1, 1, 1), (0, 1, 1), (1, 1, 1), (0, 2, 1)], 8),
    "Sierra Lite": ([(1, 0, 2), (-1, 1, 1), (0, 1, 1)], 4),
    "Sierra": ([(1, 0, 5), (2, 0, 3), (-2, 1, 2), (-1, 1, 4), (0, 1, 5), (1, 1, 4), (2, 1, 2),
                (-1, 2, 2), (0, 2, 3), (1, 2, 2)], 32),
    "Jarvis-Judice-Ninke": ([(1, 0, 7), (2, 0, 5), (-2, 1, 3), (-1, 1, 5), (0, 1, 7), (1, 1, 5), (2, 1, 3),
                             (-2, 2, 1), (-1, 2, 3), (0, 2, 5), (1, 2, 3), (2, 2, 1)], 48),
    "Stucki": ([(1, 0, 8), (2, 0, 4), (-2, 1, 2), (-1, 1, 4), (0, 1, 8), (1, 1, 4), (2, 1, 2),
                (-2, 2, 1), (-1, 2, 2), (0, 2, 4), (1, 2, 2), (2, 2, 1)], 42),
    "Burkes": ([(1, 0, 8), (2, 0, 4), (-2, 1, 2), (-1, 1, 4), (0, 1, 8), (1, 1, 4), (2, 1, 2)], 32),
}
ORDERED = ("Bayer 2x2", "Bayer 4x4", "Bayer 8x8", "Noise (IGN)")
DITHER_MODES = ["None"] + list(ED_KERNELS.keys()) + list(ORDERED)


def bayer(n):
    m = np.array([[0]], dtype=np.float32)
    while m.shape[0] < n:
        m = np.block([[4 * m, 4 * m + 2], [4 * m + 3, 4 * m + 1]])
    return (m + 0.5) / (n * n) - 0.5


def ordered_offsets(mode, h, w):
    if mode == "Noise (IGN)":
        y, x = np.mgrid[0:h, 0:w].astype(np.float32)
        t = np.mod(0.06711056 * x + 0.00583715 * y, 1.0)
        return (np.mod(52.9829189 * t, 1.0) - 0.5).astype(np.float32)
    n = {"Bayer 2x2": 2, "Bayer 4x4": 4, "Bayer 8x8": 8}[mode]
    m = bayer(n)
    return np.tile(m, (h // n + 1, w // n + 1))[:h, :w]


def error_diffuse(img255, lut, pal_rgb, mode, strength, clamp, serpentine, cancel):
    """Error diffusion in sRGB space, nearest lookups through the LUT."""
    taps, div = ED_KERNELS[mode]
    taps = [(dx, dy, wt / div) for dx, dy, wt in taps]
    maxdy = max(t[1] for t in taps)
    H, W, _ = img255.shape
    rows = img255.reshape(H, W * 3).tolist()
    pal = pal_rgb.astype(np.float64).tolist()
    lutl = lut.tolist()
    S = LUT_SHIFT
    B2 = LUT_BITS * 2
    B1 = LUT_BITS
    buf = [[0.0] * (W * 3) for _ in range(maxdy + 1)]
    out = np.empty((H, W), dtype=np.int32)
    for y in range(H):
        if cancel and (y & 7) == 0 and cancel():
            return None
        cur = buf[0]
        row = rows[y]
        orow = [0] * W
        rev = serpentine and (y & 1)
        xs = range(W - 1, -1, -1) if rev else range(W)
        for x in xs:
            i3 = x * 3
            r = row[i3] + cur[i3]
            g = row[i3 + 1] + cur[i3 + 1]
            b = row[i3 + 2] + cur[i3 + 2]
            r = 0.0 if r < 0.0 else (255.0 if r > 255.0 else r)
            g = 0.0 if g < 0.0 else (255.0 if g > 255.0 else g)
            b = 0.0 if b < 0.0 else (255.0 if b > 255.0 else b)
            idx = lutl[((int(r) >> S) << B2) | ((int(g) >> S) << B1) | (int(b) >> S)]
            orow[x] = idx
            p = pal[idx]
            er = (r - p[0]) * strength
            eg = (g - p[1]) * strength
            eb = (b - p[2]) * strength
            if er > clamp: er = clamp
            elif er < -clamp: er = -clamp
            if eg > clamp: eg = clamp
            elif eg < -clamp: eg = -clamp
            if eb > clamp: eb = clamp
            elif eb < -clamp: eb = -clamp
            for dx, dy, wt in taps:
                xx = x - dx if rev else x + dx
                if 0 <= xx < W:
                    tb = buf[dy]
                    j = xx * 3
                    tb[j] += er * wt
                    tb[j + 1] += eg * wt
                    tb[j + 2] += eb * wt
        out[y] = orow
        buf.pop(0)
        buf.append([0.0] * (W * 3))
    return out


# --------------------------------------------------------------------------
#  Pal0 settings: the palette plus how images are matched to it
# --------------------------------------------------------------------------
OPTION_DEFAULTS = {
    "excluded": [], "metric": "oklab", "kL": 1.0, "protect": 0,
    "dither": "None", "strength": 75, "clamp": 96, "serpentine": True,
}


class PalSettings:
    def __init__(self):
        self.palette = Palette.doom2()
        self.opts = dict(OPTION_DEFAULTS)
        self._matcher = (None, None)

    # ---------------- options ----------------
    def set_options(self, d):
        for k, dv in OPTION_DEFAULTS.items():
            v = (d or {}).get(k, dv)
            if k == "excluded":
                v = sorted({int(i) for i in v if 0 <= int(i) <= 255}) if isinstance(v, list) else []
            elif k == "metric":
                v = v if v in METRIC_NAME else dv
            elif k == "dither":
                v = v if v in DITHER_MODES else dv
            elif isinstance(dv, bool):
                v = bool(v)
            elif isinstance(dv, (int, float)):
                try:
                    v = type(dv)(v)
                except (TypeError, ValueError):
                    v = dv
            self.opts[k] = v

    def options(self):
        return dict(self.opts, excluded=list(self.opts["excluded"]))

    def to_dict(self):
        """For a project file: options, plus the palette when it isn't Doom 2."""
        d = {"options": self.options()}
        if not self.palette.is_doom2():
            d["palette"] = self.palette.to_dict()
        return d

    def from_dict(self, d):
        d = d or {}
        self.palette = Palette.from_dict(d["palette"]) if "palette" in d else Palette.doom2()
        self.set_options(d.get("options", {}))

    def key(self):
        o = self.opts
        return (self.palette.uid, tuple(o["excluded"]), o["metric"], o["kL"], o["protect"],
                o["dither"], o["strength"], o["clamp"], o["serpentine"])

    def is_slow(self):
        return self.opts["dither"] in ED_KERNELS and self.opts["strength"] > 0

    # ---------------- matching ----------------
    def matcher(self):
        o = self.opts
        mkey = (self.palette.uid, tuple(o["excluded"]), o["metric"], o["kL"], o["protect"])
        if self._matcher[0] != mkey:
            self._matcher = (mkey, Matcher(self.palette, set(o["excluded"]), o["metric"], o["kL"], o["protect"]))
        return self._matcher[1]

    def indices(self, img):
        """PIL image -> (H,W) uint8 palette indices."""
        a = np.asarray(img)[..., :3]
        h, w = a.shape[:2]
        o = self.opts
        m = self.matcher()
        st = o["strength"] / 100.0
        mode = o["dither"]
        if mode == "None" or st <= 0.0:
            idx = m.match_u8(a.reshape(-1, 3)).reshape(h, w)
        elif mode in ORDERED:
            off = ordered_offsets(mode, h, w) * (st * 64.0)
            src = np.clip(a.astype(np.float32) + off[..., None], 0, 255).astype(np.uint8)
            idx = m.match_u8(src.reshape(-1, 3)).reshape(h, w)
        else:
            idx = error_diffuse(a.astype(np.float64), m.lut(), self.palette.rgb, mode, st,
                                float(o["clamp"]), bool(o["serpentine"]), None)
        return idx.astype(np.uint8)

    def preview(self, img):
        """The image as it looks in the palette (RGB, or RGBA keeping transparency)."""
        idx = self.indices(img)
        rgb = self.palette.rgb[idx]
        if img.mode == "RGBA":
            return Image.fromarray(np.concatenate([rgb, np.asarray(img)[..., 3:4]], axis=2), "RGBA")
        return Image.fromarray(rgb, "RGB")

    def paletted(self, img):
        """For saving: an indexed (P) image. An image with transparency can't be
        indexed without a spare index, so it is returned as RGBA in palette colours."""
        if img.mode == "RGBA" and (np.asarray(img)[..., 3] < 255).any():
            return self.preview(img)
        im = Image.fromarray(self.indices(img), "P")
        im.putpalette(self.palette.pil_palette())
        return im
