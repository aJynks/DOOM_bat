"""png2pixel - Process Folder: run the snapshot stack on every image in a folder.

Each layer's tool is replayed with the settings (and hand edits) it was applied
with, in order. Results are saved in the output folder as
<name>-truecolour.png and / or <name>-paletted.png (Pal0 palette and options). Anything a tool couldn't do (e.g. Force Grid cell edits on an image
whose grid has a different number of cells) is listed in the report.
"""
import os
import tkinter as tk
from tkinter import filedialog, ttk

from .lib_const import S, HEAD, SMALL, IMAGE_EXTS
from .lib_stack import load_image, save_png, with_grab
from .tools.tool_registry import tool_class


def run_layers(img, layers):
    """Replay layers on img -> (image, [warnings])"""
    warns = []
    for i, ly in enumerate(layers):
        cls = tool_class(ly.tool)
        out = cls.run(img, ly.opts, ly.edits) if cls is not None else None
        if out is None:
            warns.append(f"layer {i + 2} ({ly.label}) can't be replayed: skipped")
            continue
        img, w = out
        if w:
            warns.append(f"layer {i + 2} ({ly.label}): {w}")
    return img, warns


def list_images(folder):
    try:
        names = sorted(os.listdir(folder), key=str.lower)
    except OSError:
        return []
    return [n for n in names if os.path.splitext(n)[1].lower() in IMAGE_EXTS
            and os.path.isfile(os.path.join(folder, n))]


class ProcessFolderDialog:
    def __init__(self, app):
        self.app = app
        self.running = False
        self.cancel = False
        root = app.root
        top = tk.Toplevel(root)
        self.top = top
        top.title("Process Folder")
        top.transient(root)
        top.protocol("WM_DELETE_WINDOW", self._close)
        top.minsize(S(420), S(300))

        body = ttk.Frame(top, padding=S(12))
        body.pack(fill="both", expand=True)
        layers = app.stack.layers
        ttk.Label(body, text="Apply the snapshot stack to a folder of images", font=HEAD).pack(anchor="w")
        steps = "  >  ".join(ly.label for ly in layers)
        ttk.Label(body, text=f"{len(layers)} layer{'s' if len(layers) != 1 else ''}:  {steps}", font=SMALL,
                  foreground="#555", wraplength=S(520), justify="left").pack(anchor="w", pady=(S(2), S(8)))

        grid = ttk.Frame(body)
        grid.pack(fill="x")
        grid.columnconfigure(1, weight=1)
        self.v_in = tk.StringVar(value=app.settings["batch_in"])
        self.v_out = tk.StringVar(value=app.settings["batch_out"])
        for r, (label, var) in enumerate((("Input folder", self.v_in), ("Output folder", self.v_out))):
            ttk.Label(grid, text=label).grid(row=r, column=0, sticky="w", pady=S(3), padx=(0, S(6)))
            ttk.Entry(grid, textvariable=var).grid(row=r, column=1, sticky="ew", pady=S(3))
            ttk.Button(grid, text="Browse...", takefocus=0,
                       command=lambda v=var, t=label: self._browse(v, t)).grid(row=r, column=2, padx=(S(6), 0))
        self.v_tc = tk.BooleanVar(value=app.settings["batch_tc"])
        self.v_pal = tk.BooleanVar(value=app.settings["batch_pal"])
        ttk.Checkbutton(body, text="True colour    (name-truecolour.png)", variable=self.v_tc,
                        takefocus=0).pack(anchor="w", pady=(S(8), S(2)))
        ttk.Checkbutton(body, text=f"Paletted         (name-paletted.png, Pal0: {app.pal.palette.name})",
                        variable=self.v_pal, takefocus=0).pack(anchor="w", pady=S(2))
        ttk.Label(body, text="Existing files in the output folder are overwritten.", font=SMALL,
                  foreground="#666", wraplength=S(520), justify="left").pack(anchor="w", pady=(S(6), S(6)))

        row = ttk.Frame(body)
        row.pack(fill="x")
        self.btn_run = ttk.Button(row, text="Run", command=self._run, takefocus=0)
        self.btn_run.pack(side="left")
        self.btn_close = ttk.Button(row, text="Close", command=self._close, takefocus=0)
        self.btn_close.pack(side="right")
        self.progress = ttk.Label(row, text="", font=SMALL)
        self.progress.pack(side="left", padx=S(10))

        tf = ttk.Frame(body)
        tf.pack(fill="both", expand=True, pady=(S(8), 0))
        self.text = tk.Text(tf, height=12, wrap="word", font=SMALL, state="disabled")
        sb = ttk.Scrollbar(tf, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.text.pack(side="left", fill="both", expand=True)

        top.update_idletasks()
        w, h = max(top.winfo_reqwidth(), S(560)), max(top.winfo_reqheight(), S(420))
        x = root.winfo_rootx() + max(0, (root.winfo_width() - w) // 2)
        y = root.winfo_rooty() + max(0, (root.winfo_height() - h) // 4)
        top.geometry(f"{w}x{h}+{x}+{y}")

    def _browse(self, var, title):
        d = filedialog.askdirectory(parent=self.top, title=title, initialdir=var.get() or None, mustexist=False)
        if d:
            var.set(os.path.normpath(d))

    def _log(self, line):
        self.text.configure(state="normal")
        self.text.insert("end", line + "\n")
        self.text.see("end")
        self.text.configure(state="disabled")

    def _close(self):
        if self.running:
            self.cancel = True
            return
        self.top.destroy()

    def _run(self):
        src, dst = self.v_in.get().strip(), self.v_out.get().strip()
        if not src or not os.path.isdir(src):
            self._log("Choose an input folder that exists.")
            return
        if not dst:
            self._log("Choose an output folder.")
            return
        if os.path.normcase(os.path.abspath(src)) == os.path.normcase(os.path.abspath(dst)):
            self._log("The output folder must be different from the input folder.")
            return
        try:
            os.makedirs(dst, exist_ok=True)
        except OSError as ex:
            self._log(f"Can't create the output folder: {ex}")
            return
        tc, pal = self.v_tc.get(), self.v_pal.get()
        if not (tc or pal):
            self._log("Tick at least one of True colour / Paletted.")
            return
        s = self.app.settings
        s["batch_in"], s["batch_out"], s["batch_tc"], s["batch_pal"] = src, dst, tc, pal
        s.save()
        files = list_images(src)
        if not files:
            self._log("No images in the input folder.")
            return
        layers = list(self.app.stack.layers)
        self.running, self.cancel = True, False
        self.btn_run.state(["disabled"])
        self.btn_close.configure(text="Cancel")
        done = failed = warned = 0
        self._log(f"--- {len(files)} image{'s' if len(files) != 1 else ''} ---")
        for i, name in enumerate(files):
            if self.cancel:
                self._log("Cancelled.")
                break
            self.progress.configure(text=f"{i + 1} / {len(files)}   {name}")
            self.top.update()
            try:
                img, warns = run_layers(load_image(os.path.join(src, name)), layers)
                stem = os.path.splitext(name)[0]
                if tc:
                    save_png(img, os.path.join(dst, stem + "-truecolour.png"))
                if pal:
                    save_png(with_grab(self.app.pal.paletted(img), img),
                             os.path.join(dst, stem + "-paletted.png"), optimize=True)
                done += 1
                for w in warns:
                    warned += 1
                    self._log(f"{name}: {w}")
            except Exception as ex:
                failed += 1
                self._log(f"{name}: FAILED - {ex}")
        self.running = False
        self.btn_run.state(["!disabled"])
        self.btn_close.configure(text="Close")
        summary = f"Done: {done} saved, {failed} failed, {warned} warning{'s' if warned != 1 else ''}."
        self.progress.configure(text=summary)
        self._log(summary)
        self.app.status.set_message(f"Process Folder: {summary}")
