"""png2pixel - Force Grid engine: all the image work, no UI.

Used by the Force Grid tool window and by Process Folder (batch replay).

Cell edits are recorded as an ordered list of operations, so they can be
replayed on another image of the same grid:
    {"op": "colour", "cells": runs, "rgb": [r, g, b]}   paint the cells
    {"op": "offset", "cells": runs, "v": n}             re-pick the n-th colour group
    {"op": "adjust", "cells": runs, "hue": h, "sat": s, "light": l, "contrast": c}
    {"op": "auto",   "cells": runs}                     back to automatic
"cells" is a run list [start, length, start, length, ...] of cell indices
(row * ncols + col), which keeps big selections small in a project file.
"""
import numpy as np
from PIL import Image

from ..lib_colour import adjust_np

MAX_RANK = 16               # colour groups remembered per cell (pick offset 0..15)


# --------------------------------------------------------------------------
#  Cell sets <-> run lists
# --------------------------------------------------------------------------
def mask_to_runs(mask):
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return []
    breaks = np.nonzero(np.diff(idx) != 1)[0]
    starts = np.r_[idx[0], idx[breaks + 1]]
    ends = np.r_[idx[breaks], idx[-1]]
    out = []
    for s, e in zip(starts.tolist(), ends.tolist()):
        out += [s, e - s + 1]
    return out


def runs_to_mask(runs, n):
    m = np.zeros(n, bool)
    for i in range(0, len(runs) - 1, 2):
        s, ln = int(runs[i]), int(runs[i + 1])
        if s < n:
            m[s:min(n, s + ln)] = True
    return m


# --------------------------------------------------------------------------
#  Colour helpers
# --------------------------------------------------------------------------
def rank_colours(rgb, cmap, n, mask, q, ranks=MAX_RANK):
    """Per cell, its colour groups ranked by size.
    -> cols (n, ranks, 3) uint8 (group average), cnt (n, ranks) int (0 = none)"""
    cols = np.zeros((n, ranks, 3), np.uint8)
    cnt = np.zeros((n, ranks), np.int64)
    ids = cmap[mask].astype(np.int64)
    if ids.size == 0:
        return cols, cnt
    px = rgb[mask]
    r, g, b = (px[:, i].astype(np.int64) >> q for i in range(3))
    code = (ids << 24) | (r << 16) | (g << 8) | b
    uniq, inv, counts = np.unique(code, return_inverse=True, return_counts=True)
    inv = inv.ravel()
    means = np.stack([np.bincount(inv, weights=px[:, i], minlength=len(uniq)) for i in range(3)], axis=1)
    means = np.clip(np.round(means / counts[:, None]), 0, 255).astype(np.uint8)
    cell_u = uniq >> 24
    order = np.lexsort((-counts, cell_u))
    cs = cell_u[order]
    pos = np.arange(len(order))
    first = np.r_[True, cs[1:] != cs[:-1]]
    start = np.maximum.accumulate(np.where(first, pos, 0))
    rank = pos - start
    keep = rank < ranks
    cols[cs[keep], rank[keep]] = means[order[keep]]
    cnt[cs[keep], rank[keep]] = counts[order[keep]]
    return cols, cnt


def colour_keys(cols, q):
    c = cols.astype(np.int64) >> q
    return (c[:, 0] << 16) | (c[:, 1] << 8) | c[:, 2]


def group_list(cols, keys, mask):
    """Swatches for the cells in mask: [(key, mean rgb, cell count)], biggest first."""
    idx = np.nonzero(mask)[0]
    if idx.size == 0:
        return []
    k = keys[idx]
    uniq, inv, counts = np.unique(k, return_inverse=True, return_counts=True)
    inv = inv.ravel()
    c = cols[idx].astype(np.float64)
    means = np.stack([np.bincount(inv, weights=c[:, i], minlength=len(uniq)) for i in range(3)], axis=1)
    means = np.clip(np.round(means / counts[:, None]), 0, 255).astype(int)
    order = np.argsort(-counts, kind="stable")
    return [(int(uniq[i]), tuple(int(v) for v in means[i]), int(counts[i])) for i in order]


# --------------------------------------------------------------------------
#  The engine
# --------------------------------------------------------------------------
class GridEngine:
    def __init__(self, img=None):
        self.rgb = self.opaque = None
        self.geo = None
        self.rank_cols = self.rank_cnt = self.trans_auto = None
        self.offset = self.man = self.man_has = None
        self.flat = self.trans = None
        if img is not None:
            self.set_image(img)

    def set_image(self, img):
        a = np.asarray(img)
        self.rgb = np.ascontiguousarray(a[..., :3])
        self.opaque = (a[..., 3] >= 128) if img.mode == "RGBA" else None
        if self.opaque is not None and self.opaque.all():
            self.opaque = None
        self.geo = None

    # ---------------- grid ----------------
    def build_grid(self, opts):
        """Lay the grid out; clears all cell state."""
        h, w = self.rgb.shape[:2]
        cw, ch = float(opts["cell_w"]), float(opts["cell_h"])
        ox, oy = float(opts["off_x"]) % cw, float(opts["off_y"]) % ch

        def axis(n, size, off):
            t = (np.arange(n) + 0.5 - off) / size
            raw = np.floor(t).astype(np.int64)
            idx = raw - raw[0]
            bounds = np.nonzero(np.diff(idx))[0] + 1
            return idx, t - raw, bounds, np.r_[0, bounds], np.r_[bounds, n]

        cx, fx, bx, sx, ex = axis(w, cw, ox)
        cy, fy, by, sy, ey = axis(h, ch, oy)
        ncols, nrows = int(cx[-1]) + 1, int(cy[-1]) + 1
        n = ncols * nrows
        self.geo = {
            "col": cx, "row": cy, "fx": fx, "fy": fy, "bx": bx, "by": by,
            "sx": sx, "ex": ex, "sy": sy, "ey": ey,
            "ncols": ncols, "nrows": nrows, "n": n,
            "map": (cy[:, None] * ncols + cx[None, :]).astype(np.int32),
        }
        self.offset = np.zeros(n, np.int16)
        self.man = np.zeros((n, 3), np.uint8)
        self.man_has = np.zeros(n, bool)

    # ---------------- automatic colours ----------------
    def auto(self, opts):
        g = self.geo
        n, cmap = g["n"], g["map"]
        q = int(opts["group"])
        s = opts["sample"] / 100.0
        if s >= 1.0:
            mask = np.ones(cmap.shape, bool)
        else:
            inx = np.abs(g["fx"] - 0.5) <= s / 2 + 1e-9
            iny = np.abs(g["fy"] - 0.5) <= s / 2 + 1e-9
            mask = iny[:, None] & inx[None, :]
        if self.opaque is not None:
            mask &= self.opaque
        cols, cnt = rank_colours(self.rgb, cmap, n, mask, q)
        miss = cnt[:, 0] == 0
        if miss.any():              # cells too small for the sample area: use all their pixels
            full = self.opaque if self.opaque is not None else np.ones(cmap.shape, bool)
            cols2, cnt2 = rank_colours(self.rgb, cmap, n, full, q)
            cols[miss], cnt[miss] = cols2[miss], cnt2[miss]
        has = cnt[:, 0] > 0
        if self.opaque is not None:
            total = np.bincount(cmap.ravel(), minlength=n)
            op = np.bincount(cmap[self.opaque], minlength=n)
            self.trans_auto = (op * 2 < total) | ~has
        else:
            self.trans_auto = ~has
        self.rank_cols, self.rank_cnt = cols, cnt

    def flatten(self):
        """Flat colour per cell from the automatic picks, offsets and manual colours."""
        n = self.geo["n"]
        avail = (self.rank_cnt > 0).sum(axis=1)
        r = np.minimum(self.offset.astype(np.int64), np.maximum(avail - 1, 0))
        base = self.rank_cols[np.arange(n), r]
        self.flat = np.where(self.man_has[:, None], self.man, base)
        self.trans = self.trans_auto & ~self.man_has

    def render(self, adj=None, adj_cells=None):
        """The full-size image. adj / adj_cells: a live (unbaked) adjustment preview."""
        cols = self.flat
        if adj and adj_cells is not None and adj_cells.any():
            cols = cols.copy()
            cols[adj_cells] = adjust_np(cols[adj_cells], **adj)
        cmap = self.geo["map"]
        if self.trans.any():
            rgba = np.concatenate([cols, np.where(self.trans, 0, 255).astype(np.uint8)[:, None]], axis=1)
            return Image.fromarray(rgba[cmap], "RGBA")
        return Image.fromarray(cols[cmap], "RGB")

    # ---------------- cell edit operations ----------------
    def apply_op(self, op, cells=None):
        """Apply one operation. cells: a (n,) bool mask, or None to read op["cells"].
        Leaves self.flat / self.trans up to date."""
        if cells is None:
            cells = runs_to_mask(op.get("cells", []), self.geo["n"])
        kind = op.get("op")
        if kind == "colour":
            self.man[cells] = [int(v) for v in op["rgb"][:3]]
            self.man_has[cells] = True
        elif kind == "offset":
            self.offset[cells] = int(op["v"])
            self.man_has[cells] = False
        elif kind == "auto":
            self.man_has[cells] = False
            self.offset[cells] = 0
        elif kind == "adjust":
            self.flatten()
            t = cells & ~self.trans
            if t.any():
                adj = {k: op.get(k, 0) for k in ("hue", "sat", "light", "contrast")}
                self.man[t] = adjust_np(self.flat[t], **adj)
                self.man_has[t] = True
        self.flatten()

    def replay(self, ops):
        for op in ops:
            self.apply_op(op)
        self.flatten()


def run_force_grid(img, opts, edits):
    """Headless Force Grid for batch replay -> (image, warning or None)."""
    eng = GridEngine(img)
    eng.build_grid(opts)
    eng.auto(opts)
    eng.flatten()
    warn = None
    ops = (edits or {}).get("ops", [])
    if ops:
        grid = (edits or {}).get("grid")
        if grid and list(grid) == [eng.geo["ncols"], eng.geo["nrows"]]:
            eng.replay(ops)
        else:
            warn = (f"grid is {eng.geo['ncols']} x {eng.geo['nrows']} cells, the recorded cell edits "
                    f"were made on {grid[0]} x {grid[1]}: cell edits skipped") if grid else "cell edits skipped"
    return eng.render(), warn
