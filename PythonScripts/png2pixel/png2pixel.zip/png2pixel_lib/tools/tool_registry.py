"""png2pixel - tool registry: every tool class is listed here by name."""
from .tool_base import PlaceholderTool
from .tool_force_grid import ForceGrid
from .tool_adjust import Adjust
from .tool_rebuild import Rebuild
from .tool_titlepic import TitlePic
from .tool_scale import Scale
from .tool_sprite import Sprite

TOOL_CLASSES = {
    Adjust.name: Adjust,
    ForceGrid.name: ForceGrid,
    Rebuild.name: Rebuild,
    TitlePic.name: TitlePic,
    Scale.name: Scale,
    Sprite.name: Sprite,
}


def tool_class(name):
    return TOOL_CLASSES.get(name)


def make_tool(name, host, saved):
    cls = TOOL_CLASSES.get(name)
    if cls is None:
        return PlaceholderTool(host, saved, name)
    return cls(host, saved)
