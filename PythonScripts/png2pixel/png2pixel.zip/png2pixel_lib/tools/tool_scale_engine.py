"""png2pixel - Scale engine: downscaling an image to an exact size, no UI.

Shared by the Scale tool and titlePic. Every output pixel has a "footprint" of
source pixels (it may be fractional, and taller than wide for the Doom squash).

Methods
    Classic (weighted resampling, separable kernels)
        Lanczos 3, Lanczos 2, Catmull-Rom, Mitchell, Bicubic (a = -0.75),
        Hamming, Bilinear, Box (area average: exact partial-pixel coverage)
    Point / pixel art (output colours come from the source)
        Nearest               one sample per footprint, Sample point = where
        Majority (pixel art)  the titlepic tool's majority, ported as-is: most
                              common colour on an up-to-6x6 sample grid
        Majority (grouped)    most common colour group over every footprint
                              pixel (Colour grouping), group average
        Median                per-channel median of the footprint
    Detail preserving
        DPID                  Weber et al. 2016, "Rapid, Detail-Preserving Image
                              Downscaling": pixels that differ from the local
                              average weigh more (Detail = lambda)
        Contrast keep         the one footprint pixel that differs most from
                              the footprint average
    New
        Line keeper           grouped majority, but when enough of a footprint
                              is a dark line (darker than the footprint average
                              by Line threshold, covering Line coverage), the
                              line colour wins - outlines don't break up
        Edge-weighted majority  grouped majority where pixels on edges count for
                              more (Edge weight): cleaner silhouettes

Options
    Phase search      (point methods) try sub-footprint offsets of the grid and
                      keep the one closest to an area average: the pixel grid
                      lines itself up with the art
    Linear light      average in linear RGB (classic, Box, DPID)
    Pre-flatten       Kuwahara edge-preserving smooth before scaling (radius)
    Dark / light bias weight darker (-) or lighter (+) pixels more
    Snap to source    pull each output pixel to the nearest colour actually in
                      its footprint (no invented in-between colours)
    Despeckle         replace isolated single pixels with their neighbours
    Sharpen after     unsharp mask on the result
"""
import numpy as np
from PIL import Image

from .tool_adjust_engine import srgb_to_linear, linear_to_srgb, apply_adjust, gaussian_blur

KERNELS = ["Lanczos 3", "Lanczos 2", "Catmull-Rom", "Mitchell", "Bicubic", "Hamming", "Bilinear",
           "Box (area average)"]
POINT = ["Nearest", "Majority (pixel art)", "Majority (grouped)", "Median"]
DETAIL = ["DPID", "Contrast keep"]
NEW = ["Line keeper", "Edge-weighted majority"]
METHODS = KERNELS + POINT + DETAIL + NEW

DEFAULTS = {
    "method": "Lanczos 3",
    "sample": 50, "group": 4, "detail": 50, "line_thresh": 25, "line_cover": 20, "edge_weight": 50,
    "phase": False, "linear": True, "flatten": 0, "bias": 0, "snap": 0, "despeckle": False, "sharpen": 0,
}

# which options mean something for which methods (the UI greys out the rest)
USES = {
    "sample": {"Nearest"},
    "group": {"Majority (grouped)", "Line keeper", "Edge-weighted majority"},
    "detail": {"DPID"},
    "line_thresh": {"Line keeper"},
    "line_cover": {"Line keeper"},
    "edge_weight": {"Edge-weighted majority"},
    "phase": {"Nearest", "Majority (pixel art)", "Majority (grouped)", "Median", "Line keeper",
              "Edge-weighted majority"},
    "linear": set(KERNELS) | {"DPID"},
    "bias": set(KERNELS) | {"Majority (grouped)", "DPID", "Line keeper", "Edge-weighted majority"},
}
PIXEL_METHODS = set(POINT) | {"Contrast keep", "Line keeper", "Edge-weighted majority"}


def option_used(key, method):
    return key not in USES or method in USES[key]


# ==========================================================================
#  Separable kernels
# ==========================================================================
def _sinc(x):
    return np.sinc(x)


def _cubic(b, c):
    def k(x):
        x = np.abs(x)
        x2, x3 = x * x, x * x * x
        out = np.where(x < 1, (12 - 9 * b - 6 * c) * x3 + (-18 + 12 * b + 6 * c) * x2 + (6 - 2 * b),
                       np.where(x < 2, (-b - 6 * c) * x3 + (6 * b + 30 * c) * x2 + (-12 * b - 48 * c) * x
                                + (8 * b + 24 * c), 0.0))
        return out / 6.0
    return k


def _keys(a):
    def k(x):
        x = np.abs(x)
        return np.where(x <= 1, (a + 2) * x ** 3 - (a + 3) * x ** 2 + 1,
                        np.where(x < 2, a * x ** 3 - 5 * a * x ** 2 + 8 * a * x - 4 * a, 0.0))
    return k


KERNEL_DEF = {
    "Lanczos 3": (lambda x: _sinc(x) * _sinc(x / 3.0), 3.0),
    "Lanczos 2": (lambda x: _sinc(x) * _sinc(x / 2.0), 2.0),
    "Catmull-Rom": (_cubic(0.0, 0.5), 2.0),
    "Mitchell": (_cubic(1 / 3, 1 / 3), 2.0),
    "Bicubic": (_keys(-0.75), 2.0),
    "Hamming": (lambda x: _sinc(x) * (0.54 + 0.46 * np.cos(np.pi * x)), 1.0),
    "Bilinear": (lambda x: np.maximum(0.0, 1.0 - np.abs(x)), 1.0),
}


def _weights(n_in, n_out, method):
    """(n_out, n_in) resampling matrix, rows sum to 1."""
    s = n_in / float(n_out)
    x = np.arange(n_in, dtype=np.float64)
    if method == "Box (area average)":
        a = np.arange(n_out, dtype=np.float64)[:, None] * s
        b = a + s
        w = np.maximum(0.0, np.minimum(x[None, :] + 1, b) - np.maximum(x[None, :], a))
    else:
        fn, support = KERNEL_DEF[method]
        scale = max(s, 1.0)
        centre = (np.arange(n_out, dtype=np.float64) + 0.5) * s - 0.5
        d = (x[None, :] - centre[:, None]) / scale
        w = np.where(np.abs(d) < support, fn(d), 0.0)
    tot = w.sum(axis=1, keepdims=True)
    tot[tot == 0] = 1.0
    return (w / tot).astype(np.float32)


def _resample(x, out_w, out_h, method, weights=None):
    """x (H,W,C) float -> (out_h,out_w,C). weights (H,W): per-pixel weights."""
    h, w, c = x.shape
    wx = _weights(w, out_w, method)
    wy = _weights(h, out_h, method)

    def apply(a):
        cc = a.shape[2]
        t = np.matmul(a.transpose(0, 2, 1), wx.T)              # (H, C, out_w)
        t = wy @ t.reshape(h, cc * out_w)                      # (out_h, C*out_w)
        return t.reshape(out_h, cc, out_w).transpose(0, 2, 1)
    if weights is None:
        return apply(x.astype(np.float32))
    wt = weights.astype(np.float32)[..., None]
    num = apply(x.astype(np.float32) * wt)
    den = apply(wt)
    return num / np.maximum(den, 1e-8)


# ==========================================================================
#  Footprints
# ==========================================================================
def _footprints(h, w, out_h, out_w, ox=0.0, oy=0.0):
    """Footprint index per source pixel (clipped so the output size is exact).
    ox / oy shift the footprint grid by a fraction of a footprint."""
    cw, ch = w / float(out_w), h / float(out_h)
    col = np.clip(np.floor((np.arange(w) + 0.5) / cw - ox).astype(np.int64), 0, out_w - 1)
    row = np.clip(np.floor((np.arange(h) + 0.5) / ch - oy).astype(np.int64), 0, out_h - 1)
    return (row[:, None] * out_w + col[None, :]).astype(np.int64)


def _vote(rgb, cmap, n, mask, q, weights=None):
    """Most common (or most weighted) colour group per footprint -> (cols (n,3) float, has (n,))."""
    cols = np.zeros((n, 3), np.float32)
    has = np.zeros(n, bool)
    ids = cmap[mask]
    if ids.size == 0:
        return cols, has
    px = rgb[mask]
    r, g, b = (px[:, i].astype(np.int64) >> q for i in range(3))
    code = (ids << 24) | (r << 16) | (g << 8) | b
    uniq, inv, counts = np.unique(code, return_inverse=True, return_counts=True)
    inv = inv.ravel()
    score = counts.astype(np.float64) if weights is None else np.bincount(inv, weights=weights[mask],
                                                                            minlength=len(uniq))
    cell_u = uniq >> 24
    order = np.lexsort((-score, cell_u))
    cs = cell_u[order]
    first = order[np.r_[True, cs[1:] != cs[:-1]]]
    sums = np.stack([np.bincount(inv, weights=px[:, i], minlength=len(uniq)) for i in range(3)], axis=1)
    cols[cell_u[first]] = sums[first] / counts[first][:, None]
    has[cell_u[first]] = True
    return cols, has


def _cell_mean(vals, cmap, n, weights=None):
    """Mean of vals (H,W,C) per footprint -> (n, C)."""
    flat = cmap.ravel()
    v = vals.reshape(-1, vals.shape[-1]).astype(np.float64)
    wt = np.ones(len(flat)) if weights is None else weights.ravel().astype(np.float64)
    den = np.bincount(flat, weights=wt, minlength=n)
    out = np.stack([np.bincount(flat, weights=v[:, i] * wt, minlength=n) for i in range(v.shape[1])], axis=1)
    return out / np.maximum(den, 1e-12)[:, None]


def _pick_max(score, cmap, n):
    """Per footprint, the flat index of the pixel with the highest score."""
    flat = cmap.ravel()
    order = np.lexsort((-score.ravel(), flat))
    cs = flat[order]
    first = order[np.r_[True, cs[1:] != cs[:-1]]]
    out = np.zeros(n, np.int64)
    out[cs[np.r_[True, cs[1:] != cs[:-1]]]] = first
    return out


def _luma(rgb01):
    return 0.2126 * rgb01[..., 0] + 0.7152 * rgb01[..., 1] + 0.0722 * rgb01[..., 2]


# ==========================================================================
#  Methods
# ==========================================================================
def _nearest(u8, out_w, out_h, p, ox=0.0, oy=0.0):
    h, w = u8.shape[:2]
    cw, ch = w / float(out_w), h / float(out_h)
    f = min(max(p / 100.0, 0.0), 0.999)
    xs = np.clip(np.floor((np.arange(out_w) + f + ox) * cw).astype(np.int64), 0, w - 1)
    ys = np.clip(np.floor((np.arange(out_h) + f + oy) * ch).astype(np.int64), 0, h - 1)
    return u8[ys][:, xs]


def _majority_titlepic(src, size, box, thr=0.5):
    """Ported unchanged from the titlepic tool. src (H,W,4) uint8 ->
    (rgb (h,w,3) float 0..1, mask (h,w) bool)."""
    SH, SW = src.shape[:2]
    W, H = size
    x0, y0, x1, y1 = box if box else (0.0, 0.0, float(SW), float(SH))
    sx, sy = (x1 - x0) / W, (y1 - y0) / H
    kx = int(min(6, max(1, round(sx))))
    ky = int(min(6, max(1, round(sy))))
    xi = np.floor(x0 + (np.arange(W)[:, None] + (np.arange(kx)[None, :] + 0.5) / kx) * sx).astype(np.int64)
    yi = np.floor(y0 + (np.arange(H)[:, None] + (np.arange(ky)[None, :] + 0.5) / ky) * sy).astype(np.int64)
    xi = np.clip(xi, 0, SW - 1)
    yi = np.clip(yi, 0, SH - 1)
    n = kx * ky
    a_cut = max(1, int(round(thr * 255)))
    rgb_out = np.zeros((H, W, 3), dtype=np.float32)
    mask = np.zeros((H, W), dtype=bool)
    rows = max(1, int(4000000 // max(1, W * n * n)))
    for r0 in range(0, H, rows):
        r1 = min(H, r0 + rows)
        smp = src[yi[r0:r1][:, None, :, None], xi[None, :, None, :]].reshape(r1 - r0, W, n, 4)
        op = smp[..., 3] >= a_cut
        key = (smp[..., 0].astype(np.int64) << 16) | (smp[..., 1].astype(np.int64) << 8) | smp[..., 2]
        key = np.where(op, key, -1)
        counts = (key[..., :, None] == key[..., None, :]).sum(-1)
        rgbf = smp[..., :3].astype(np.float32)
        nop = op.sum(-1, keepdims=True)
        mean = (rgbf * op[..., None]).sum(-2) / np.maximum(nop, 1)
        dist = ((rgbf - mean[..., None, :]) ** 2).sum(-1)
        dist = np.where(op, dist, 200000.0)
        best = np.argmax(counts.astype(np.float64) * 1e6 - dist, axis=-1)
        pick = np.take_along_axis(smp, best[..., None, None], axis=2)[..., 0, :]
        rgb_out[r0:r1] = pick[..., :3] / 255.0
        mask[r0:r1] = pick[..., 3] >= a_cut
    return rgb_out, mask


def _median(rgb01, cmap, n, mask):
    out = np.zeros((n, 3), np.float32)
    flat = cmap.ravel()[mask.ravel()]
    if flat.size == 0:
        return out
    v = rgb01.reshape(-1, 3)[mask.ravel()]
    counts = np.bincount(flat, minlength=n)
    starts = np.r_[0, np.cumsum(counts)[:-1]]
    for c in range(3):
        order = np.lexsort((v[:, c], flat))
        sv = v[order, c]
        has = counts > 0
        out[has, c] = sv[starts[has] + counts[has] // 2]
    return out


def _sobel(l):
    p = np.pad(l, 1, mode="edge")
    gx = (p[:-2, 2:] + 2 * p[1:-1, 2:] + p[2:, 2:]) - (p[:-2, :-2] + 2 * p[1:-1, :-2] + p[2:, :-2])
    gy = (p[2:, :-2] + 2 * p[2:, 1:-1] + p[2:, 2:]) - (p[:-2, :-2] + 2 * p[:-2, 1:-1] + p[:-2, 2:])
    g = np.hypot(gx, gy)
    m = g.max()
    return g / m if m > 0 else g


def _kuwahara(rgb01, r):
    """Edge-preserving smooth: each pixel takes the mean of whichever of its four
    (r+1)x(r+1) corner windows has the lowest brightness variance."""
    h, w, _ = rgb01.shape
    l = _luma(rgb01).astype(np.float64)

    def integral(a):
        s = np.zeros((h + 1, w + 1) + a.shape[2:], np.float64)
        s[1:, 1:] = np.cumsum(np.cumsum(a, axis=0), axis=1)
        return s
    sl, sl2 = integral(l), integral(l * l)
    sc = integral(rgb01.astype(np.float64))
    yy, xx = np.mgrid[0:h, 0:w]
    best_var = np.full((h, w), np.inf)
    out = np.zeros_like(rgb01, dtype=np.float64)
    for dy0, dy1 in ((-r, 0), (0, r)):
        for dx0, dx1 in ((-r, 0), (0, r)):
            y0 = np.clip(yy + dy0, 0, h - 1)
            y1 = np.clip(yy + dy1, 0, h - 1) + 1
            x0 = np.clip(xx + dx0, 0, w - 1)
            x1 = np.clip(xx + dx1, 0, w - 1) + 1
            cnt = (y1 - y0) * (x1 - x0)

            def box(s):
                return s[y1, x1] - s[y0, x1] - s[y1, x0] + s[y0, x0]
            m = box(sl) / cnt
            var = box(sl2) / cnt - m * m
            better = var < best_var
            best_var = np.where(better, var, best_var)
            mc = box(sc) / cnt[..., None]
            out = np.where(better[..., None], mc, out)
    return out.astype(np.float32)


def _snap(out01, rgb_u8, cmap, n, mask, strength):
    """Pull each output pixel to the nearest colour group actually in its footprint."""
    from .tool_force_grid_engine import rank_colours
    cols, cnt = rank_colours(rgb_u8, cmap, n, mask, 2, ranks=12)
    o = out01.reshape(n, 3) * 255.0
    d = ((cols.astype(np.float32) - o[:, None, :]) ** 2).sum(-1)
    d = np.where(cnt > 0, d, np.inf)
    best = np.argmin(d, axis=1)
    pick = cols[np.arange(n), best].astype(np.float32)
    has = cnt[:, 0] > 0
    pick[~has] = o[~has]
    k = strength / 100.0
    return ((o * (1 - k) + pick * k) / 255.0).reshape(out01.shape)


def _despeckle(out01, thresh=40.0 / 255.0):
    h, w, _ = out01.shape
    if h < 3 or w < 3:
        return out01
    p = np.pad(out01, ((1, 1), (1, 1), (0, 0)), mode="edge")
    nb = np.stack([p[1 + dy:1 + dy + h, 1 + dx:1 + dx + w] for dy in (-1, 0, 1) for dx in (-1, 0, 1)
                   if dy or dx], axis=0)                       # (8, h, w, 3)
    d = np.sqrt(((nb - out01[None]) ** 2).sum(-1)).min(axis=0)
    speck = d > thresh
    med = np.median(nb, axis=0)
    return np.where(speck[..., None], med, out01)


# ==========================================================================
#  Main entry
# ==========================================================================
def scale_image(img, size, opts):
    """PIL image -> PIL image of exactly size (w, h), using opts (see DEFAULTS)."""
    o = dict(DEFAULTS)
    o.update(opts or {})
    out_w, out_h = max(1, int(size[0])), max(1, int(size[1]))
    method = o["method"] if o["method"] in METHODS else DEFAULTS["method"]
    a = np.asarray(img)
    h, w = a.shape[:2]
    rgb_u8 = np.ascontiguousarray(a[..., :3])
    alpha = a[..., 3] if img.mode == "RGBA" else None
    opaque = alpha >= 128 if alpha is not None else np.ones((h, w), bool)
    rgb01 = rgb_u8.astype(np.float32) / 255.0
    if o["flatten"] > 0:
        rgb01 = _kuwahara(rgb01, int(o["flatten"]))
        rgb_u8 = (np.clip(rgb01, 0, 1) * 255 + 0.5).astype(np.uint8)
    n = out_w * out_h
    lum = _luma(rgb01)
    bias_w = np.exp((o["bias"] / 100.0) * 6.0 * (lum - 0.5)) if o["bias"] and option_used("bias", method) else None

    def weights(extra=None):
        wt = None
        for part in (alpha.astype(np.float32) / 255.0 if alpha is not None else None, bias_w, extra):
            if part is not None:
                wt = part if wt is None else wt * part
        return wt

    def footprint_result(ox, oy):
        """Point-style methods for one grid phase -> (rgb (out_h,out_w,3) 0..1, opaque (out_h,out_w))."""
        if method == "Nearest":
            pick = _nearest(np.dstack([rgb_u8, (opaque * 255).astype(np.uint8)]), out_w, out_h, o["sample"], ox, oy)
            return pick[..., :3] / 255.0, pick[..., 3] >= 128
        if method == "Majority (pixel art)":
            cw, ch = w / float(out_w), h / float(out_h)
            src = np.dstack([rgb_u8, (opaque * 255).astype(np.uint8)])
            box = (ox * cw, oy * ch, w + ox * cw, h + oy * ch)
            return _majority_titlepic(src, (out_w, out_h), box)
        cmap = _footprints(h, w, out_h, out_w, ox, oy)
        q = int(o["group"])
        if method == "Median":
            cols = _median(rgb01, cmap, n, opaque)
        elif method == "Majority (grouped)":
            cols, _ = _vote(rgb_u8, cmap, n, opaque, q, weights())
            cols = cols / 255.0
        elif method == "Edge-weighted majority":
            # edges of a smoothed copy, so noise doesn't count as edges
            sig = max(0.6, min(w / float(out_w), h / float(out_h)) / 3.0)
            edge = _sobel(gaussian_blur(np.repeat(lum[..., None], 3, axis=2), sig)[..., 0])
            cols, _ = _vote(rgb_u8, cmap, n, opaque, q, weights(1.0 + edge * (o["edge_weight"] / 100.0) * 8.0))
            cols = cols / 255.0
        else:   # Line keeper
            cols, _ = _vote(rgb_u8, cmap, n, opaque, q, weights())
            cols = cols / 255.0
            cell_l = _cell_mean(lum[..., None], cmap, n)[:, 0]
            line = opaque & (lum < cell_l[cmap] - (o["line_thresh"] / 100.0) * 0.5)
            total = np.bincount(cmap[opaque], minlength=n)
            frac = np.bincount(cmap[line], minlength=n) / np.maximum(total, 1)
            lcols, lhas = _vote(rgb_u8, cmap, n, line, q)
            use = lhas & (frac >= o["line_cover"] / 100.0)
            cols[use] = lcols[use] / 255.0
        tot = np.bincount(cmap.ravel(), minlength=n)
        op = np.bincount(cmap[opaque], minlength=n)
        return cols.reshape(out_h, out_w, 3), (op * 2 >= tot).reshape(out_h, out_w)

    # ---------------- run the method ----------------
    if method in KERNELS:
        x = srgb_to_linear(rgb01) if o["linear"] else rgb01
        res = _resample(x, out_w, out_h, method, weights())
        res = linear_to_srgb(np.clip(res, 0, 1)) if o["linear"] else res
        out_a = None
        if alpha is not None:
            out_a = _resample(alpha[..., None].astype(np.float32) / 255.0, out_w, out_h, method)[..., 0]
        out_mask = None
    elif method in DETAIL:
        cmap = _footprints(h, w, out_h, out_w)
        x = srgb_to_linear(rgb01) if (o["linear"] and method == "DPID") else rgb01
        avg = _cell_mean(x, cmap, n, weights()).astype(np.float32)
        if method == "DPID":
            g = avg.reshape(out_h, out_w, 3)
            p = np.pad(g, ((1, 1), (1, 1), (0, 0)), mode="edge")
            k = np.array([1, 2, 1], np.float32)
            g = sum(k[i] * p[i:i + out_h, 1:-1] for i in range(3)) / 4.0
            p = np.pad(g, ((0, 0), (1, 1), (0, 0)), mode="edge")
            g = sum(k[i] * p[:, i:i + out_w] for i in range(3)) / 4.0
            avg_s = g.reshape(n, 3)
            diff = np.sqrt(((x - avg_s[cmap]) ** 2).sum(-1)) / np.sqrt(3.0)
            lam = o["detail"] / 100.0 * 3.0
            wt = np.power(diff + 1e-6, lam)
            ww = weights(wt)
            res = _cell_mean(x, cmap, n, ww).reshape(out_h, out_w, 3).astype(np.float32)
            if o["linear"]:
                res = linear_to_srgb(np.clip(res, 0, 1))
        else:
            diff = np.sqrt(((rgb01 - avg[cmap]) ** 2).sum(-1))
            diff = np.where(opaque, diff, -1.0)
            pick = _pick_max(diff, cmap, n)
            res = rgb01.reshape(-1, 3)[pick].reshape(out_h, out_w, 3)
        tot = np.bincount(cmap.ravel(), minlength=n)
        op = np.bincount(cmap[opaque], minlength=n)
        out_mask = (op * 2 >= tot).reshape(out_h, out_w)
        out_a = None
    else:
        if o["phase"]:
            ref = _resample(rgb01, out_w, out_h, "Box (area average)")
            steps = [i / 8.0 - 0.375 for i in range(8)]
            best_x, best_err = 0.0, None
            for ox in steps:
                r, _m = footprint_result(ox, 0.0)
                e = float(((r - ref) ** 2).mean())
                if best_err is None or e < best_err:
                    best_x, best_err = ox, e
            best_y, best_err = 0.0, None
            for oy in steps:
                r, _m = footprint_result(best_x, oy)
                e = float(((r - ref) ** 2).mean())
                if best_err is None or e < best_err:
                    best_y, best_err = oy, e
            res, out_mask = footprint_result(best_x, best_y)
        else:
            res, out_mask = footprint_result(0.0, 0.0)
        out_a = None

    res = np.clip(res, 0.0, 1.0).astype(np.float32)

    # ---------------- options on the result ----------------
    if o["snap"] > 0:
        cmap = _footprints(h, w, out_h, out_w)
        res = _snap(res, rgb_u8, cmap, n, opaque, o["snap"])
    if o["despeckle"]:
        res = _despeckle(res)
    if o["sharpen"] > 0:
        res = apply_adjust(res, "Sharpen", {"amount": o["sharpen"], "radius": 0.7, "threshold": 0})

    rgb = (np.clip(res, 0, 1) * 255.0 + 0.5).astype(np.uint8)
    if alpha is None:
        return Image.fromarray(rgb, "RGB")
    if out_a is not None:                      # classic filters: smooth alpha
        a8 = (np.clip(out_a, 0, 1) * 255.0 + 0.5).astype(np.uint8)
    else:                                      # pixel methods: on / off
        a8 = np.where(out_mask, 255, 0).astype(np.uint8)
    return Image.fromarray(np.dstack([rgb, a8]), "RGBA")


def doom_height(h):
    """The squashed height that stretches back to h in Doom (1.2 tall pixels)."""
    return max(1, int(round(h / 1.2)))
