"""png2pixel - Sprite: finish a small image as a Doom sprite / graphic.

Source images often come with a background, soft anti-aliased edges and colour halos;
Doom graphics need hard (1-bit) transparency, a clean silhouette and offsets.
Run this last, on the small pixel-art image. In order:

    Background    Colour key: pixels within Tolerance of the key colour become
                  transparent. Key = Auto (most common border colour) or picked
                  from the view. "Only touching the edges" removes just the
                  background connected to the image border, so key-coloured
                  pixels inside the sprite survive.
                  Defringe: edge pixels blended towards the key colour (the halo
                  left round a cut-out) are removed, or recoloured to the
                  sprite's inner colour when only slightly tinted.
    Hard alpha    Doom has no partial transparency: alpha below Threshold goes
                  fully transparent, the rest fully opaque.
    Cleanup       Remove specks: opaque pixels with this few opaque neighbours
                  or fewer go. Fill pinholes: transparent pixels surrounded by
                  the sprite are filled from their neighbours.
    Outline       Outer (a ring round the sprite) or Inner (the sprite's own edge
                  pixels), 4- or 8-connected. Colour: a fixed colour, or each
                  outline pixel takes its neighbours' colour darkened by Darken %.
    Trim          crop to the visible pixels, plus Padding.
    Offsets       Doom offsets saved in exported PNGs (a grAb chunk; SLADE reads
                  it): Feet = centred, bottom sunk Ground sink px into the floor
                  (monsters, items, decorations); Centre (projectiles, effects);
                  Custom X / Y; None. A crosshair in the view marks the origin.
"""
import tkinter as tk
from tkinter import colorchooser, ttk

import numpy as np
from PIL import Image

from ..lib_const import S, SMALL, GRID_SEL
from ..lib_colour import rgb255_to_hex, hex_to_rgb255
from ..lib_widgets import NumberBox, section
from .tool_base import Tool

KEY_MODES = ["None", "Auto (border colour)", "Picked colour"]
OUTLINES = ["None", "Outer", "Inner"]
OUT_COLOURS = ["Darken neighbours", "Fixed colour"]
OFFSETS = ["None", "Feet (monsters, items)", "Centre (projectiles)", "Custom"]

DEFAULTS = {
    "key_mode": KEY_MODES[1], "key": "#00ffff", "tolerance": 12, "edges_only": True, "defringe": 10,
    "alpha_thr": 50,
    "speck": 0, "pinholes": False,
    "outline": OUTLINES[0], "outline_8": False, "outline_col": OUT_COLOURS[0], "outline_fixed": "#101010",
    "darken": 60,
    "trim": True, "padding": 0,
    "offsets": OFFSETS[1], "sink": 4, "off_x": 0, "off_y": 0,
    "show_result": True,
}


# ==========================================================================
#  Helpers
# ==========================================================================
def _neighbours(m, eight=True):
    """Count of True neighbours for each pixel of bool mask m."""
    p = np.pad(m, 1).astype(np.int16)
    h, w = m.shape
    offs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if eight:
        offs += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    return sum(p[1 + dy:1 + dy + h, 1 + dx:1 + dx + w] for dy, dx in offs)


def _any_neighbour(m, eight=True):
    return _neighbours(m, eight) > 0


def _connected_to_border(cand):
    """Pixels of bool mask cand 4-connected to the image border (scanline sweeps,
    repeated until nothing changes - a few passes for normal shapes)."""
    h, w = cand.shape
    reached = np.zeros_like(cand)
    reached[0, :] = cand[0, :]
    reached[-1, :] = cand[-1, :]
    reached[:, 0] |= cand[:, 0]
    reached[:, -1] |= cand[:, -1]

    def sweep(c, r):
        # runs of candidate pixels along each row: a run touching a reached pixel is reached
        flat_c = np.concatenate([c, np.zeros((c.shape[0], 1), bool)], axis=1).ravel()
        flat_r = np.concatenate([r, np.zeros((r.shape[0], 1), bool)], axis=1).ravel()
        start = flat_c & ~np.r_[False, flat_c[:-1]]
        run = np.cumsum(start) * flat_c
        hit = np.bincount(run, weights=flat_r.astype(np.float64), minlength=run.max() + 1) > 0
        hit[0] = False
        return hit[run].reshape(c.shape[0], c.shape[1] + 1)[:, :-1]

    for _ in range(64):
        before = int(reached.sum())
        reached = sweep(cand, reached)
        reached = sweep(cand.T, reached.T).T
        if int(reached.sum()) == before:
            break
    return reached


def _auto_key(rgb):
    """The most common colour on the image border (grouped), as (r, g, b)."""
    border = np.concatenate([rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]]).astype(np.int64)
    q = border >> 3
    code = (q[:, 0] << 10) | (q[:, 1] << 5) | q[:, 2]
    vals, inv, counts = np.unique(code, return_inverse=True, return_counts=True)
    best = np.argmax(counts)
    return tuple(int(v) for v in border[inv.ravel() == best].mean(axis=0).round())


def _dist(rgb, col):
    d = rgb.astype(np.float32) - np.array(col, np.float32)
    return np.sqrt((d * d).sum(-1))


def _neighbour_mean(rgb, m, eight=True):
    """Per pixel: mean colour of its neighbours that are in mask m."""
    h, w = m.shape
    p = np.pad(rgb.astype(np.float32), ((1, 1), (1, 1), (0, 0)))
    pm = np.pad(m, 1).astype(np.float32)
    offs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if eight:
        offs += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    tot = np.zeros((h, w, 3), np.float32)
    cnt = np.zeros((h, w), np.float32)
    for dy, dx in offs:
        mm = pm[1 + dy:1 + dy + h, 1 + dx:1 + dx + w]
        tot += p[1 + dy:1 + dy + h, 1 + dx:1 + dx + w] * mm[..., None]
        cnt += mm
    return tot / np.maximum(cnt, 1)[..., None]


# ==========================================================================
#  The whole pipeline (also used by Process Folder)
# ==========================================================================
def make_sprite(img, opts):
    """-> (RGBA image with info["grab"] when offsets are on, details dict)"""
    o = dict(DEFAULTS)
    o.update(opts or {})
    a = np.asarray(img.convert("RGBA")).copy()
    rgb, alpha = a[..., :3], a[..., 3]
    info = {"key": None}

    # ---- background
    if o["key_mode"] != KEY_MODES[0]:
        key = _auto_key(rgb) if o["key_mode"] == KEY_MODES[1] else (hex_to_rgb255(o["key"]) or (0, 255, 255))
        info["key"] = key
        tol = o["tolerance"] / 100.0 * 441.7
        d = _dist(rgb, key)
        cand = (d <= tol) & (alpha > 0)
        if o["edges_only"]:
            cand = _connected_to_border(cand)
        alpha = np.where(cand, 0, alpha)

    # ---- hard alpha
    thr = o["alpha_thr"] / 100.0 * 255.0
    op = alpha.astype(np.float32) > thr

    # ---- defringe: edge pixels blended towards the key colour (the halo round a
    # cut-out) are measured by how far along the line from the sprite's inner
    # colour to the key colour they sit: far along -> removed, a little -> recoloured
    if info["key"] is not None and o["defringe"] > 0:
        key = np.array(info["key"], np.float32)
        limit = max(0.05, 0.5 - o["defringe"] / 100.0)
        for _ in range(2):
            edge = op & _any_neighbour(~op, True)
            inner = op & ~edge
            has_in = _any_neighbour(inner, True) & edge
            if not has_in.any():
                break
            ref = _neighbour_mean(rgb, inner, True)
            v = key - ref
            t = ((rgb.astype(np.float32) - ref) * v).sum(-1) / np.maximum((v * v).sum(-1), 1.0)
            kill = has_in & (t >= limit)
            tint = has_in & (t > 0.08) & ~kill
            rgb = np.where(tint[..., None], ref.round().astype(np.uint8), rgb)
            op = op & ~kill
            if not kill.any():
                break

    # ---- cleanup
    if o["speck"] > 0:
        op = op & ~(_neighbours(op, True) <= o["speck"] - 1)
    if o["pinholes"]:
        hole = ~op & (_neighbours(op, True) >= 7)
        if hole.any():
            fill = _neighbour_mean(rgb, op)
            rgb = np.where(hole[..., None], fill.round().astype(np.uint8), rgb)
            op = op | hole

    # ---- outline
    if o["outline"] != OUTLINES[0] and op.any():
        eight = bool(o["outline_8"])
        if o["outline"] == "Outer":
            ring = ~op & _any_neighbour(op, eight)
            src_mask = op
        else:
            ring = op & _any_neighbour(~op, eight)
            src_mask = op & ~ring
            if not src_mask.any():
                src_mask = op
        if o["outline_col"] == OUT_COLOURS[1]:
            col = np.array(hex_to_rgb255(o["outline_fixed"]) or (16, 16, 16), np.float32)
            new = np.broadcast_to(col, rgb.shape)
        else:
            base = _neighbour_mean(rgb, src_mask, True)
            if o["outline"] == "Inner":
                base = np.where(_any_neighbour(src_mask, True)[..., None], base, rgb.astype(np.float32))
            new = base * (1.0 - o["darken"] / 100.0)
        rgb = np.where(ring[..., None], np.clip(new, 0, 255).round().astype(np.uint8), rgb)
        op = op | ring

    out = np.dstack([rgb, np.where(op, 255, 0).astype(np.uint8)])

    # ---- trim
    if o["trim"] and op.any():
        ys, xs = np.nonzero(op)
        pad = int(o["padding"])
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        crop = out[y0:y1, x0:x1]
        if pad > 0:
            crop = np.pad(crop, ((pad, pad), (pad, pad), (0, 0)))
        out = crop
    res = Image.fromarray(np.ascontiguousarray(out), "RGBA")

    # ---- offsets
    h, w = out.shape[:2]
    mode = o["offsets"]
    if mode == OFFSETS[1]:
        grab = (w // 2, h - int(o["sink"]))
    elif mode == OFFSETS[2]:
        grab = (w // 2, h // 2)
    elif mode == OFFSETS[3]:
        grab = (int(o["off_x"]), int(o["off_y"]))
    else:
        grab = None
    if grab is not None:
        res.info["grab"] = grab
    info["grab"] = grab
    return res, info


def run_sprite(img, opts, edits):
    out, _info = make_sprite(img, opts)
    return out, None


# ==========================================================================
#  The tool window
# ==========================================================================
class Sprite(Tool):
    name = "Sprite"
    hint = "Sprite: background to transparency, hard alpha, cleanup, outline, trim and Doom offsets."
    defaults = dict(DEFAULTS)

    @staticmethod
    def run(img, opts, edits):
        return run_sprite(img, opts, edits)

    def __init__(self, host, saved):
        super().__init__(host, saved)
        self._result = None
        self._info = {}
        self._job = None
        self._quiet = False
        self.vars = {}

    def layer_label(self):
        if self._result is not None:
            w, h = self._result.size
            g = self._info.get("grab")
            return f"Sprite {w}x{h}" + (f" @{g[0]},{g[1]}" if g else "")
        return self.name

    # ---------------- controls ----------------
    def build(self, parent):
        p = ttk.Frame(parent, padding=(S(10), 0, S(10), S(10)))
        p.pack(fill="both", expand=True)
        p.columnconfigure(1, weight=1)
        self.p = p
        self._row = 0

        self._section("Background")
        self._combo("key_mode", "Colour key", KEY_MODES)
        krow = self._here()
        self.key_btn = tk.Button(krow, width=6, relief="raised", takefocus=0, command=self._choose_key)
        self.key_btn.pack(side="left")
        ttk.Button(krow, text="Pick from view", command=self._pick_key, takefocus=0).pack(side="left", padx=S(6))
        self.lab_key = ttk.Label(krow, text="", font=SMALL, foreground="#555")
        self.lab_key.pack(side="left")
        self._slider("tolerance", "Tolerance", 0, 100)
        self._check("edges_only", "Only background touching the image edges")
        self._slider("defringe", "Defringe", 0, 50)

        self._section("Transparency")
        self._slider("alpha_thr", "Hard alpha at", 1, 99)
        self._slider("speck", "Remove specks", 0, 3)
        self._check("pinholes", "Fill pinholes")

        self._section("Outline")
        self._combo("outline", "Outline", OUTLINES)
        self._check("outline_8", "8-connected (round corners off)")
        self._combo("outline_col", "Colour", OUT_COLOURS)
        frow = self._here()
        self.out_btn = tk.Button(frow, width=6, relief="raised", takefocus=0, command=self._choose_outline)
        self.out_btn.pack(side="left")
        ttk.Label(frow, text="fixed colour", font=SMALL, foreground="#555").pack(side="left", padx=S(6))
        self._slider("darken", "Darken %", 0, 100)

        self._section("Trim and offsets")
        self._check("trim", "Trim to the visible pixels")
        self._slider("padding", "Padding", 0, 16)
        self._combo("offsets", "Offsets", OFFSETS)
        self._slider("sink", "Ground sink", 0, 16)
        crow = self._here()
        ttk.Label(crow, text="X").pack(side="left")
        self.box_x = NumberBox(crow, self.opts["off_x"], -4096, 4096, step=1, decimals=0, width=6,
                               on_change=lambda v: self._set("off_x", int(v)))
        self.box_x.pack(side="left", padx=(S(4), S(10)))
        ttk.Label(crow, text="Y").pack(side="left")
        self.box_y = NumberBox(crow, self.opts["off_y"], -4096, 4096, step=1, decimals=0, width=6,
                               on_change=lambda v: self._set("off_y", int(v)))
        self.box_y.pack(side="left", padx=S(4))
        self.lab_info = ttk.Label(p, text="", font=SMALL, foreground="#2a6")
        self.lab_info.grid(row=self._row, column=0, columnspan=2, sticky="w", pady=(S(6), 0))
        self._row += 1
        ttk.Label(p, text="Offsets are saved in exported PNGs (grAb chunk) for SLADE. Run Sprite last: "
                          "a tool after it doesn't keep the offsets.", font=SMALL, foreground="#666",
                  wraplength=S(320), justify="left").grid(row=self._row, column=0, columnspan=2,
                                                          sticky="w", pady=(S(4), 0))
        self._row += 1

        self._section("View")
        self._check("show_result", "Show result (off = the image before)", redraw_only=True)
        self._colour_buttons()

    def _section(self, text):
        f = ttk.Frame(self.p)
        f.grid(row=self._row, column=0, columnspan=2, sticky="ew")
        section(f, text)
        self._row += 1

    def _here(self):
        f = ttk.Frame(self.p)
        f.grid(row=self._row, column=1, sticky="w", pady=S(2))
        self._row += 1
        return f

    def _combo(self, key, label, values):
        ttk.Label(self.p, text=label).grid(row=self._row, column=0, sticky="w", padx=(0, S(8)), pady=S(3))
        var = tk.StringVar(value=self.opts[key])
        cb = ttk.Combobox(self.p, textvariable=var, values=values, state="readonly")
        cb.grid(row=self._row, column=1, sticky="ew", pady=S(3))
        var.trace_add("write", lambda *a: self._var(key))
        self.vars[key] = var
        self._row += 1

    def _slider(self, key, label, lo, hi):
        lab = ttk.Label(self.p, text=label)
        lab.grid(row=self._row, column=0, sticky="sw", padx=(0, S(8)), pady=(0, S(2)))
        var = tk.IntVar(value=int(self.opts[key]))
        tk.Scale(self.p, from_=lo, to=hi, orient="horizontal", variable=var, showvalue=True, highlightthickness=0,
                 length=S(220), sliderlength=S(30), width=S(18), font=SMALL, takefocus=0).grid(
            row=self._row, column=1, sticky="ew")
        lab.bind("<Double-Button-1>", lambda e: var.set(DEFAULTS[key]))
        var.trace_add("write", lambda *a: self._var(key))
        self.vars[key] = var
        self._row += 1

    def _check(self, key, label, redraw_only=False):
        var = tk.BooleanVar(value=bool(self.opts[key]))
        ttk.Checkbutton(self.p, text=label, variable=var, takefocus=0).grid(
            row=self._row, column=0, columnspan=2, sticky="w", pady=S(2))
        var.trace_add("write", lambda *a: self._var(key, redraw_only))
        self.vars[key] = var
        self._row += 1

    def _colour_buttons(self):
        for btn, key in ((self.key_btn, "key"), (self.out_btn, "outline_fixed")):
            btn.configure(bg=self.opts[key], activebackground=self.opts[key])
        k = self._info.get("key")
        self.lab_key.configure(text=f"using {rgb255_to_hex(k)}" if k else "")

    def _var(self, key, redraw_only=False):
        if self._quiet:
            return
        try:
            v = self.vars[key].get()
        except tk.TclError:
            return
        self._set(key, v, redraw_only)

    def _set(self, key, v, redraw_only=False):
        if self.opts.get(key) == v:
            return
        self.opts[key] = v
        if redraw_only:
            self.changed()
        else:
            self._schedule()

    def _choose_key(self):
        res = colorchooser.askcolor(color=self.opts["key"], parent=self.host.win)
        if res and res[1]:
            self.opts["key"] = res[1]
            self.vars["key_mode"].set(KEY_MODES[2])
            self._colour_buttons()
            self._schedule()

    def _pick_key(self):
        self.app.status.set_message("Click the background colour in the view  (Esc cancels).")

        def got(rgb):
            self.opts["key"] = rgb255_to_hex(rgb)
            self.vars["key_mode"].set(KEY_MODES[2])
            self._colour_buttons()
            self._schedule()
            self.app.status.set_message(f"Sprite: key colour {self.opts['key']}")
        # pick from the image before Sprite, not the result
        self.opts["show_result"] = False
        self.vars["show_result"].set(False)
        self.changed()
        self.app.view.start_pick(got)

    def _choose_outline(self):
        res = colorchooser.askcolor(color=self.opts["outline_fixed"], parent=self.host.win)
        if res and res[1]:
            self.opts["outline_fixed"] = res[1]
            self.vars["outline_col"].set(OUT_COLOURS[1])
            self._colour_buttons()
            self._schedule()

    def sync_widgets(self):
        self._quiet = True
        for k, var in self.vars.items():
            var.set(self.opts[k])
        self.box_x.set(self.opts["off_x"])
        self.box_y.set(self.opts["off_y"])
        self._quiet = False
        self._colour_buttons()

    def on_reset(self):
        self._schedule(now=True)

    # ---------------- processing ----------------
    def set_input(self, img):
        super().set_input(img)
        self._schedule(now=True)

    def _schedule(self, now=False):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if now:
            self._compute()
        else:
            self._job = self.app.root.after(60, self._compute)

    def flush(self):
        if self._job is not None:
            self._compute()

    def _compute(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if self.input is None:
            self._result, self._info = None, {}
        else:
            self._result, self._info = make_sprite(self.input, self.opts)
        if hasattr(self, "lab_info"):
            self._colour_buttons()
            if self._result is not None:
                w, h = self._result.size
                g = self._info.get("grab")
                self.lab_info.configure(text=f"Result {w} x {h}" + (f"   offsets {g[0]}, {g[1]}" if g else
                                                                      "   no offsets"))
        self.changed()

    def result(self):
        return self._result if self.input is not None else None

    def display(self):
        if self.opts["show_result"] and self._result is not None:
            return self._result
        return self.input

    def close(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None

    # ---------------- overlay: the offset origin ----------------
    def overlay(self, canvas, x0, y0, k, cw, ch):
        if not self.opts["show_result"] or self._result is None:
            return
        g = self._info.get("grab")
        if not g:
            return
        cx, cy = x0 + g[0] * k, y0 + g[1] * k
        r = S(10)
        for col, wd in (("#000", S(3)), (GRID_SEL, S(1))):
            canvas.create_line(cx - r, cy, cx + r, cy, fill=col, width=wd)
            canvas.create_line(cx, cy - r, cx, cy + r, fill=col, width=wd)
