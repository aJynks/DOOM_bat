"""png2pixel - the scaling method and options panel, shared by Scale and titlePic.

Builds the Method dropdown and every option, bound to the tool's opts (the keys
of tool_scale_engine.DEFAULTS). Options a method doesn't use are greyed out.
Double-click a slider's name to reset that slider.
"""
import tkinter as tk
from tkinter import ttk

from ..lib_const import S, SMALL
from .tool_scale_engine import METHODS, DEFAULTS, option_used

ABOUT = {
    "Lanczos 3": "Sharpest classic filter; faint halos on hard edges.",
    "Lanczos 2": "A little softer than Lanczos 3, fewer halos.",
    "Catmull-Rom": "Sharp cubic, very little ringing.",
    "Mitchell": "Balanced cubic: a touch soft, almost no halos.",
    "Bicubic": "Classic sharp bicubic (a = -0.75).",
    "Hamming": "Soft windowed filter, like the titlepic tool's Hamming.",
    "Bilinear": "Soft, smooth.",
    "Box (area average)": "Exact average of each footprint. Never aliases; soft.",
    "Nearest": "One sample per footprint: crisp, can drop details. Sample point = where.",
    "Majority (pixel art)": "The titlepic tool's majority: most common colour (no new colours).",
    "Majority (grouped)": "Most common colour group over the whole footprint (no new colours).",
    "Median": "Per-channel median: shrugs off noise, keeps edges.",
    "DPID": "Detail-preserving (Weber 2016): small high-contrast details survive.",
    "Contrast keep": "The footprint pixel most unlike its surroundings: very punchy.",
    "Line keeper": "Majority that keeps dark outlines unbroken.",
    "Edge-weighted majority": "Majority where edge pixels count more: clean silhouettes.",
}

# key, label, lo, hi, resolution
SLIDERS = [
    ("sample", "Sample point %", 0, 100, 1),
    ("group", "Colour grouping", 0, 5, 1),
    ("detail", "Detail", 0, 100, 1),
    ("line_thresh", "Line threshold", 0, 100, 1),
    ("line_cover", "Line coverage %", 0, 100, 1),
    ("edge_weight", "Edge weight", 0, 100, 1),
]
OPTION_SLIDERS = [
    ("flatten", "Pre-flatten", 0, 6, 1),
    ("bias", "Dark / light bias", -100, 100, 1),
    ("snap", "Snap to source %", 0, 100, 1),
    ("sharpen", "Sharpen after", 0, 300, 1),
]


class ScalePanel:
    def __init__(self, parent, tool, on_change):
        self.tool = tool
        self.on_change = on_change
        self._quiet = False
        o = tool.opts
        f = ttk.Frame(parent)
        f.pack(fill="x")
        self.frame = f
        f.columnconfigure(1, weight=1)
        self.vars, self.widgets = {}, {}
        r = 0
        ttk.Label(f, text="Method").grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(3))
        self.v_method = tk.StringVar(value=o["method"] if o["method"] in METHODS else DEFAULTS["method"])
        cb = ttk.Combobox(f, textvariable=self.v_method, values=METHODS, state="readonly", height=len(METHODS))
        cb.grid(row=r, column=1, sticky="ew", pady=S(3))
        cb.bind("<<ComboboxSelected>>", lambda e: self._method_changed())
        r += 1
        self.lab_about = ttk.Label(f, text="", font=SMALL, foreground="#555", wraplength=S(330), justify="left")
        self.lab_about.grid(row=r, column=0, columnspan=2, sticky="w", pady=(0, S(4)))
        r += 1
        for spec in SLIDERS:
            r = self._slider(f, r, *spec)
        self.vars["phase"] = tk.BooleanVar(value=o["phase"])
        self.widgets["phase"] = ttk.Checkbutton(f, text="Phase search (line the grid up with the art; slow on big images)",
                                                variable=self.vars["phase"], takefocus=0,
                                                command=lambda: self._changed("phase"))
        self.widgets["phase"].grid(row=r, column=0, columnspan=2, sticky="w", pady=S(2))
        r += 1
        ttk.Separator(f).grid(row=r, column=0, columnspan=2, sticky="ew", pady=S(6))
        r += 1
        self.vars["linear"] = tk.BooleanVar(value=o["linear"])
        self.widgets["linear"] = ttk.Checkbutton(f, text="Linear light (average real brightness)",
                                                 variable=self.vars["linear"], takefocus=0,
                                                 command=lambda: self._changed("linear"))
        self.widgets["linear"].grid(row=r, column=0, columnspan=2, sticky="w", pady=S(2))
        r += 1
        for spec in OPTION_SLIDERS:
            r = self._slider(f, r, *spec)
        self.vars["despeckle"] = tk.BooleanVar(value=o["despeckle"])
        self.widgets["despeckle"] = ttk.Checkbutton(f, text="Despeckle (remove lone pixels)",
                                                    variable=self.vars["despeckle"], takefocus=0,
                                                    command=lambda: self._changed("despeckle"))
        self.widgets["despeckle"].grid(row=r, column=0, columnspan=2, sticky="w", pady=S(2))
        self._update_states()

    def _slider(self, f, r, key, label, lo, hi, res):
        var = tk.IntVar(value=int(self.tool.opts[key]))
        lab = ttk.Label(f, text=label)
        lab.grid(row=r, column=0, sticky="sw", padx=(0, S(8)), pady=(0, S(2)))
        sc = tk.Scale(f, from_=lo, to=hi, resolution=res, orient="horizontal", variable=var, showvalue=True,
                      highlightthickness=0, length=S(220), sliderlength=S(30), width=S(18), font=SMALL,
                      takefocus=0)
        sc.grid(row=r, column=1, sticky="ew")
        lab.bind("<Double-Button-1>", lambda e: var.set(DEFAULTS[key]))
        var.trace_add("write", lambda *a: self._changed(key))
        self.vars[key] = var
        self.widgets[key] = sc
        self.widgets[key + "_label"] = lab
        return r + 1

    def _method_changed(self):
        self.tool.opts["method"] = self.v_method.get()
        self._update_states()
        self.on_change()

    def _changed(self, key):
        if self._quiet:
            return
        try:
            v = self.vars[key].get()
        except tk.TclError:
            return
        if self.tool.opts.get(key) == v:
            return
        self.tool.opts[key] = v
        self.on_change()

    def _update_states(self):
        m = self.v_method.get()
        self.lab_about.configure(text=ABOUT.get(m, ""))
        for key, w in self.widgets.items():
            if key.endswith("_label"):
                continue
            used = option_used(key, m)
            if isinstance(w, tk.Scale):
                w.configure(state="normal" if used else "disabled", fg="#000" if used else "#aaa")
                self.widgets[key + "_label"].configure(foreground="#000" if used else "#aaa")
            else:
                w.state(["!disabled"] if used else ["disabled"])

    def sync(self):
        o = self.tool.opts
        self._quiet = True
        self.v_method.set(o["method"])
        for key, var in self.vars.items():
            var.set(o[key])
        self._quiet = False
        self._update_states()
