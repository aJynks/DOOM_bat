"""png2pixel - Adjust engine: whole-image adjustments, no UI.

Ported from the titlepic tool's Tweak Image window (same maths, same results),
plus Sharpen and Blur / Denoise. Every adjustment works on an (H,W,3) float32
sRGB image in 0..1 and returns one. Used by the Adjust tool window and by
Process Folder.

TOOLS: name -> (function, param spec). Param spec entries:
    ("s", key, label, lo, hi, resolution, default)   slider
    ("c", key, label, [values], default)            dropdown
    ("b", key, label, default)                      tick box
    ("col", key, label, "#rrggbb")                  colour button
    ("curve", key, default_points)                  curve editor
"""
import math

import numpy as np
from PIL import Image


# --------------------------------------------------------------------------
#  Colour maths
# --------------------------------------------------------------------------
def srgb_to_linear(x):
    x = np.asarray(x, dtype=np.float32)
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4).astype(np.float32)


def linear_to_srgb(x):
    x = np.clip(np.asarray(x, dtype=np.float32), 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1.0 / 2.4) - 0.055).astype(np.float32)


def linear_to_oklab(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l, m, s = np.cbrt(l), np.cbrt(m), np.cbrt(s)
    L = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
    A = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
    B = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
    return np.stack([L, A, B], axis=-1).astype(np.float32)


def oklab_to_linear(lab):
    L, A, B = lab[..., 0], lab[..., 1], lab[..., 2]
    l = L + 0.3963377774 * A + 0.2158037573 * B
    m = L - 0.1055613458 * A - 0.0638541728 * B
    s = L - 0.0894841775 * A - 1.2914855480 * B
    l, m, s = l ** 3, m ** 3, s ** 3
    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    b = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    return np.stack([r, g, b], axis=-1).astype(np.float32)



def gaussian_blur(x, sigma):
    rad = max(1, int(math.ceil(sigma * 3.0)))
    k = np.exp(-0.5 * (np.arange(-rad, rad + 1, dtype=np.float32) / sigma) ** 2)
    k /= k.sum()
    p = np.pad(x, ((rad, rad), (0, 0), (0, 0)), mode="edge")
    y = np.zeros_like(x)
    for i, kv in enumerate(k):
        y += kv * p[i:i + x.shape[0]]
    p = np.pad(y, ((0, 0), (rad, rad), (0, 0)), mode="edge")
    z = np.zeros_like(x)
    for i, kv in enumerate(k):
        z += kv * p[:, i:i + x.shape[1]]
    return z


def apply_sharpen(x, amount, radius):
    if amount <= 0:
        return x
    blur = gaussian_blur(x, max(0.2, radius))
    return np.clip(x + (amount / 100.0) * (x - blur), 0.0, 1.0).astype(np.float32)



# --------------------------------------------------------------------------
#  Image tweak tools
#  Every tool works on an (H,W,3) float32 sRGB image in 0..1 and returns one.
# --------------------------------------------------------------------------
RANGES = ["Reds", "Yellows", "Greens", "Cyans", "Blues", "Magentas"]
_HUE_CENTRES = None


def to_ok(x):
    return linear_to_oklab(srgb_to_linear(x))


def from_ok(lab):
    return linear_to_srgb(oklab_to_linear(lab))


def luma(x):
    return (0.2126 * x[..., 0] + 0.7152 * x[..., 1] + 0.0722 * x[..., 2]).astype(np.float32)


def hue_centres():
    global _HUE_CENTRES
    if _HUE_CENTRES is None:
        prim = np.array([[1, 0, 0], [1, 1, 0], [0, 1, 0], [0, 1, 1], [0, 0, 1], [1, 0, 1]], dtype=np.float32)
        lab = linear_to_oklab(prim)
        _HUE_CENTRES = np.degrees(np.arctan2(lab[:, 2], lab[:, 1])) % 360.0
    return _HUE_CENTRES


def hue_weights(lab):
    """(6,H,W) weights per colour range (a partition of unity around the hue
    wheel), multiplied by a chroma ramp so greys are not affected."""
    c = hue_centres()
    h = np.degrees(np.arctan2(lab[..., 2], lab[..., 1])) % 360.0
    ramp = np.clip(np.hypot(lab[..., 1], lab[..., 2]) / 0.05, 0.0, 1.0)
    out = []
    n = len(c)
    for i in range(n):
        ci, cp, cn = c[i], c[(i - 1) % n], c[(i + 1) % n]
        d = (h - ci + 180.0) % 360.0 - 180.0
        span_n = (cn - ci) % 360.0
        span_p = (ci - cp) % 360.0
        w = np.where(d >= 0, 1.0 - d / span_n, 1.0 + d / span_p)
        out.append(np.clip(w, 0.0, 1.0) * ramp)
    return np.stack(out).astype(np.float32)


def _range_weight(lab, name):
    if name == "Master":
        return np.ones(lab.shape[:2], dtype=np.float32)
    return hue_weights(lab)[RANGES.index(name)]


def monotone_lut(points, n=1024):
    pts = {}
    for px, py in points:
        pts[min(max(float(px), 0.0), 1.0)] = min(max(float(py), 0.0), 1.0)
    xs = np.array(sorted(pts), dtype=np.float64)
    ys = np.array([pts[k] for k in xs], dtype=np.float64)
    t = np.linspace(0.0, 1.0, n)
    if len(xs) < 2:
        return t.astype(np.float32)
    if len(xs) == 2:
        return np.clip(np.interp(t, xs, ys), 0, 1).astype(np.float32)
    d = np.diff(ys) / np.diff(xs)
    m = np.empty(len(xs))
    m[0], m[-1] = d[0], d[-1]
    m[1:-1] = (d[:-1] + d[1:]) / 2.0
    for k in range(1, len(xs) - 1):
        if d[k - 1] * d[k] <= 0:
            m[k] = 0.0
    for k in range(len(d)):
        if d[k] == 0:
            m[k] = m[k + 1] = 0.0
        else:
            a, b = m[k] / d[k], m[k + 1] / d[k]
            s = a * a + b * b
            if s > 9.0:
                tau = 3.0 / math.sqrt(s)
                m[k], m[k + 1] = tau * a * d[k], tau * b * d[k]
    i = np.clip(np.searchsorted(xs, t, side="right") - 1, 0, len(xs) - 2)
    h = xs[i + 1] - xs[i]
    s = np.clip((t - xs[i]) / h, 0.0, 1.0)
    h00 = 2 * s ** 3 - 3 * s ** 2 + 1
    h10 = s ** 3 - 2 * s ** 2 + s
    h01 = -2 * s ** 3 + 3 * s ** 2
    h11 = s ** 3 - s ** 2
    y = h00 * ys[i] + h10 * h * m[i] + h01 * ys[i + 1] + h11 * h * m[i + 1]
    y = np.where(t < xs[0], ys[0], np.where(t > xs[-1], ys[-1], y))
    return np.clip(y, 0.0, 1.0).astype(np.float32)


def _channels(name):
    return {"RGB": [0, 1, 2], "Red": [0], "Green": [1], "Blue": [2]}[name]


def t_basic(x, p):
    bp = p["black"] / 255.0
    wp = max(p["white"] / 255.0, bp + 1.0 / 255.0)
    x = np.clip((x - bp) / (wp - bp), 0.0, 1.0)
    if p["gamma"] != 1.0:
        x = np.power(x, 1.0 / p["gamma"])
    if p["brightness"]:
        x = x + p["brightness"] / 200.0
    if p["contrast"]:
        x = (x - 0.5) * (2.0 ** (p["contrast"] / 50.0)) + 0.5
    x = np.clip(x, 0.0, 1.0).astype(np.float32)
    if p["saturation"] != 100 or p["hue"] != 0:
        lab = to_ok(x)
        s = p["saturation"] / 100.0
        ang = math.radians(p["hue"])
        ca, sa = math.cos(ang) * s, math.sin(ang) * s
        a, b = lab[..., 1].copy(), lab[..., 2].copy()
        lab[..., 1] = a * ca - b * sa
        lab[..., 2] = a * sa + b * ca
        x = from_ok(lab)
    return x


def t_levels(x, p):
    ib, iw = p["in_black"] / 255.0, max(p["in_white"], p["in_black"] + 1) / 255.0
    ob, ow = p["out_black"] / 255.0, p["out_white"] / 255.0
    y = x.copy()
    for c in _channels(p["channel"]):
        v = np.clip((x[..., c] - ib) / (iw - ib), 0.0, 1.0) ** (1.0 / p["gamma"])
        y[..., c] = ob + v * (ow - ob)
    return y


def t_curves(x, p):
    lut = monotone_lut(p["points"])
    y = x.copy()
    for c in _channels(p["channel"]):
        y[..., c] = lut[np.clip((x[..., c] * 1023.0 + 0.5).astype(np.int32), 0, 1023)]
    return y


def t_brightcon(x, p):
    y = x + p["brightness"] / 200.0
    if p["contrast"]:
        y = (y - 0.5) * (2.0 ** (p["contrast"] / 50.0)) + 0.5
    return y


def t_exposure(x, p):
    lin = srgb_to_linear(x) * (2.0 ** p["exposure"]) + p["offset"] / 100.0
    y = linear_to_srgb(lin)
    if p["gamma"] != 1.0:
        y = np.power(np.clip(y, 0, 1), 1.0 / p["gamma"])
    return y


def t_hsl(x, p):
    lab = to_ok(x)
    w = _range_weight(lab, p["range"])
    ang = np.radians(p["hue"]) * w
    s = 1.0 + p["saturation"] / 100.0 * w
    a, b = lab[..., 1], lab[..., 2]
    ca, sa = np.cos(ang), np.sin(ang)
    lab[..., 1] = (a * ca - b * sa) * s
    lab[..., 2] = (a * sa + b * ca) * s
    l = p["lightness"] / 100.0 * w
    L = lab[..., 0]
    lab[..., 0] = np.where(l > 0, L + l * (1.0 - L), L * (1.0 + l))
    return from_ok(lab)


def t_vibrance(x, p):
    lab = to_ok(x)
    C = np.hypot(lab[..., 1], lab[..., 2])
    f = (1.0 + p["vibrance"] / 100.0 * (1.0 - np.clip(C / 0.25, 0.0, 1.0))) * (1.0 + p["saturation"] / 100.0)
    lab[..., 1] *= f
    lab[..., 2] *= f
    return from_ok(lab)


def t_colour_balance(x, p):
    Y = luma(x)
    w = {"Shadows": (1.0 - Y) ** 2, "Highlights": Y ** 2, "Midtones": 4.0 * Y * (1.0 - Y)}[p["tones"]]
    d = np.array([p["cyan_red"], p["magenta_green"], p["yellow_blue"]], dtype=np.float32) / 100.0 * 0.25
    y = x + w[..., None] * d
    if p["preserve"]:
        y = y + (Y - luma(y))[..., None]
    return y


def t_white_balance(x, p):
    lin = srgb_to_linear(x)
    t, n = p["temperature"] / 100.0, p["tint"] / 100.0
    m = np.array([(1 + 0.25 * t) * (1 + 0.12 * n), 1 - 0.2 * n, (1 - 0.25 * t) * (1 + 0.12 * n)], dtype=np.float32)
    y = lin * m
    Y0 = 0.2126 * lin[..., 0] + 0.7152 * lin[..., 1] + 0.0722 * lin[..., 2]
    Y1 = 0.2126 * y[..., 0] + 0.7152 * y[..., 1] + 0.0722 * y[..., 2]
    y = y * (Y0 / np.maximum(Y1, 1e-6))[..., None]
    return linear_to_srgb(y)


def t_shadows_highlights(x, p):
    lab = to_ok(x)
    L = lab[..., 0]
    bl = gaussian_blur(L[..., None], max(0.5, p["radius"]))[..., 0]
    ms, mh = (1.0 - bl) ** 2, bl ** 2
    s, h = p["shadows"] / 100.0, p["highlights"] / 100.0
    if s:
        L = L + s * ms * ((1.0 - L) if s > 0 else L) * 0.8
    if h:
        L = L + h * mh * ((1.0 - L) if h > 0 else L) * 0.8
    lab[..., 0] = L
    return from_ok(lab)


def t_colorize(x, p):
    lab = to_ok(x)
    L = lab[..., 0]
    l = p["lightness"] / 100.0
    L = L + l * (1.0 - L) if l > 0 else L * (1.0 + l)
    C = p["saturation"] / 100.0 * 0.2
    ang = math.radians(p["hue"])
    col = np.stack([L, np.full_like(L, C * math.cos(ang)), np.full_like(L, C * math.sin(ang))], axis=-1)
    y = from_ok(col)
    k = p["strength"] / 100.0
    return x * (1.0 - k) + y * k


def t_black_white(x, p):
    lab = to_ok(x)
    C = np.hypot(lab[..., 1], lab[..., 2])
    w = hue_weights(lab)
    adj = sum(w[i] * (p[r.lower()] - 50.0) / 100.0 for i, r in enumerate(RANGES))
    L = np.clip(lab[..., 0] + C * adj * 1.5, 0.0, 1.0)
    grey = from_ok(np.stack([L, np.zeros_like(L), np.zeros_like(L)], axis=-1))
    k = p["strength"] / 100.0
    return x * (1.0 - k) + grey * k


def t_channel_mixer(x, p):
    c = ["Red", "Green", "Blue"].index(p["output"])
    y = x.copy()
    y[..., c] = (p["red"] * x[..., 0] + p["green"] * x[..., 1] + p["blue"] * x[..., 2]) / 100.0 + p["constant"] / 100.0
    return y


def _hex_rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32) / 255.0


def t_gradient_map(x, p):
    t = np.clip(luma(x), 0.0, 1.0)[..., None]
    c0, c1, c2 = _hex_rgb(p["shadow"]), _hex_rgb(p["mid"]), _hex_rgb(p["highlight"])
    if p["use_mid"]:
        lo = c0 + (c1 - c0) * np.clip(t * 2.0, 0, 1)
        hi = c1 + (c2 - c1) * np.clip(t * 2.0 - 1.0, 0, 1)
        y = np.where(t < 0.5, lo, hi)
    else:
        y = c0 + (c2 - c0) * t
    k = p["strength"] / 100.0
    return x * (1.0 - k) + y * k


def t_selective(x, p):
    name = p["range"]
    if name in RANGES:
        w = hue_weights(to_ok(x))[RANGES.index(name)]
    else:
        Y = luma(x)
        sat = np.clip((x.max(-1) - x.min(-1)) / 0.25, 0.0, 1.0)
        if name == "Whites":
            w = np.clip((Y - 0.66) / 0.34, 0.0, 1.0)
        elif name == "Blacks":
            w = np.clip((0.33 - Y) / 0.33, 0.0, 1.0)
        else:
            w = (1.0 - sat) * (1.0 - np.abs(2.0 * Y - 1.0))
    y = x.copy()
    for c, key in enumerate(("cyan", "magenta", "yellow")):
        y[..., c] = x[..., c] * (1.0 - p[key] / 100.0 * w)
    y = y * (1.0 - p["black"] / 100.0 * 0.6 * w)[..., None]
    return y


def t_invert(x, p):
    return x + (1.0 - 2.0 * x) * (p["amount"] / 100.0)


def t_posterize(x, p):
    n = max(2, int(p["levels"]))
    return np.round(np.clip(x, 0, 1) * (n - 1)) / (n - 1)


def t_threshold(x, p):
    v = (luma(x) >= p["level"] / 255.0).astype(np.float32)
    return np.repeat(v[..., None], 3, axis=-1)


# param spec:
#   ("s", key, label, lo, hi, resolution, default)   slider
#   ("c", key, label, [values], default)            dropdown
#   ("b", key, label, default)                      tick box
#   ("col", key, label, "#rrggbb")                  colour button
#   ("curve", key, default_points)                  curve editor
CHANS = ["RGB", "Red", "Green", "Blue"]

# --------------------------------------------------------------------------
#  Sharpen / Blur / Denoise (new in png2pixel)
# --------------------------------------------------------------------------
def t_sharpen(x, p):
    """Unsharp mask; Threshold leaves differences smaller than it alone (keeps noise down)."""
    if p["amount"] <= 0:
        return x
    blur = gaussian_blur(x, max(0.2, p["radius"]))
    d = x - blur
    if p["threshold"] > 0:
        t = p["threshold"] / 255.0
        d = np.where(np.abs(d) >= t, d, 0.0)
    return x + (p["amount"] / 100.0) * d


def _box(a, r):
    """Box filter (mean over a (2r+1)^2 window) of an (H,W[,C]) array, edges clamped."""
    pad = [(r, r), (r, r)] + [(0, 0)] * (a.ndim - 2)
    c = np.pad(a, pad, mode="edge").astype(np.float64)
    c = np.cumsum(np.cumsum(c, axis=0), axis=1)
    c = np.pad(c, [(1, 0), (1, 0)] + [(0, 0)] * (a.ndim - 2))
    k = 2 * r + 1
    h, w = a.shape[:2]
    s = c[k:k + h, k:k + w] - c[:h, k:k + w] - c[k:k + h, :w] + c[:h, :w]
    return (s / (k * k)).astype(np.float32)


def t_blur(x, p):
    r = max(1, int(p["radius"]))
    k = p["strength"] / 100.0
    m = p["method"]
    if m == "Gaussian":
        y = gaussian_blur(x, r / 2.0)
    elif m == "Median":
        from PIL import Image, ImageFilter
        size = min(2 * r + 1, 15)
        im = Image.fromarray((np.clip(x, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB")
        y = np.asarray(im.filter(ImageFilter.MedianFilter(size)), dtype=np.float32) / 255.0
    else:
        # guided filter, guided by itself: smooths flat areas, keeps edges
        eps = (0.002 + 0.05 * k) ** 2
        mean = _box(x, r)
        var = _box(x * x, r) - mean * mean
        a = var / (var + eps)
        b = mean - a * mean
        y = _box(a, r) * x + _box(b, r)
        return y
    return x * (1.0 - k) + y * k


TOOLS = {
    "Basic": (t_basic, [
        ("s", "black", "Black", 0, 254, 1, 0),
        ("s", "white", "White", 1, 255, 1, 255),
        ("s", "gamma", "Gamma", 0.2, 3.0, 0.01, 1.0),
        ("s", "brightness", "Brightness", -100, 100, 1, 0),
        ("s", "contrast", "Contrast", -100, 100, 1, 0),
        ("s", "saturation", "Saturation", 0, 300, 1, 100),
        ("s", "hue", "Hue", -180, 180, 1, 0)]),
    "Levels": (t_levels, [
        ("c", "channel", "Channel", CHANS, "RGB"),
        ("s", "in_black", "Input black", 0, 254, 1, 0),
        ("s", "in_white", "Input white", 1, 255, 1, 255),
        ("s", "gamma", "Gamma", 0.1, 5.0, 0.01, 1.0),
        ("s", "out_black", "Output black", 0, 255, 1, 0),
        ("s", "out_white", "Output white", 0, 255, 1, 255)]),
    "Curves": (t_curves, [
        ("c", "channel", "Channel", CHANS, "RGB"),
        ("curve", "points", [[0.0, 0.0], [1.0, 1.0]])]),
    "Brightness / Contrast": (t_brightcon, [
        ("s", "brightness", "Brightness", -100, 100, 1, 0),
        ("s", "contrast", "Contrast", -100, 100, 1, 0)]),
    "Exposure": (t_exposure, [
        ("s", "exposure", "Exposure (stops)", -5.0, 5.0, 0.05, 0.0),
        ("s", "offset", "Offset", -50, 50, 1, 0),
        ("s", "gamma", "Gamma", 0.1, 5.0, 0.01, 1.0)]),
    "HSL": (t_hsl, [
        ("c", "range", "Range", ["Master"] + RANGES, "Master"),
        ("s", "hue", "Hue", -180, 180, 1, 0),
        ("s", "saturation", "Saturation", -100, 200, 1, 0),
        ("s", "lightness", "Lightness", -100, 100, 1, 0)]),
    "Vibrance": (t_vibrance, [
        ("s", "vibrance", "Vibrance", -100, 200, 1, 0),
        ("s", "saturation", "Saturation", -100, 200, 1, 0)]),
    "Colour Balance": (t_colour_balance, [
        ("c", "tones", "Tones", ["Shadows", "Midtones", "Highlights"], "Midtones"),
        ("s", "cyan_red", "Cyan / Red", -100, 100, 1, 0),
        ("s", "magenta_green", "Magenta / Green", -100, 100, 1, 0),
        ("s", "yellow_blue", "Yellow / Blue", -100, 100, 1, 0),
        ("b", "preserve", "Preserve luminosity", True)]),
    "White Balance": (t_white_balance, [
        ("s", "temperature", "Temperature", -100, 100, 1, 0),
        ("s", "tint", "Tint (green / magenta)", -100, 100, 1, 0)]),
    "Shadows / Highlights": (t_shadows_highlights, [
        ("s", "shadows", "Shadows", -100, 100, 1, 0),
        ("s", "highlights", "Highlights", -100, 100, 1, 0),
        ("s", "radius", "Radius (px)", 1, 40, 1, 10)]),
    "Colorize": (t_colorize, [
        ("s", "hue", "Hue", 0, 360, 1, 25),
        ("s", "saturation", "Saturation", 0, 100, 1, 50),
        ("s", "lightness", "Lightness", -100, 100, 1, 0),
        ("s", "strength", "Strength", 0, 100, 1, 100)]),
    "Black & White": (t_black_white, [
        ("s", "reds", "Reds", -100, 200, 1, 50),
        ("s", "yellows", "Yellows", -100, 200, 1, 50),
        ("s", "greens", "Greens", -100, 200, 1, 50),
        ("s", "cyans", "Cyans", -100, 200, 1, 50),
        ("s", "blues", "Blues", -100, 200, 1, 50),
        ("s", "magentas", "Magentas", -100, 200, 1, 50),
        ("s", "strength", "Strength", 0, 100, 1, 100)]),
    "Channel Mixer": (t_channel_mixer, [
        ("c", "output", "Output channel", ["Red", "Green", "Blue"], "Red"),
        ("s", "red", "Red %", -200, 200, 1, 100),
        ("s", "green", "Green %", -200, 200, 1, 0),
        ("s", "blue", "Blue %", -200, 200, 1, 0),
        ("s", "constant", "Constant", -100, 100, 1, 0)]),
    "Gradient Map": (t_gradient_map, [
        ("col", "shadow", "Shadows", "#000000"),
        ("b", "use_mid", "Use midtone colour", True),
        ("col", "mid", "Midtones", "#8b2323"),
        ("col", "highlight", "Highlights", "#ffd7a0"),
        ("s", "strength", "Strength", 0, 100, 1, 100)]),
    "Selective Colour": (t_selective, [
        ("c", "range", "Colours", RANGES + ["Whites", "Neutrals", "Blacks"], "Reds"),
        ("s", "cyan", "Cyan", -100, 100, 1, 0),
        ("s", "magenta", "Magenta", -100, 100, 1, 0),
        ("s", "yellow", "Yellow", -100, 100, 1, 0),
        ("s", "black", "Black", -100, 100, 1, 0)]),
    "Invert": (t_invert, [
        ("s", "amount", "Amount", 0, 100, 1, 100)]),
    "Posterize": (t_posterize, [
        ("s", "levels", "Levels", 2, 32, 1, 6)]),
    "Threshold": (t_threshold, [
        ("s", "level", "Level", 0, 255, 1, 128)]),
    "Sharpen": (t_sharpen, [
        ("s", "amount", "Amount %", 0, 400, 1, 100),
        ("s", "radius", "Radius (px)", 0.2, 10.0, 0.1, 1.0),
        ("s", "threshold", "Threshold", 0, 64, 1, 0)]),
    "Blur / Denoise": (t_blur, [
        ("c", "method", "Method", ["Edge-preserving", "Gaussian", "Median"], "Edge-preserving"),
        ("s", "radius", "Radius (px)", 1, 20, 1, 3),
        ("s", "strength", "Strength", 0, 100, 1, 50)]),
}
ADJUST_NAMES = list(TOOLS.keys())


def tool_defaults(name):
    d = {}
    for spec in TOOLS[name][1]:
        if spec[0] == "s":
            d[spec[1]] = spec[6]
        elif spec[0] == "c":
            d[spec[1]] = spec[4]
        elif spec[0] == "b":
            d[spec[1]] = spec[3]
        elif spec[0] == "col":
            d[spec[1]] = spec[3]
        elif spec[0] == "curve":
            d[spec[1]] = [list(pt) for pt in spec[2]]
    return d


def apply_adjust(x, name, params):
    """x (H,W,3) float32 0..1 -> adjusted, clipped."""
    fn = TOOLS[name][0]
    p = tool_defaults(name)
    p.update(params or {})
    return np.clip(fn(x.astype(np.float32), p), 0.0, 1.0).astype(np.float32)


def is_default(name, params):
    d = tool_defaults(name)
    for k, dv in d.items():
        v = (params or {}).get(k, dv)
        if isinstance(dv, float) or isinstance(v, float):
            if abs(float(v) - float(dv)) > 1e-9:
                return False
        elif v != dv:
            return False
    return True


def image_to_float(img):
    """PIL image -> (rgb float32 0..1, alpha uint8 or None)"""
    a = np.asarray(img)
    alpha = a[..., 3].copy() if img.mode == "RGBA" else None
    return a[..., :3].astype(np.float32) / 255.0, alpha


def float_to_image(x, alpha=None):
    rgb = (np.clip(x, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
    if alpha is not None:
        return Image.fromarray(np.concatenate([rgb, alpha[..., None]], axis=2), "RGBA")
    return Image.fromarray(rgb, "RGB")


def histograms(img):
    """(4, 256) counts: luma, red, green, blue."""
    a = np.asarray(img)[..., :3]
    y = (0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2] + 0.5).astype(np.int64)
    out = [np.bincount(y.ravel(), minlength=256)[:256]]
    for c in range(3):
        out.append(np.bincount(a[..., c].ravel(), minlength=256)[:256])
    return np.stack(out).astype(np.float64)


def run_adjust(img, opts, edits):
    """Headless Adjust for batch replay -> (image, warning or None)."""
    name = opts.get("adjust")
    if name not in TOOLS:
        return img, f"unknown adjustment {name!r}: skipped"
    params = (opts.get("params") or {}).get(name, {})
    x, alpha = image_to_float(img)
    return float_to_image(apply_adjust(x, name, params), alpha), None
