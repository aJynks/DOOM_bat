"""png2pixel - Adjust (tool window; the maths is in tool_adjust_engine).

Whole-image adjustments: Basic, Levels, Curves, Brightness / Contrast, Exposure,
HSL, Vibrance, Colour Balance, White Balance, Shadows / Highlights, Colorize,
Black & White, Channel Mixer, Gradient Map, Selective Colour, Invert,
Posterize, Threshold, Sharpen, Blur / Denoise.

One adjustment at a time. Picking another adjustment while the current one is
changing the image asks Apply / Discard / Cancel, like switching tools:
Apply adds a snapshot layer ("Adjust: Levels") and the next adjustment starts
on that result. The window's Apply adds the layer and closes.

Settings are remembered per adjustment. Reset adjustment = this adjustment's
defaults; the window's Reset = every adjustment's defaults. Double-click a
slider's label to reset just that slider.
"""
import copy
import tkinter as tk
from tkinter import colorchooser, ttk

import numpy as np

from ..lib_const import S, SMALL, HEAD
from ..lib_widgets import ask_apply, note
from .tool_base import Tool
from .tool_adjust_engine import (
    TOOLS, ADJUST_NAMES, tool_defaults, apply_adjust, is_default, image_to_float, float_to_image,
    histograms, monotone_lut, run_adjust)

# adjustments whose default settings already change the image
EFFECTS = {"Colorize", "Black & White", "Gradient Map", "Invert", "Posterize", "Threshold",
           "Sharpen", "Blur / Denoise"}
HIST_INDEX = {"RGB": 0, "Red": 1, "Green": 2, "Blue": 3}


class Adjust(Tool):
    name = "Adjust"
    hint = "Adjust: pick an adjustment; switching to another asks to apply or discard the current one."
    defaults = {"adjust": ADJUST_NAMES[0], "params": {}}

    @staticmethod
    def run(img, opts, edits):
        """Batch replay (Process Folder) -> (image, warning or None)."""
        return run_adjust(img, opts, edits)

    def __init__(self, host, saved):
        super().__init__(host, saved)
        if self.opts["adjust"] not in TOOLS:
            self.opts["adjust"] = ADJUST_NAMES[0]
        # a restored layer only carries its own adjustment: keep the others' remembered settings
        remembered = (self.app.settings["tools"].get(self.name) or {}).get("params") or {}
        params = copy.deepcopy(remembered) if isinstance(remembered, dict) else {}
        params.update(copy.deepcopy(self.opts.get("params") or {}))
        self.opts["params"] = {k: v for k, v in params.items() if k in TOOLS and isinstance(v, dict)}
        self.x = self.alpha = None      # input as float
        self.hist = None
        self._result = None
        self._job = None
        self.vars = {}
        self.hist_c = self.curve_c = None
        self.curve_drag = None
        self._building = False

    # ---------------- current adjustment ----------------
    @property
    def cur(self):
        return self.opts["adjust"]

    def params(self, name=None):
        name = name or self.cur
        p = tool_defaults(name)
        p.update(self.opts["params"].get(name, {}))
        self.opts["params"][name] = p
        return p

    def active(self):
        """Does the current adjustment change the image?"""
        return self.cur in EFFECTS or not is_default(self.cur, self.params())

    def layer_label(self):
        return f"Adjust: {self.cur}"

    def layer_opts(self):
        return {"adjust": self.cur, "params": {self.cur: copy.deepcopy(self.params())}}

    # ==================================================================
    #  Controls
    # ==================================================================
    def build(self, parent):
        p = ttk.Frame(parent, padding=(S(10), S(8), S(10), S(10)))
        p.pack(fill="both", expand=True)
        head = ttk.Frame(p)
        head.pack(fill="x")
        ttk.Label(head, text="Adjustment", font=HEAD).pack(side="left", padx=(0, S(6)))
        self.v_adj = tk.StringVar(value=self.cur)
        cb = ttk.Combobox(head, textvariable=self.v_adj, values=ADJUST_NAMES, state="readonly",
                          height=len(ADJUST_NAMES), width=20)
        cb.pack(side="left", fill="x", expand=True)
        cb.bind("<<ComboboxSelected>>", lambda e: self._switch())
        row = ttk.Frame(p)
        row.pack(fill="x", pady=(S(6), 0))
        ttk.Button(row, text="Reset adjustment", command=self._reset_current, takefocus=0).pack(side="left")
        self.lab_state = ttk.Label(row, text="", font=SMALL, foreground="#246")
        self.lab_state.pack(side="left", padx=S(8))
        ttk.Separator(p).pack(fill="x", pady=S(8))
        self.panel = ttk.Frame(p)
        self.panel.pack(fill="both", expand=True)
        note(p, "Double-click a slider's name to reset that slider.", pady=(S(8), 0))
        self._build_panel()

    def _build_panel(self):
        for w in self.panel.winfo_children():
            w.destroy()
        self.vars = {}
        self.hist_c = self.curve_c = None
        self._building = True
        name = self.cur
        prm = self.params()
        d = tool_defaults(name)
        f = self.panel
        f.columnconfigure(1, weight=1)
        r = 0
        if name == "Levels":
            self.hist_c = tk.Canvas(f, width=S(300), height=S(90), bg="#fafafa",
                                    highlightthickness=1, highlightbackground="#999")
            self.hist_c.grid(row=r, column=0, columnspan=2, pady=S(4))
            r += 1
        for spec in TOOLS[name][1]:
            kind, key = spec[0], spec[1]
            if kind == "s":
                _, _, label, lo, hi, res, dv = spec
                var = tk.DoubleVar(value=prm[key]) if isinstance(res, float) else tk.IntVar(value=int(prm[key]))
                lab = ttk.Label(f, text=label)
                lab.grid(row=r, column=0, sticky="sw", padx=(0, S(8)), pady=(0, S(2)))
                tk.Scale(f, from_=lo, to=hi, resolution=res, orient="horizontal", variable=var,
                         showvalue=True, highlightthickness=0, length=S(240), sliderlength=S(30),
                         width=S(18), font=SMALL, takefocus=0).grid(row=r, column=1, sticky="ew")
                lab.bind("<Double-Button-1>", lambda e, v=var, dv=dv: v.set(dv))
            elif kind == "c":
                _, _, label, values, dv = spec
                var = tk.StringVar(value=prm[key])
                ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(3))
                c = ttk.Combobox(f, textvariable=var, values=values, state="readonly")
                c.grid(row=r, column=1, sticky="ew", pady=S(3))
            elif kind == "b":
                _, _, label, dv = spec
                var = tk.BooleanVar(value=bool(prm[key]))
                ttk.Checkbutton(f, text=label, variable=var, takefocus=0).grid(
                    row=r, column=0, columnspan=2, sticky="w", pady=S(3))
            elif kind == "col":
                _, _, label, dv = spec
                var = tk.StringVar(value=prm[key])
                ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(3))
                btn = tk.Button(f, bg=prm[key], activebackground=prm[key], width=10, relief="raised",
                                takefocus=0)
                btn.configure(command=lambda v=var, b=btn: self._pick_colour(v, b))
                btn.grid(row=r, column=1, sticky="w", pady=S(3))
            elif kind == "curve":
                if not isinstance(prm.get(key), list) or len(prm[key]) < 2:
                    prm[key] = [list(pt) for pt in d[key]]
                self.curve_c = tk.Canvas(f, width=S(300), height=S(300), bg="#fafafa",
                                         highlightthickness=1, highlightbackground="#999")
                self.curve_c.grid(row=r, column=0, columnspan=2, pady=S(6))
                self.curve_c.bind("<ButtonPress-1>", self._curve_press)
                self.curve_c.bind("<B1-Motion>", self._curve_move)
                self.curve_c.bind("<ButtonRelease-1>", lambda e: setattr(self, "curve_drag", None))
                self.curve_c.bind("<Button-3>", self._curve_delete)
                r += 1
                ttk.Label(f, text="Click to add a point, drag to move, right-click to delete.",
                          foreground="#666", font=SMALL).grid(row=r, column=0, columnspan=2, sticky="w")
                r += 1
                continue
            self.vars[key] = var
            var.trace_add("write", lambda *a, k=key: self._var_changed(k))
            r += 1
        self._building = False
        self._draw_graphs()
        self._update_state()

    def _pick_colour(self, var, btn):
        res = colorchooser.askcolor(color=var.get(), parent=self.host.win)
        if res and res[1]:
            var.set(res[1])
            btn.configure(bg=res[1], activebackground=res[1])

    def _var_changed(self, key):
        if self._building:
            return
        try:
            v = self.vars[key].get()
        except tk.TclError:
            return
        self.params()[key] = v
        self._draw_graphs()
        self._schedule()

    def sync_widgets(self):
        self.v_adj.set(self.cur)
        self._build_panel()

    def on_reset(self):
        self._schedule(now=True)

    def _reset_current(self):
        self.opts["params"][self.cur] = tool_defaults(self.cur)
        self._build_panel()
        self._schedule(now=True)
        self.app.status.set_message(f"Adjust: {self.cur} reset to defaults.")

    # ---------------- switching adjustments ----------------
    def _switch(self):
        new = self.v_adj.get()
        if new == self.cur:
            return
        self.flush()
        if self.result() is not None:
            choice = ask_apply(self.host.win, self.layer_label())
            if choice == "cancel":
                self.v_adj.set(self.cur)
                return
            if choice == "apply":
                self.host.apply_continue()
        self.opts["adjust"] = new
        self._build_panel()
        self._schedule(now=True)

    # ==================================================================
    #  Processing
    # ==================================================================
    def set_input(self, img):
        super().set_input(img)
        if img is None:
            self.x = self.alpha = self.hist = None
        else:
            self.x, self.alpha = image_to_float(img)
            self.hist = histograms(img)
        if hasattr(self, "panel"):
            self._draw_graphs()
        self._schedule(now=True)

    def _schedule(self, now=False):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if now:
            self._compute()
        else:
            self._job = self.app.root.after(50, self._compute)

    def flush(self):
        if self._job is not None:
            self._compute()

    def _compute(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if self.x is None or not self.active():
            self._result = None
        else:
            self._result = float_to_image(apply_adjust(self.x, self.cur, self.params()), self.alpha)
        self._update_state()
        self.changed()

    def result(self):
        return self._result if self.input is not None else None

    def display(self):
        return self._result if self._result is not None else self.input

    def _update_state(self):
        if hasattr(self, "lab_state"):
            self.lab_state.configure(text="changing the image" if self.active() else "no change yet")

    def close(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None

    # ==================================================================
    #  Histogram / curve
    # ==================================================================
    def _hist(self):
        if self.hist is None:
            return None
        ch = self.params().get("channel", "RGB")
        return self.hist[HIST_INDEX.get(ch, 0)]

    def _draw_hist(self, c, w, h, colour):
        hist = self._hist()
        if hist is None:
            return
        m = max(1.0, float(np.percentile(hist, 99.5)))
        for i in range(256):
            v = min(1.0, hist[i] / m)
            x = i * w / 256.0
            c.create_rectangle(x, h - v * h, x + w / 256.0 + 1, h, fill=colour, outline="")

    def _draw_graphs(self):
        if self.hist_c is not None:
            c = self.hist_c
            c.delete("all")
            w, h = int(c.cget("width")), int(c.cget("height"))
            self._draw_hist(c, w, h, "#888")
            p = self.params()
            for key in ("in_black", "in_white"):
                if key in p:
                    x = p[key] * w / 255.0
                    c.create_line(x, 0, x, h, fill="#c00", width=S(1))
        if self.curve_c is not None:
            c = self.curve_c
            c.delete("all")
            n = int(c.cget("width"))
            self._draw_hist(c, n, n, "#ddd")
            for i in range(1, 4):
                c.create_line(i * n / 4, 0, i * n / 4, n, fill="#ccc")
                c.create_line(0, i * n / 4, n, i * n / 4, fill="#ccc")
            c.create_line(0, n, n, 0, fill="#bbb", dash=(3, 3))
            pts = self.params()["points"]
            lut = monotone_lut(pts, 256)
            coords = []
            for i in range(256):
                coords += [i * n / 255.0, n - lut[i] * n]
            c.create_line(*coords, fill="#222", width=S(2))
            r = S(5)
            for px, py in pts:
                X, Y = px * n, n - py * n
                c.create_oval(X - r, Y - r, X + r, Y + r, fill="#fff", outline="#000", width=S(1))

    def _curve_xy(self, e):
        n = int(self.curve_c.cget("width"))
        return min(max(e.x / n, 0.0), 1.0), min(max(1.0 - e.y / n, 0.0), 1.0), n

    def _curve_changed(self):
        self._draw_graphs()
        self._schedule()

    def _curve_press(self, e):
        pts = self.params()["points"]
        x, y, n = self._curve_xy(e)
        tol = S(9) / n
        for i, (px, py) in enumerate(pts):
            if abs(px - x) <= tol and abs(py - y) <= tol:
                self.curve_drag = i
                return
        pts.append([x, y])
        pts.sort(key=lambda pt: pt[0])
        self.curve_drag = next(i for i, pt in enumerate(pts) if pt[0] == x and pt[1] == y)
        self._curve_changed()

    def _curve_move(self, e):
        if self.curve_drag is None:
            return
        pts = self.params()["points"]
        x, y, n = self._curve_xy(e)
        i = self.curve_drag
        eps = 1.0 / 255.0
        lo = pts[i - 1][0] + eps if i > 0 else 0.0
        hi = pts[i + 1][0] - eps if i < len(pts) - 1 else 1.0
        pts[i] = [min(max(x, lo), hi), y]
        self._curve_changed()

    def _curve_delete(self, e):
        pts = self.params()["points"]
        if len(pts) <= 2:
            return
        x, y, n = self._curve_xy(e)
        tol = S(9) / n
        for i, (px, py) in enumerate(pts):
            if abs(px - x) <= tol and abs(py - y) <= tol:
                del pts[i]
                self._curve_changed()
                return
