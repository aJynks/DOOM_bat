"""png2pixel - Rebuild.

Turns every grid cell into one pixel of that cell's colour: a 1024 x 768 image
with 16 px cells becomes 64 x 48. Each pixel is the cell's most common colour
(straight after Force Grid every cell is flat anyway; after e.g. Sharpen the
most common colour is still a real colour from the cell, not an invented
average). Partial cells at the edges become pixels too, so the result matches
Force Grid's rebuild size. A cell that is mostly transparent becomes a
transparent pixel.

The grid is filled in from the nearest Force Grid layer in the snapshot stack
when the tool opens ("From Force Grid" copies it again); otherwise it uses its
own remembered settings. Show result off = the image underneath with the grid
drawn over it, to check it lines up.
"""
import tkinter as tk
from tkinter import ttk

import numpy as np
from PIL import Image

from ..lib_const import S, SMALL, GRID_LINE
from ..lib_widgets import section, note
from .tool_base import Tool
from .tool_gridui import GridControls
from .tool_force_grid_engine import GridEngine, rank_colours

GRID_KEYS = ("cell_w", "cell_h", "shape", "off_x", "off_y")


def rebuild_image(img, opts):
    """-> (small image, (ncols, nrows))"""
    eng = GridEngine(img)
    eng.build_grid(opts)
    g = eng.geo
    n, cmap = g["n"], g["map"]
    mask = eng.opaque if eng.opaque is not None else np.ones(cmap.shape, bool)
    cols, cnt = rank_colours(eng.rgb, cmap, n, mask, 0, ranks=1)
    rgb = cols[:, 0].reshape(g["nrows"], g["ncols"], 3)
    if eng.opaque is not None:
        total = np.bincount(cmap.ravel(), minlength=n)
        op = np.bincount(cmap[eng.opaque], minlength=n)
        alpha = np.where((op * 2 < total) | (cnt[:, 0] == 0), 0, 255).astype(np.uint8)
        out = Image.fromarray(np.concatenate([rgb, alpha.reshape(g["nrows"], g["ncols"], 1)], axis=2), "RGBA")
    else:
        out = Image.fromarray(rgb, "RGB")
    return out, (g["ncols"], g["nrows"]), eng


def run_rebuild(img, opts, edits):
    """Headless Rebuild for batch replay -> (image, warning or None)."""
    out, _size, _eng = rebuild_image(img, opts)
    return out, None


class Rebuild(Tool):
    name = "Rebuild"
    hint = "Rebuild: every cell becomes one pixel. The grid comes from the last Force Grid layer."
    defaults = {
        "cell_w": 8.0, "cell_h": 8.0, "shape": "raw", "off_x": 0.0, "off_y": 0.0,
        "show_grid": True, "show_result": True,
    }

    @staticmethod
    def run(img, opts, edits):
        return run_rebuild(img, opts, edits)

    def __init__(self, host, saved):
        super().__init__(host, saved)
        self._result = None
        self._eng = None
        self._job = None
        self._source = ""

    # ==================================================================
    #  Controls
    # ==================================================================
    def build(self, parent):
        if self.restored:
            self._source = "Grid from the deleted Rebuild layer"
        else:
            self._copy_force_grid()
        o = self.opts
        p = ttk.Frame(parent, padding=(S(10), 0, S(10), S(10)))
        p.pack(fill="both", expand=True)
        section(p, "Grid")
        self.lab_src = ttk.Label(p, text="", font=SMALL, foreground="#2a6")
        self.lab_src.pack(anchor="w", pady=(0, S(4)))
        self.grid = GridControls(p, self, self._grid_changed)
        ttk.Button(p, text="From Force Grid", command=self._from_fg_button, takefocus=0).pack(anchor="w", pady=(S(8), 0))
        note(p, "Each cell becomes one pixel of its most common colour. Type a Raw or Doom size to set the "
                "cells (offset goes to 0); Doom Size gives a squashed result that stretches back in Doom.",
             pady=(S(6), 0))

        section(p, "View")
        self.v_res = tk.BooleanVar(value=o["show_result"])
        self.v_grid = tk.BooleanVar(value=o["show_grid"])
        ttk.Checkbutton(p, text="Show result (off = the image underneath, with the grid)", variable=self.v_res,
                        takefocus=0, command=lambda: self._view("show_result", self.v_res)).pack(anchor="w")
        ttk.Checkbutton(p, text="Show grid lines (when the result is off)", variable=self.v_grid,
                        takefocus=0, command=lambda: self._view("show_grid", self.v_grid)).pack(anchor="w")
        self._update_labels()

    def sync_widgets(self):
        o = self.opts
        self.grid.sync()
        self.v_res.set(o["show_result"])
        self.v_grid.set(o["show_grid"])

    def on_reset(self):
        self._source = "defaults"
        self._schedule(now=True)

    # ---------------- grid source ----------------
    def _copy_force_grid(self):
        """Copy the grid from the nearest Force Grid layer. -> True if found"""
        layers = self.app.stack.layers
        for i in range(len(layers) - 1, -1, -1):
            ly = layers[i]
            if ly.tool == "Force Grid":
                for k in GRID_KEYS:
                    if k in ly.opts:
                        self.opts[k] = type(self.defaults[k])(ly.opts[k])
                self._source = f"Grid from layer {i + 2} (Force Grid)"
                return True
        self._source = "No Force Grid layer: using the last settings"
        return False

    def _from_fg_button(self):
        if self._copy_force_grid():
            self.sync_widgets()
            self._schedule(now=True)
        else:
            self._update_labels()
            self.app.status.set_message("Rebuild: there is no Force Grid layer in the stack.")

    # ---------------- option changes ----------------
    def _grid_changed(self):
        self._source = "Grid edited"
        self._schedule()

    def _view(self, key, var):
        self.opts[key] = var.get()
        self.changed()

    # ==================================================================
    #  Processing
    # ==================================================================
    def set_input(self, img):
        super().set_input(img)
        self._schedule(now=True)

    def _schedule(self, now=False):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if now:
            self._compute()
        else:
            self._job = self.app.root.after(40, self._compute)

    def flush(self):
        if self._job is not None:
            self._compute()

    def _compute(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if self.input is None:
            self._result = self._eng = None
        else:
            self._result, _size, self._eng = rebuild_image(self.input, self.opts)
        self._update_labels()
        self.changed()

    def result(self):
        return self._result if self.input is not None else None

    def display(self):
        if self.opts["show_result"] and self._result is not None:
            return self._result
        return self.input

    def _update_labels(self):
        if not hasattr(self, "lab_src"):
            return
        self.lab_src.configure(text=self._source)
        self.grid.update_sizes()

    def close(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None

    # ==================================================================
    #  Grid overlay (only over the image underneath)
    # ==================================================================
    def overlay(self, canvas, x0, y0, k, cw, ch):
        if self.opts["show_result"] or not self.opts["show_grid"]:
            return
        eng = self._eng
        if eng is None or eng.geo is None or min(self.opts["cell_w"], self.opts["cell_h"]) * k < 4:
            return
        g = eng.geo
        h, w = eng.rgb.shape[:2]
        top, bot = max(0.0, y0), min(float(ch), y0 + h * k)
        left, right = max(0.0, x0), min(float(cw), x0 + w * k)
        if bot <= top or right <= left:
            return
        xs = x0 + g["bx"] * k
        for x in xs[(xs >= 0) & (xs <= cw)]:
            canvas.create_line(x, top, x, bot, fill=GRID_LINE, width=1)
        ys = y0 + g["by"] * k
        for y in ys[(ys >= 0) & (ys <= ch)]:
            canvas.create_line(left, y, right, y, fill=GRID_LINE, width=1)
