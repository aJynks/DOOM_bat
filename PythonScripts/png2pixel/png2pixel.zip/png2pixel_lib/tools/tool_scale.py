"""png2pixel - Scale: a normal downscale of the image to another size.

    Scale %, Keep aspect
    [x] Raw Size    W x H      the plain scaled size
    [ ] Doom Size   W x H      the same width, height / 1.2: squashed so it
                               stretches back to shape in Doom
Typing into any box updates the others; the ticked size is what the preview
shows and Apply bakes in. Method and options: see tool_scale_engine.

Process Folder: with Keep aspect the width is kept and the height follows each
image's shape; without it the exact size is used.
"""
import tkinter as tk
from tkinter import ttk

from ..lib_const import S, SMALL
from ..lib_widgets import NumberBox, section, note
from .tool_base import Tool
from .tool_scale_engine import DEFAULTS as SCALE_DEFAULTS, scale_image, doom_height
from .tool_scaleui import ScalePanel


def target_size(img_size, opts):
    """(w, h) the Scale tool makes for an image of img_size."""
    iw, ih = img_size
    w = max(1, int(opts["width"]))
    if opts["keep"]:
        h = max(1, int(round(w * ih / float(iw))))
    else:
        h = max(1, int(opts["height"]))
    return (w, doom_height(h)) if opts["shape"] == "doom" else (w, h)


def run_scale(img, opts, edits):
    return scale_image(img, target_size(img.size, opts), opts), None


class Scale(Tool):
    name = "Scale"
    hint = "Scale: downscale to an exact size; Doom Size squashes it for Doom's tall pixels."
    defaults = dict(SCALE_DEFAULTS, width=320, height=240, keep=True, shape="raw", show_result=True)

    @staticmethod
    def run(img, opts, edits):
        return run_scale(img, opts, edits)

    def __init__(self, host, saved):
        super().__init__(host, saved)
        self._result = None
        self._job = None
        self._quiet = False

    def layer_label(self):
        if self._result is not None:
            w, h = self._result.size
            return f"Scale {w}x{h}" + (" (Doom)" if self.opts["shape"] == "doom" else "")
        return self.name

    # ==================================================================
    #  Controls
    # ==================================================================
    def build(self, parent):
        o = self.opts
        p = ttk.Frame(parent, padding=(S(10), 0, S(10), S(10)))
        p.pack(fill="both", expand=True)
        section(p, "Size")
        self.lab_src = ttk.Label(p, text="", font=SMALL, foreground="#555")
        self.lab_src.pack(anchor="w")
        row = ttk.Frame(p)
        row.pack(fill="x", pady=S(3))
        ttk.Label(row, text="Scale %").pack(side="left", padx=(0, S(6)))
        self.box_pct = NumberBox(row, 25, 0.1, 100, step=1, decimals=2, width=7, on_change=self._pct)
        self.box_pct.pack(side="left")
        self.v_keep = tk.BooleanVar(value=o["keep"])
        ttk.Checkbutton(row, text="Keep aspect", variable=self.v_keep, takefocus=0,
                        command=self._keep).pack(side="left", padx=S(12))
        sz = ttk.Frame(p)
        sz.pack(fill="x", pady=(S(4), 0))
        self.v_raw = tk.BooleanVar(value=o["shape"] == "raw")
        self.v_doom = tk.BooleanVar(value=o["shape"] == "doom")
        self.boxes = {}
        for r, (key, label, var) in enumerate((("raw", "Raw Size", self.v_raw), ("doom", "Doom Size", self.v_doom))):
            ttk.Checkbutton(sz, text=label, variable=var, takefocus=0,
                            command=lambda k=key: self._ticked(k)).grid(row=r, column=0, sticky="w", pady=S(2))
            bw = NumberBox(sz, 1, 1, 16384, step=1, decimals=0, width=6, on_change=lambda v, k=key: self._typed(k, "w", v))
            bw.grid(row=r, column=1, padx=(S(8), 0))
            ttk.Label(sz, text=" x ").grid(row=r, column=2)
            bh = NumberBox(sz, 1, 1, 16384, step=1, decimals=0, width=6, on_change=lambda v, k=key: self._typed(k, "h", v))
            bh.grid(row=r, column=3)
            self.boxes[key] = (bw, bh)
        note(p, "Doom Size keeps the width and divides the height by 1.2, so it stretches back to shape in Doom.",
             pady=(S(4), 0))
        row = ttk.Frame(p)
        row.pack(fill="x", pady=(S(6), 0))
        ttk.Label(row, text="Title screen").pack(side="left", padx=(0, S(6)))
        for w in (320, 426, 560):
            ttk.Button(row, text=f"{w} x 200", takefocus=0,
                       command=lambda w=w: self._preset(w, 200)).pack(side="left", padx=S(2))

        section(p, "Method")
        self.panel = ScalePanel(p, self, self._schedule)

        section(p, "View")
        self.v_res = tk.BooleanVar(value=o["show_result"])
        ttk.Checkbutton(p, text="Show result (off = the image before scaling)", variable=self.v_res, takefocus=0,
                        command=self._view).pack(anchor="w")
        self._sync_size()

    def sync_widgets(self):
        self.v_keep.set(self.opts["keep"])
        self.v_res.set(self.opts["show_result"])
        self.panel.sync()
        self._sync_size()

    def on_reset(self):
        self._schedule(now=True)

    # ---------------- size ----------------
    def _img(self):
        return self.input.size if self.input is not None else None

    def _sync_size(self):
        """Put width / height / % / both sizes into the boxes (not the one being typed in)."""
        o = self.opts
        self.v_raw.set(o["shape"] == "raw")
        self.v_doom.set(o["shape"] == "doom")
        size = self._img()
        if size is None:
            self.lab_src.configure(text="")
            return
        iw, ih = size
        if o["keep"]:
            o["height"] = max(1, int(round(o["width"] * ih / float(iw))))
        foc = self.app.focus_name()
        vals = {("raw", "w"): o["width"], ("raw", "h"): o["height"],
                ("doom", "w"): o["width"], ("doom", "h"): doom_height(o["height"])}
        for (key, axis), v in vals.items():
            box = self.boxes[key][0 if axis == "w" else 1]
            if foc != str(box):
                box.set(v)
        if foc != str(self.box_pct):
            self.box_pct.set(100.0 * o["width"] / iw)
        self.lab_src.configure(text=f"Image {iw} x {ih}")

    def _size_changed(self):
        self._sync_size()
        self._schedule()

    def _pct(self, v):
        size = self._img()
        if size is None:
            return
        self.opts["width"] = max(1, int(round(size[0] * v / 100.0)))
        if not self.opts["keep"]:
            self.opts["height"] = max(1, int(round(size[1] * v / 100.0)))
        self._size_changed()

    def _keep(self):
        self.opts["keep"] = self.v_keep.get()
        self._size_changed()

    def _ticked(self, key):
        on = (self.v_raw if key == "raw" else self.v_doom).get()
        if not on:                      # one is always ticked here: re-tick
            (self.v_raw if key == "raw" else self.v_doom).set(True)
            return
        self.opts["shape"] = key
        self._size_changed()

    def _typed(self, key, axis, v):
        size = self._img()
        if size is None or v < 1:
            return
        iw, ih = size
        o = self.opts
        v = int(v)
        if axis == "w":
            o["width"] = v
        else:
            raw_h = int(round(v * 1.2)) if key == "doom" else v
            if o["keep"]:
                o["width"] = max(1, int(round(raw_h * iw / float(ih))))
            o["height"] = raw_h
        o["shape"] = key
        self._size_changed()

    def _preset(self, w, h):
        """Title screen preset: exactly w x h (Raw Size, Keep aspect off)."""
        o = self.opts
        o["keep"], o["width"], o["height"], o["shape"] = False, int(w), int(h), "raw"
        self.v_keep.set(False)
        self._size_changed()
        self.app.status.set_message(f"Scale: {w} x {h} title screen size.")

    def _view(self):
        self.opts["show_result"] = self.v_res.get()
        self.changed()

    # ==================================================================
    #  Processing
    # ==================================================================
    def set_input(self, img):
        super().set_input(img)
        if hasattr(self, "boxes"):
            self._sync_size()
        self._schedule(now=True)

    def _schedule(self, now=False):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if now:
            self._compute()
        else:
            self._job = self.app.root.after(80, self._compute)

    def flush(self):
        if self._job is not None:
            self._compute()

    def _compute(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if self.input is None:
            self._result = None
        else:
            self.app.root.config(cursor="watch")
            try:
                self._result = scale_image(self.input, target_size(self.input.size, self.opts), self.opts)
            finally:
                self.app.root.config(cursor="")
        self.changed()

    def result(self):
        return self._result if self.input is not None else None

    def display(self):
        if self.opts["show_result"] and self._result is not None:
            return self._result
        return self.input

    def close(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
