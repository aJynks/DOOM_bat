"""png2pixel - grid controls shared by Force Grid and Rebuild.

    Cell width / height, Offset X / Y
    [x] Raw Size    W x H      square cells
    [ ] Doom Size   W x H      cells 1.2x taller than wide: the rebuild comes out
                               squashed and stretches back to shape in Doom

Both sizes always show (from the cell width), and update live. Typing into
either sets the cells (offset goes to 0) and ticks it. Ticking one unticks the
other; the ticked one decides the cell height, so it is what the preview shows
and what Apply bakes in. A cell height typed by hand that matches neither
unticks both (a free grid); "Result" always shows the real rebuild size.

Tool options used: cell_w, cell_h, off_x, off_y, shape ("raw" / "doom" / "free").
"""
import math
import tkinter as tk
from tkinter import ttk

from ..lib_const import S, SMALL
from ..lib_widgets import NumberBox

DOOM = 1.2
SHAPES = ("raw", "doom", "free")


def count_cells(n, size, off):
    """How many grid cells cover n pixels (partial edge cells count)."""
    size = float(size)
    off = float(off) % size
    return int(math.floor((n - 0.5 - off) / size) - math.floor((0.5 - off) / size) + 1)


class GridControls:
    def __init__(self, parent, tool, on_change):
        self.tool = tool
        self.on_change = on_change
        o = tool.opts
        if o.get("shape") not in SHAPES:
            o["shape"] = "raw"
        g = ttk.Frame(parent)
        g.pack(fill="x")
        self.frame = g

        def lab(text, r):
            ttk.Label(g, text=text).grid(row=r, column=0, sticky="w", pady=S(2), padx=(0, S(6)))
        lab("Cell width", 0)
        self.box_w = NumberBox(g, o["cell_w"], 1, 4096, step=1, decimals=3, on_change=self._cell_w)
        self.box_w.grid(row=0, column=1, sticky="w")
        lab("Cell height", 1)
        self.box_h = NumberBox(g, o["cell_h"], 1, 4096, step=1, decimals=3, on_change=self._cell_h)
        self.box_h.grid(row=1, column=1, sticky="w")
        lab("Offset X", 2)
        self.box_x = NumberBox(g, o["off_x"], 0, 4096, step=1, decimals=3, on_change=lambda v: self._set({"off_x": v}))
        self.box_x.grid(row=2, column=1, sticky="w")
        lab("Offset Y", 3)
        self.box_y = NumberBox(g, o["off_y"], 0, 4096, step=1, decimals=3, on_change=lambda v: self._set({"off_y": v}))
        self.box_y.grid(row=3, column=1, sticky="w")

        sz = ttk.Frame(parent)
        sz.pack(fill="x", pady=(S(6), 0))
        self.v_raw = tk.BooleanVar(value=o["shape"] == "raw")
        self.v_doom = tk.BooleanVar(value=o["shape"] == "doom")
        self.boxes = {}
        for r, (key, label, var) in enumerate((("raw", "Raw Size", self.v_raw), ("doom", "Doom Size", self.v_doom))):
            ttk.Checkbutton(sz, text=label, variable=var, takefocus=0,
                            command=lambda k=key: self._ticked(k)).grid(row=r, column=0, sticky="w", pady=S(2))
            bw = NumberBox(sz, 1, 1, 8192, step=1, decimals=0, width=6,
                           on_change=lambda v, k=key: self._typed(k, "w", v))
            bw.grid(row=r, column=1, padx=(S(8), 0))
            ttk.Label(sz, text=" x ").grid(row=r, column=2)
            bh = NumberBox(sz, 1, 1, 8192, step=1, decimals=0, width=6,
                           on_change=lambda v, k=key: self._typed(k, "h", v))
            bh.grid(row=r, column=3)
            self.boxes[key] = (bw, bh)
        self.lab_result = ttk.Label(parent, text="", font=SMALL)
        self.lab_result.pack(anchor="w", pady=(S(4), 0))

    # ---------------- helpers ----------------
    def _img(self):
        img = self.tool.input
        return img.size if img is not None else None

    def _set(self, changes):
        o = self.tool.opts
        changed = False
        for k, v in changes.items():
            if o.get(k) != v:
                o[k] = v
                changed = True
        if changed:
            self.on_change()

    def _set_shape(self, shape):
        self.tool.opts["shape"] = shape
        self.v_raw.set(shape == "raw")
        self.v_doom.set(shape == "doom")

    # ---------------- edits ----------------
    def _cell_w(self, v):
        shape = self.tool.opts["shape"]
        ch = v if shape == "raw" else v * DOOM if shape == "doom" else self.tool.opts["cell_h"]
        if shape in ("raw", "doom"):
            self.box_h.set(ch)
        self._set({"cell_w": v, "cell_h": ch})

    def _cell_h(self, v):
        cw = self.tool.opts["cell_w"]
        if abs(v - cw) < 1e-6:
            shape = "raw"
        elif abs(v - cw * DOOM) < 1e-3:
            shape = "doom"
        else:
            shape = "free"
        self._set_shape(shape)
        self._set({"cell_h": v})

    def _ticked(self, key):
        on = (self.v_raw if key == "raw" else self.v_doom).get()
        if not on:
            self._set_shape("free")
            self.update_sizes()
            return
        self._set_shape(key)
        cw = self.tool.opts["cell_w"]
        ch = cw if key == "raw" else cw * DOOM
        self.box_h.set(ch)
        self._set({"cell_h": ch})

    def _typed(self, key, axis, v):
        size = self._img()
        if size is None or v < 1:
            return
        w, h = size
        if axis == "w":
            cw = w / float(int(v))
        else:
            cw = h / float(int(v)) / (DOOM if key == "doom" else 1.0)
        ch = cw * DOOM if key == "doom" else cw
        self._set_shape(key)
        self.box_w.set(cw)
        self.box_h.set(ch)
        self.box_x.set(0)
        self.box_y.set(0)
        self._set({"cell_w": cw, "cell_h": ch, "off_x": 0.0, "off_y": 0.0})

    # ---------------- display ----------------
    def sync(self):
        o = self.tool.opts
        if o.get("shape") not in SHAPES:
            o["shape"] = "raw"
        self.box_w.set(o["cell_w"])
        self.box_h.set(o["cell_h"])
        self.box_x.set(o["off_x"])
        self.box_y.set(o["off_y"])
        self._set_shape(o["shape"])
        self.update_sizes()

    def update_sizes(self):
        size = self._img()
        if size is None:
            self.lab_result.configure(text="")
            return
        w, h = size
        o = self.tool.opts
        foc = self.tool.app.focus_name()
        cols = count_cells(w, o["cell_w"], o["off_x"])
        rows = {"raw": count_cells(h, o["cell_w"], o["off_y"]),
                "doom": count_cells(h, o["cell_w"] * DOOM, o["off_y"])}
        for key, (bw, bh) in self.boxes.items():
            if foc != str(bw):
                bw.set(cols)
            if foc != str(bh):
                bh.set(rows[key])
        real = (cols, count_cells(h, o["cell_h"], o["off_y"]))
        tag = {"raw": "Raw", "doom": "Doom", "free": "free grid"}[o["shape"]]
        self.lab_result.configure(text=f"Result: {real[0]} x {real[1]}  ({tag})   {real[0] * real[1]:,} cells")
