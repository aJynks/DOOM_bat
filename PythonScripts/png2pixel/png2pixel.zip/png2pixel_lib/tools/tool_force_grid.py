"""png2pixel - Force Grid (the tool window; the image work is in tool_force_grid_engine).

Set a grid and every cell is redrawn as one solid colour, at the image's full
size. Nothing is shrunk: the rebuild size (one pixel per cell) is shown, and can
be typed in to set the grid.

Automatic colour per cell
    Each cell's original pixels are grouped (Colour grouping: near-identical
    colours counted together) and ranked by how much of the cell they cover.
    The cell takes the top group's average colour. Sample area lets only the
    middle of each cell vote, so blurry block edges don't.

Editing cells (all edits give flat single colours)
    Select cells in the view: click one, drag a rectangle, Shift adds,
    Ctrl removes. "Apply edits to" chooses Selection or Whole image.

Grid: Raw Size (square cells) or Doom Size (cells 1.2x taller, so a Rebuild
comes out squashed and stretches back to shape in Doom); see tool_gridui.

    Colour list (flat cell colours)
        In selection  the colours of the selected cells. Click one to narrow
                      the edits to cells of that colour (Ctrl-click for
                      several). With Whole image, matching cells anywhere.
        Adjacent      the colours of the cells around the selection; click one
                      to paint the targets with it.
        Merge similar groups near-identical colours into one swatch.

    Edits on the target cells
        Pick offset   0 = each cell's top colour group, 1 = its 2nd, 2 = 3rd ...
        Adjustments   hue / saturation / lightness / contrast, live preview;
                      "Apply to cells" bakes them in and zeroes the sliders.
                      Pending adjustments are baked when the targets change
                      and when the tool is applied.
        Colour        the picker (any style), hex box, Pick from view.
        Auto          back to the automatic colour.

Every edit is recorded as an operation on a set of cells, so the snapshot stack
can replay it on other images with the same grid (Process Folder).
Changing the grid clears every edit and the selection (they no longer line up).
"""
import tkinter as tk
from tkinter import ttk

import numpy as np

from ..lib_const import S, SMALL, GRID_LINE, GRID_SEL
from ..lib_colour import rgb255_to_hex
from ..lib_colourpick import ColourPicker, MODES
from ..lib_widgets import section, note
from .tool_base import Tool
from .tool_gridui import GridControls
from .tool_force_grid_engine import (
    GridEngine, MAX_RANK, colour_keys, group_list, mask_to_runs, run_force_grid)

MAX_LIST = 400              # swatches drawn in the colour list
TARGET_LINE = "#ff3cdc"     # outline of colour-narrowed targets
SCOPES = ["Selection", "Whole image"]
SOURCES = ["In selection", "Adjacent"]
ADJ = (("hue", "Hue", -180, 180), ("sat", "Saturation", -100, 100),
       ("light", "Lightness", -100, 100), ("contrast", "Contrast", -100, 100))


class ForceGrid(Tool):
    name = "Force Grid"
    hint = "Force Grid: set the grid, then select cells (drag, Shift adds, Ctrl removes) to edit them."
    uses_mouse = True
    defaults = {
        "cell_w": 8.0, "cell_h": 8.0, "shape": "raw",
        "off_x": 0.0, "off_y": 0.0,
        "sample": 80, "group": 4,
        "show_grid": True, "show_result": True,
        "scope": SCOPES[0], "source": SOURCES[0], "list_merge": 2,
        "picker": MODES[0],
    }

    @staticmethod
    def run(img, opts, edits):
        """Batch replay (Process Folder) -> (image, warning or None)."""
        return run_force_grid(img, opts, edits)

    def __init__(self, host, saved):
        super().__init__(host, saved)
        self.eng = GridEngine()
        self.ops = []               # recorded cell edit operations
        self.sel = None             # (nrows, ncols) bool
        self.picks = None           # (n,) bool, or None = no colour narrowing
        self.adj = {k: 0 for k, *_ in ADJ}
        self._result = None
        self._need = 0              # 3 = grid, 2 = automatic colours, 1 = final image
        self._job = None
        self._list_job = None
        self._list = []
        self._drag = None

    # shortcuts into the engine
    @property
    def geo(self):
        return self.eng.geo

    @property
    def flat(self):
        return self.eng.flat

    @property
    def trans(self):
        return self.eng.trans

    # ==================================================================
    #  Controls
    # ==================================================================
    def build(self, parent):
        o = self.opts
        p = ttk.Frame(parent, padding=(S(10), 0, S(10), S(10)))
        p.pack(fill="both", expand=True)

        # ---- grid ----
        section(p, "Grid")
        self.grid = GridControls(p, self, lambda: self._schedule(3))
        note(p, "Type a Raw or Doom size to set the cells (offset goes to 0). Doom cells are 1.2x taller, "
                "so a Rebuild comes out squashed for Doom. Force Grid itself keeps the full image size.",
             pady=(S(4), 0))

        # ---- automatic colour ----
        section(p, "Automatic colour")
        self.v_sample = tk.IntVar(value=o["sample"])
        self.v_group = tk.IntVar(value=o["group"])
        self._slider(p, "Sample area", self.v_sample, 20, 100, "%", lambda v: self._set("sample", v, 2))
        self._slider(p, "Colour grouping", self.v_group, 0, 5, "", lambda v: self._set("group", v, 2))
        note(p, "Each cell takes its biggest colour group. Sample area reads only the middle of "
                "each cell; Colour grouping counts near-identical colours together (0 = exact).")

        # ---- view ----
        section(p, "View")
        self.v_grid = tk.BooleanVar(value=o["show_grid"])
        self.v_res = tk.BooleanVar(value=o["show_result"])
        ttk.Checkbutton(p, text="Show grid lines", variable=self.v_grid, takefocus=0,
                        command=lambda: self._set("show_grid", self.v_grid.get(), 0)).pack(anchor="w")
        ttk.Checkbutton(p, text="Show result (off = the image underneath)", variable=self.v_res, takefocus=0,
                        command=lambda: self._set("show_result", self.v_res.get(), 0)).pack(anchor="w")

        # ---- selection ----
        section(p, "Selection")
        note(p, "Click a cell, or drag a rectangle. Shift adds, Ctrl removes.")
        row = ttk.Frame(p)
        row.pack(fill="x", pady=(S(4), S(2)))
        ttk.Button(row, text="Select all", command=self._select_all, takefocus=0).pack(side="left")
        ttk.Button(row, text="Select none", command=self._select_none, takefocus=0).pack(side="left", padx=S(4))
        row = ttk.Frame(p)
        row.pack(fill="x", pady=S(2))
        ttk.Label(row, text="Apply edits to").pack(side="left")
        self.v_scope = tk.StringVar(value=o["scope"])
        cb = ttk.Combobox(row, textvariable=self.v_scope, values=SCOPES, state="readonly", width=12)
        cb.pack(side="left", padx=S(6))
        cb.bind("<<ComboboxSelected>>", lambda e: self._scope_changed())
        self.lab_sel = ttk.Label(p, text="", font=SMALL)
        self.lab_sel.pack(anchor="w", pady=(S(2), 0))

        # ---- colours ----
        section(p, "Colours")
        row = ttk.Frame(p)
        row.pack(fill="x")
        self.v_source = tk.StringVar(value=o["source"])
        for s in SOURCES:
            ttk.Radiobutton(row, text=s, value=s, variable=self.v_source, takefocus=0,
                            command=self._source_changed).pack(side="left", padx=(0, S(10)))
        ttk.Button(row, text="All colours", command=self._clear_picks, takefocus=0).pack(side="right")
        lf = ttk.Frame(p)
        lf.pack(fill="x", pady=(S(4), 0))
        self.list_c = tk.Canvas(lf, height=S(150), highlightthickness=1, highlightbackground="#999", bg="#f4f4f4")
        sb = ttk.Scrollbar(lf, orient="vertical", command=self.list_c.yview)
        self.list_c.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.list_c.pack(side="left", fill="x", expand=True)
        self.list_c.bind("<Button-1>", self._list_click)
        self.v_merge = tk.IntVar(value=o["list_merge"])
        self._slider(p, "Merge similar", self.v_merge, 0, 5, "", lambda v: self._set("list_merge", v, -1))
        self.lab_list = note(p, "")

        # ---- edits ----
        section(p, "Edit targets")
        self.v_offset = tk.IntVar(value=0)
        self._slider(p, "Pick offset", self.v_offset, 0, MAX_RANK - 1, "", self._offset_changed)
        note(p, "0 = each cell's biggest colour group, 1 = its 2nd, 2 = its 3rd ...")
        self.v_adj = {}
        for key, label, lo, hi in ADJ:
            v = tk.IntVar(value=0)
            self.v_adj[key] = v
            self._slider(p, label, v, lo, hi, "", lambda val, k=key: self._adj_changed(k, val))
        row = ttk.Frame(p)
        row.pack(fill="x", pady=(S(4), S(2)))
        ttk.Button(row, text="Apply to cells", command=self._bake, takefocus=0).pack(side="left")
        ttk.Button(row, text="Zero sliders", command=self._zero_adj, takefocus=0).pack(side="left", padx=S(4))
        ttk.Button(row, text="Auto", command=self._auto_targets, takefocus=0).pack(side="right")
        self.lab_manual = ttk.Label(p, text="", font=SMALL)
        self.lab_manual.pack(anchor="w", pady=(0, S(6)))

        self.picker = ColourPicker(p, self._picked, mode=o["picker"], on_mode=lambda m: self._set("picker", m, -1),
                                   on_eyedrop=self._eyedrop)
        self.picker.pack(fill="x", pady=(S(2), 0))

    def _slider(self, parent, label, var, lo, hi, unit, on_change):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=S(2))
        ttk.Label(row, text=label, width=15).pack(side="left")
        val = ttk.Label(row, text=f"{var.get()}{unit}", width=5, anchor="e")

        def moved(_v):
            v = int(round(float(var.get())))
            if var.get() != v:
                var.set(v)
            on_change(v)
        ttk.Scale(row, from_=lo, to=hi, variable=var, command=moved,
                  takefocus=0).pack(side="left", fill="x", expand=True, padx=S(6))
        val.pack(side="left")
        var.trace_add("write", lambda *_: val.configure(text=f"{int(round(float(var.get())))}{unit}"))

    def sync_widgets(self):
        o = self.opts
        self.grid.sync()
        self.v_sample.set(o["sample"])
        self.v_group.set(o["group"])
        self.v_grid.set(o["show_grid"])
        self.v_res.set(o["show_result"])
        self.v_scope.set(o["scope"])
        self.v_source.set(o["source"])
        self.v_merge.set(o["list_merge"])
        if self.picker.mode_var.get() != o["picker"]:
            self.picker.mode_var.set(o["picker"])
            self.picker._build_mode()

    def on_reset(self):
        self._schedule(3)

    # ---------------- option changes ----------------
    def _set(self, key, value, level):
        """level: 3 grid, 2 automatic colours, 1 final, 0 redraw only, -1 controls only"""
        if self.opts.get(key) == value:
            return
        self.opts[key] = value
        if key == "list_merge":
            self._refresh_list()
        elif level >= 1:
            self._schedule(level)
        elif level == 0:
            self.changed()

    # ==================================================================
    #  Input / processing
    # ==================================================================
    def set_input(self, img):
        super().set_input(img)
        if img is None:
            self.eng = GridEngine()
        else:
            self.eng.set_image(img)
        self._schedule(3, now=True)

    def _schedule(self, level, now=False):
        self._need = max(self._need, level)
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if now:
            self._compute()
        else:
            self._job = self.app.root.after(40, self._compute)

    def flush(self):
        """Finish any pending recompute now (before Apply)."""
        if self._job is not None or self._need:
            self._compute()

    def finalize(self):
        """Before Apply: bake pending adjustments so they are recorded."""
        if any(self.adj.values()):
            self._bake()

    def _compute(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        need, self._need = self._need, 0
        eng = self.eng
        if eng.rgb is None:
            self._result = None
            self._update_labels()
            self._refresh_list()
            self.changed()
            return
        if need >= 3 or eng.geo is None:
            had_edits = bool(self.ops)
            eng.build_grid(self.opts)
            self.ops = []
            self.sel = np.zeros((eng.geo["nrows"], eng.geo["ncols"]), bool)
            self.picks = None
            self._zero_adj(refresh=False)
            if had_edits:
                self.app.status.set_message("Force Grid: grid changed, cell edits cleared.")
            need = 2
        if need >= 2:
            eng.auto(self.opts)
            if self.ops:            # automatic colours changed: re-run the edits on top
                eng.offset[:] = 0
                eng.man_has[:] = False
                eng.flatten()
                eng.replay(self.ops)
        eng.flatten()
        self._render()
        self._update_labels()
        self._refresh_list()
        self._targets_changed()
        self.changed()

    def _render(self):
        self._result = self.eng.render(self.adj, self._adj_targets())

    def result(self):
        return self._result if self.input is not None else None

    def display(self):
        if self.opts["show_result"] and self._result is not None:
            return self._result
        return self.input

    # ---------------- snapshot stack ----------------
    def export_edits(self):
        if not self.ops or self.geo is None:
            return {}
        return {"grid": [self.geo["ncols"], self.geo["nrows"]], "ops": [dict(o) for o in self.ops]}

    def import_edits(self, edits):
        """Restore recorded cell edits (a layer deleted from the snapshot stack)."""
        ops = (edits or {}).get("ops", [])
        if not ops or self.geo is None:
            return
        if list(edits.get("grid", [])) != [self.geo["ncols"], self.geo["nrows"]]:
            self.app.status.set_message("Force Grid: recorded cell edits don't fit this grid, skipped.")
            return
        self.ops = [dict(o) for o in ops]
        self.eng.replay(self.ops)
        self._render()
        self._update_labels()
        self._refresh_list()
        self._targets_changed()
        self.changed()

    def _do(self, op, cells, coalesce=False):
        """Apply an edit operation to cells and record it."""
        runs = mask_to_runs(cells)
        op = dict(op, cells=runs)
        self.eng.apply_op(op, cells)
        last = self.ops[-1] if self.ops else None
        if coalesce and last is not None and last["op"] == op["op"] and last["cells"] == runs:
            self.ops[-1] = op       # dragging a picker / slider: keep only the latest value
        else:
            self.ops.append(op)

    # ==================================================================
    #  Targets
    # ==================================================================
    def _scope_mask(self):
        if self.opts["scope"] == SCOPES[1]:
            return np.ones(self.geo["n"], bool)
        return self.sel.ravel().copy()

    def targets(self):
        """(n,) bool: the cells edits apply to."""
        if self.geo is None:
            return None
        if self.picks is not None:
            return self.picks & self._scope_mask()
        return self._scope_mask()

    def _adj_targets(self):
        if not any(self.adj.values()):
            return None
        t = self.targets()
        if t is None:
            return None
        t = t & ~self.trans
        return t if t.any() else None

    def _targets_changed(self):
        """Selection, scope or colour picks changed: refresh the edit controls."""
        t = self.targets()
        if t is None or not t.any():
            self.v_offset.set(0)
            self.picker.set_colour((0, 0, 0), before=None)
        else:
            offs = self.eng.offset[t]
            self.v_offset.set(int(np.bincount(offs.astype(np.int64)).argmax()))
            vis = t & ~self.trans
            if vis.any():
                lst = group_list(self.flat, colour_keys(self.flat, 0), vis)
                dom = lst[0][1]
                self.picker.set_colour(dom, before=dom)
        self._update_labels()

    def _before_target_change(self):
        """Pending adjustments belong to the old targets: bake them first."""
        if any(self.adj.values()):
            self._bake()

    # ==================================================================
    #  Mouse: selecting cells
    # ==================================================================
    def _cell_at(self, u, v):
        return int(self.geo["col"][u]), int(self.geo["row"][v])

    def press(self, u, v, state):
        if self.geo is None:
            return
        self._before_target_change()
        mode = "sub" if state & 0x0004 else "add" if state & 0x0001 else "new"
        c, r = self._cell_at(u, v)
        base = self.sel.copy() if mode != "new" else np.zeros_like(self.sel)
        self._drag = (mode, c, r, base, (c, r))
        self._apply_drag()

    def drag(self, u, v):
        if self._drag is None or self.geo is None:
            return
        mode, c0, r0, base, cur = self._drag
        c, r = self._cell_at(u, v)
        if (c, r) != cur:
            self._drag = (mode, c0, r0, base, (c, r))
            self._apply_drag()

    def release(self, u, v):
        if self._drag is None or self.geo is None:
            return
        self.drag(u, v)
        self._drag = None
        self.picks = None
        self._refresh_list()
        self._targets_changed()
        self.changed()

    def _apply_drag(self):
        mode, c0, r0, base, (c1, r1) = self._drag
        rect = np.zeros_like(base)
        rect[min(r0, r1):max(r0, r1) + 1, min(c0, c1):max(c0, c1) + 1] = True
        if mode == "add":
            self.sel = base | rect
        elif mode == "sub":
            self.sel = base & ~rect
        else:
            self.sel = rect
        self._update_labels()
        self.changed()

    def _select_all(self):
        if self.geo is not None:
            self._before_target_change()
            self.sel[:] = True
            self.picks = None
            self._refresh_list()
            self._targets_changed()
            self.changed()

    def _select_none(self):
        if self.geo is not None:
            self._before_target_change()
            self.sel[:] = False
            self.picks = None
            self._refresh_list()
            self._targets_changed()
            self.changed()

    def _scope_changed(self):
        self._before_target_change()
        self.opts["scope"] = self.v_scope.get()
        self.picks = None
        if self.geo is not None:
            self._refresh_list()
            self._targets_changed()
            self.changed()

    # ==================================================================
    #  Colour list
    # ==================================================================
    def _source_changed(self):
        self.opts["source"] = self.v_source.get()
        self._refresh_list()

    def _clear_picks(self):
        if self.picks is not None:
            self._before_target_change()
            self.picks = None
            self._refresh_list()
            self._targets_changed()
            self.changed()

    def _refresh_list_soon(self):
        if self._list_job is None:
            self._list_job = self.app.root.after(150, self._refresh_list)

    def _refresh_list(self):
        if self._list_job is not None:
            self.app.root.after_cancel(self._list_job)
            self._list_job = None
        lc = self.list_c
        lc.delete("all")
        self._list = []
        if self.geo is None or self.flat is None:
            self.lab_list.configure(text="")
            lc.configure(scrollregion=(0, 0, 0, 0))
            return
        q = int(self.opts["list_merge"])
        keys = colour_keys(self.flat, q)
        adjacent = self.opts["source"] == SOURCES[1]
        if adjacent:
            s = self.sel
            pad = np.pad(s, 1)
            grow = np.zeros_like(s)
            for dy in (0, 1, 2):
                for dx in (0, 1, 2):
                    grow |= pad[dy:dy + s.shape[0], dx:dx + s.shape[1]]
            mask = (grow & ~s).ravel() & ~self.trans
        else:
            mask = self.sel.ravel() & ~self.trans
        self._list = group_list(self.flat, keys, mask)
        scope = self._scope_mask() & ~self.trans
        rh, sw = S(20), S(30)
        for i, (key, col, cnt) in enumerate(self._list[:MAX_LIST]):
            y = i * rh
            hx = rgb255_to_hex(col)
            picked = False
            if not adjacent and self.picks is not None:
                cells = (keys == key) & scope
                picked = bool(cells.any() and self.picks[cells].all())
            if picked:
                lc.create_rectangle(1, y + 1, S(1000), y + rh - 1, fill="#cfe3f7", width=0)
            lc.create_rectangle(S(4), y + S(3), S(4) + sw, y + rh - S(3), fill=hx, outline="#444")
            lc.create_text(S(10) + sw, y + rh // 2, anchor="w", font=SMALL,
                           text=f"{hx}    {cnt} cell{'s' if cnt != 1 else ''}")
        if len(self._list) > MAX_LIST:
            lc.create_text(S(10), MAX_LIST * rh + rh // 2, anchor="w", font=SMALL, fill="#666",
                           text=f"... {len(self._list) - MAX_LIST} more (raise Merge similar)")
        n = min(len(self._list), MAX_LIST) + (1 if len(self._list) > MAX_LIST else 0)
        lc.configure(scrollregion=(0, 0, S(300), n * rh))
        if not self.sel.any():
            txt = "Select cells to list their colours."
        elif adjacent:
            txt = "Click a colour to paint the targets with it."
        else:
            txt = "Click a colour to edit only cells of that colour (Ctrl-click: several)."
        self.lab_list.configure(text=txt)

    def _list_click(self, e):
        i = int(self.list_c.canvasy(e.y) // S(20))
        if not (0 <= i < min(len(self._list), MAX_LIST)) or self.geo is None:
            return
        key, col, _cnt = self._list[i]
        if self.opts["source"] == SOURCES[1]:
            self._set_colour(col)
            return
        self._before_target_change()
        keys = colour_keys(self.flat, int(self.opts["list_merge"]))
        cells = (keys == key) & self._scope_mask() & ~self.trans
        ctrl = bool(e.state & 0x0004)
        if ctrl and self.picks is not None:
            if self.picks[cells].all():
                self.picks = self.picks & ~cells
            else:
                self.picks = self.picks | cells
            if not self.picks.any():
                self.picks = None
        elif self.picks is not None and np.array_equal(self.picks, cells):
            self.picks = None
        else:
            self.picks = cells
        self._refresh_list()
        self._targets_changed()
        self.changed()

    # ==================================================================
    #  Edits on the targets
    # ==================================================================
    def _live_targets(self, what):
        t = self.targets()
        if t is None or not t.any():
            self.app.status.set_message(f"Force Grid: select cells first ({what}).")
            return None
        return t

    def _after_edit(self, list_now=True):
        self._render()
        self._update_labels()
        if list_now:
            self._refresh_list()
        else:
            self._refresh_list_soon()
        self.changed()

    def _set_colour(self, rgb):
        t = self._live_targets("colour")
        if t is None:
            return
        self._do({"op": "colour", "rgb": [int(x) for x in rgb[:3]]}, t)
        self._after_edit()

    def _picked(self, rgb):
        t = self.targets()
        if t is None or not t.any():
            return
        self._do({"op": "colour", "rgb": [int(x) for x in rgb[:3]]}, t, coalesce=True)
        self._after_edit(list_now=False)

    def _offset_changed(self, v):
        t = self._live_targets("pick offset")
        if t is None:
            return
        self._do({"op": "offset", "v": int(v)}, t, coalesce=True)
        self._after_edit(list_now=False)

    def _adj_changed(self, key, v):
        self.adj[key] = int(v)
        if self.geo is not None:
            self._render()
            self.changed()

    def _bake(self):
        t = self._adj_targets()
        if t is not None:
            self._do(dict({"op": "adjust"}, **self.adj), t)
        self._zero_adj(refresh=False)
        if self.geo is not None:
            self._after_edit()

    def _zero_adj(self, refresh=True):
        for k in self.adj:
            self.adj[k] = 0
            if hasattr(self, "v_adj"):
                self.v_adj[k].set(0)
        if refresh and self.geo is not None:
            self._render()
            self.changed()

    def _auto_targets(self):
        t = self._live_targets("auto")
        if t is None:
            return
        self._zero_adj(refresh=False)
        self._do({"op": "auto"}, t)
        self.v_offset.set(0)
        self._after_edit()

    def _eyedrop(self):
        if self._live_targets("pick from view") is None:
            return
        self.app.status.set_message("Click anywhere in the view to pick a colour  (Esc cancels).")

        def got(rgb):
            self.app.status.set_message(f"Picked {rgb255_to_hex(rgb)}")
            self.picker.set_colour(rgb, before=self.picker.before)
            self._set_colour(rgb)
        self.app.view.start_pick(got)

    # ==================================================================
    #  Labels / housekeeping
    # ==================================================================
    def _update_labels(self):
        self.grid.update_sizes()
        if self.geo is None:
            self.lab_sel.configure(text="")
            self.lab_manual.configure(text="")
            return
        nsel = int(self.sel.sum())
        t = self.targets()
        nt = int(t.sum()) if t is not None else 0
        extra = "  (narrowed by colour)" if self.picks is not None else ""
        self.lab_sel.configure(text=f"Selected: {nsel:,} cells    Targets: {nt:,} cells{extra}")
        edited = int((self.eng.man_has | (self.eng.offset > 0)).sum())
        self.lab_manual.configure(text=f"Edited cells: {edited:,}    Recorded edits: {len(self.ops)}")

    def scroll_targets(self):
        def wheel(e):
            self.list_c.yview_scroll(-1 if e.delta > 0 else 1, "units")
        return [(self.list_c, wheel)]

    def close(self):
        for job in (self._job, self._list_job):
            if job is not None:
                self.app.root.after_cancel(job)
        self._job = self._list_job = None

    # ==================================================================
    #  Viewport overlay
    # ==================================================================
    def overlay(self, canvas, x0, y0, k, cw, ch):
        g = self.geo
        if g is None or self.eng.rgb is None:
            return
        h, w = self.eng.rgb.shape[:2]
        if self.opts["show_grid"] and min(self.opts["cell_w"], self.opts["cell_h"]) * k >= 4:
            top, bot = max(0.0, y0), min(float(ch), y0 + h * k)
            left, right = max(0.0, x0), min(float(cw), x0 + w * k)
            if bot > top and right > left:
                xs = x0 + g["bx"] * k
                for x in xs[(xs >= 0) & (xs <= cw)]:
                    canvas.create_line(x, top, x, bot, fill=GRID_LINE, width=1)
                ys = y0 + g["by"] * k
                for y in ys[(ys >= 0) & (ys <= ch)]:
                    canvas.create_line(left, y, right, y, fill=GRID_LINE, width=1)
        colx = x0 + np.r_[g["sx"], w] * k
        rowy = y0 + np.r_[g["sy"], h] * k
        if self.picks is not None:
            t = (self.picks & self._scope_mask()).reshape(self.sel.shape)
            self._outline(canvas, t, colx, rowy, cw, ch, TARGET_LINE, S(1) + 1)
        if self.sel.any():
            self._outline(canvas, self.sel, colx, rowy, cw, ch, GRID_SEL, S(2))
        if self._drag is not None:
            _m, c0, r0, _b, (c1, r1) = self._drag
            canvas.create_rectangle(colx[min(c0, c1)], rowy[min(r0, r1)], colx[max(c0, c1) + 1],
                                    rowy[max(r0, r1) + 1], outline="#ffffff", dash=(4, 3), width=1)

    @staticmethod
    def _outline(canvas, m, colx, rowy, cw, ch, colour, width):
        """Draw the boundary of the cells in mask m (nrows, ncols)."""
        p = np.pad(m, 1)
        v = p[1:-1, 1:] != p[1:-1, :-1]         # (nrows, ncols+1) vertical edges
        hz = p[1:, 1:-1] != p[:-1, 1:-1]        # (nrows+1, ncols) horizontal edges
        rs, js = np.nonzero(v)
        xs, ya, yb = colx[js], rowy[rs], rowy[rs + 1]
        on = (xs >= -2) & (xs <= cw + 2) & (yb >= 0) & (ya <= ch)
        if on.sum() + hz.sum() > 40000:         # far too much to draw: skip
            return
        for x, a, b in zip(xs[on], ya[on], yb[on]):
            canvas.create_line(x, a, x, b, fill=colour, width=width)
        rs, js = np.nonzero(hz)
        ys, xa, xb = rowy[rs], colx[js], colx[js + 1]
        on = (ys >= -2) & (ys <= ch + 2) & (xb >= 0) & (xa <= cw)
        for y, a, b in zip(ys[on], xa[on], xb[on]):
            canvas.create_line(a, y, b, y, fill=colour, width=width)
