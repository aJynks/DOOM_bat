"""png2pixel - the tool interface every tool follows.

A tool lives in its own window (opened by the ToolHost). It gets the current
working image as its input, shows a live result in the viewport, and either
Applies it (it becomes the new working image) or is Discarded. Its options are
remembered between sessions; Reset puts them back to the defaults.
"""
import copy
from tkinter import ttk

from ..lib_const import S, SMALL


class Tool:
    name = ""
    defaults = {}
    hint = ""                   # status bar text shown when the tool opens
    uses_mouse = False          # True: the tool gets left-button press / drag / release

    def __init__(self, host, saved):
        self.host = host
        self.app = host.app
        self.opts = copy.deepcopy(self.defaults)
        if isinstance(saved, dict):
            for k, v in saved.items():
                if k not in self.defaults:
                    continue
                d = self.defaults[k]
                if isinstance(d, bool):
                    ok = isinstance(v, bool)
                elif isinstance(d, (int, float)):
                    ok = isinstance(v, (int, float)) and not isinstance(v, bool)
                else:
                    ok = isinstance(v, type(d))
                if ok:
                    self.opts[k] = copy.deepcopy(v) if isinstance(d, (dict, list)) else type(d)(v)
        self.input = None
        self.restored = False       # True when reopened from a deleted layer (set by the host)

    # ---- called by the host -------------------------------------------
    def build(self, parent):
        """Create the tool's controls inside parent."""

    def set_input(self, img):
        """A new working image (on open, and when another image is opened)."""
        self.input = img

    def result(self):
        """The image Apply would commit, or None if there is nothing to apply."""
        return None

    def display(self):
        """The image the viewport should show while the tool is open."""
        return self.result() or self.input

    def flush(self):
        """Finish any pending (debounced) work so result() is current."""

    def finalize(self):
        """Just before Apply: settle anything pending so export_edits() has it."""

    # ---- snapshot stack -------------------------------------------------
    def layer_label(self):
        """Name shown for this tool's layer in the snapshot list."""
        return self.name

    def layer_opts(self):
        """The settings recorded with the layer (replayed by Process Folder)."""
        return copy.deepcopy(self.opts)

    def export_edits(self):
        """Hand edits made on this image (JSON-able), recorded with the layer."""
        return {}

    def import_edits(self, edits):
        """Restore recorded hand edits (a layer was deleted back into the tool)."""

    @staticmethod
    def run(img, opts, edits):
        """Headless replay for Process Folder -> (image, warning or None).
        None means the tool can't be replayed."""
        return None

    def reset(self):
        self.opts = copy.deepcopy(self.defaults)
        self.sync_widgets()
        self.on_reset()

    def sync_widgets(self):
        """Put self.opts into the controls."""

    def on_reset(self):
        self.changed()

    def overlay(self, canvas, x0, y0, k, cw, ch):
        """Draw on top of the image (grid lines etc). x0, y0 = image origin on
        the canvas, k = zoom, cw, ch = canvas size."""

    def press(self, u, v, state):
        """Left button down on image pixel (u, v); state has Shift 0x1, Ctrl 0x4."""

    def drag(self, u, v):
        """Left button dragged to pixel (u, v) (clamped to the image)."""

    def hover(self, u, v):
        """Mouse over pixel (u, v), no button: return a cursor name, or None."""
        return None

    def release(self, u, v):
        """Left button released at pixel (u, v)."""

    def scroll_targets(self):
        """[(widget, fn(event))] - widgets that scroll themselves with the wheel."""
        return []

    def close(self):
        """The window is closing."""

    # ---- for the tool itself ------------------------------------------
    def changed(self):
        self.host.tool_changed()


class PlaceholderTool(Tool):
    def __init__(self, host, saved, name):
        self.name = name
        super().__init__(host, saved)

    def build(self, parent):
        ttk.Label(parent, text="Placeholder - this tool's controls go here.",
                  font=SMALL, foreground="#666", wraplength=S(260)).pack(anchor="w", pady=S(6))

    def display(self):
        return self.input
