"""png2pixel - titlePic: cut a Doom title screen out of the image.

    Size          320 x 200 vanilla, 426 x 200 widescreen, 560 x 200 ultra wide,
                  or Free: any shape, crop only (no squash, no scaling)
    Doom squash   on:  the crop box is locked to width : 240 (e.g. 426:240) and
                       the result is squashed to 200 tall, so it stretches back
                       to shape in Doom
                  off: the crop box is locked to width : 200 (for an image that
                       is already squashed, e.g. a Doom Size rebuild)
    Scale         off: crop only - the layer is the cut-out at the image's own
                       resolution (scale it later with the Scale tool)
                  on:  crop and scale to exactly width x 200 in one go, with the
                       Scale tool's methods and options
In the view: drag inside the box to move it, drag a corner or an edge to resize
it (a fixed size keeps its shape; Free moves just that corner / edge). The
cursor shows what you'll grab. A yellow readout shows the crop's size, and in
brackets the size it reduces to when Scale is on. Show result shows the finished
screen. Process Folder replays the crop at the same place relative to each image.
"""
import tkinter as tk
from tkinter import ttk

from ..lib_const import S, SMALL, HEAD, GRID_SEL
from ..lib_widgets import section, note
from .tool_base import Tool
from .tool_scale_engine import DEFAULTS as SCALE_DEFAULTS, scale_image
from .tool_scaleui import ScalePanel

SIZES = {"320 x 200  vanilla": 320, "426 x 200  widescreen": 426, "560 x 200  ultra wide": 560,
         "Free  (crop only)": None}
MIN_BOX = 4.0
SIZE_NAMES = list(SIZES)


def is_free(opts):
    return SIZES.get(opts["size"], 426) is None


def crop_aspect(opts):
    """Locked width / height of the crop box, or None for Free."""
    w = SIZES.get(opts["size"], 426)
    if w is None:
        return None
    return w / (240.0 if opts["squash"] else 200.0)


def fit_crop(img_size, opts, crop=None):
    """The crop box in pixels (x0, y0, x1, y1): the stored fractions re-fitted to
    the locked shape around their centre, or the largest centred box."""
    iw, ih = img_size
    ar = crop_aspect(opts)
    if ar is None:                      # Free: the stored box as it is, kept inside the image
        if crop and len(crop) == 4:
            x0, x1 = sorted((min(max(crop[0], 0.0), 1.0) * iw, min(max(crop[2], 0.0), 1.0) * iw))
            y0, y1 = sorted((min(max(crop[1], 0.0), 1.0) * ih, min(max(crop[3], 0.0), 1.0) * ih))
            if x1 - x0 >= 1 and y1 - y0 >= 1:
                return (x0, y0, x1, y1)
        return (0.0, 0.0, float(iw), float(ih))
    if crop and len(crop) == 4:
        cx = (crop[0] + crop[2]) / 2.0 * iw
        cy = (crop[1] + crop[3]) / 2.0 * ih
        w = (crop[2] - crop[0]) * iw
        h = w / ar
    else:
        cx, cy = iw / 2.0, ih / 2.0
        w, h = iw, iw / ar
    if h > ih:
        h = ih
        w = h * ar
    if w > iw:
        w = iw
        h = w / ar
    x0 = min(max(cx - w / 2.0, 0.0), iw - w)
    y0 = min(max(cy - h / 2.0, 0.0), ih - h)
    return (x0, y0, x0 + w, y0 + h)


def make_titlepic(img, opts, box):
    out_w = SIZES.get(opts["size"], 426)
    b = tuple(int(round(v)) for v in box)
    b = (b[0], b[1], max(b[0] + 1, b[2]), max(b[1] + 1, b[3]))
    cut = img.crop(b)
    if out_w is None or not opts["scale"]:
        return cut
    if cut.size == (out_w, 200):
        return cut.copy()
    return scale_image(cut, (out_w, 200), opts)


def run_titlepic(img, opts, edits):
    box = fit_crop(img.size, opts, opts.get("crop"))
    return make_titlepic(img, opts, box), None


class TitlePic(Tool):
    name = "titlePic"
    hint = "titlePic: drag the box to move it, drag a corner to resize. Tick Scale to make the finished screen."
    uses_mouse = True
    defaults = dict(SCALE_DEFAULTS, size=SIZE_NAMES[1], squash=True, scale=True, crop=[], show_result=False)

    @staticmethod
    def run(img, opts, edits):
        return run_titlepic(img, opts, edits)

    def __init__(self, host, saved):
        super().__init__(host, saved)
        if self.opts["size"] not in SIZES:
            self.opts["size"] = SIZE_NAMES[1]
        self.box = None             # crop box in image pixels
        self._result = None
        self._job = None
        self._drag = None

    def layer_label(self):
        w = SIZES[self.opts["size"]]
        if w is None:
            b = self.box or (0, 0, 0, 0)
            return f"titlePic crop {int(round(b[2] - b[0]))}x{int(round(b[3] - b[1]))}"
        if self.opts["scale"]:
            return f"titlePic {w}x200"
        return f"titlePic crop {w}:{240 if self.opts['squash'] else 200}"

    # ==================================================================
    #  Controls
    # ==================================================================
    def build(self, parent):
        o = self.opts
        p = ttk.Frame(parent, padding=(S(10), 0, S(10), S(10)))
        p.pack(fill="both", expand=True)
        section(p, "Title screen")
        self.v_size = tk.StringVar(value=o["size"])
        for name in SIZE_NAMES:
            ttk.Radiobutton(p, text=name, value=name, variable=self.v_size, takefocus=0,
                            command=self._shape_changed).pack(anchor="w")
        self.v_squash = tk.BooleanVar(value=o["squash"])
        self.c_squash = ttk.Checkbutton(p, text="Doom squash (crop at 240 tall, squash to 200)",
                                        variable=self.v_squash, takefocus=0, command=self._shape_changed)
        self.c_squash.pack(anchor="w", pady=(S(6), 0))
        self.v_scale = tk.BooleanVar(value=o["scale"])
        self.c_scale = ttk.Checkbutton(p, text="Scale (off = crop only, at the image's own resolution)",
                                       variable=self.v_scale, takefocus=0, command=self._scale_toggled)
        self.c_scale.pack(anchor="w")
        self.lab_info = ttk.Label(p, text="", font=SMALL, foreground="#2a6")
        self.lab_info.pack(anchor="w", pady=(S(4), 0))
        row = ttk.Frame(p)
        row.pack(fill="x", pady=(S(6), 0))
        ttk.Button(row, text="Fit box", command=self._fit_box, takefocus=0).pack(side="left")
        self.v_res = tk.BooleanVar(value=o["show_result"])
        ttk.Checkbutton(row, text="Show result", variable=self.v_res, takefocus=0,
                        command=self._view).pack(side="left", padx=S(12))
        note(p, "Drag inside the box to move it, drag a corner or an edge to resize it.", pady=(S(4), 0))

        self.scale_wrap = ttk.Frame(p)
        self.scale_wrap.pack(fill="x")
        section(self.scale_wrap, "Scaling")
        self.panel = ScalePanel(self.scale_wrap, self, self._schedule)
        self._scale_visible()

    def _scale_visible(self):
        free = is_free(self.opts)
        for c in (self.c_squash, self.c_scale):
            c.state(["disabled"] if free else ["!disabled"])
        if self.opts["scale"] and not free:
            self.scale_wrap.pack(fill="x")
        else:
            self.scale_wrap.pack_forget()

    def sync_widgets(self):
        o = self.opts
        self.v_size.set(o["size"])
        self.v_squash.set(o["squash"])
        self.v_scale.set(o["scale"])
        self.v_res.set(o["show_result"])
        self.panel.sync()
        self._scale_visible()

    def on_reset(self):
        self._fit_box()

    # ---------------- options ----------------
    def _shape_changed(self):
        self.opts["size"] = self.v_size.get()
        self.opts["squash"] = self.v_squash.get()
        self._scale_visible()
        if self.input is not None:
            self.box = fit_crop(self.input.size, self.opts, self._fractions())
            self._store_box()
        self._schedule(now=True)

    def _scale_toggled(self):
        self.opts["scale"] = self.v_scale.get()
        self._scale_visible()
        self._schedule(now=True)

    def _view(self):
        self.opts["show_result"] = self.v_res.get()
        self.changed()

    def _fit_box(self):
        if self.input is not None:
            self.box = fit_crop(self.input.size, self.opts, None)
            self._store_box()
        self._schedule(now=True)

    def _fractions(self):
        if self.box is None or self.input is None:
            return self.opts.get("crop") or None
        iw, ih = self.input.size
        x0, y0, x1, y1 = self.box
        return [x0 / iw, y0 / ih, x1 / iw, y1 / ih]

    def _store_box(self):
        self.opts["crop"] = [round(v, 6) for v in self._fractions()]

    # ==================================================================
    #  Mouse: move / resize the crop box
    # ==================================================================
    CURSORS = {("corner", 0, 0): "size_nw_se", ("corner", 1, 1): "size_nw_se",
               ("corner", 1, 0): "size_ne_sw", ("corner", 0, 1): "size_ne_sw",
               ("edge", "l"): "sb_h_double_arrow", ("edge", "r"): "sb_h_double_arrow",
               ("edge", "t"): "sb_v_double_arrow", ("edge", "b"): "sb_v_double_arrow",
               ("move",): "fleur"}

    def _hit(self, u, v):
        """What the pointer at pixel (u, v) would grab: corner, edge, inside or nothing."""
        if self.box is None or self.opts["show_result"]:
            return None
        x0, y0, x1, y1 = self.box
        px, py = u + 0.5, v + 0.5
        tol = S(12) / max(self.app.view.k(), 1e-6)
        near_l, near_r = abs(px - x0) <= tol, abs(px - x1) <= tol
        near_t, near_b = abs(py - y0) <= tol, abs(py - y1) <= tol
        in_x = x0 - tol <= px <= x1 + tol
        in_y = y0 - tol <= py <= y1 + tol
        for cx, nx in ((0, near_l), (1, near_r)):
            for cy, ny in ((0, near_t), (1, near_b)):
                if nx and ny:
                    return ("corner", cx, cy)
        if near_l and in_y:
            return ("edge", "l")
        if near_r and in_y:
            return ("edge", "r")
        if near_t and in_x:
            return ("edge", "t")
        if near_b and in_x:
            return ("edge", "b")
        if x0 <= px <= x1 and y0 <= py <= y1:
            return ("move",)
        return None

    def hover(self, u, v):
        hit = self._hit(u, v)
        return self.CURSORS.get(hit) if hit else None

    def press(self, u, v, state):
        hit = self._hit(u, v)
        if hit is not None:
            self._drag = (hit, (u, v), self.box)

    def drag(self, u, v):
        if self._drag is None or self.input is None:
            return
        hit, (su, sv), start = self._drag
        x0, y0, x1, y1 = start
        iw, ih = self.input.size
        ar = crop_aspect(self.opts)
        px, py = u + 0.5, v + 0.5
        if hit[0] == "move":
            w, h = x1 - x0, y1 - y0
            nx = min(max(x0 + (u - su), 0.0), iw - w)
            ny = min(max(y0 + (v - sv), 0.0), ih - h)
            self.box = (nx, ny, nx + w, ny + h)
        elif hit[0] == "corner":
            _, cx, cy = hit
            ax, ay = (x1 if cx == 0 else x0), (y1 if cy == 0 else y0)      # opposite corner stays put
            if ar is None:
                qx = min(max(px, 0.0), float(iw))
                qy = min(max(py, 0.0), float(ih))
                qx = min(qx, ax - MIN_BOX) if cx == 0 else max(qx, ax + MIN_BOX)
                qy = min(qy, ay - MIN_BOX) if cy == 0 else max(qy, ay + MIN_BOX)
                self.box = (min(ax, qx), min(ay, qy), max(ax, qx), max(ay, qy))
            else:
                w = max(abs(px - ax), abs(py - ay) * ar, 8.0)
                maxw = ax if cx == 0 else iw - ax
                maxh = ay if cy == 0 else ih - ay
                w = min(w, maxw, maxh * ar)
                h = w / ar
                nx = ax - w if cx == 0 else ax
                ny = ay - h if cy == 0 else ay
                self.box = (nx, ny, nx + w, ny + h)
        else:
            side = hit[1]
            if ar is None:                       # Free: only this edge moves
                b = [x0, y0, x1, y1]
                if side == "l":
                    b[0] = min(max(px, 0.0), x1 - MIN_BOX)
                elif side == "r":
                    b[2] = max(min(px, float(iw)), x0 + MIN_BOX)
                elif side == "t":
                    b[1] = min(max(py, 0.0), y1 - MIN_BOX)
                else:
                    b[3] = max(min(py, float(ih)), y0 + MIN_BOX)
                self.box = tuple(b)
            elif side in ("l", "r"):             # width from the edge, height follows, centred
                cy = (y0 + y1) / 2.0
                w = (x1 - px) if side == "l" else (px - x0)
                w = min(max(w, 8.0), x1 if side == "l" else iw - x0, ih * ar)
                h = w / ar
                nx = x1 - w if side == "l" else x0
                ny = min(max(cy - h / 2.0, 0.0), ih - h)
                self.box = (nx, ny, nx + w, ny + h)
            else:                                # height from the edge, width follows, centred
                cx = (x0 + x1) / 2.0
                h = (y1 - py) if side == "t" else (py - y0)
                h = min(max(h, 8.0 / ar), y1 if side == "t" else ih - y0, iw / ar)
                w = h * ar
                ny = y1 - h if side == "t" else y0
                nx = min(max(cx - w / 2.0, 0.0), iw - w)
                self.box = (nx, ny, nx + w, ny + h)
        self._update_info()
        self.changed()

    def release(self, u, v):
        if self._drag is None:
            return
        self.drag(u, v)
        self._drag = None
        self._store_box()
        self._schedule()

    # ==================================================================
    #  Processing
    # ==================================================================
    def set_input(self, img):
        super().set_input(img)
        if img is not None:
            self.box = fit_crop(img.size, self.opts, self.opts.get("crop") or None)
            self._store_box()
        else:
            self.box = None
        self._schedule(now=True)

    def _schedule(self, now=False):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if now:
            self._compute()
        else:
            self._job = self.app.root.after(80, self._compute)

    def flush(self):
        if self._job is not None:
            self._compute()

    def _compute(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None
        if self.input is None or self.box is None:
            self._result = None
        else:
            self._result = make_titlepic(self.input, self.opts, self.box)
        self._update_info()
        self.changed()

    def readout(self):
        """'1280 x 720  (426 x 200)': the crop's size, and the reduced size when scaling."""
        if self.box is None:
            return ""
        x0, y0, x1, y1 = self.box
        txt = f"{int(round(x1 - x0))} x {int(round(y1 - y0))}"
        w = SIZES[self.opts["size"]]
        if w is not None and self.opts["scale"]:
            txt += f"  ({w} x 200)"
        return txt

    def _update_info(self):
        if not hasattr(self, "lab_info") or self.box is None:
            return
        x0, y0 = self.box[0], self.box[1]
        self.lab_info.configure(text=f"Crop {self.readout()}   at {int(round(x0))}, {int(round(y0))}")

    def result(self):
        return self._result if self.input is not None else None

    def display(self):
        if self.opts["show_result"] and self._result is not None:
            return self._result
        return self.input

    def close(self):
        if self._job is not None:
            self.app.root.after_cancel(self._job)
            self._job = None

    # ==================================================================
    #  Overlay: shade outside the box, outline and corner handles
    # ==================================================================
    def overlay(self, canvas, x0, y0, k, cw, ch):
        if self.opts["show_result"] or self.box is None or self.input is None:
            return
        bx0, by0, bx1, by1 = (x0 + self.box[0] * k, y0 + self.box[1] * k, x0 + self.box[2] * k, y0 + self.box[3] * k)
        iw, ih = self.input.size
        ix0, iy0, ix1, iy1 = x0, y0, x0 + iw * k, y0 + ih * k
        for r in ((ix0, iy0, ix1, by0), (ix0, by1, ix1, iy1), (ix0, by0, bx0, by1), (bx1, by0, ix1, by1)):
            if r[2] > r[0] and r[3] > r[1]:
                canvas.create_rectangle(*r, fill="#000000", stipple="gray50", width=0)
        canvas.create_rectangle(bx0, by0, bx1, by1, outline="#000", width=S(2) + 2)
        canvas.create_rectangle(bx0, by0, bx1, by1, outline=GRID_SEL, width=S(2))
        hs = S(6)
        for px, py in ((bx0, by0), (bx1, by0), (bx0, by1), (bx1, by1)):
            canvas.create_rectangle(px - hs, py - hs, px + hs, py + hs, fill=GRID_SEL, outline="#000")
        es = S(4)
        for px, py in (((bx0 + bx1) / 2, by0), ((bx0 + bx1) / 2, by1), (bx0, (by0 + by1) / 2), (bx1, (by0 + by1) / 2)):
            canvas.create_rectangle(px - es, py - es, px + es, py + es, fill=GRID_SEL, outline="#000")
        # yellow size readout above the box (inside it when there's no room above)
        txt = self.readout()
        ty = by0 - S(8) if by0 - S(22) > 0 else by0 + S(14)
        tx = max(bx0, S(4)) + S(2)
        for dx, dy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
            canvas.create_text(tx + dx, ty + dy, text=txt, anchor="sw" if ty < by0 else "nw",
                               fill="#000", font=HEAD)
        canvas.create_text(tx, ty, text=txt, anchor="sw" if ty < by0 else "nw", fill=GRID_SEL, font=HEAD)
