"""png2pixel - the viewport: shows the result image, zoom / pan / fit.

Panning: drag with the middle or right button, or hold Space and just move the
mouse (plain left-drag is kept free for the tools). Center puts the image back
in the middle without changing the zoom. Works at any zoom;
the image can't be dragged fully out of the view.

Zoom is "fit" until the wheel is used. Fit uses a whole-number zoom when the
image fits (pixel exact), or a fractional one when the image is bigger than the
view. At 100% and above the zoom is always a whole number, drawn
nearest-neighbour, so every result pixel is an exact square. Below 100% (big
sources) the zoom moves in smooth steps. Zooming out goes past fit as well:
whole-number levels down to 1:1, then smooth steps until the image is about
MIN_VIEW px on its longest side.
  wheel            above 100%: ZOOM_STEPS levels a notch, below: x ZOOM_FRAC
  Ctrl/Shift+wheel above 100%: ZOOM_STEPS_FINE levels,   below: x ZOOM_FRAC_FINE
"""
import math
import tkinter as tk

import numpy as np
from PIL import Image, ImageTk

from .lib_const import (
    S, VIEW_BG, VIEW_BORDER, VIEW_HINT, VIEW_TEXT, CHECK_A, CHECK_B, MAX_ZOOM, ZOOM_STEPS,
    ZOOM_STEPS_FINE, ZOOM_FRAC, ZOOM_FRAC_FINE, PAN_KEEP, MIN_VIEW, ALLBTN_BG, ALLBTN_HOVER, ALLBTN_FG, FONT)
from .lib_panels import GlyphButton


class Viewport:
    def __init__(self, parent, on_view_change, on_toggle_all):
        self.on_view_change = on_view_change
        self.canvas = tk.Canvas(parent, bg=VIEW_BG, highlightthickness=0, takefocus=0)
        self.img = None                 # PIL image shown (the result)
        self.pick_img = None            # what the eyedropper reads
        self.zoom = None                # None = fit, else the zoom (whole number at >= 1)
        self.pan = [0.0, 0.0]
        self.photo = None
        self._small = (None, None)      # (key, downscaled image) cache for zoom < 1
        self._drag = None
        self._space = False             # Space held: moving the mouse pans
        self._space_anchor = None       # (x, y, pan x, pan y) when Space went down
        self._job = None
        self._pixel = None
        self._hint = "Open an image  (Ctrl+O)"
        self._gen = 0                   # bumps on every new image (cache key)
        self.overlay = None             # fn(canvas, x0, y0, k, cw, ch) drawn over the image
        self.mouse = None               # tool taking left button: press(u, v, state) / drag(u, v) / release(u, v)
        self._tool_drag = False
        self._tool_cursor = ""          # cursor a tool asks for while hovering (e.g. crop handles)
        self.mouse_outside_ok = True    # a tool drag may start outside the image
        self._pick_cb = None            # eyedropper: fn((r, g, b)) for the next left click

        c = self.canvas
        c.bind("<Configure>", lambda e: self.redraw_soon())
        for b in (1, 2, 3):
            c.bind(f"<ButtonPress-{b}>", self._pan_start)
            c.bind(f"<B{b}-Motion>", self._pan_move)
            c.bind(f"<ButtonRelease-{b}>", self._pan_end)
        # double-click fits (left only when no tool uses left clicks; middle always)
        c.bind("<Double-Button-1>", lambda e: self.mouse is None and self._pick_cb is None and self.fit())
        c.bind("<Double-Button-2>", lambda e: self.fit())
        c.bind("<Motion>", self._motion)
        c.bind("<Leave>", self._leave)

        # hide / show all panels, floating in the top-left corner
        self.allbtn = GlyphButton(c, "\u2630", on_toggle_all, bg=ALLBTN_BG, fg=ALLBTN_FG, hover=ALLBTN_HOVER,
                                  font=FONT, tip="Hide / show all panels (Tab)")
        self.allbtn.configure(padx=S(6), pady=S(1))
        self.allbtn.place(x=S(6), y=S(6))

    # ------------------------------------------------------------------
    #  Image
    # ------------------------------------------------------------------
    def set_image(self, img, keep_view=False, pick=None):
        """img: what to show. pick: what the eyedropper reads (default img) -
        the true-colour image when the view shows a palette preview.
        keep_view: the zoom and position stay as they are, even when the new image
        is a different size (at fit, the zoom is frozen at the current fit level
        rather than re-fitting). Only Fit / Center / double-click, opening an
        image and loading a project (keep_view False) move the view."""
        if keep_view and (img is None or self.img is None):
            keep_view = False
        if keep_view and self.zoom is None and img.size != self.img.size:
            self.zoom = self.k()            # freeze the fit zoom of the image shown so far
        self.img = img
        self.pick_img = pick if pick is not None and pick.size == img.size else img
        self._gen += 1
        self._small = (None, None)
        if not keep_view:
            self.zoom = None
            self.pan = [0.0, 0.0]
        self.redraw()

    def set_hint(self, text):
        self._hint = text
        if self.img is None:
            self.redraw()

    # ------------------------------------------------------------------
    #  Zoom
    # ------------------------------------------------------------------
    def _size(self):
        c = self.canvas
        return max(1, c.winfo_width()), max(1, c.winfo_height())

    def fit_k(self):
        cw, ch = self._size()
        k = min(cw / self.img.width, ch / self.img.height)
        return max(1, int(k)) if k >= 1 else k

    def k(self):
        return self.zoom if self.zoom else self.fit_k()

    def min_k(self):
        """Smallest zoom: the image about MIN_VIEW px on its longest side (never above 1:1)."""
        return min(1.0, S(MIN_VIEW) / float(max(self.img.width, self.img.height)))

    def zoom_text(self):
        if self.img is None:
            return "-"
        k = self.k()
        ks = f"{k}x" if k >= 1 else (f"{k * 100:.0f}%" if k >= 0.1 else f"{k * 100:.1f}%")
        return ks if self.zoom else f"fit ({ks})"

    def center(self):
        """Put the image in the middle of the view; the zoom stays as it is."""
        self.pan = [0.0, 0.0]
        self._space_anchor = None
        self.redraw()

    def fit(self):
        self.zoom = None
        self.pan = [0.0, 0.0]
        self.redraw()

    def zoom_at(self, x, y, up, fine=False):
        if self.img is None:
            return
        old = self.k()
        steps = ZOOM_STEPS_FINE if fine else ZOOM_STEPS
        frac = ZOOM_FRAC_FINE if fine else ZOOM_FRAC
        if up:
            if old < 1:
                new = old * frac
                if new >= 0.999:
                    new = 1                     # land exactly on 1:1
            else:
                cap = max(MAX_ZOOM, int(old))   # tiny images can fit above MAX_ZOOM
                new = min(cap, int(old) + steps)
        else:
            # out past fit too: whole-number levels down to 1:1, then smooth steps
            # until the image is about MIN_VIEW px on its longest side
            floor = self.min_k()
            if old > 1:
                new = max(1, int(old) - steps)  # stop on 1:1 before going below it
            else:
                if old <= floor * 1.0001:
                    return
                new = max(floor, old / frac)
        if abs(new - old) < 1e-9:
            return
        cw, ch = self._size()
        ux = (x - cw / 2 - self.pan[0]) / old
        uy = (y - ch / 2 - self.pan[1]) / old
        self.zoom = new
        self.pan = [x - cw / 2 - ux * new, y - ch / 2 - uy * new]
        self.redraw()

    def wheel(self, e):
        """Called by the app for wheel events over the canvas."""
        fine = bool(e.state & 0x0004) or bool(e.state & 0x0001)     # Ctrl or Shift
        x = e.x_root - self.canvas.winfo_rootx()
        y = e.y_root - self.canvas.winfo_rooty()
        self.zoom_at(x, y, e.delta > 0, fine)

    # ------------------------------------------------------------------
    #  Pan
    # ------------------------------------------------------------------
    def set_space(self, held):
        """Space held / released (from the app's key bindings)."""
        if held == self._space:
            return
        self._space = held
        # holding Space pans with plain mouse movement (no click needed)
        self._space_anchor = None
        if held and self.img is not None:
            c = self.canvas
            x = c.winfo_pointerx() - c.winfo_rootx()
            y = c.winfo_pointery() - c.winfo_rooty()
            self._space_anchor = (x, y, self.pan[0], self.pan[1])
        if self._drag is None:
            self._idle_cursor()

    def _idle_cursor(self):
        if self._space and self.img is not None:
            cur = "hand2"
        elif self._pick_cb is not None:
            cur = "crosshair"
        elif self.mouse is not None and self._tool_cursor:
            cur = self._tool_cursor
        else:
            cur = ""
        try:
            self.canvas.configure(cursor=cur)
        except tk.TclError:                 # a Windows-only cursor name elsewhere
            self.canvas.configure(cursor="fleur" if cur else "")

    # ---------------- eyedropper ----------------
    def start_pick(self, callback):
        self._pick_cb = callback
        self._idle_cursor()

    def cancel_pick(self):
        if self._pick_cb is not None:
            self._pick_cb = None
            self._idle_cursor()

    def is_picking(self):
        return self._pick_cb is not None

    def _pixel_at(self, x, y):
        if self.img is None:
            return None
        x0, y0, k = self._origin()
        u = int(math.floor((x - x0) / k))
        v = int(math.floor((y - y0) / k))
        if 0 <= u < self.img.width and 0 <= v < self.img.height:
            return u, v
        return None

    def _pixel_clamped(self, x, y):
        """Image pixel under (x, y), clamped to the image edge (for drags)."""
        x0, y0, k = self._origin()
        u = int(math.floor((x - x0) / k))
        v = int(math.floor((y - y0) / k))
        return min(max(u, 0), self.img.width - 1), min(max(v, 0), self.img.height - 1)

    def _pan_start(self, e):
        if self.img is None:
            return
        if e.num == 1 and not self._space:
            # left button is for the tools (and the eyedropper)
            p = self._pixel_at(e.x, e.y)
            if self._pick_cb is not None:
                if p is not None:
                    cb = self._pick_cb
                    self._pick_cb = None
                    self._idle_cursor()
                    c = self.pick_img.getpixel(p)
                    cb(tuple(c[:3]) if isinstance(c, tuple) else (c, c, c))
            elif self.mouse is not None and (p is not None or self.mouse_outside_ok):
                self._tool_drag = True
                self.mouse.press(*self._pixel_clamped(e.x, e.y), e.state)
            return
        self._drag = (e.x, e.y, self.pan[0], self.pan[1])
        self.canvas.configure(cursor="fleur")

    def _pan_move(self, e):
        if self._tool_drag:
            if self.mouse is not None and self.img is not None:
                self.mouse.drag(*self._pixel_clamped(e.x, e.y))
            self._motion(e)
            return
        if self._drag:
            sx, sy, px, py = self._drag
            self.pan = [px + e.x - sx, py + e.y - sy]
            self.redraw()
            self._motion(e)

    def _pan_end(self, e):
        if self._tool_drag:
            self._tool_drag = False
            if self.mouse is not None and self.img is not None:
                self.mouse.release(*self._pixel_clamped(e.x, e.y))
            return
        if self._drag is None:
            return
        self._drag = None
        self._idle_cursor()

    def _clamp_pan(self, w, h, cw, ch):
        # the image may move until only PAN_KEEP pixels of it are left on screen
        keep_x = min(S(PAN_KEEP), w, cw)
        keep_y = min(S(PAN_KEEP), h, ch)
        mx = max(0.0, (w + cw) / 2 - keep_x)
        my = max(0.0, (h + ch) / 2 - keep_y)
        self.pan[0] = min(max(self.pan[0], -mx), mx)
        self.pan[1] = min(max(self.pan[1], -my), my)

    # ------------------------------------------------------------------
    #  Cursor readout
    # ------------------------------------------------------------------
    def _origin(self):
        cw, ch = self._size()
        k = self.k()
        w, h = self.img.width * k, self.img.height * k
        return cw / 2 + self.pan[0] - w / 2, ch / 2 + self.pan[1] - h / 2, k

    def _motion(self, e):
        if self._space and self._drag is None and self.img is not None:
            if self._space_anchor is None:
                self._space_anchor = (e.x, e.y, self.pan[0], self.pan[1])
            sx, sy, px, py = self._space_anchor
            self.pan = [px + e.x - sx, py + e.y - sy]
            self.redraw()
        elif (self.mouse is not None and self.img is not None and not self._tool_drag and self._drag is None
                and hasattr(self.mouse, "hover")):
            cur = self.mouse.hover(*self._pixel_clamped(e.x, e.y)) or ""
            if cur != self._tool_cursor:
                self._tool_cursor = cur
                self._idle_cursor()
        px = self._pixel_at(e.x, e.y)
        if px != self._pixel:
            self._pixel = px
            self.on_view_change()

    def _leave(self, _e):
        if self._pixel is not None:
            self._pixel = None
            self.on_view_change()

    def pixel(self):
        return self._pixel

    # ------------------------------------------------------------------
    #  Drawing
    # ------------------------------------------------------------------
    def redraw_soon(self):
        if self._job is None:
            self._job = self.canvas.after_idle(self.redraw)

    def redraw(self):
        if self._job is not None:
            self.canvas.after_cancel(self._job)
            self._job = None
        c = self.canvas
        c.delete("all")
        cw, ch = self._size()
        if self.img is None:
            c.create_text(cw // 2, ch // 2, text=self._hint, fill=VIEW_HINT, font=VIEW_TEXT)
            self.photo = None
            self.on_view_change()
            return
        im = self.img
        k = self.k()
        w, h = im.width * k, im.height * k
        self._clamp_pan(w, h, cw, ch)
        x0 = cw / 2 + self.pan[0] - w / 2
        y0 = ch / 2 + self.pan[1] - h / 2
        if k >= 1:
            u0 = max(0, int(math.floor(-x0 / k)))
            v0 = max(0, int(math.floor(-y0 / k)))
            u1 = min(im.width, int(math.ceil((cw - x0) / k)))
            v1 = min(im.height, int(math.ceil((ch - y0) / k)))
            if u1 <= u0 or v1 <= v0:
                self.on_view_change()
                return
            part = im.crop((u0, v0, u1, v1)).resize(((u1 - u0) * k, (v1 - v0) * k), Image.Resampling.NEAREST)
            px, py = x0 + u0 * k, y0 + v0 * k
        else:
            size = (max(1, int(round(w))), max(1, int(round(h))))
            key = (self._gen, size)
            if self._small[0] != key:
                # a high-res source shown smaller than 1:1 is averaged, not
                # point-sampled, so the overview isn't full of aliasing
                self._small = (key, im.resize(size, Image.Resampling.BOX))
            small = self._small[1]
            # only the part that is on screen
            a0, b0 = max(0, int(-x0)), max(0, int(-y0))
            a1, b1 = min(small.width, int(math.ceil(cw - x0))), min(small.height, int(math.ceil(ch - y0)))
            if a1 <= a0 or b1 <= b0:
                self.on_view_change()
                return
            part = small.crop((a0, b0, a1, b1))
            px, py = x0 + a0, y0 + b0
        if part.mode == "RGBA":
            part = self._on_checker(part)
        elif part.mode != "RGB":
            part = part.convert("RGB")
        self.photo = ImageTk.PhotoImage(part)
        c.create_image(int(round(px)), int(round(py)), image=self.photo, anchor="nw")
        c.create_rectangle(int(x0) - 1, int(y0) - 1, int(x0 + w), int(y0 + h), outline=VIEW_BORDER)
        if self.overlay is not None:
            self.overlay(c, x0, y0, k, cw, ch)
        self.on_view_change()

    @staticmethod
    def _on_checker(im):
        n = S(8)
        w, h = im.size
        yy, xx = np.mgrid[0:h, 0:w]
        chk = ((xx // n + yy // n) & 1).astype(bool)
        bg = np.where(chk, np.uint8(CHECK_B), np.uint8(CHECK_A))
        base = Image.fromarray(np.repeat(bg[..., None], 3, axis=2), "RGB").convert("RGBA")
        return Image.alpha_composite(base, im).convert("RGB")
