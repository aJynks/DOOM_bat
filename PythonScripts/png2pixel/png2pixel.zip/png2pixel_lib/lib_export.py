"""png2pixel - the Export window.

Saves the top layer of the snapshot stack:
    True colour   <name>-truecolour.png
    Paletted      <name>-paletted.png   indexed PNG using the Pal0 palette and
                  options (an image with transparency is saved as RGBA in the
                  palette's colours, as an indexed PNG would need a spare index)
The folder and tick boxes are remembered.
"""
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .lib_const import S, HEAD, SMALL, APP
from .lib_stack import save_png, with_grab

SUFFIX_TC = "-truecolour.png"
SUFFIX_PAL = "-paletted.png"


class ExportDialog:
    def __init__(self, app, base_name):
        self.app = app
        root = app.root
        top = tk.Toplevel(root)
        self.top = top
        top.title("Export")
        top.transient(root)
        top.resizable(True, False)
        top.protocol("WM_DELETE_WINDOW", top.destroy)
        top.bind("<Escape>", lambda e: top.destroy())

        body = ttk.Frame(top, padding=S(12))
        body.pack(fill="both", expand=True)
        ttk.Label(body, text="Export the top layer", font=HEAD).pack(anchor="w")
        w, h = app.work.size
        ttk.Label(body, text=f"{w} x {h}   palette: {app.pal.palette.name}", font=SMALL,
                  foreground="#555").pack(anchor="w", pady=(S(2), S(8)))

        g = ttk.Frame(body)
        g.pack(fill="x")
        g.columnconfigure(1, weight=1)
        self.v_dir = tk.StringVar(value=app.settings["export_dir"] or app.settings["last_dir"])
        self.v_name = tk.StringVar(value=base_name)
        ttk.Label(g, text="Folder").grid(row=0, column=0, sticky="w", padx=(0, S(6)), pady=S(3))
        ttk.Entry(g, textvariable=self.v_dir, width=40).grid(row=0, column=1, sticky="ew", pady=S(3))
        ttk.Button(g, text="Browse...", command=self._browse, takefocus=0).grid(row=0, column=2, padx=(S(6), 0))
        ttk.Label(g, text="Name").grid(row=1, column=0, sticky="w", padx=(0, S(6)), pady=S(3))
        ttk.Entry(g, textvariable=self.v_name).grid(row=1, column=1, sticky="ew", pady=S(3))

        self.v_tc = tk.BooleanVar(value=app.settings["export_tc"])
        self.v_pal = tk.BooleanVar(value=app.settings["export_pal"])
        ttk.Checkbutton(body, text=f"True colour    (name{SUFFIX_TC})", variable=self.v_tc,
                        takefocus=0).pack(anchor="w", pady=(S(8), S(2)))
        ttk.Checkbutton(body, text=f"Paletted         (name{SUFFIX_PAL}, Pal0 settings)", variable=self.v_pal,
                        takefocus=0).pack(anchor="w", pady=S(2))
        if app.host.tool is not None and app.host.tool.result() is not None:
            ttk.Label(body, text=f"{app.host.tool.name} is open and not applied: its result isn't included.",
                      font=SMALL, foreground="#a60").pack(anchor="w", pady=(S(6), 0))

        row = ttk.Frame(body)
        row.pack(fill="x", pady=(S(12), 0))
        ttk.Button(row, text="Save", command=self._save, takefocus=0).pack(side="right")
        ttk.Button(row, text="Cancel", command=top.destroy, takefocus=0).pack(side="right", padx=S(4))

        top.update_idletasks()
        x = root.winfo_rootx() + max(0, (root.winfo_width() - top.winfo_reqwidth()) // 2)
        y = root.winfo_rooty() + max(0, (root.winfo_height() - top.winfo_reqheight()) // 3)
        top.geometry(f"+{x}+{y}")
        top.grab_set()

    def _browse(self):
        d = filedialog.askdirectory(parent=self.top, title="Export folder", initialdir=self.v_dir.get() or None)
        if d:
            self.v_dir.set(os.path.normpath(d))

    def _save(self):
        folder, name = self.v_dir.get().strip(), self.v_name.get().strip()
        tc, pal = self.v_tc.get(), self.v_pal.get()
        if not (tc or pal):
            messagebox.showinfo(APP, "Tick at least one of True colour / Paletted.", parent=self.top)
            return
        if not folder or not name:
            messagebox.showinfo(APP, "Choose a folder and a name.", parent=self.top)
            return
        jobs = []
        if tc:
            jobs.append(("tc", os.path.join(folder, name + SUFFIX_TC)))
        if pal:
            jobs.append(("pal", os.path.join(folder, name + SUFFIX_PAL)))
        exist = [os.path.basename(p) for _, p in jobs if os.path.exists(p)]
        if exist and not messagebox.askokcancel(APP, "Overwrite?\n\n" + "\n".join(exist), parent=self.top):
            return
        try:
            os.makedirs(folder, exist_ok=True)
            img = self.app.work
            for kind, path in jobs:
                if kind == "tc":
                    save_png(img, path)
                else:
                    save_png(with_grab(self.app.pal.paletted(img), img), path, optimize=True)
        except Exception as ex:
            messagebox.showerror(APP, f"Could not save:\n{ex}", parent=self.top)
            return
        s = self.app.settings
        s["export_dir"], s["export_tc"], s["export_pal"] = folder, tc, pal
        s.save()
        self.app.status.set_message("Exported " + ", ".join(os.path.basename(p) for _, p in jobs))
        self.top.destroy()
