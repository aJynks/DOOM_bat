"""png2pixel - the Pal0 options window.

Opened from the Pal0 button in the top bar. Not a tool: it can stay open
alongside one. Changes show at once in the viewer when Preview is ticked.

    Load... / Doom 2   the palette (Doom 2 PLAYPAL 0 at every start; a project
                       remembers a custom palette)
    swatches           click to exclude / include an index (excluded = never used)
    Exclude            the same as text: 0, 247-255
    Metric             how "nearest colour" is measured; Lightness weight and
                       Chroma protect apply to OKLab / CIELAB
    Dither             None, error diffusion (slow on big images) or ordered
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .lib_const import S, SMALL, HEAD, APP
from .lib_palette import (
    Palette, load_palette, parse_indices, format_indices, METRIC_NAMES, METRIC_CODE, METRIC_NAME,
    DITHER_MODES, OPTION_DEFAULTS, ED_KERNELS)
from .lib_settings import geometry_on_screen, fit_to_screen
from .lib_widgets import ScrollFrame

KEY = "Pal0"        # name for the remembered window position


class PalDialog:
    def __init__(self, app):
        self.app = app
        self.pal = app.pal
        root = app.root
        top = tk.Toplevel(root)
        self.top = top
        top.title("Pal0")
        top.transient(root)
        try:
            top.attributes("-toolwindow", True)
        except tk.TclError:
            pass
        top.protocol("WM_DELETE_WINDOW", self.close)
        top.bind("<Escape>", lambda e: self.close())
        self._quiet = False
        self.cell = S(16)

        self.scroll = ScrollFrame(top)
        self.scroll.pack(fill="both", expand=True)
        body = ttk.Frame(self.scroll.inner, padding=S(10))
        body.pack(fill="both", expand=True)

        # ---- palette ----
        ttk.Label(body, text="Palette", font=HEAD).pack(anchor="w")
        self.lab_name = ttk.Label(body, text="", foreground="#2a6")
        self.lab_name.pack(anchor="w")
        row = ttk.Frame(body)
        row.pack(fill="x", pady=S(4))
        ttk.Button(row, text="Load...", command=self._load, takefocus=0).pack(side="left")
        ttk.Button(row, text="Doom 2", command=self._doom2, takefocus=0).pack(side="left", padx=S(4))
        n = 16 * self.cell + 1
        self.sw = tk.Canvas(body, width=n, height=n, bg="#000", highlightthickness=0, cursor="hand2")
        self.sw.pack(pady=S(4))
        self.sw.bind("<Button-1>", self._swatch_click)
        self.sw.bind("<Motion>", self._swatch_motion)
        self.sw.bind("<Leave>", lambda e: self.lab_hover.configure(text=""))
        self.lab_hover = ttk.Label(body, text="", font=SMALL, foreground="#555")
        self.lab_hover.pack(anchor="w")
        row = ttk.Frame(body)
        row.pack(fill="x", pady=S(2))
        ttk.Label(row, text="Exclude").pack(side="left", padx=(0, S(6)))
        self.v_ex = tk.StringVar()
        ent = ttk.Entry(row, textvariable=self.v_ex)
        ent.pack(side="left", fill="x", expand=True)
        ent.bind("<Return>", lambda e: self._exclude_typed())
        ent.bind("<FocusOut>", lambda e: self._exclude_typed())

        # ---- matching ----
        ttk.Separator(body).pack(fill="x", pady=S(8))
        ttk.Label(body, text="Matching", font=HEAD).pack(anchor="w")
        g = ttk.Frame(body)
        g.pack(fill="x")
        g.columnconfigure(1, weight=1)
        self.v = {}
        self.v["metric"] = tk.StringVar()
        self._combo(g, 0, "Metric", "metric", METRIC_NAMES)
        self.v["kL"] = tk.DoubleVar()
        self.s_kl = self._scale(g, 1, "Lightness wt", "kL", 0.1, 3.0, 0.05)
        self.v["protect"] = tk.IntVar()
        self.s_pr = self._scale(g, 2, "Chroma protect", "protect", 0, 300, 1)

        # ---- dither ----
        ttk.Separator(body).pack(fill="x", pady=S(8))
        ttk.Label(body, text="Dither", font=HEAD).pack(anchor="w")
        g2 = ttk.Frame(body)
        g2.pack(fill="x")
        g2.columnconfigure(1, weight=1)
        self.v["dither"] = tk.StringVar()
        self._combo(g2, 0, "Method", "dither", DITHER_MODES)
        self.v["strength"] = tk.IntVar()
        self._scale(g2, 1, "Strength", "strength", 0, 100, 1)
        self.v["clamp"] = tk.IntVar()
        self.s_cl = self._scale(g2, 2, "Error clamp", "clamp", 4, 255, 1)
        self.v["serpentine"] = tk.BooleanVar()
        self.c_serp = ttk.Checkbutton(g2, text="Serpentine scan", variable=self.v["serpentine"], takefocus=0)
        self.c_serp.grid(row=3, column=0, columnspan=2, sticky="w", pady=S(3))
        self.v["serpentine"].trace_add("write", lambda *a: self._changed("serpentine"))
        self.lab_slow = ttk.Label(body, text="", font=SMALL, foreground="#a60", wraplength=S(300), justify="left")
        self.lab_slow.pack(anchor="w", pady=(S(4), 0))

        row = ttk.Frame(body)
        row.pack(fill="x", pady=(S(10), 0))
        ttk.Button(row, text="Reset options", command=self._reset, takefocus=0).pack(side="left")
        ttk.Button(row, text="Close", command=self.close, takefocus=0).pack(side="right")

        self.sync()
        saved = geometry_on_screen(root, app.settings["popups"].get(KEY))
        if not saved:
            top.update_idletasks()
            w = self.scroll.inner.winfo_reqwidth() + self.scroll.bar.winfo_reqwidth() + S(4)
            h = self.scroll.inner.winfo_reqheight()
            x = root.winfo_rootx() + S(60)
            y = root.winfo_rooty() + S(80)
            saved = f"{w}x{h}+{x}+{y}"
        top.geometry(fit_to_screen(root, saved))

    def handle_wheel(self, path, e):
        if path.startswith(str(self.top)):
            self.scroll.wheel(e)
            return True
        return False

    # ---------------- widgets ----------------
    def _combo(self, g, r, label, key, values):
        ttk.Label(g, text=label).grid(row=r, column=0, sticky="w", padx=(0, S(8)), pady=S(3))
        c = ttk.Combobox(g, textvariable=self.v[key], values=values, state="readonly")
        c.grid(row=r, column=1, sticky="ew", pady=S(3))
        self.v[key].trace_add("write", lambda *a: self._changed(key))
        return c

    def _scale(self, g, r, label, key, lo, hi, res):
        lab = ttk.Label(g, text=label)
        lab.grid(row=r, column=0, sticky="sw", padx=(0, S(8)), pady=(0, S(2)))
        sc = tk.Scale(g, from_=lo, to=hi, resolution=res, orient="horizontal", variable=self.v[key],
                      showvalue=True, highlightthickness=0, length=S(200), sliderlength=S(30),
                      width=S(18), font=SMALL, takefocus=0)
        sc.grid(row=r, column=1, sticky="ew")
        lab.bind("<Double-Button-1>", lambda e: self.v[key].set(OPTION_DEFAULTS[key]))
        self.v[key].trace_add("write", lambda *a: self._changed(key))
        return sc

    # ---------------- state <-> widgets ----------------
    def sync(self):
        """Put the current palette and options into the window."""
        o = self.pal.opts
        self._quiet = True
        self.v["metric"].set(METRIC_NAME.get(o["metric"], METRIC_NAMES[0]))
        self.v["kL"].set(o["kL"])
        self.v["protect"].set(o["protect"])
        self.v["dither"].set(o["dither"])
        self.v["strength"].set(o["strength"])
        self.v["clamp"].set(o["clamp"])
        self.v["serpentine"].set(o["serpentine"])
        self.v_ex.set(format_indices(o["excluded"]))
        self._quiet = False
        self.lab_name.configure(text=self.pal.palette.name)
        self._update_states()
        self._draw_swatches()

    def _changed(self, key):
        if self._quiet:
            return
        try:
            v = self.v[key].get()
        except tk.TclError:
            return
        if key == "metric":
            v = METRIC_CODE.get(v, "oklab")
        self.pal.opts[key] = v
        self._update_states()
        self.app.pal_changed()

    def _update_states(self):
        lab = self.pal.opts["metric"] in ("oklab", "cielab")
        for w in (self.s_kl, self.s_pr):
            w.configure(state="normal" if lab else "disabled", fg="#000" if lab else "#999")
        ed = self.pal.opts["dither"] in ED_KERNELS
        self.s_cl.configure(state="normal" if ed else "disabled", fg="#000" if ed else "#999")
        self.c_serp.state(["!disabled"] if ed else ["disabled"])
        self.lab_slow.configure(text="Error diffusion runs pixel by pixel: on big images the preview "
                                     "updates after a pause." if ed else "")

    # ---------------- palette ----------------
    def _load(self):
        path = filedialog.askopenfilename(
            parent=self.top, title="Load palette",
            initialdir=self.app.settings["palette_dir"] or None,
            filetypes=[("Palettes", "*.pal *.lmp *.gpl *.wad *.png *.bmp *.gif *.pcx"), ("All files", "*.*")])
        if not path:
            return
        try:
            p = load_palette(path)
        except Exception as ex:
            messagebox.showerror(APP, f"Could not load the palette:\n{path}\n\n{ex}", parent=self.top)
            return
        import os
        self.app.settings["palette_dir"] = os.path.dirname(path)
        self.app.settings.save()
        self.pal.palette = p
        self.sync()
        self.app.pal_changed()
        self.app.status.set_message(f"Pal0: loaded {p.name}")

    def _doom2(self):
        self.pal.palette = Palette.doom2()
        self.sync()
        self.app.pal_changed()

    def _reset(self):
        self.pal.set_options(OPTION_DEFAULTS)
        self.sync()
        self.app.pal_changed()

    # ---------------- swatches / exclude ----------------
    def _draw_swatches(self):
        c = self.sw
        c.delete("all")
        n = self.cell
        rgb = self.pal.palette.rgb
        ex = set(self.pal.opts["excluded"])
        for i in range(256):
            x, y = (i % 16) * n, (i // 16) * n
            r, g, b = (int(v) for v in rgb[i])
            c.create_rectangle(x, y, x + n, y + n, fill=f"#{r:02x}{g:02x}{b:02x}", outline="#000")
            if i in ex:
                lum = 0.3 * r + 0.59 * g + 0.11 * b
                col = "#000" if lum > 128 else "#fff"
                c.create_line(x + 2, y + 2, x + n - 2, y + n - 2, fill=col, width=S(1))
                c.create_line(x + n - 2, y + 2, x + 2, y + n - 2, fill=col, width=S(1))

    def _index_at(self, e):
        i = (e.y // self.cell) * 16 + e.x // self.cell
        return i if 0 <= e.x < 16 * self.cell and 0 <= e.y < 16 * self.cell else None

    def _swatch_click(self, e):
        i = self._index_at(e)
        if i is None:
            return
        ex = set(self.pal.opts["excluded"])
        ex.symmetric_difference_update({i})
        self.pal.opts["excluded"] = sorted(ex)
        self.v_ex.set(format_indices(ex))
        self._draw_swatches()
        self.app.pal_changed()

    def _swatch_motion(self, e):
        i = self._index_at(e)
        if i is None:
            return
        r, g, b = (int(v) for v in self.pal.palette.rgb[i])
        state = "  (excluded)" if i in self.pal.opts["excluded"] else ""
        self.lab_hover.configure(text=f"Index {i}   #{r:02x}{g:02x}{b:02x}{state}")

    def _exclude_typed(self):
        try:
            ex = parse_indices(self.v_ex.get())
        except ValueError:
            self.v_ex.set(format_indices(self.pal.opts["excluded"]))
            return
        if sorted(ex) != self.pal.opts["excluded"]:
            self.pal.opts["excluded"] = sorted(ex)
            self._draw_swatches()
            self.app.pal_changed()
        self.v_ex.set(format_indices(ex))

    def close(self):
        try:
            self.app.settings["popups"][KEY] = self.top.geometry()
        except tk.TclError:
            pass
        self.app.pal_dialog = None
        self.app.settings.save()
        self.top.destroy()
