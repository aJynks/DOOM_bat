"""png2pixel - the tool window host.

Only one tool is open at a time. Its window is detached (drag it anywhere, any
monitor) and stays open while you work. Opening another tool while the current
one has a result asks Apply / Discard / Cancel first.

Every tool window has:
    Reset     put this tool's options back to their defaults
    Discard   close without changing the image
    Apply     the result becomes the working image, then the window closes
Closing the window (X / Esc) asks Apply / Discard / Cancel when there is a
result. Each tool's options and window position are remembered.
"""
import tkinter as tk
from tkinter import ttk

from .lib_const import S
from .lib_settings import geometry_on_screen, fit_to_screen
from .tools.tool_registry import make_tool
from .lib_widgets import ScrollFrame, ask_apply



class ToolHost:
    def __init__(self, app):
        self.app = app
        self.tool = None
        self.win = None
        self.body = None
        self.btn_apply = None

    # ------------------------------------------------------------------
    #  Open / close
    # ------------------------------------------------------------------
    def show(self, name, opts=None, edits=None):
        """Open a tool. opts / edits: restore a deleted layer's settings and hand edits."""
        if self.tool is not None:
            if self.tool.name == name and opts is None:
                self.win.deiconify()
                self.win.lift()
                return
            if not self.close(ask=True):
                return
        saved = opts if opts is not None else self.app.settings["tools"].get(name)
        tool = make_tool(name, self, saved)
        tool.restored = opts is not None    # reopened from a deleted layer
        self.tool = tool
        self._build_window(tool)
        tool.set_input(self.app.work)
        if edits:
            tool.import_edits(edits)
        self.app.tools.set_tool_open(name, True)
        self.app.tool_opened(tool)
        self._update_buttons()

    def _build_window(self, tool):
        root = self.app.root
        top = tk.Toplevel(root)
        self.win = top
        top.title(tool.name)
        top.transient(root)                 # stays above the main window
        try:
            top.attributes("-toolwindow", True)     # thin title bar (Windows)
        except tk.TclError:
            pass
        top.protocol("WM_DELETE_WINDOW", lambda: self.close(ask=True))
        top.bind("<Escape>", lambda e: self._escape())
        top.minsize(S(260), S(160))

        bar = ttk.Frame(top, padding=(S(8), S(6)))
        bar.pack(side="bottom", fill="x")
        ttk.Separator(top).pack(side="bottom", fill="x")
        ttk.Button(bar, text="Reset", command=self._reset, takefocus=0).pack(side="left")
        self.btn_apply = ttk.Button(bar, text="Apply", command=self.apply, takefocus=0)
        self.btn_apply.pack(side="right")
        ttk.Button(bar, text="Discard", command=self.discard, takefocus=0).pack(side="right", padx=S(4))

        self.body = ScrollFrame(top)
        self.body.pack(side="top", fill="both", expand=True)
        tool.build(self.body.inner)

        saved = geometry_on_screen(root, self.app.settings["popups"].get(tool.name))
        top.geometry(fit_to_screen(root, saved or self._default_geometry()))

    def _default_geometry(self):
        root, top = self.app.root, self.win
        top.update_idletasks()
        w = self.body.inner.winfo_reqwidth() + self.body.bar.winfo_reqwidth() + S(6)
        h = self.body.inner.winfo_reqheight() + S(60)
        h = min(h, int(root.winfo_screenheight() * 0.85))
        strip = self.app.tools.winfo_width() if self.app.tools.is_open else 0
        x = root.winfo_rootx() + root.winfo_width() - strip - w - S(24)
        y = root.winfo_rooty() + S(60)
        return f"{w}x{h}+{max(0, x)}+{max(0, y)}"

    def close(self, ask=True):
        """Close the open tool. Returns False if the user cancelled."""
        if self.tool is None:
            return True
        self.tool.flush()
        if ask and self.tool.result() is not None:
            choice = ask_apply(self.win, self.tool.name)
            if choice == "cancel":
                return False
            if choice == "apply":
                return self.apply()
        self._teardown()
        return True

    def apply(self):
        if self.tool is None:
            return True
        img, name, opts, edits, label = self._take_result()
        self._teardown()
        if img is not None:
            self.app.commit(img, name, opts, edits, label)
        return True

    def _take_result(self):
        t = self.tool
        t.flush()
        t.finalize()
        t.flush()
        return t.result(), t.name, t.layer_opts(), t.export_edits(), t.layer_label()

    def apply_continue(self):
        """Add the current result as a layer but keep the tool open, now working on
        that result (used when a tool switches what it is doing, e.g. Adjust)."""
        if self.tool is None:
            return
        img, name, opts, edits, label = self._take_result()
        if img is None:
            return
        self.app.commit(img, name, opts, edits, label)
        self.tool.set_input(self.app.work)
        self._update_buttons()

    def discard(self):
        if self.tool is not None:
            name = self.tool.name
            self._teardown()
            self.app.status.set_message(f"{name} discarded.")

    def _teardown(self):
        tool = self.tool
        self.save_state()
        tool.close()
        self.app.view.cancel_pick()
        self.tool = None
        self.win.destroy()
        self.win = self.body = self.btn_apply = None
        self.app.tools.set_tool_open(tool.name, False)
        self.app.tool_closed()
        self.app.settings.save()

    def _escape(self):
        if self.app.view.is_picking():
            self.app.view.cancel_pick()
            self.app.status.set_message("Pick cancelled.")
        else:
            self.close(ask=True)

    def _reset(self):
        if self.tool is not None:
            self.tool.reset()
            self.app.status.set_message(f"{self.tool.name}: options reset to defaults.")

    # ------------------------------------------------------------------
    #  From the tool / app
    # ------------------------------------------------------------------
    def tool_changed(self):
        self._update_buttons()
        self.app.refresh_display()

    def _update_buttons(self):
        if self.btn_apply is not None and self.tool is not None:
            self.btn_apply.state(["!disabled"] if self.tool.result() is not None else ["disabled"])

    def new_input(self, img):
        if self.tool is not None:
            self.tool.set_input(img)
            self._update_buttons()

    def handle_wheel(self, path, e):
        """Wheel over the tool window (path = widget path under the pointer):
        scroll a list that scrolls itself, otherwise the window body."""
        if self.win is None or not path or not path.startswith(str(self.win)):
            return False
        for target, fn in self.tool.scroll_targets():
            if path.startswith(str(target)):
                fn(e)
                return True
        self.body.wheel(e)
        return True

    def save_state(self):
        if self.tool is None:
            return
        self.app.settings["tools"][self.tool.name] = dict(self.tool.opts)
        try:
            self.app.settings["popups"][self.tool.name] = self.win.geometry()
        except tk.TclError:
            pass
