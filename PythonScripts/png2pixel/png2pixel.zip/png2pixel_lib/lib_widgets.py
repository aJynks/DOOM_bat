"""png2pixel - shared widgets: scroll frame, number box, section header, dialogs."""
import tkinter as tk
from tkinter import ttk

from .lib_const import S, HEAD, SMALL


class ScrollFrame(ttk.Frame):
    """A vertically scrolling frame, like a web page: put widgets in .inner.
    The draggable scrollbar on the right edge only shows when the content is
    taller than the window; the mouse wheel scrolls it from anywhere inside."""

    STEP = 20       # pixels (before DPI scaling) per scroll unit; 3 units per wheel notch

    def __init__(self, parent):
        super().__init__(parent)
        bg = ttk.Style().lookup("TFrame", "background") or "#dcdad5"
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=bg, yscrollincrement=S(self.STEP))
        self.bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.bar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self._bar_shown = False
        self.inner = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._inner_changed)
        self.canvas.bind("<Configure>", self._canvas_changed)

    def _inner_changed(self, _e=None):
        self.canvas.configure(scrollregion=(0, 0, self.inner.winfo_reqwidth(), self.inner.winfo_reqheight()))
        self._update_bar()

    def _canvas_changed(self, e):
        self.canvas.itemconfigure(self._win, width=e.width)
        self._update_bar()

    def needs_scroll(self):
        return self.inner.winfo_reqheight() > self.canvas.winfo_height() + 1

    def _update_bar(self):
        need = self.needs_scroll()
        if need and not self._bar_shown:
            self.bar.pack(side="right", fill="y", before=self.canvas)
            self._bar_shown = True
        elif not need and self._bar_shown:
            self.bar.pack_forget()
            self._bar_shown = False
            self.canvas.yview_moveto(0)

    def wheel(self, e):
        if self.needs_scroll():
            self.canvas.yview_scroll(-3 if e.delta > 0 else 3, "units")


def section(parent, text):
    """A bold section heading with a rule under it."""
    f = ttk.Frame(parent)
    f.pack(fill="x", pady=(S(8), S(2)))
    ttk.Label(f, text=text, font=HEAD).pack(anchor="w")
    ttk.Separator(f).pack(fill="x", pady=(S(2), 0))
    return f


def note(parent, text, **kw):
    lab = ttk.Label(parent, text=text, font=SMALL, foreground="#666", wraplength=S(320), justify="left")
    lab.pack(anchor="w", **kw)
    return lab


class NumberBox(ttk.Spinbox):
    """A spinbox holding a float. on_change(value) fires on a valid edit."""

    def __init__(self, parent, value, lo, hi, step=1.0, on_change=None, width=7, decimals=2):
        self._var = tk.StringVar()
        self.lo, self.hi, self.decimals = lo, hi, decimals
        self._on_change = on_change
        self._quiet = False
        super().__init__(parent, from_=lo, to=hi, increment=step, textvariable=self._var, width=width)
        self.set(value)
        self._var.trace_add("write", self._edited)
        self.bind("<FocusOut>", lambda e: self.set(self.get_value()))
        self.bind("<Return>", lambda e: self.set(self.get_value()))

    def _fmt(self, v):
        s = f"{v:.{self.decimals}f}".rstrip("0").rstrip(".") if self.decimals else str(int(round(v)))
        return s or "0"

    def set(self, value, quiet=True):
        self._quiet = quiet
        self._var.set(self._fmt(value))
        self._quiet = False

    def get_value(self):
        try:
            v = float(self._var.get())
        except ValueError:
            return self.lo
        return min(self.hi, max(self.lo, v))

    def _edited(self, *_):
        if self._quiet or self._on_change is None:
            return
        try:
            v = float(self._var.get())
        except ValueError:
            return
        if self.lo <= v <= self.hi:
            self._on_change(v)


def ask_apply(parent, tool_name):
    """Apply / Discard / Cancel for an unapplied tool result."""
    top = tk.Toplevel(parent)
    top.title("Unapplied result")
    top.transient(parent)
    top.resizable(False, False)
    choice = {"v": "cancel"}

    body = ttk.Frame(top, padding=S(14))
    body.pack(fill="both", expand=True)
    ttk.Label(body, text=f"{tool_name} has a result that hasn't been applied.", font=HEAD).pack(anchor="w")
    ttk.Label(body, text="Apply it to the image, or discard it?").pack(anchor="w", pady=(S(4), S(12)))
    row = ttk.Frame(body)
    row.pack(anchor="e")

    def done(v):
        choice["v"] = v
        top.destroy()

    ttk.Button(row, text="Apply", command=lambda: done("apply")).pack(side="left", padx=S(3))
    ttk.Button(row, text="Discard", command=lambda: done("discard")).pack(side="left", padx=S(3))
    ttk.Button(row, text="Cancel", command=lambda: done("cancel")).pack(side="left", padx=S(3))
    top.bind("<Escape>", lambda e: done("cancel"))
    top.protocol("WM_DELETE_WINDOW", lambda: done("cancel"))

    top.update_idletasks()
    px, py = parent.winfo_rootx(), parent.winfo_rooty()
    pw, ph = parent.winfo_width(), parent.winfo_height()
    w, h = top.winfo_reqwidth(), top.winfo_reqheight()
    top.geometry(f"+{px + max(0, (pw - w) // 2)}+{py + max(0, (ph - h) // 3)}")
    top.grab_set()
    top.focus_set()
    parent.wait_window(top)
    return choice["v"]
