"""png2pixel - colour space conversions.

All RGB values here are floats 0..1 unless a name says 255. Hue is in degrees.
The *_np functions take numpy arrays (any shape) and return (..., 3) arrays.
"""
import colorsys

import numpy as np


# --------------------------------------------------------------------------
#  Hex
# --------------------------------------------------------------------------
def rgb255_to_hex(c):
    return "#{:02x}{:02x}{:02x}".format(*(int(v) for v in c[:3]))


def hex_to_rgb255(text):
    """'#rrggbb', 'rrggbb', '#rgb' or 'rgb' -> (r, g, b), else None."""
    t = text.strip().lstrip("#")
    if len(t) == 3:
        t = "".join(ch * 2 for ch in t)
    if len(t) != 6:
        return None
    try:
        return tuple(int(t[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return None


def to255(rgb):
    return tuple(int(round(min(1.0, max(0.0, v)) * 255)) for v in rgb)


def to01(rgb255):
    return tuple(v / 255.0 for v in rgb255[:3])


# --------------------------------------------------------------------------
#  HSV / HSL
# --------------------------------------------------------------------------
def rgb_to_hsv(rgb):
    h, s, v = colorsys.rgb_to_hsv(*rgb)
    return h * 360.0, s, v


def hsv_to_rgb(h, s, v):
    return colorsys.hsv_to_rgb((h % 360.0) / 360.0, s, v)


def rgb_to_hsl(rgb):
    h, l, s = colorsys.rgb_to_hls(*rgb)
    return h * 360.0, s, l


def hsl_to_rgb(h, s, l):
    return colorsys.hls_to_rgb((h % 360.0) / 360.0, l, s)


def hsv_to_rgb_np(h, s, v):
    h, s, v = np.broadcast_arrays(np.asarray(h, np.float32), np.asarray(s, np.float32), np.asarray(v, np.float32))
    h6 = (h % 360.0) / 60.0
    i = np.floor(h6).astype(np.int32) % 6
    f = h6 - np.floor(h6)
    p = v * (1 - s)
    q = v * (1 - s * f)
    t = v * (1 - s * (1 - f))
    r = np.choose(i, [v, q, p, p, t, v])
    g = np.choose(i, [t, v, v, q, p, p])
    b = np.choose(i, [p, p, t, v, v, q])
    return np.stack([r, g, b], axis=-1)


def hsl_to_rgb_np(h, s, l):
    h, s, l = np.broadcast_arrays(np.asarray(h, np.float32), np.asarray(s, np.float32), np.asarray(l, np.float32))
    c = (1 - np.abs(2 * l - 1)) * s
    h6 = (h % 360.0) / 60.0
    x = c * (1 - np.abs(h6 % 2 - 1))
    m = l - c / 2
    i = np.floor(h6).astype(np.int32) % 6
    z = np.zeros_like(c)
    r = np.choose(i, [c, x, z, z, x, c])
    g = np.choose(i, [x, c, c, x, z, z])
    b = np.choose(i, [z, z, x, c, c, x])
    return np.stack([r + m, g + m, b + m], axis=-1)


# --------------------------------------------------------------------------
#  OKLab / OKLCH  (L 0..1, C about 0..0.37, H degrees)
# --------------------------------------------------------------------------
def _srgb_to_linear(x):
    x = np.asarray(x, np.float64)
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def _linear_to_srgb(x):
    x = np.clip(x, 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1 / 2.4) - 0.055)


def rgb_to_oklch(rgb):
    r, g, b = (float(v) for v in _srgb_to_linear(rgb))
    l_ = (0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b) ** (1 / 3)
    m_ = (0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b) ** (1 / 3)
    s_ = (0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b) ** (1 / 3)
    L = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_
    a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_
    bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
    C = (a * a + bb * bb) ** 0.5
    H = (np.degrees(np.arctan2(bb, a)) + 360.0) % 360.0
    return L, C, float(H)


def oklch_to_rgb_np(L, C, H):
    """Returns (..., 3) sRGB clipped into gamut."""
    L, C, H = np.broadcast_arrays(np.asarray(L, np.float64), np.asarray(C, np.float64), np.asarray(H, np.float64))
    hr = np.radians(H)
    a, b = C * np.cos(hr), C * np.sin(hr)
    l_ = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3
    m_ = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3
    s_ = (L - 0.0894841775 * a - 1.2914855480 * b) ** 3
    r = 4.0767416621 * l_ - 3.3077115913 * m_ + 0.2309699292 * s_
    g = -1.2684380046 * l_ + 2.6097574011 * m_ - 0.3413193965 * s_
    bl = -0.0041960863 * l_ - 0.7034186147 * m_ + 1.7076147010 * s_
    return _linear_to_srgb(np.stack([r, g, bl], axis=-1))


def oklch_to_rgb(L, C, H):
    return tuple(float(v) for v in oklch_to_rgb_np(L, C, H))


# --------------------------------------------------------------------------
#  Adjustments (hue / saturation / lightness / contrast), done in OKLab so a
#  hue shift keeps lightness and lightness keeps hue
# --------------------------------------------------------------------------
def rgb_to_oklab_np(rgb01):
    lin = _srgb_to_linear(rgb01)
    r, g, b = lin[..., 0], lin[..., 1], lin[..., 2]
    l_ = np.cbrt(0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b)
    m_ = np.cbrt(0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b)
    s_ = np.cbrt(0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b)
    L = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_
    a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_
    bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
    return L, a, bb


def adjust_np(rgb255, hue=0.0, sat=0.0, light=0.0, contrast=0.0):
    """rgb255 (m,3) uint8 -> adjusted (m,3) uint8.
    hue: degrees, sat / light / contrast: -100..100"""
    if len(rgb255) == 0:
        return rgb255
    L, a, b = rgb_to_oklab_np(rgb255.astype(np.float64) / 255.0)
    C = np.hypot(a, b)
    H = np.degrees(np.arctan2(b, a)) + hue
    C = C * max(0.0, 1.0 + sat / 100.0)
    if light > 0:
        L = L + (1.0 - L) * (light / 100.0)
    elif light < 0:
        L = L * (1.0 + light / 100.0)
    if contrast:
        L = 0.5 + (L - 0.5) * (1.0 + contrast / 100.0)
    L = np.clip(L, 0.0, 1.0)
    out = oklch_to_rgb_np(L, C, H)
    return np.clip(np.round(out * 255.0), 0, 255).astype(np.uint8)
