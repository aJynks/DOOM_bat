"""png2pixel - remembered UI state: window, panels, popup positions, last folder.

Stored per machine in %APPDATA%\\png2pixel\\settings.json (monitor layouts
differ between machines, so this is deliberately not kept next to the script).
"""
import copy
import json
import os
import re

from .lib_const import APP, PANEL_KEYS

DEFAULTS = {
    "geometry": None,                       # main window "WxH+X+Y" (normal state)
    "zoomed": False,                        # main window maximised
    "panels": {k: True for k in PANEL_KEYS},
    "popups": {},                           # tool name -> window "WxH+X+Y"
    "tools": {},                            # tool name -> its remembered options
    "last_dir": "",                         # last folder an image was opened from
    "project_dir": "",                      # last project folder
    "export_dir": "",                       # last export folder
    "batch_in": "",                         # Process Folder input / output
    "batch_out": "",
    "batch_tc": True,                       # Process Folder: save true colour / paletted
    "batch_pal": True,
    "export_tc": True,                      # Export: save true colour / paletted
    "export_pal": True,
    "pal_options": {},                      # Pal0 matching / dither options (the palette itself
    "palette_dir": "",                      #   always starts as Doom 2; projects keep a custom one)
}


def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, APP, "settings.json")


class Settings:
    def __init__(self):
        self.path = settings_path()
        self.data = copy.deepcopy(DEFAULTS)
        self.load()

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except (OSError, ValueError):
            return
        if not isinstance(raw, dict):
            return
        for key, dv in DEFAULTS.items():
            v = raw.get(key, dv)
            if isinstance(dv, dict):
                if isinstance(v, dict):
                    merged = dict(dv)
                    merged.update(v)
                    self.data[key] = merged
            elif dv is None or isinstance(v, type(dv)):
                self.data[key] = v

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)
        except OSError:
            pass                            # remembering is best-effort

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value


# --------------------------------------------------------------------------
#  Geometry checks (a saved position may be on a monitor that isn't there)
# --------------------------------------------------------------------------
_GEOM = re.compile(r"^(\d+)x(\d+)([+-]-?\d+)([+-]-?\d+)$")


def parse_geometry(g):
    if not isinstance(g, str):
        return None
    m = _GEOM.match(g.strip())
    if not m:
        return None
    w, h = int(m.group(1)), int(m.group(2))
    x = int(m.group(3).replace("+-", "-").lstrip("+"))
    y = int(m.group(4).replace("+-", "-").lstrip("+"))
    return w, h, x, y


def virtual_screen(root):
    """(x, y, w, h) of the whole desktop across all monitors."""
    try:
        import ctypes
        u = ctypes.windll.user32
        return u.GetSystemMetrics(76), u.GetSystemMetrics(77), u.GetSystemMetrics(78), u.GetSystemMetrics(79)
    except Exception:
        return 0, 0, root.winfo_screenwidth(), root.winfo_screenheight()


def fit_to_screen(root, g, margin=60):
    """A "WxH+X+Y" geometry with its height cut down to the desktop and moved up
    if needed, so the whole window (and its bottom buttons) is on screen."""
    p = parse_geometry(g)
    if not p:
        return g
    w, h, x, y = p
    vx, vy, vw, vh = virtual_screen(root)
    try:
        sh = root.winfo_screenheight()
    except Exception:
        sh = vh
    maxh = max(200, min(vh, sh) - margin * 2)
    h = min(h, maxh)
    y = max(vy, min(y, vy + vh - h - margin))
    return f"{w}x{h}+{x}+{y}"


def geometry_on_screen(root, g):
    """The geometry string if its title bar lands on a monitor, else None."""
    p = parse_geometry(g)
    if not p:
        return None
    w, h, x, y = p
    vx, vy, vw, vh = virtual_screen(root)
    cx, cy = x + w // 2, y + 10
    if vx <= cx < vx + vw and vy <= cy < vy + vh and w > 50 and h > 50:
        return g
    return None
