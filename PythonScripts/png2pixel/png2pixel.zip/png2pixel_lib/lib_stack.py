"""png2pixel - the snapshot stack and project files.

The stack is the original image plus one layer per applied tool. Each layer
holds the tool's name, the settings it was applied with, its recorded hand
edits, and the resulting image. The top layer is what the view shows and what
the next tool works on.

Project file (.png2pixel) = a zip:
    project.json        version, source name, layers (tool, settings, edits)
    original.png        the opened image
    layers/001.png ...  each layer's result
"""
import io
import json
import os
import struct
import zipfile

from PIL import Image

from .lib_const import APP, VERSION

PROJECT_EXT = ".png2pixel"
FORMAT = 1


class Layer:
    def __init__(self, tool, opts, edits, image, label=None):
        self.tool = tool
        self.label = label or tool
        self.opts = dict(opts)
        self.edits = edits or {}
        self.image = image


class Stack:
    def __init__(self):
        self.original = None
        self.source_name = ""
        self.layers = []
        self.pal0 = None            # Pal0 settings read from a project file

    def reset(self, img, source_name=""):
        self.original = img
        self.source_name = source_name
        self.layers = []

    def top(self):
        return self.layers[-1].image if self.layers else self.original

    def push(self, tool, opts, edits, image, label=None):
        self.layers.append(Layer(tool, opts, edits, image, label))

    def pop(self):
        return self.layers.pop() if self.layers else None

    def rows(self):
        """[(number, label, size)] for the snapshot list."""
        if self.original is None:
            return []
        out = [(1, "Original", self.original.size)]
        for i, ly in enumerate(self.layers):
            out.append((i + 2, ly.label, ly.image.size))
        return out


# --------------------------------------------------------------------------
#  Project files
# --------------------------------------------------------------------------
def load_image(path):
    """Open any image Pillow reads as RGB, or RGBA when it has transparency."""
    im = Image.open(path)
    im.load()
    return _normalise(im)


def with_grab(dst, src):
    """Copy Doom offsets from src to dst (e.g. onto a paletted copy)."""
    g = src.info.get("grab") if hasattr(src, "info") else None
    if g:
        dst.info["grab"] = tuple(g)
    return dst


def _normalise(im):
    has_alpha = im.mode in ("RGBA", "LA", "PA") or "transparency" in im.info
    return im.convert("RGBA" if has_alpha else "RGB")


# --------------------------------------------------------------------------
#  Doom offsets: a PNG "grAb" chunk (two big-endian int32: x, y), read by
#  SLADE / SLumpEd / DoomTools. An image carries them as img.info["grab"].
# --------------------------------------------------------------------------
def _pnginfo(img):
    grab = img.info.get("grab") if hasattr(img, "info") else None
    if not grab:
        return None
    from PIL import PngImagePlugin
    pi = PngImagePlugin.PngInfo()
    pi.add(b"grAb", struct.pack(">ii", int(grab[0]), int(grab[1])))
    return pi


def save_png(img, fp, **kw):
    """img.save(fp, "PNG") that keeps Doom offsets (grAb) when the image has them."""
    pi = _pnginfo(img)
    if pi is not None:
        kw["pnginfo"] = pi
    img.save(fp, "PNG", **kw)


def read_grab(data):
    """Doom offsets from PNG bytes, or None."""
    i = data.find(b"grAb")
    if i < 4 or i + 12 > len(data):
        return None
    if struct.unpack(">I", data[i - 4:i])[0] != 8:
        return None
    return struct.unpack(">ii", data[i + 4:i + 12])


def _png_bytes(img):
    buf = io.BytesIO()
    save_png(img, buf, optimize=False)
    return buf.getvalue()


def save_project(path, stack, pal0=None):
    meta = {
        "app": APP, "app_version": VERSION, "format": FORMAT,
        "source_name": stack.source_name,
        "layers": [{"tool": ly.tool, "label": ly.label, "opts": ly.opts, "edits": ly.edits,
                    "image": f"layers/{i + 1:03d}.png"} for i, ly in enumerate(stack.layers)],
    }
    if pal0 is not None:
        meta["pal0"] = pal0
    tmp = path + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("project.json", json.dumps(meta, indent=1))
        z.writestr("original.png", _png_bytes(stack.original))
        for i, ly in enumerate(stack.layers):
            z.writestr(f"layers/{i + 1:03d}.png", _png_bytes(ly.image))
    os.replace(tmp, path)


def _open_png(z, name):
    data = z.read(name)
    im = Image.open(io.BytesIO(data))
    im.load()
    out = _normalise(im)
    g = read_grab(data)
    if g:
        out.info["grab"] = g
    return out


def load_project(path):
    """-> Stack (raises ValueError with a readable message on a bad file)"""
    try:
        with zipfile.ZipFile(path, "r") as z:
            meta = json.loads(z.read("project.json").decode("utf-8"))
            if meta.get("app") != APP:
                raise ValueError("not a png2pixel project")
            if int(meta.get("format", 0)) > FORMAT:
                raise ValueError("made by a newer png2pixel")
            st = Stack()
            st.reset(_open_png(z, "original.png"), meta.get("source_name", ""))
            st.pal0 = meta.get("pal0")
            for ly in meta.get("layers", []):
                st.push(ly["tool"], ly.get("opts", {}), ly.get("edits", {}), _open_png(z, ly["image"]),
                        ly.get("label"))
            return st
    except (zipfile.BadZipFile, KeyError, json.JSONDecodeError) as ex:
        raise ValueError(f"damaged or not a project file ({ex})")
