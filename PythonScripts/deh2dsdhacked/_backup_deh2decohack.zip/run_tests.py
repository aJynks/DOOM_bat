#!/usr/bin/env python3
"""
run_tests.py -- regression suite for the DEH/DECORATE -> DECOHack converter.

Covers:
  1. Flag-field resolution. DEH patches write flag fields either as a raw
     number or as mnemonics (WhackEd4 does the latter), plus several
     alternate spellings and a number-with-gloss form. A crash here was a
     real shipped bug, so every accepted form is pinned down.
  2. End-to-end conversion of each sample input without exceptions.
  3. DECORATE ground truth (delegates to test_decorate/verify_stock.py).

Run:  python run_tests.py
"""
import os
import subprocess
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from deh_ir import parse_deh
from deco_emitter import Tables, Emitter, convert

FAILS = []


def check(name, got, want):
    if got == want:
        print(f"  ok   {name}")
    else:
        print(f"  FAIL {name}: got {got!r}, want {want!r}")
        FAILS.append(name)


def test_flag_resolution(tables, sample_deh):
    print("\n[1] flag field resolution")
    ir = parse_deh(sample_deh)
    e = Emitter(ir, tables)
    cases = [
        # (raw value, namespace, expected int)
        ("NOBLOCKMAP+NOGRAVITY", "thing", 0x10 | 0x200),
        ("SOLID, SHOOTABLE", "thing", 0x2 | 0x4),
        ("SOLID SHOOTABLE", "thing", 0x2 | 0x4),
        ("262148 (SOLID+SHOOTABLE)", "thing", 262148),
        ("0", "thing", 0),
        ("", "thing", 0),
        (2147483648, "thing", 2147483648),
        ("TRANSLUCENT", "thing", 0x80000000),
        # documented alternate spellings
        ("NOTDEATHMATCH", "thing", 0x02000000),
        ("TRANSLATION", "thing", 0x04000000),
        ("UNUSED1", "thing", 0x08000000),
        ("UNUSED2", "thing", 0x10000000),
        ("UNUSED3", "thing", 0x20000000),
        ("FRIENDLY", "thing", 0x40000000),
        ("RANGEHALF+BOSS", "mbf21", 0x40 | 0x200),
        ("NOAUTOFIRE|SILENT", "weapon", 4 | 2),
        ("SKILL5FAST", "state", 1),
        # unknown mnemonics must degrade, not crash
        ("BOGUSFLAG+SOLID", "thing", 0x2),
    ]
    for value, kind, want in cases:
        try:
            got = e._resolve_bits(value, kind, "test")
        except Exception as exc:
            got = f"EXCEPTION {exc}"
        check(f"{kind}: {str(value)[:32]!r}", got, want)
    check("unknown mnemonic warns",
          any("BOGUSFLAG" in w for w in e.warnings), True)


def test_mnemonic_patch_matches_manual_math(tables, path):
    """Independently recompute every Bits field in a mnemonic-style patch."""
    print("\n[2] mnemonic patch resolves to the same bits as manual math")
    import re
    ir = parse_deh(path)
    Emitter(ir, tables)  # runs normalization
    table = {n: int(b) for b, n in tables.flags["doom"].items()}
    raw, cur = {}, None
    with open(path, encoding="latin-1") as f:
        for line in f:
            line = line.strip()
            m = re.match(r"^Thing (\d+)", line)
            if m:
                cur = int(m.group(1))
            m = re.match(r"^Bits = (.+)$", line)
            if m and cur is not None:
                raw[cur] = m.group(1).strip()
    bad = 0
    for num, text in raw.items():
        want = 0
        for tok in text.split("+"):
            tok = tok.strip()
            if tok and tok != "0":
                want |= table.get(tok, 0)
        if ir.things[num]["bits"] != want:
            bad += 1
    check(f"{len(raw)} Bits fields recomputed", bad, 0)


def test_conversions(paths):
    print("\n[3] end-to-end conversions")
    for path in paths:
        name = os.path.basename(path)
        if not os.path.isfile(path):
            print(f"  skip {name} (not present)")
            continue
        try:
            text = convert(path)
            check(f"convert {name}", bool(text.strip()), True)
        except Exception:
            print(f"  FAIL convert {name}:")
            traceback.print_exc()
            FAILS.append(f"convert {name}")


def test_decorate_ground_truth():
    print("\n[4] DECORATE ground truth vs vanilla tables")
    script = os.path.join(HERE, "test_decorate", "verify_stock.py")
    if not os.path.isfile(script):
        print("  skip (verify_stock.py not present)")
        return
    res = subprocess.run([sys.executable, script], capture_output=True, text=True)
    tail = [l for l in res.stdout.strip().split("\n") if "comparison" in l]
    print("  " + (tail[-1] if tail else "(no summary)"))
    if res.returncode != 0:
        FAILS.append("decorate ground truth")


def main():
    tables = Tables()
    samples = [
        os.path.join(HERE, "whacked_test.deh"),
        os.path.join(HERE, "D2DEHFIX.DEH"),
        os.path.join(HERE, "eviternity.deh"),
        os.path.join(HERE, "test_decorate", "stock_monsters.dec"),
    ]
    first_deh = next((p for p in samples if p.endswith((".deh", ".DEH"))
                      and os.path.isfile(p)), None)
    if first_deh:
        test_flag_resolution(tables, first_deh)
    whacked = os.path.join(HERE, "whacked_test.deh")
    if os.path.isfile(whacked):
        test_mnemonic_patch_matches_manual_math(tables, whacked)
    test_conversions(samples)
    test_decorate_ground_truth()

    print("\n" + "=" * 60)
    if FAILS:
        print(f"{len(FAILS)} FAILURE(S): " + ", ".join(FAILS))
        return 1
    print("all tests passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
