"""
deco_emitter.py
---------------
Stage 3 of the DEH -> DECOHack converter.

Takes the DehIR from deh_ir plus the base tables from ./data/ and emits
structured, human-readable DECOHack source targeting the `dsdhacked` patch
format (MBF21 feature set, dsda-doom).

Core ideas
==========
* The DEH file is a set of DELTAS against the engine base tables. We overlay
  those deltas onto DECOHack's own base state table to get the "effective"
  state table, then reconstruct labeled state blocks per thing/weapon by
  walking next-state chains from each entry point (spawn/see/pain/...).

* Reconstructed chains are emitted INSIDE thing blocks ("floating" states,
  reallocated freely by DECOHack) whenever that is provably safe. A state
  must instead be PINNED to its original index (emitted via top-level
  `state <N> { ... }` fill blocks, referenced by `state <label> <N>` /
  `goto <N>`) when its index identity matters:
    - referenced by more than one thing/weapon,
    - referenced by a STATE-type action pointer arg from outside the one
      thing that owns it,
    - referenced by the next-pointer of a state outside its owner chain,
    - or not reachable from any DEH-declared entry point at all (orphans -
      e.g. edits to vanilla states of things the DEH never declares).

* MBF-era pointers (A_Spawn, A_RandomJump, ...) read misc1/misc2; MBF21
  pointers read Args1-8. We keep one unified 8-slot arg array per state
  (base misc1/misc2 seed slots 0/1) and let the pointer's signature decide
  how many slots to read.
"""

import json
import os
import re
from collections import defaultdict

from deh_ir import DehIR

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

DEHEXTRA_STATE_START = 1089  # first "blank" extended state index
TNT1_SPRITE_INDEX = 138

# DEH thing frame fields -> DECOHack state label (emission order)
THING_LABELS = [
    ("initial_frame", "spawn"),
    ("first_moving_frame", "see"),
    ("close_attack_frame", "melee"),
    ("far_attack_frame", "missile"),
    ("injury_frame", "pain"),
    ("death_frame", "death"),
    ("exploding_frame", "xdeath"),
    ("respawn_frame", "raise"),
]
# NOTE: the DEH field names are crosswise to DECOHack's labels (verified
# empirically against DECOHack-compiled output): DEH "Select frame" is the
# A_Lower/downstate chain = DECOHack `deselect`, and DEH "Deselect frame"
# is the A_Raise/upstate chain = DECOHack `select`.
WEAPON_LABELS = [
    ("bobbing_frame", "ready"),
    ("select_frame", "deselect"),
    ("deselect_frame", "select"),
    ("shooting_frame", "fire"),
    ("firing_frame", "flash"),
]

# DEH thing property -> (decohack property, kind)
# kind: int | fixed16 | speed (fixed if missile) | sound | thing
THING_PROPS = [
    ("hit_points", "health", "int"),
    ("speed", "speed", "speed"),
    ("width", "radius", "fixed16"),
    ("height", "height", "fixed16"),
    ("missile_damage", "damage", "int"),
    ("reaction_time", "reactiontime", "int"),
    ("pain_chance", "painchance", "int"),
    ("mass", "mass", "int"),
    ("alert_sound", "seesound", "sound"),
    ("attack_sound", "attacksound", "sound"),
    ("pain_sound", "painsound", "sound"),
    ("death_sound", "deathsound", "sound"),
    ("action_sound", "activesound", "sound"),
    # Extended
    ("dropped_item", "dropitem", "thing"),
    # MBF21
    ("fast_speed", "fastspeed", "speed"),
    ("melee_range", "meleerange", "fixed16"),
    ("infighting_group", "infightinggroup", "int"),
    ("projectile_group", "projectilegroup", "int"),
    ("splash_group", "splashgroup", "int"),
    ("rip_sound", "ripsound", "sound"),
]

WEAPON_PROPS = [
    ("ammo_type", "ammotype", "int"),
    ("ammo_per_shot", "ammopershot", "int"),
    ("min_ammo", "minammo", "int"),
]

MISC_PROPS = [
    ("initial_health", "initialHealth"),
    ("initial_bullets", "initialBullets"),
    ("max_health", "maxHealth"),
    ("max_armor", "maxArmor"),
    ("green_armor_class", "greenArmorClass"),
    ("blue_armor_class", "blueArmorClass"),
    ("max_soulsphere", "maxSoulsphereHealth"),
    ("soulsphere_health", "soulsphereHealth"),
    ("megasphere_health", "megasphereHealth"),
    ("god_mode_health", "godModeHealth"),
    ("idfa_armor", "idfaArmor"),
    ("idfa_armor_class", "idfaArmorClass"),
    ("idkfa_armor", "idkfaArmor"),
    ("idkfa_armor_class", "idkfaArmorClass"),
    ("bfg_cells_shot", "bfgCellsPerShot"),
    ("monsters_infight", "monsterInfighting"),
]

# Alternate spellings for thing flag mnemonics that DEH patches may use.
# Editors differ: WhackEd4 writes mnemonics rather than a numeric bit field,
# and several bits have more than one accepted name (some are historical
# "UNUSEDn" names for bits that MBF later gave real meanings to). Verified
# against the project's Flags_Mnemonics reference.
THING_FLAG_ALIASES = {
    "NOTDEATHMATCH": "NOTDMATCH",
    "TRANSLATION": "TRANSLATION1",
    "UNUSED1": "TRANSLATION2",
    "UNUSED2": "TOUCHY",
    "UNUSED3": "BOUNCES",
    "UNUSED4": "FRIEND",
    "FRIENDLY": "FRIEND",
}

# MBF21 state ("Frame") flags.
STATE_FLAG_BITS = {"SKILL5FAST": 1}

MBF21_WEAPON_FLAGS = {
    1: "NOTHRUST", 2: "SILENT", 4: "NOAUTOFIRE", 8: "FLEEMELEE",
    16: "AUTOSWITCHFROM", 32: "NOAUTOSWITCHTO",
}

# MBF21 per-thing default flag words (deh thing number -> value).
# Derived from the MBF21 spec's vanilla-behavior replication; cyberdemon's
# value (303720) verified byte-identical against DECOHack's own tables.
MBF21_BASE_FLAGS = {
    4: 0x00086,    # Archvile: SHORTMRANGE|DMGIGNORED|NOTHRESHOLD
    6: 0x00140,    # Revenant: RANGEHALF|LONGMELEE
    9: 0x00400,    # Mancubus: MAP07BOSS1
    16: 0x01000,   # Baron of Hell: E1M8BOSS
    19: 0x00040,   # Lost Soul: RANGEHALF
    20: 0x54248,   # Spider Mastermind: NORADIUSDMG|RANGEHALF|BOSS|E3M8BOSS|E4M8BOSS|FULLVOLSOUNDS
    21: 0x00800,   # Arachnotron: MAP07BOSS2
    22: 0x4A268,   # Cyberdemon: NORADIUSDMG|HIGHERMPROB|RANGEHALF|BOSS|E2M8BOSS|E4M6BOSS|FULLVOLSOUNDS
}


def _load(name):
    with open(os.path.join(DATA, name)) as f:
        return json.load(f)


class Tables:
    def __init__(self):
        self.states = _load("states.json")          # list of dicts
        self.sprites = _load("sprites.json")        # list of names
        self.sounds = _load("sounds.json")          # list of names (0..114)
        self.mobjinfo = _load("mobjinfo.json")      # list of dicts
        self.pointers = _load("pointers.json")      # name -> sig
        self.flags = _load("flags.json")            # {"doom": bit->name, "mbf21": ...}
        self.strings = _load("strings.json")        # default text -> mnemonic
        # DECOHack's OWN built-in slot mnemonics (from its constants/*.dh
        # includes). These are the names `#include <dsdhacked>` provides, so
        # they are what generated output should refer to things/weapons by.
        self.aliases = _load("aliases.json")
        self.weaponinfo = _load("weaponinfo.json")
        # BEX codeptr names come without A_; build lookup
        self.ptr_by_bare = {k[2:].upper(): k for k in self.pointers}


class Emitter:
    def __init__(self, ir: DehIR, tables: Tables, complete: bool = False):
        self.complete = complete
        self.ir = ir
        self.t = tables
        self.warnings = []
        self.out = []

        # sprite renames (boom-style name->name in [SPRITES], old Text blocks)
        self.sprite_rename = {}
        self.sprite_by_index = {}   # dsdhacked numeric [SPRITES] entries
        for k, v in ir.sprites.items():
            if isinstance(k, int):
                self.sprite_by_index[k] = v
            else:
                self.sprite_rename[k.upper()] = v.upper()
        for old, new in ir.text_renames:
            if len(old) == 4 and len(new) == 4 and old.isupper():
                self.sprite_rename[old] = new.upper()

        self.sound_rename = {}
        self.sound_by_index = {}
        for k, v in ir.sound_names.items():
            if isinstance(k, int):
                self.sound_by_index[k] = v
            else:
                self.sound_rename[k.lower()] = v.lower()

        self._normalize_flag_fields()
        self._build_effective_states()

    # ------------------------------------------------------------------
    # Effective state table
    # ------------------------------------------------------------------

    def _blank_state(self, i):
        return {"sprite": TNT1_SPRITE_INDEX, "frame": 0, "bright": False,
                "tics": -1, "next": i, "args": [0] * 8, "mbfflags": 0,
                "action": None}

    # ------------------------------------------------------------------
    # Flag field normalization
    # ------------------------------------------------------------------

    def _bit_lookup(self, kind):
        """name -> bit value, for a given flag namespace."""
        if kind == "thing":
            table = {n: int(b) for b, n in self.t.flags["doom"].items()}
            for alias, real in THING_FLAG_ALIASES.items():
                if real in table:
                    table[alias] = table[real]
            return table
        if kind == "mbf21":
            return {n: int(b) for b, n in self.t.flags["mbf21"].items()}
        if kind == "weapon":
            return {n: b for b, n in MBF21_WEAPON_FLAGS.items()}
        if kind == "state":
            return dict(STATE_FLAG_BITS)
        return {}

    def _resolve_bits(self, value, kind, where):
        """Turn a DEH bits field into an integer.

        DEH patches express flag fields either as a raw number or as a list of
        mnemonics -- WhackEd4 writes the latter (`Bits = NOBLOCKMAP+NOGRAVITY`),
        and some editors write a number with a parenthetical gloss
        (`Bits = 262148 (SOLID+SHOOTABLE)`). Separators seen in the wild are
        '+', ',' and whitespace.
        """
        if value is None or isinstance(value, int):
            return value
        text = str(value).strip()
        if not text:
            return 0

        # number, optionally followed by a parenthetical mnemonic gloss
        m = re.match(r"^(-?\d+)\s*(?:\(.*\))?$", text)
        if m:
            return int(m.group(1))

        table = self._bit_lookup(kind)
        total, unknown = 0, []
        for token in re.split(r"[+,\s|]+", text):
            token = token.strip().upper()
            if not token or token == "0":
                continue
            if token in table:
                total |= table[token]
            elif re.fullmatch(r"-?\d+", token):
                total |= int(token)
            else:
                unknown.append(token)
        if unknown:
            self.warn(f"{where}: unrecognized flag mnemonic(s) "
                      f"{', '.join(unknown)} -- ignored; check the output's "
                      f"flags against the original patch")
        return total

    def _normalize_flag_fields(self):
        """Resolve every mnemonic flag field in the IR to an integer.

        Done once up front so the rest of the emitter can treat these as
        numbers; several code paths (flag emission, and the MISSILE check that
        decides whether Speed is fixed-point) index into them arithmetically.
        """
        for num, d in self.ir.things.items():
            if "bits" in d:
                d["bits"] = self._resolve_bits(d["bits"], "thing", f"thing {num} Bits")
            if "mbf21_bits" in d:
                d["mbf21_bits"] = self._resolve_bits(
                    d["mbf21_bits"], "mbf21", f"thing {num} MBF21 Bits")
        for num, d in self.ir.weapons.items():
            if "mbf21_bits" in d:
                d["mbf21_bits"] = self._resolve_bits(
                    d["mbf21_bits"], "weapon", f"weapon {num} MBF21 Bits")
        for num, f in self.ir.frames.items():
            if "mbf21_bits" in f:
                f["mbf21_bits"] = self._resolve_bits(
                    f["mbf21_bits"], "state", f"frame {num} MBF21 Bits")

    def _build_effective_states(self):
        self.eff = {}
        self.modified = set()

        base_len = len(self.t.states)
        touched = set(self.ir.frames) | set(self.ir.codeptr)
        for i in touched:
            if i < base_len:
                b = self.t.states[i]
                st = {"sprite": b["sprite"], "frame": b["frame"] & 0x7FFF,
                      "bright": b["bright"] or bool(b["frame"] & 0x8000),
                      "tics": b["tics"], "next": b["next"],
                      "args": [b.get("misc1", 0), b.get("misc2", 0), 0, 0, 0, 0, 0, 0],
                      "mbfflags": b.get("mbfflags", 0),
                      "action": b.get("action")}
            else:
                st = self._blank_state(i)

            f = self.ir.frames.get(i, {})
            if "sprite_number" in f:
                st["sprite"] = f["sprite_number"]
            if "sprite_subnumber" in f:
                sub = f["sprite_subnumber"]
                st["frame"] = sub & 0x7FFF
                st["bright"] = bool(sub & 0x8000)
            if "duration" in f:
                st["tics"] = f["duration"]
            if "next_frame" in f:
                st["next"] = f["next_frame"]
            if "mbf21_bits" in f:
                st["mbfflags"] = f["mbf21_bits"]
            if "args" in f:
                for slot, val in enumerate(f["args"]):
                    if val is not None:
                        st["args"][slot] = val
            if i in self.ir.codeptr:
                bare = self.ir.codeptr[i].upper()
                if bare in ("NULL", ""):
                    st["action"] = None
                else:
                    ptr = self.t.ptr_by_bare.get(bare)
                    if ptr is None:
                        self.warn(f"Frame {i}: unknown codepointer '{self.ir.codeptr[i]}' kept verbatim")
                        ptr = "A_" + self.ir.codeptr[i]
                    st["action"] = ptr

            self.eff[i] = st
            self.modified.add(i)

    def base_state(self, i):
        """Effective view of an UNMODIFIED base state (for chain walking)."""
        if i in self.eff:
            return self.eff[i]
        if i < len(self.t.states):
            b = self.t.states[i]
            return {"sprite": b["sprite"], "frame": b["frame"] & 0x7FFF,
                    "bright": b["bright"] or bool(b["frame"] & 0x8000),
                    "tics": b["tics"], "next": b["next"],
                    "args": [b.get("misc1", 0), b.get("misc2", 0), 0, 0, 0, 0, 0, 0],
                    "mbfflags": b.get("mbfflags", 0), "action": b.get("action")}
        return self._blank_state(i)

    # ------------------------------------------------------------------
    # Name resolution helpers
    # ------------------------------------------------------------------

    def sprite_name(self, idx):
        if idx < len(self.t.sprites):
            name = self.t.sprites[idx]
        elif idx in self.sprite_by_index:
            name = self.sprite_by_index[idx]
        else:
            self.warn(f"sprite index {idx} has no name (missing [SPRITES] entry?); using XX{idx % 100:02d}")
            name = f"XX{idx % 100:02d}"
        return self.sprite_rename.get(name, name)

    def sound_name(self, idx):
        if idx == 0:
            return None
        if idx < len(self.t.sounds):
            name = self.t.sounds[idx]
        elif 500 <= idx <= 699:
            name = "fre%03d" % (idx - 500)
        elif idx in self.sound_by_index:
            name = self.sound_by_index[idx]
        else:
            self.warn(f"sound index {idx} out of known range; emitted as fre-style guess")
            return None
        return self.sound_rename.get(name, name)

    def thing_display_name(self, num):
        """Priority: the patch's own declared name (explicit modder intent) ->
        DECOHack's built-in slot alias -> engine enum name -> bare fallback."""
        if num in self.ir.things_names:
            return self.ir.things_names[num]
        return self.thing_alias(num)

    def thing_alias(self, num):
        """DECOHack's built-in mnemonic for a thing slot, ignoring any name
        the patch itself declared."""
        alias = self.t.aliases.get("things", {}).get(str(num))
        if alias:
            return alias
        if 1 <= num <= len(self.t.mobjinfo):
            # Upstream DoomTools has at least one duplicated #define (slot 128
            # is both MT_MISC77 and MT_MISC78), which leaves a gap; the engine
            # enum name is the correct intended value in that case.
            return self.t.mobjinfo[num - 1]["name"]
        return f"Thing{num}"

    def weapon_display_name(self, num):
        if num in self.ir.weapons_names:
            return self.ir.weapons_names[num]
        return self.weapon_alias(num)

    def weapon_alias(self, num):
        alias = self.t.aliases.get("weapons", {}).get(str(num))
        if alias:
            return alias
        if 0 <= num < len(self.t.weaponinfo):
            return self.t.weaponinfo[num]["name"]
        return f"Weapon{num}"

    def base_thing(self, num):
        if 1 <= num <= len(self.t.mobjinfo):
            return self.t.mobjinfo[num - 1]
        return {}

    def warn(self, msg):
        self.warnings.append(msg)

    # ------------------------------------------------------------------
    # Base-table state ownership
    # ------------------------------------------------------------------

    BASE_THING_ENTRIES = [
        ("spawnstate", "spawn"), ("seestate", "see"), ("meleestate", "melee"),
        ("missilestate", "missile"), ("painstate", "pain"),
        ("deathstate", "death"), ("xdeathstate", "xdeath"),
        ("raisestate", "raise"),
    ]
    # DECOHack label names for the vanilla weapon state entry points.
    # upstate = weapon being raised = DECOHack `select`;
    # downstate = being lowered = DECOHack `deselect`.
    BASE_WEAPON_ENTRIES = [
        ("readystate", "ready"), ("downstate", "deselect"),
        ("upstate", "select"), ("atkstate", "fire"),
        ("holdatkstate", "fire (hold)"), ("flashstate", "flash"),
    ]

    def build_base_ownership(self):
        """Map every base state index to the vanilla thing/weapon whose default
        state chains reach it, and which entry label it sits under.

        This is what lets a states-only patch (one that edits Frame blocks but
        never declares the owning Thing) still say which actor each edited
        state actually belongs to.
        """
        self.base_owner = defaultdict(list)   # state -> [(dist, kind, num, label)]

        def walk(start, kind, num, label):
            cur, dist, seen = start, 0, set()
            while cur and cur not in seen and dist < 4000:
                seen.add(cur)
                self.base_owner[cur].append((dist, kind, num, label))
                nxt = self.base_state(cur)["next"]
                if nxt == cur:
                    break
                cur = nxt
                dist += 1

        for i, m in enumerate(self.t.mobjinfo):
            for field, label in self.BASE_THING_ENTRIES:
                start = m.get(field, 0)
                if isinstance(start, int) and start:
                    walk(start, "thing", i + 1, label)
        for wnum, w in enumerate(self.t.weaponinfo):
            for field, label in self.BASE_WEAPON_ENTRIES:
                start = w.get(field, 0)
                if isinstance(start, int) and start:
                    walk(start, "weapon", wnum, label)

    def base_owner_of(self, state):
        """Best guess owner of a base state: the entry chain that reaches it
        soonest wins; ties broken by lowest slot. Returns (text, extra_count)
        or (None, 0)."""
        recs = self.base_owner.get(state)
        if not recs:
            return None, 0
        recs = sorted(recs, key=lambda r: (r[0], r[1] != "thing", r[2]))
        dist, kind, num, label = recs[0]
        distinct = {(k, n) for _d, k, n, _l in recs}
        if kind == "thing":
            text = f"thing {num} ({self.thing_alias(num)}) {label} states"
        else:
            text = f"weapon {num} ({self.weapon_alias(num)}) {label} states"
        return text, len(distinct) - 1

    # ------------------------------------------------------------------
    # Ownership / pinning analysis
    # ------------------------------------------------------------------

    def touched_owners(self):
        """Every thing/weapon the patch affects: declared outright, or owning
        a state the patch modifies."""
        out = set()
        for num in self.ir.things:
            out.add(("thing", num))
        for num in self.ir.weapons:
            out.add(("weapon", num))
        for s in self.modified:
            for _dist, kind, num, _label in self.base_owner.get(s, []):
                out.add((kind, num))
        return out

    def _entry_state(self, kind, num, label):
        """Where a chain starts, patch value winning over the vanilla value.

        This mirrors what the engine does at load time: a DEH patch is an
        overlay, so any entry the patch does not touch keeps its Doom 2 value.
        """
        if kind == "thing":
            d = self.ir.things.get(num, {})
            deh_field = next((f for f, l in THING_LABELS if l == label), None)
            if deh_field and deh_field in d:
                return d[deh_field]
            base_field = next((f for f, l in self.BASE_THING_ENTRIES if l == label), None)
            base = self.base_thing(num)
            val = base.get(base_field, 0) if base_field else 0
            return val if isinstance(val, int) else 0
        d = self.ir.weapons.get(num, {})
        deh_field = next((f for f, l in WEAPON_LABELS if l == label), None)
        if deh_field and deh_field in d:
            return d[deh_field]
        base_field = next((f for f, l in self.BASE_WEAPON_ENTRIES if l == label), None)
        if base_field and 0 <= num < len(self.t.weaponinfo):
            val = self.t.weaponinfo[num].get(base_field, 0)
            return val if isinstance(val, int) else 0
        return 0

    def analyze(self):
        # entry points: (owner_key, label, state)
        self.entries = []
        if self.complete:
            # Rebuild each affected thing/weapon in full, taking entry points
            # from the patch where it sets them and from Doom 2 otherwise.
            for kind, num in sorted(self.touched_owners()):
                labels = ([l for _f, l in THING_LABELS] if kind == "thing"
                          else [l for _f, l in WEAPON_LABELS])
                for label in labels:
                    start = self._entry_state(kind, num, label)
                    if start:
                        self.entries.append(((kind, num), label, start))
        else:
            for num in sorted(self.ir.things):
                for field, label in THING_LABELS:
                    if field in self.ir.things[num]:
                        self.entries.append((("thing", num), label, self.ir.things[num][field]))
            for num in sorted(self.ir.weapons):
                for field, label in WEAPON_LABELS:
                    if field in self.ir.weapons[num]:
                        self.entries.append((("weapon", num), label, self.ir.weapons[num][field]))

        # Walk chains from every entry, recording owners per modified state.
        owners = defaultdict(set)
        for owner, _label, start in self.entries:
            for s in self._chain_states(start):
                owners[s].add(owner)

        # STATE-typed pointer args: record referencing owner (or None if
        # the referencing state is itself unowned).
        state_arg_refs = defaultdict(set)   # target -> set(referencing state idx)
        for i in self.modified:
            st = self.eff[i]
            if not st["action"]:
                continue
            sig = self.t.pointers.get(st["action"], {}).get("params", [])
            for slot, ptype in enumerate(sig):
                if ptype == "STATE" and st["args"][slot]:
                    state_arg_refs[st["args"][slot]].add(i)

        # Fixpoint: a jump-target chain reachable ONLY through STATE args of
        # states owned by exactly one thing belongs to that thing. This lets
        # A_RandomJump / A_HealChase / A_JumpIf* decision sub-chains float
        # inside the owner's states block with synthesized labels instead of
        # being pinned by index.
        self.pseudo_entries = defaultdict(list)   # owner -> [target state]
        changed = True
        while changed:
            changed = False
            for tgt, refs in list(state_arg_refs.items()):
                if tgt in owners or tgt not in self.modified or tgt == 0:
                    continue
                ref_owners = set()
                for r in refs:
                    ref_owners |= owners.get(r, set())
                if len(ref_owners) == 1:
                    owner = next(iter(ref_owners))
                    for s in self._chain_states(tgt):
                        owners[s].add(owner)
                    self.pseudo_entries[owner].append(tgt)
                    changed = True

        # next-references between states (for cross-chain pinning)
        candidates = set(self.modified)
        if self.complete:
            candidates |= set(owners)
        next_refs = defaultdict(set)
        for i in candidates:
            nxt = self.base_state(i)["next"]
            if nxt in candidates and nxt != i:
                next_refs[nxt].add(i)

        self.pinned = set()
        for s in candidates:
            owns = owners.get(s, set())
            if len(owns) == 0:
                self.pinned.add(s)                       # orphan
            elif len(owns) > 1:
                self.pinned.add(s)                       # shared
            else:
                owner = next(iter(owns))
                # state-arg reference from a state not owned by same owner?
                for ref in state_arg_refs.get(s, ()):
                    if owners.get(ref, set()) != {owner}:
                        self.pinned.add(s)
                        break
                else:
                    # next-reference from outside the owner's own states
                    for ref in next_refs.get(s, ()):
                        if owners.get(ref, set()) != {owner}:
                            self.pinned.add(s)
                            break

        self.owners = owners
        self.state_arg_refs = state_arg_refs
        if self.complete:
            self._pin_engine_constrained(owners)

    # States whose index the engine computes arithmetically rather than
    # following a next-pointer. Verified in dsda-doom's p_pspr.c:
    #   A_FireSomething(player, adder) sets ps_flash to flashstate + adder
    #   A_FirePlasma passes P_Random & 1        -> uses flashstate and +1
    #   A_FireCGun  passes psp->state - &states[S_CHAIN1]
    #                                           -> offset from HARDCODED 52
    # So a plasma-style flash pair must stay adjacent, and a chaingun-style
    # fire chain must stay at its original indices or the subtraction yields
    # a wild offset.
    S_CHAIN1 = 52
    FLASH_PAIR_POINTERS = {"A_FirePlasma"}
    FIRE_INDEX_POINTERS = {"A_FireCGun"}

    def _pin_engine_constrained(self, owners):
        self.engine_pin_reason = {}

        def pin(state, reason):
            if state and (state < len(self.t.states) or state in self.modified):
                self.pinned.add(state)
                self.engine_pin_reason.setdefault(state, reason)

        # A modified state that more than one VANILLA actor can reach must keep
        # its index. The patch edits it in place, so every actor sharing it sees
        # the change; floating it into one owner's block would silently leave
        # the others on the original vanilla behavior.
        for s in self.modified:
            base_owners = {(k, n) for _d, k, n, _l in self.base_owner.get(s, [])}
            if len(base_owners) > 1:
                pin(s, "shared by " + ", ".join(
                    f"{k} {n}" for k, n in sorted(base_owners))
                    + " in vanilla, so the edit must stay at this index")

        for kind, num in sorted(self.touched_owners()):
            if kind != "weapon":
                continue
            fire = self._entry_state("weapon", num, "fire")
            flash = self._entry_state("weapon", num, "flash")
            ptrs = {self.base_state(s).get("action")
                    for s in self._chain_states(fire)} if fire else set()

            if ptrs & self.FLASH_PAIR_POINTERS and flash:
                pin(flash, "A_FirePlasma picks flashstate or flashstate+1 at "
                           "random, so these two must stay adjacent")
                pin(flash + 1, "second half of the A_FirePlasma flash pair")
            if ptrs & self.FIRE_INDEX_POINTERS:
                # Only the states between the fire entry and the last
                # A_FireCGun call need their original indices; stop before
                # running back into another label's chain (the vanilla fire
                # chain ends by looping to ready).
                others = {self._entry_state("weapon", num, l)
                          for _f, l in WEAPON_LABELS if l != "fire"}
                chain = []
                for s in self._chain_states(fire):
                    if s in others:
                        break
                    chain.append(s)
                last_call = max((i for i, s in enumerate(chain)
                                 if self.base_state(s).get("action")
                                 in self.FIRE_INDEX_POINTERS), default=-1)
                for s in chain[:last_call + 1] or chain:
                    pin(s, f"A_FireCGun derives its flash offset from state "
                           f"index {self.S_CHAIN1}, so this weapon keeps its "
                           f"original state indices")
                if flash:
                    pin(flash, "A_FireCGun indexes flashstate + offset")
                    pin(flash + 1, "second half of the A_FireCGun flash pair")
                # Once any of a weapon's states must stay at a fixed index,
                # the rest have to as well: a pinned block can only hand off
                # to another state by index, so a half-floating chain would
                # leave the tail unreachable.
                for s, owns in owners.items():
                    if (kind, num) in owns:
                        pin(s, f"kept with the rest of weapon {num}, which is "
                               f"index-locked by A_FireCGun")

    def _chain_states(self, start):
        """States belonging to a chain starting at `start`.

        Default mode follows only modified states, since untouched vanilla
        states need no re-emission. Complete mode walks the whole chain,
        because the goal there is to restate the actor in full.
        """
        seen = []
        cur = start
        visited = set()
        while cur not in visited:
            visited.add(cur)
            if cur == 0:
                break
            if not self.complete and cur not in self.modified:
                break
            if self.complete and cur >= len(self.t.states) and cur not in self.modified:
                break
            seen.append(cur)
            cur = self.base_state(cur)["next"]
        return seen

    # ------------------------------------------------------------------
    # Rendering primitives
    # ------------------------------------------------------------------

    @staticmethod
    def frame_letter(sub):
        return chr(ord("A") + sub)

    @staticmethod
    def fmt_fixed(v):
        if v % 65536 == 0:
            return "%d.0" % (v // 65536)
        # shortest decimal that round-trips back to the exact fixed value
        for nd in range(1, 6):
            d = round(v / 65536.0, nd)
            if int(round(d * 65536)) == v:
                s = ("%%.%df" % nd) % d
                return s.rstrip("0").rstrip(".") if "." in s else s
        return repr(v / 65536.0)

    def fmt_arg(self, ptype, value, ctx):
        if ptype in ("FIXED", "ANGLEFIXED"):
            return self.fmt_fixed(value)
        if ptype == "SOUND":
            name = self.sound_name(value)
            return f'"{name}"' if name else "0"
        if ptype in ("THING", "THINGMISSILE"):
            if value:
                name = self.thing_display_name(value)
                if not name.startswith("Thing"):
                    ctx.setdefault("comments", []).append(
                        f"thing {value} = {name}")
            return str(value)
        if ptype == "STATE":
            return self._state_ref(value, ctx)
        return str(value)

    def _state_ref(self, target, ctx):
        """Resolve a STATE pointer arg to a label (same thing) or raw index."""
        labels = ctx.get("labels", {})
        if target in labels:
            return labels[target]
        multi = ctx.get("multi", {})
        if target in multi and multi[target]:
            return multi[target][0]
        if target in self.modified and target not in self.pinned:
            # modified but floating and not label-resolvable here: this should
            # not happen if analysis was right; fall back with a warning
            self.warn(f"STATE arg -> {target}: floating state referenced by "
                      f"index; behavior may break (pin analysis gap)")
        return str(target)

    def render_state_line(self, idx, ctx, letters=None):
        st = self.eff[idx] if idx in self.eff else self.base_state(idx)
        parts = [self.sprite_name(st["sprite"])]
        parts.append(letters or self.frame_letter(st["frame"]))
        parts.append(str(st["tics"]))
        if st["bright"]:
            parts.append("Bright")
        if st["mbfflags"] & 1:
            parts.append("Fast")
        if st["action"]:
            sig = self.t.pointers.get(st["action"], {}).get("params", [])
            if sig:
                argstrs = [self.fmt_arg(pt, st["args"][i], ctx)
                           for i, pt in enumerate(sig)]
                # trim trailing zero-ish args for readability
                while argstrs and argstrs[-1] in ("0", "0.0"):
                    argstrs.pop()
                call = st["action"]
                if argstrs:
                    call += "(" + ", ".join(argstrs) + ")"
                parts.append(call)
            else:
                parts.append(st["action"])
                # non-parameterized pointer with stray misc values = Offset
                if st["args"][0] or st["args"][1]:
                    parts.append(f"Offset({st['args'][0]}, {st['args'][1]})")
        elif st["args"][0] or st["args"][1]:
            parts.append(f"Offset({st['args'][0]}, {st['args'][1]})")
        comment = ""
        if ctx.get("comments"):
            comment = "\t// " + "; ".join(ctx.pop("comments"))
        return "\t\t" + " ".join(parts) + comment

    # ------------------------------------------------------------------
    # Chain emission inside a thing/weapon block
    # ------------------------------------------------------------------

    def emit_states_block(self, owner, label_entries):
        """
        label_entries: list of (label, start_state).
        Returns (lines, used_raw_assignments) where lines is the states {}
        body, and used_raw_assignments is a list of (label, index) pairs for
        entries that point at pinned/unmodified states.
        """
        raw_assign = []
        chains = {}          # label -> [state indices]
        claimed = {}         # state -> label owning its rendering

        # Phase A: build chains
        for label, start in label_entries:
            if start == 0:
                raw_assign.append((label, 0))
                continue
            if start in self.pinned or (not self.complete
                                        and start not in self.modified):
                raw_assign.append((label, start))
                continue
            if start in claimed:
                # label aliases another label's chain start or middle
                chains[label] = []
                continue
            seq = []
            cur = start
            while ((cur in self.modified or self.complete)
                   and cur not in self.pinned
                   and cur not in claimed and cur not in seq and cur != 0):
                if self.complete and cur >= len(self.t.states) \
                        and cur not in self.modified:
                    break
                seq.append(cur)
                nxt = self.base_state(cur)["next"]
                if nxt == cur:
                    break
                cur = nxt
            for s in seq:
                claimed[s] = label
            chains[label] = seq

        # Phase B: compute needed synthetic labels (goto targets mid-chain
        # + STATE-arg targets inside this owner's chains)
        labels = {}          # state index -> primary label name
        multi = {}           # state index -> [additional stacked labels]
        for label, start in label_entries:
            if chains.get(label):
                if chains[label][0] in labels:
                    multi.setdefault(chains[label][0], []).append(label)
                else:
                    labels[chains[label][0]] = label

        synth_needed = set()
        all_owned = set(claimed)
        for label, seq in chains.items():
            if not seq:
                continue
            last = seq[-1]
            nxt = self.base_state(last)["next"]
            if nxt != last and nxt in all_owned and nxt not in labels:
                synth_needed.add(nxt)
        for i in all_owned:
            st = self.base_state(i)
            if st["action"]:
                sig = self.t.pointers.get(st["action"], {}).get("params", [])
                for slot, ptype in enumerate(sig):
                    if ptype == "STATE":
                        tgt = st["args"][slot]
                        if tgt in all_owned and tgt not in labels:
                            synth_needed.add(tgt)
        for s in sorted(synth_needed):
            labels[s] = f"st{s}"

        # entries that landed on states claimed by an earlier label:
        # stack the label at that state (rendered as an extra 'label:' line)
        for label, start in label_entries:
            if not chains.get(label) and start in claimed:
                multi.setdefault(start, [])
                if label not in multi[start]:
                    multi[start].append(label)

        # Phase C: render
        ctx = {"labels": labels, "multi": multi}
        lines = []
        label_order = [l for l, s in label_entries if chains.get(l)]
        for label in label_order:
            seq = chains[label]
            if not seq:
                continue
            lines.append(f"\t{label}:")
            for extra in multi.get(seq[0], []):
                if extra != label:
                    lines.append(f"\t{extra}:")
            i = 0
            while i < len(seq):
                idx = seq[i]
                if i > 0:
                    if idx in labels and labels[idx] != label:
                        lines.append(f"\t{labels[idx]}:")
                    for extra in multi.get(idx, []):
                        lines.append(f"\t{extra}:")
                # letter-run compression
                run = [idx]
                j = i + 1
                while j < len(seq):
                    a, b = self.base_state(seq[j - 1]), self.base_state(seq[j])
                    if (self.base_state(seq[j-1])["next"] == seq[j]
                            and seq[j] not in labels
                            and seq[j] not in multi
                            and seq[j] not in self.state_arg_refs
                            and a["sprite"] == b["sprite"]
                            and a["tics"] == b["tics"]
                            and a["bright"] == b["bright"]
                            and a["mbfflags"] == b["mbfflags"]
                            and a["action"] == b["action"]
                            and a["args"] == b["args"]):
                        run.append(seq[j]); j += 1
                    else:
                        break
                letters = "".join(self.frame_letter(self.base_state(s)["frame"]) for s in run)
                lines.append(self.render_state_line(idx, ctx, letters=letters))
                i = j

            # terminator
            last = seq[-1]
            st = self.base_state(last)
            nxt = st["next"]
            if nxt == last:
                if st["tics"] < 0:
                    lines.append("\t\tstop")
                elif last == seq[0]:
                    lines.append("\t\tloop")   # single-state self-loop
                else:
                    lines.append("\t\twait")
            elif nxt == 0:
                lines.append("\t\tstop")
            elif nxt in labels:
                if nxt == seq[0] and labels[nxt] == label:
                    lines.append("\t\tloop")
                else:
                    lines.append(f"\t\tgoto {labels[nxt]}")
            elif nxt == 1:
                lines.append("\t\tgoto LightDone")
            else:
                note = ""
                if nxt not in self.modified and nxt < len(self.t.states):
                    note = f"\t// -> base state {nxt}"
                elif nxt in self.pinned:
                    note = f"\t// -> pinned state {nxt}"
                lines.append(f"\t\tgoto {nxt}{note}")
        return lines, raw_assign

    # ------------------------------------------------------------------
    # Block emitters
    # ------------------------------------------------------------------

    # Which mobjinfo field backs each DEH thing property, for restating a
    # thing in full from the vanilla table plus the patch's deltas.
    THING_PROP_BASE = {
        "hit_points": "spawnhealth", "speed": "speed", "width": "radius",
        "height": "height", "missile_damage": "damage",
        "reaction_time": "reactiontime", "pain_chance": "painchance",
        "mass": "mass", "alert_sound": "seesound",
        "attack_sound": "attacksound", "pain_sound": "painsound",
        "death_sound": "deathsound", "action_sound": "activesound",
    }

    def _complete_thing_props(self, d, base, num):
        """Every property of a thing, patch value winning over the Doom 2 value.

        MBF21-only properties are emitted only when the patch sets them, since
        vanilla has no value to restate and DECOHack already supplies the
        correct MBF21 defaults.
        """
        out = []
        for deh_key, prop, kind in THING_PROPS:
            if deh_key in d:
                out.append(self._prop_line(prop, kind, d[deh_key], d, base, num))
                continue
            base_field = self.THING_PROP_BASE.get(deh_key)
            if not base_field:
                continue                      # MBF21-only, nothing to restate
            v = base.get(base_field, 0)
            if not isinstance(v, int):
                continue
            if kind == "sound" and v == 0:
                continue                      # no sound is the default
            out.append(self._prop_line(prop, kind, v, d, base, num))
        return out

    # dsda's weaponinfo stores the ammo type as an enum name. DECOHack's
    # ammotype takes the numeric value: ammotype_t is
    # { am_clip, am_shell, am_cell, am_misl, NUMAMMO, am_noammo }.
    AMMO_ENUM = {"am_clip": 0, "am_shell": 1, "am_cell": 2, "am_misl": 3,
                 "am_noammo": 5}

    def _complete_weapon_props(self, d, num):
        out = []
        base = self.t.weaponinfo[num] if 0 <= num < len(self.t.weaponinfo) else {}
        if "ammo_type" in d:
            out.append(f"\tammotype {d['ammo_type']}")
        else:
            ammo = base.get("ammo")
            if isinstance(ammo, str):
                ammo = self.AMMO_ENUM.get(ammo)
            if isinstance(ammo, int):
                out.append(f"\tammotype {ammo}")
        if "ammo_per_shot" in d:
            out.append(f"\tammopershot {d['ammo_per_shot']}")
        elif isinstance(base.get("ammopershot"), int):
            out.append(f"\tammopershot {base['ammopershot']}")
        return out

    def emit_thing(self, num):
        d = self.ir.things.get(num, {})
        name = self.thing_display_name(num)
        base = self.base_thing(num)
        w = []
        alias = self.thing_alias(num)
        w.append(f'thing {num} "{name}"'
                 + (f"\t// {alias}" if alias and alias != name else ""))
        w.append("{")

        body = []
        for old, new in getattr(self, "reskins", {}).get(num, []):
            body.append(f"\treskin {old} to {new}")
        if self.complete:
            body.extend(self._complete_thing_props(d, base, num))
        else:
            for deh_key, prop, kind in THING_PROPS:
                if deh_key not in d:
                    continue
                v = d[deh_key]
                body.append(self._prop_line(prop, kind, v, d, base, num))

        # flags
        body.extend(self._flag_lines(d, base, num))

        # entry states
        if self.complete:
            label_entries = []
            for _f, label in THING_LABELS:
                start = self._entry_state("thing", num, label)
                if start:
                    label_entries.append((label, start))
        else:
            label_entries = [(label, d[f]) for f, label in THING_LABELS if f in d]
        for tgt in sorted(getattr(self, "pseudo_entries", {}).get(("thing", num), [])):
            label_entries.append((f"st{tgt}", tgt))
        state_lines, raw_assign = self.emit_states_block(("thing", num), label_entries)
        for label, target in raw_assign:
            if isinstance(target, tuple):
                body.append(f"\tstate {label} {target[1]}\t// alias of local label")
            elif target == 0:
                body.append(f"\tstate {label} 0\t// removed")
            else:
                note = self._pin_note(target)
                body.append(f"\tstate {label} {target}{note}")
        if state_lines:
            body.append("")
            body.append("\tstates")
            body.append("\t{")
            body.extend(state_lines)
            body.append("\t}")

        # unknown fields warning
        known = {k for k, _, _ in THING_PROPS} | {f for f, _ in THING_LABELS} | {"bits", "mbf21_bits", "id"}
        for k in d:
            if k not in known:
                body.append(f"\t// TODO: unhandled DEH field '{k}' = {d[k]}")
                self.warn(f"thing {num}: unhandled field {k}={d[k]}")

        w.extend(body)
        w.append("}")
        return w

    def _prop_line(self, prop, kind, v, d, base, num):
        if kind == "int":
            return f"\t{prop} {v}"
        if kind == "fixed16":
            if v % 65536 == 0:
                return f"\t{prop} {v // 65536}"
            return f"\t{prop} {self.fmt_fixed(v)}"
        if kind == "speed":
            flags = d.get("bits", base.get("flags", 0))
            if flags & 0x10000 and v % 65536 == 0 and abs(v) >= 65536:  # MISSILE
                return f"\t{prop} {v // 65536}"
            if flags & 0x10000 and v % 65536 != 0:
                return f"\t{prop} {self.fmt_fixed(v)}"
            return f"\t{prop} {v}"
        if kind == "sound":
            name = self.sound_name(v)
            if name is None:
                return f'\t{prop} ""\t// cleared (0) -- verify empty-string is accepted'
            return f'\t{prop} "{name}"'
        if kind == "thing":
            comment = ""
            if 1 <= v <= len(self.t.mobjinfo):
                comment = f"\t// {self.thing_display_name(v)}"
            return f"\t{prop} {v}{comment}"
        return f"\t{prop} {v}"

    def _flag_lines(self, d, base, num):
        lines = []
        doom_bits = d.get("bits")
        mbf21_bits = d.get("mbf21_bits")
        if doom_bits is not None:
            lines.append("")
            lines.append("\tclear flags")
            for bit_str, name in sorted(self.t.flags["doom"].items(), key=lambda kv: int(kv[0])):
                if doom_bits & int(bit_str):
                    lines.append(f"\t+{name}")
            # clear flags nukes BOTH sets; re-assert mbf21 flags
            eff_mbf21 = mbf21_bits if mbf21_bits is not None else MBF21_BASE_FLAGS.get(num, 0)
            for bit_str, name in sorted(self.t.flags["mbf21"].items(), key=lambda kv: int(kv[0])):
                if eff_mbf21 & int(bit_str):
                    lines.append(f"\t+{name}")
        elif mbf21_bits is not None:
            lines.append("")
            base_mbf = MBF21_BASE_FLAGS.get(num, 0)
            for bit_str, name in sorted(self.t.flags["mbf21"].items(), key=lambda kv: int(kv[0])):
                bit = int(bit_str)
                if (mbf21_bits & bit) and not (base_mbf & bit):
                    lines.append(f"\t+{name}")
                elif (base_mbf & bit) and not (mbf21_bits & bit):
                    lines.append(f"\t-{name}")
        return lines

    def base_thing_states(self, num):
        """All base states reachable from a base thing's default entry points."""
        base = self.base_thing(num)
        out = set()
        for field in ("spawnstate", "seestate", "painstate", "meleestate",
                      "missilestate", "deathstate", "xdeathstate", "raisestate"):
            cur = base.get(field, 0)
            steps = 0
            while cur and cur not in out and steps < 2000:
                out.add(cur)
                cur = self.base_state(cur)["next"]
                steps += 1
        return out

    def compute_reskins(self):
        """Map sprite renames onto per-thing reskin clauses for renames that
        would otherwise be lost on unmodified base states."""
        self.reskins = defaultdict(list)     # thing num -> [(old, new)]
        if not self.sprite_rename:
            return
        covered = set()
        for num in range(1, len(self.t.mobjinfo) + 1):
            owned = self.base_thing_states(num)
            needed = set()
            for s in owned:
                if s in self.modified:
                    continue           # re-rendered with the new name already
                spr = self.t.sprites[self.base_state(s)["sprite"]] \
                    if self.base_state(s)["sprite"] < len(self.t.sprites) else None
                if spr in self.sprite_rename:
                    needed.add(spr)
                    covered.add(s)
            for spr in sorted(needed):
                self.reskins[num].append((spr, self.sprite_rename[spr]))
        # warn about renamed sprites on base states owned by no thing
        for i in range(len(self.t.states)):
            if i in self.modified or i in covered:
                continue
            spr_idx = self.t.states[i]["sprite"]
            spr = self.t.sprites[spr_idx] if spr_idx < len(self.t.sprites) else None
            if spr in self.sprite_rename and i not in covered:
                # owned by weapons or unreferenced; only warn once per sprite
                pass
        weapon_like = {s for s in range(90)}   # weapon states live in 0..89
        for spr in self.sprite_rename:
            for i in weapon_like:
                b = self.t.states[i]
                if b["sprite"] < len(self.t.sprites) and \
                        self.t.sprites[b["sprite"]] == spr and i not in self.modified:
                    self.warn(f"sprite rename {spr}->{self.sprite_rename[spr]} "
                              f"touches base WEAPON state {i}; add a "
                              f"'weapon N reskin {spr} to {self.sprite_rename[spr]}' manually")
                    break

    def _pin_note(self, target):
        if target in self.pinned:
            return f"\t// pinned states below"
        if target not in self.modified:
            return f"\t// unmodified base state"
        return ""

    def emit_weapon(self, num):
        d = self.ir.weapons.get(num, {})
        name = self.weapon_display_name(num)
        alias = self.weapon_alias(num)
        w = [f'weapon {num} "{name}"'
             + (f"\t// {alias}" if alias and alias != name else ""), "{"]
        if self.complete:
            w.extend(self._complete_weapon_props(d, num))
        else:
            for deh_key, prop, kind in WEAPON_PROPS:
                if deh_key in d:
                    w.append(f"\t{prop} {d[deh_key]}")
        if "mbf21_bits" in d:
            for bit, fname in sorted(MBF21_WEAPON_FLAGS.items()):
                if d["mbf21_bits"] & bit:
                    w.append(f"\t+{fname}")
        if self.complete:
            label_entries = []
            for _f, label in WEAPON_LABELS:
                start = self._entry_state("weapon", num, label)
                if start:
                    label_entries.append((label, start))
        else:
            label_entries = [(label, d[f]) for f, label in WEAPON_LABELS if f in d]
        for tgt in sorted(getattr(self, "pseudo_entries", {}).get(("weapon", num), [])):
            label_entries.append((f"st{tgt}", tgt))
        state_lines, raw_assign = self.emit_states_block(("weapon", num), label_entries)
        for label, target in raw_assign:
            if isinstance(target, tuple):
                w.append(f"\tstate {label} {target[1]}")
            else:
                w.append(f"\tstate {label} {target}{self._pin_note(target) if target else ''}")
        if state_lines:
            w.append("")
            w.append("\tstates")
            w.append("\t{")
            w.extend(state_lines)
            w.append("\t}")
        known = {k for k, _, _ in WEAPON_PROPS} | {f for f, _ in WEAPON_LABELS} | {"mbf21_bits"}
        for k in d:
            if k not in known:
                w.append(f"\t// TODO: unhandled DEH weapon field '{k}' = {d[k]}")
        w.append("}")
        return w

    def _pinned_owner_comments(self, run):
        """Comment lines identifying who a pinned state run belongs to.

        Two cases:
        - the patch declares the owning thing/weapon, so DEH-side ownership
          analysis found it -> name it via `reached from`;
        - nothing in the patch declares an owner (a states-only patch), so fall
          back to the vanilla base tables to say which stock actor's states
          these actually are.
        """
        lines = []
        reasons = getattr(self, "engine_pin_reason", {})
        for s in run:
            if s in reasons:
                lines.append(f"// {reasons[s]}")
                break
        deh_owners = set()
        for s in run:
            deh_owners |= self.owners.get(s, set())
        if deh_owners:
            parts = []
            for kind, num in sorted(deh_owners):
                name = (self.thing_display_name(num) if kind == "thing"
                        else self.weapon_display_name(num))
                parts.append(f"{kind} {num} ({name})")
            lines.append("// reached from: " + ", ".join(parts))
            return lines

        # Orphan states: attribute them from the vanilla base tables.
        seen, ordered = set(), []
        for s in run:
            text, extra = self.base_owner_of(s)
            if text and text not in seen:
                seen.add(text)
                ordered.append((s, text, extra))
        if not ordered:
            lines.append("// not reachable from any known thing or weapon "
                         "(unused/free state)")
            return lines
        if len(ordered) == 1:
            _s, text, extra = ordered[0]
            suffix = f"; also used by {extra} other actor(s)" if extra else ""
            lines.append(f"// vanilla {text}{suffix}")
        else:
            lines.append("// vanilla states, by index:")
            for s, text, extra in ordered:
                suffix = f"; also used by {extra} other actor(s)" if extra else ""
                lines.append(f"//   {s}: {text}{suffix}")
        return lines

    def emit_pinned_blocks(self):
        """Group pinned states into maximal consecutive-index runs whose
        next-links are sequential, emit as `state fill N { ... }` blocks,
        single states as `state N { ... }`."""
        if not self.pinned:
            return []
        out = ["", "//" + "-" * 70,
               "// Pinned states: these must keep their original indices because",
               "// they are shared between things, referenced by index, or edits",
               "// to states of things the DEH never (re)declares.",
               "//" + "-" * 70]
        ctx = {"labels": {}}
        done = set()
        for s in sorted(self.pinned):
            if s in done:
                continue
            run = [s]
            cur = s
            while True:
                nxt = self.base_state(cur)["next"]
                if nxt == cur + 1 and nxt in self.pinned and nxt not in done \
                        and nxt not in run:
                    run.append(nxt)
                    cur = nxt
                else:
                    break
            done.update(run)
            head = "state fill %d" % s if len(run) > 1 else "state %d" % s
            out.append("")
            out.extend(self._pinned_owner_comments(run))
            out.append(head)
            out.append("{")
            i = 0
            while i < len(run):
                idx = run[i]
                r = [idx]
                j = i + 1
                while j < len(run):
                    a, b = self.base_state(run[j-1]), self.base_state(run[j])
                    if (a["next"] == run[j] and a["sprite"] == b["sprite"]
                            and a["tics"] == b["tics"] and a["bright"] == b["bright"]
                            and a["action"] == b["action"] and a["args"] == b["args"]
                            and a["mbfflags"] == b["mbfflags"]
                            and run[j] not in self.state_arg_refs):
                        r.append(run[j]); j += 1
                    else:
                        break
                letters = "".join(self.frame_letter(self.base_state(x)["frame"]) for x in r)
                line = self.render_state_line(idx, ctx, letters=letters)
                out.append(line.replace("\t\t", "\t", 1))
                i = j
            last = run[-1]
            st = self.base_state(last)
            nxt = st["next"]
            if nxt == last:
                out.append("\tstop" if st["tics"] < 0 else "\twait")
            elif nxt == 0:
                out.append("\tstop")
            else:
                note = "" if nxt in self.modified else "\t// -> base state"
                out.append(f"\tgoto {nxt}{note}")
            out.append("}")
        return out

    # ------------------------------------------------------------------
    # Top-level document
    # ------------------------------------------------------------------

    def _check_emitted_coverage(self, text):
        """Every numeric goto/state reference must land on something stable.

        Floating states get reallocated by DECOHack, so a reference by raw
        index is only safe if that index is pinned or is an untouched vanilla
        state. Anything else means a chain was dropped on the floor.
        """
        emitted_pins = {int(m) for m in re.findall(r"^state(?: fill)? (\d+)", text, re.M)}
        covered = set()
        for start in emitted_pins:
            cur = start
            for _ in range(4000):
                if cur in covered or not cur:
                    break
                covered.add(cur)
                nxt = self.base_state(cur)["next"]
                if nxt == cur or nxt not in self.pinned:
                    break
                cur = nxt
        for m in re.finditer(r"goto (\d+)", text):
            tgt = int(m.group(1))
            if tgt in covered or tgt not in self.modified:
                continue
            self.warn(f"goto {tgt} refers to a state that the patch modifies "
                      f"but that is not emitted at a fixed index -- its edits "
                      f"may be lost; please report this input")

    def emit(self):
        o = self.out
        o.append("#include <dsdhacked>")
        o.append("")
        o.append("/*")
        o.append("   Converted from DeHackEd by deh2decohack")
        o.append(f"   Source: Doom version = {self.ir.doom_version}, "
                 f"Patch format = {self.ir.patch_format}")
        o.append("   Target: DECOHack `dsdhacked` patch (MBF21 / dsda-doom)")
        o.append("*/")

        self.build_base_ownership()
        self.analyze()
        self.compute_reskins()

        # strings
        strings_out = dict(self.ir.strings)
        for old, new in self.ir.text_renames:
            if len(old) == 4 and len(new) == 4 and old.isupper():
                continue  # sprite rename, handled via resolution
            mnem = self.t.strings.get(old)
            if mnem:
                strings_out[mnem] = new
            else:
                self.warn(f"Text rename: no mnemonic found for source string "
                          f"{old[:40]!r}; add manually")
                o.append(f"// TODO: unmatched Text rename: {old[:60]!r} -> {new[:60]!r}")
        if strings_out:
            o.append("")
            o.append("strings")
            o.append("{")
            for k, v in strings_out.items():
                escaped = v.replace('"', '\\"')
                o.append(f'\t{k} "{escaped}"')
            o.append("}")

        # pars
        if self.ir.pars:
            o.append("")
            o.append("pars")
            o.append("{")
            for line in self.ir.pars:
                o.append(f"\t{line}")
            o.append("}")

        # misc
        if self.ir.misc:
            o.append("")
            o.append("misc")
            o.append("{")
            deh_to_deco = dict(MISC_PROPS)
            for k, v in self.ir.misc.items():
                prop = deh_to_deco.get(k)
                if prop:
                    o.append(f"\t{prop} {v}")
                else:
                    o.append(f"\t// TODO: unhandled Misc field '{k}' = {v}")
            o.append("}")

        # ammo
        for num in sorted(self.ir.ammo):
            d = self.ir.ammo[num]
            o.append("")
            o.append(f"ammo {num}")
            o.append("{")
            if "max_ammo" in d:
                o.append(f"\tmax {d['max_ammo']}")
            if "per_ammo" in d:
                o.append(f"\tpickup {d['per_ammo']}")
            o.append("}")

        # weapons / things
        if self.complete:
            touched = self.touched_owners()
            wnums = sorted(n for k, n in touched if k == "weapon")
            tnums = sorted(n for k, n in touched if k == "thing")
            o.append("")
            o.append("// Complete mode: each thing and weapon the patch affects is")
            o.append("// restated in full -- values the patch does not set are taken")
            o.append("// from Doom 2, the same overlay the patch itself performs.")
        else:
            wnums = sorted(self.ir.weapons)
            tnums = sorted(self.ir.things)
        for num in wnums:
            o.append("")
            o.extend(self.emit_weapon(num))
        for num in tnums:
            o.append("")
            o.extend(self.emit_thing(num))

        # reskin-only blocks for base things untouched by the DEH
        extra_reskins = [n for n in sorted(getattr(self, "reskins", {}))
                         if n not in self.ir.things and self.reskins[n]]
        if extra_reskins:
            o.append("")
            o.append("// Sprite renames carried by the original patch's Text/[SPRITES]")
            o.append("// blocks, applied to otherwise-untouched things via reskin:")
            for n in extra_reskins:
                clauses = " ".join(f"reskin {a} to {b}" for a, b in self.reskins[n])
                o.append(f'thing {n} {clauses}\t// {self.thing_display_name(n)}')

        # pinned state blocks
        o.extend(self.emit_pinned_blocks())

        # sound table edits ([SOUNDS] with numeric keys need no output --
        # names resolve inline; name->name renames were applied likewise)

        self._check_emitted_coverage("\n".join(o))

        if self.warnings:
            o.append("")
            o.append("//" + "=" * 70)
            o.append("// Converter warnings:")
            for wmsg in self.warnings:
                o.append("//   " + wmsg)
        return "\n".join(o) + "\n"


def convert(deh_path, tables=None, complete=False):
    from deh_ir import parse_deh
    ir = parse_deh(deh_path)
    t = tables or Tables()
    return Emitter(ir, t, complete=complete).emit()
